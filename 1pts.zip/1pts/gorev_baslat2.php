<?
@session_start();
include_once("Guvenlik.Filtre.php");
include_once("includes/extendsFPDFV1.class.inc.php");

//*****************************************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//
@require_once('includes/veritabani.php');


$whoInSQL = "select * from db_calisma_saatlari where end_time is null order by start_time DESC limit 0,1";
//echo $tablo;
$whoInResult= mysql_query($whoInSQL);
$workingMan = null;
if(@mysql_num_rows($whoInResult)>0){
	$workingMan = mysql_fetch_assoc($whoInResult);
}
$login_durum=mysql_real_escape_string($_GET['p']);  //Giri� se�enekleri
$login_durum_2=mysql_real_escape_string($_POST['p']);  //Giri� se�enekleri
$hata=mysql_real_escape_string($_POST['HID']); 

if(empty($login_durum)){
$login_durum="4";	
}


if($login_durum=="4"){
$tip="G�revli Giri�i";
$sql_ek="and yetki='4'";
	//Site Kullan�c�s�
}




/*$tablo = "select * from db_super_users where username='$user' and password='$sifre'  ";
$sorgu= mysql_query($tablo);
if (@mysql_num_rows($sorgu) > 0 ) {
header("Location: Home.php"); //e�er �nceden loginse direk y�nlendir 
}*/


$buton_gonder=$_POST['gonder'];  
$post_username=$_POST['username'];  //K.ad�
$post_password=$_POST['password'];  //�ire


if($buton_gonder){ //e�er butona t�klarsam
$tablo = "select * from db_super_users where username='$post_username' and password='$post_password' ".$sql_ek;
$theLastSql= "select * from db_calisma_saatlari where end_time is null ";
//echo $tablo;
$lastResult= mysql_query($theLastSql);
$lastUser = mysql_fetch_assoc($lastResult);
$sorgu= mysql_query($tablo);
	if (@mysql_num_rows($sorgu) > 0 ) {
		$kullaniciadi1 = @mysql_result($sorgu,0,"username");
		$ad = @mysql_result($sorgu,0,"ad");
		$ids = @mysql_result($sorgu,0,"id");
		$soyad = @mysql_result($sorgu,0,"soyad");
		if($_REQUEST['userId'] ){
                                        if( $lastUser['user_name']==$_POST['username'] )
                                        {
                                            $updateSQL = "update db_calisma_saatlari set end_time = NOW() where id={$_REQUEST['userId']}";
                                            //echo $tablo;
                                            //mysql_query($updateSQL);

                                            $getdateSQL = "select * from db_calisma_saatlari where id={$_REQUEST['userId']}";
                                            $result = mysql_query($getdateSQL);
                                            $findrecord = null;
                                            if(@mysql_num_rows($result)>0){
                                                    $findrecord = mysql_fetch_assoc($result);
                                            }

                                            if(!is_null( $findrecord ) ){
                                                    $_GET['is_short'] = 1;
                                                    $_GET['start'] = $findrecord['start_time'];
													$my_end_time=$tarih +" "+ $zaman;
                                                    $_GET['end'] = $my_end_time;
                                                    $_GET['ad'] = $ad;
                                                    $_GET['soyad'] = $soyad;
                                                    $_GET['odemenokta'] = $post_pointid;                                                    
                                                    $sqlQuery = "SELECT * FROM db_odemeler  WHERE id>0 AND tarihzaman  BETWEEN '{$findrecord['start_time']}' AND NOW() ORDER BY id";

                                                    $pdfFile = wsfWritePdf($sqlQuery,null,null,'p','F');
                                                                                            $pdfjavascript= "<script>  window.location = '{$pdfFile}'; </script>";
                                            }
                                        }
		}else{
				//mysql_query("INSERT INTO `db_calisma_saatlari` (`user_id` ,`user_name`,`start_time`)VALUES ( '{$ids}','{$kullaniciadi1}' , NOW())");
		}
                if(!isset($pdfjavascript)){
		@header("Location: gorev_baslat.php"); //e�er �nceden loginse direk y�nlendir 
                }
	
	}
	
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9" />
    <meta name="robots" content="noindex,nofollow">
    <link rel="stylesheet" href="stil.css" type="text/css">
    <?php echo $pdfjavascript;?>
    <title><? echo $ttt[1]; ?></title>
    <link href="stil.css" rel="stylesheet" type="text/css" />
    <script language="JavaScript" src="controls.js"></script>
    <script src="ajax.js" type="text/javascript" language="JavaScript"></script>
  <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
  <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
  </head>
<body>
<?
if (isset($_SESSION['birincil'])) header("home.php");
else{
?>
<h1><? echo $ttt[1]; ?></h1>
<form name="giris" action="" method="POST">
  <table border="0" align="center" class="ictablo" width="400px;" style="margin-top:200px;">
<caption><h1><?=$tip?></h1></caption>    <tr>
      <th colspan="3" align="center">
      <input type="hidden" name="p" value="<?=@$_GET['p']?>">
      </th>
    </tr>
    <tr>
      <TD colspan="2" align="center" style="color:red"><?=@$ikaz?></td>
    </tr>
	<?php
	$btnValue = 'Ba�lat';
	if(!is_null($workingMan)){
	$btnValue = 'RAPOR';
		?>
<tr>
	<td class="formleft">g�revli Ad� :</td>
	<td>
	<?php echo $workingMan['user_name'];?>
	</td>
</tr>
	<input type="hidden" value="<?php echo $workingMan['id'];?>" name="userId" />
		<?php
	}
	?>
    <tr>
      <td class="formleft">Kullan�c� Ad� :</td>
      <td><span id="sprytextfield1">
        <input name="username"  type="text" />
      <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td class="formleft">�ifre :</td>
       <td><span id="sprytextfield2">
       <input name="password" type="password" value="">
       <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td colspan="2" align="center">
        <label></label></td>
    </tr>
  
    <tr>
      <td align="center" colspan="3"><input name="gonder" type="submit" class=button id="gonder"  value="<?php echo $btnValue?>" /></td>
    </tr>

<tr>
      <td align="center" colspan="3">   
		  <div>
			  <a href="index.php">Giri�e D�n</a>
		  </div>
	  </td>
    </tr>
  </table>
  </form>
<? 
}
?>
  <script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
//-->
  </script>
</body>
</html>
