<?
@session_start();
include_once("Guvenlik.Filtre.php");

function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}
//*****************************************//
//**********PCC ELEKTRON�K*****************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}
$islem=trim(mysql_real_escape_string($_GET['Islem']));

$AUID=trim(mysql_real_escape_string($_GET['AUID']));
$AUID2=trim(mysql_real_escape_string($_POST['AUID']));
$arac_bilgi=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE id='$AUID' or id='$AUID2'"));
$sahipid=$arac_bilgi["kullaniciid"];
$sahibi_kim_ki=@mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='$sahipid'"));

$ekle=mysql_real_escape_string($_POST['ekle']);
$ekle2=mysql_real_escape_string($_POST['ekle2']);

$a1=trim(mysql_real_escape_string(strtoupper($_POST['a1'])));
$a1 = str_replace(" ","",$a1);
$a2=trim(mysql_real_escape_string($_POST['a2']));
$a3=trim(mysql_real_escape_string($_POST['a3']));
$a4=trim(mysql_real_escape_string($_POST['a4']));
$a5=trim(mysql_real_escape_string($_POST['a5']));
$a6=trim(mysql_real_escape_string($_POST['a6']));
$a10=trim(mysql_real_escape_string($_POST['a10']));

if($_GET['Durum']=="Duzenle"){
    $tipID = $_GET['tipID'];
    $query = "SELECT * from db_aractipleri WHERE tipID=".$tipID;
    $result = mysql_query($query);
    $num_results = mysql_num_rows($result);
    if ($num_results)
    {
        $tipAdi = mysql_result($result,0,"tipAdi");
    }

}

if($ekle=="Guncelle"){
    $tipID = $_POST['tipID'];
    $tipAdi = $_POST['tipAdi'];
    $query = "UPDATE db_aractipleri SET tipAdi = '".$tipAdi."' WHERE tipID=".$tipID;
    $result = mysql_query($query);
	
}

if($_GET['Durum']=="Sil")
{
    $tipID = $_GET['tipID'];
    $query = "DELETE from db_aractipleri WHERE tipID=".$tipID;
    $result = mysql_query($query);
    
@header("Location: Aractipi.Arama.php");
}
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>&lt;? echo $ttt[1]; ?&gt;</TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
    <div align="center"><span class="solmenu"><?
	if($sonucum=="YetkiDisiAlan2"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Bu plaka �nceden kay�t edilmi�!<br>";}
    if($sonucum=="Ok"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ara� Ba�ar�yla G�ncellendi!<br>";}
    if($sonucum=="cOk"){echo "<img src='images/icons/accept.png' width='16' height='16'> Abonelik S�resi Ba�ar�yla Yenilendi!<br>";}

	?>
    </span></div>
      <FORM method=post name=misafirtanimla action=Aractipi.Guncelle.php>
      <INPUT type="hidden" name="ekle" value="duzenle">
       <INPUT type="hidden" name="tipID" value="<? echo $tipID; ?>">
        <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH colSpan=2>Ara� Tipi G�ncelle</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD align=right>Ara� Tipi: </TD>
              <TD><input name=tipAdi value="<? echo  $tipAdi; ?>" class=text_input id="a6"></TD>
            </TR>
            <TR>
              <TD width="40%" align=right></TD>
              <TD><INPUT class=button value=Guncelle type=submit name=ekle>
                &nbsp; </TD>
            </TR>
          </TBODY>
        </TABLE>
      </FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
//-->
</script>
</BODY></HTML>