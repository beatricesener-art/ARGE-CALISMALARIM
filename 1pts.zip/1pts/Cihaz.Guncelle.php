<?
@session_start();
include_once("Guvenlik.Filtre.php");


//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');


$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];

$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='2'"; //sistem y�neticisi
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}


$KID=trim(mysql_real_escape_string($_GET['KID']));
$KID2=trim(mysql_real_escape_string($_POST['KID']));
$uu=mysql_fetch_array(mysql_query("SELECT * FROM db_cihazlar WHERE id='$KID'"));

$ekle=mysql_real_escape_string($_POST['ekle']);
$a1=htmlspecialchars(trim(mysql_real_escape_string($_POST['a1'])));
$a2=htmlspecialchars(trim(mysql_real_escape_string($_POST['a2'])));
$a3=htmlspecialchars(trim(mysql_real_escape_string($_POST['a3'])));
$a4=htmlspecialchars(trim(mysql_real_escape_string($_POST['a4'])));
$a5=htmlspecialchars(trim(mysql_real_escape_string($_POST['a5'])));
$a6=htmlspecialchars(trim(mysql_real_escape_string($_POST['a6'])));
$a8=htmlspecialchars(trim(mysql_real_escape_string($_POST['a8'])));
$a9=htmlspecialchars(trim(mysql_real_escape_string($_POST['a9'])));
$a10=htmlspecialchars(trim(mysql_real_escape_string($_POST['a10'])));
$a11=htmlspecialchars(trim(mysql_real_escape_string($_POST['a11'])));




if($ekle="Ekle"){
	
	if(($a1>' ')&&($a2>' ')&&($a3>' ')&&($a5>' ')&&($a6>' ')){
	$ekle="UPDATE `db_cihazlar` SET `kamera_ID` = '$a1',
`sistem_ID` = '$a2',
`role_ID` = '$a3',
`kapi_ID` = '$a4',
`cihaz_Yon` = '$a5',
`cihaz_Durum` = '$a6',`cikisizin` = '$a7',`camgrup` = '$a8',`cihaztipi` = '$a9', `ipAdres` = '$a10' , `port` = '$a11' WHERE `db_cihazlar`.`id` ='$KID2' LIMIT 1 ";
	mysql_query($ekle)or die(mysql_error());
	$uyari="Kamera G�ncellendi!";
	@header("Location: Cihaz.Guncelle.php?KID=$KID2&Durum=Ok");
	}//if bo� de�ilse
}//if ekle ise
$sonucum=$_GET['Durum'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css">
<LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
    <div align="center"><span class="solmenu"><?
	if($sonucum=="KartEklendi"){echo "<img src='images/icons/accept.png' width='16' height='16'> Kart Eklendi!<br>";}
    if($sonucum=="BuKartnodaBaskaKartMevcut"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Bu Kart �nceden Eklenmi�!<br>";}
	if($sonucum=="Ok"){echo "<img src='images/icons/accept.png' width='16' height='16'> Bilgiler G�ncellendi!<br>";}
	if($sonucum=="NoEdit"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Kendi Hesab�n�z �zerinde Durum De�i�tirme ��lemi Yapamazs�n�z!<br>";}
	if($uyari){echo "<img src='images/icons/exclamation.png' width='16' height='16'> $uyari!<br>";}
	?>
    </span></div>
      <FORM method=post name=misafirtanimla action=Cihaz.Guncelle.php>
      <INPUT 
      type="hidden" name="ekle" value="duzenle">
       <INPUT 
      type="hidden" name="KID" value="<? echo $KID; ?>">
        <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH colSpan=2>Kamera Ekle</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>KameraNo:</TD>
              <TD><span id="sprytextfield1">
                <input name=a1 value="<? echo $uu[1]; ?>" class=text_input id="a1">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Sistem ID:</TD>
              <TD><SELECT id=a2  name=a2>
              <?
			$sorgula=mysql_query("SELECT * FROM db_sistemler ORDER BY id");
			while($sistem=mysql_fetch_array($sorgula)){
			  ?>
                <option value="<? echo $sistem[1]; ?>" <?
				$aa=$uu[2];
				$bb=$sistem[1];
				if($aa==$bb){ echo "selected='selected'";} ?>><? echo $sistem[1];  ?></option>
                <? } //while sorgul ?>
              </SELECT></TD>
            </TR>
            <TR>
              <TD align=right>Kap� Grubu: </TD>
              <TD><SELECT id=a8  name=a8>
                <?
			$sorgula=mysql_query("SELECT * FROM db_camgrup ORDER BY id");
			while($sistem=mysql_fetch_array($sorgula)){
			  ?>
                <option value="<? echo $sistem[0]; ?>" <?
				$aa=$uu[8];
				$bb=$sistem[0];
				if($aa==$bb){ echo "selected='selected'";} ?>><? echo $sistem[1];  ?></option>
                <? } //while sorgul ?>
              </SELECT></TD>
            </TR>
            <TR>
              <TD align=right>R�le ID:</TD>
              <TD><span id="sprytextfield2">
                <input name=a3 value="<? echo $uu[3]; ?>" class=text_input id="a3">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
			<TR>
              <TD align=right>Cihaz SeriNo:</TD>
              <TD><span id="sprytextfield3">
                <input name=a4 value="<? echo $uu[4]; ?>" class=text_input id="a4">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
			<TR>
              <TD align=right>Cihaz IP Adres:</TD>
              <TD><span id="sprytextfield5">
                <input name=a10 value="<? echo $uu[11]; ?>" class=text_input id="a10">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
			<TR>
              <TD align=right>Cihaz Port:</TD>
              <TD><span id="sprytextfield6">
                <input name=a11 value="<? echo $uu[12]; ?>" class=text_input id="a11">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD align=right>Cihaz Y�n:</TD>
              <TD><SELECT id=a5 onchange=misafirGoster() name=a5>
                <option value="g" <? if($uu[5]=="g"){ echo "selected='selected'";} ?>>��k��</option>
                <option value="c" <? if($uu[5]=="c"){ echo "selected='selected'";} ?>>Giri�</option>
              </SELECT></TD>
            </TR>
            <TR>
              <TD align=right>Cihaz Durum:</TD>
              <TD><SELECT id=a6 onchange=misafirGoster() name=a6>
                <option value="a"  <? if($uu[6]=="a"){ echo "selected='selected'";} ?>>Aktif</option>
                <option value="p"  <? if($uu[6]=="p"){ echo "selected='selected'";} ?>>Pasif</option>
                <option value="f"  <? if($uu[6]=="f"){ echo "selected='selected'";} ?>>Silinmi�</option>
              </SELECT></TD>
            </TR>
            <TR>
              <TD align=right>Her Durumda ��k���na �zin Ver:</TD>
              <TD><label>
                <input type="checkbox" name="a7" <? if($uu[7]==1){ echo "checked";} ?>  value="1" id="a7">
              </label></TD>
            </TR>
			<TR>
              <TD align=right>Cihaz Tipi:</TD>
              <TD><span id="sprytextfield4">
                <input name=a9 value="<? echo $uu[10]; ?>" class=text_input id="a9">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD width="40%" align=right></TD>
              <TD><INPUT class=button value=Guncelle type=submit name=ekle>
                &nbsp; </TD>
            </TR>
          </TBODY>
        </TABLE>
        <H2>Varolan Cihazlar</H2>
        <TABLE class=ictablo width=571>
          <TBODY>
            <TR>
              <TH width="40">#ID</TH>
              <TH width="50">KamNo</TH>
              <TH width="58">Kap�</TH>
              <TH width="58">Sistem ID</TH>
              <TH width="30">R�leID</TH>
			  <TH width="50">SeriNo</TH>
			  <TH width="50">IP</TH>
              <TH width="40">Y&ouml;n</TH>
              <TH width="40">Durum</TH>
			  <TH width="40">ChzTipi</TH>
              <TH width="100">��lemler</TH>
            </TR>
            
<?
$tablo2="SELECT * FROM db_cihazlar order by id";
$sorgu2=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 
?>
			
		
            <TR>
              <TD align=middle>#<? echo $xxd[0]; ?></TD>
              <TD align=middle><? echo $xxd[1]; ?></TD>
              <TD align=middle><? 
			  $khjkhjk=$xxd[8];
			  $hh=mysql_fetch_array(mysql_query("SELECT * FROM db_camgrup WHERE id='$khjkhjk'"));
			  echo $hh[1];
			  
			  ?></TD>
              <TD align=middle><? 
			  echo $xxd[2];
			 
			  ?></TD>
              <TD align=middle><? echo $xxd[3]; ?></TD>
			  <TD align=middle><? echo $xxd[4]; ?></TD>
			  <TD align=middle><? echo $xxd[11]; ?></TD>
              <TD align=middle><? if($xxd[5]=="c"){echo "Giri�";}else{ echo "��k��"; } ?></TD>
              <TD align=middle><? if($xxd[6]=="a"){echo "Aktif";};if($xxd[6]=="p"){echo "Pasif";};if($xxd[6]=="f"){echo "Silinmi�";} ?></TD>
			  <TD align=middle><? echo $xxd[10]; ?></TD>
              <TD align=middle>
              <INPUT value="<? echo $xxd[0]; ?>" type=hidden name="sistem">
                
                <input class="button small" name="Duzenle" value="D�zenle" onClick="javascript:document.location.href='Cihaz.Guncelle.php?KID=<? echo $xxd['id'] ?>'" type="button" id="Sil" />
                 <input class="button small" name="Sil" value="Sil" onClick="JavaScript:if (confirm('Silmek istedi�inizden emin misin?')) javascript:document.location.href='Cihaz.Duzenle.php?KID=<? echo $xxd['id'] ?>&Olay=Sil'" type="button" id="Sil" />                </TD>
            </TR>
            
<? 
} //sistemler son fetch
?>
          </TBODY>
        </TABLE>
        <p>&nbsp;</p>
      </FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
//-->
</script>
</BODY></HTML>