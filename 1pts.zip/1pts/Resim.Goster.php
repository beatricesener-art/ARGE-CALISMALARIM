<?php
ini_set("display_errors","off");

//*****************************************//
//**********PCC ELEKTRONIK*****************//
//********Plaka Tanima Sistemi*************//
//************Resim ResizePro**************//
//*****************************************//
ini_set("upload_max_filesize", "200M");
header ("Content-type: image/jpeg");
$img = $_GET['img'];

//$img="http://84.16.252.128/azul.jpg";
//$img="E:/4738_83958208546_667528546_1944243_6743423_n__800x600_.jpg";

/*$fp = fopen($img, "rb+");
$imageFile = fread ($fp, 20000000);
fclose($fp);

echo $imageFile;
echo "marul";
*/
$img2="images/no-pic.png";
$img3="images/no-pic.png";
$percent = $_GET['percent'];
//$percent= 50;
$constrain = $_GET['constrain'];
$w = $_GET['w'];
$h = $_GET['h'];
$SourceFile = $img;
$DestinationFile = 'images/watermark.gif';


///////////////////////////////////

// get image size of img
$x = @getimagesize($img);
// image width
$sw = $x[0];
// image height
$sh = $x[1];

if ($percent > 0) {
	// calculate resized height and width if percent is defined
	$percent = $percent * 0.01;
	$w = $sw * $percent;
	$h = $sh * $percent;
} else {
	if (isset ($w) AND !isset ($h)) {
		// autocompute height if only width is set
		$h = (100 / ($sw / $w)) * .01;
		$h = @round ($sh * $h);
	} elseif (isset ($h) AND !isset ($w)) {
		// autocompute width if only height is set
		$w = (100 / ($sh / $h)) * .01;
		$w = @round ($sw * $w);
	} elseif (isset ($h) AND isset ($w) AND isset ($constrain)) {
		// get the smaller resulting image dimension if both height
		// and width are set and $constrain is also set
		$hx = (100 / ($sw / $w)) * .01;
		$hx = @round ($sh * $hx);

		$wx = (100 / ($sh / $h)) * .01;
		$wx = @round ($sw * $wx);

		if ($hx < $h) {
			$h = (100 / ($sw / $w)) * .01;
			$h = @round ($sh * $h);
		} else {
			$w = (100 / ($sh / $h)) * .01;
			$w = @round ($sw * $w);
		}
	}
}

$watermark = imagecreatefromgif('images/watermark.gif');  
$watermark_width = imagesx($watermark);  
$watermark_height = imagesy($watermark);  
$im = imagecreatetruecolor($watermark_width, $watermark_height); 
$dest_x = $w - $watermark_width - 5;  
$dest_y = $h - $watermark_height - 2;  
$im = @ImageCreateFromJPEG ($img) or // Read JPEG Image
$im = @ImageCreateFromPNG ($img) or // or PNG Image
$im = @ImageCreateFromGIF ($img) or // or GIF Image
$im = false; // If image is not JPEG, PNG, or GIF

if (!$im) {
	// We get errors from PHP's ImageCreate functions...
	// So let's echo back the contents of the actual image.
	readfile($img)or die(readfile($img3));
} else {
	// Create the resized image destination
	$thumb = @ImageCreateTrueColor ($w, $h);
	// Copy from image source, resize it, and paste to image destination
	@ImageCopyResampled ($thumb, $im, 0, 0, 0, 0, $w, $h, $sw, $sh);
	if($w>200||$h>200){
	imagecopymerge($thumb, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 100);  
	}
	// Output resized image
	@ImageJPEG ($thumb);
	//imagejpeg($image);  
    @imagedestroy($thumb);  
    @imagedestroy($watermark);
	@imagedestroy($im);
	
}
?>
