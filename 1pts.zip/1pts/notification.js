function check(){
   		 if ($("#notification").is(":hidden")){
	   		$.get("Real.Arac.Kontrol.php?checkNum=2", function(data){
				if(data!="0"){
				 	$("#notificationIn").load("Real.Arac.Kontrol.php");
				 	$("#notification").slideDown("slow");
				}
			});
		}
		 window.setTimeout(function() {check();}, 2000);
		 window.setTimeout(function() {$("#notification").hide();}, 2000);
	}
	
$(document).ready(function(){

	$("#notification").hide();
	
	
	$("#notificationClose").click(function () {
    	$("#notification").hide();
    });
    
    window.setTimeout(function() {
		check();
	}, 1000);
   
    
});
