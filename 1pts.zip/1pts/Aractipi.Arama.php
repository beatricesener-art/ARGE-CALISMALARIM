<?
include_once("includes/Sayfalama.Fonk.php");
include_once("Guvenlik.Filtre.php");


//*****************************************//
//**********PCC ELEKTRON�K*****************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//
require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];

$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='4' or yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$KID=trim(mysql_real_escape_string($_GET['KID']));
$KID2=trim(mysql_real_escape_string($_POST['KID']));


$islem=trim(mysql_real_escape_string($_GET['islem']));
$aractipadi=trim(mysql_real_escape_string($_GET['aractipadi']));
$a4=trim(mysql_real_escape_string($_GET['a4']));
$a5=trim(mysql_real_escape_string($_GET['a5']));
$a6=trim(mysql_real_escape_string($_GET['a6']));
$a7=trim(mysql_real_escape_string($_GET['a7']));
$a8=trim(mysql_real_escape_string($_GET['a8']));
$a9=trim(mysql_real_escape_string($_GET['a9']));//Grupname bas�yor
$a10=trim(mysql_real_escape_string($_GET['a10']));
$a11=trim(mysql_real_escape_string($_GET['a11']));
$a12=trim(mysql_real_escape_string($_GET['a12']));
$a13=trim(mysql_real_escape_string($_GET['a13']));
$a14=trim(mysql_real_escape_string($_GET['a14']));

if($_GET['Temizle']=="Temizle"){

//@header("Location: Gorevli.Arac.Arama.php?Temizlendi");
}else if ($islem=="db_ekle")
{
    $query = "insert into db_aractipleri values ( NULL, '$aractipadi')";
    $result = mysql_query($query);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>Ara� Tipi D�zenleme</TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>

<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
		<script src="jquery.js" language="JavaScript" type="text/javascript"></script>

<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>

<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
	<style>

		#notification{
	position:absolute;
	bottom:0%;
	right:2%;
	height:122px;
	width:200px;
	border:1px solid black;
	border-bottom:0px;
	background: url('images/pts_solback.jpg') repeat-y;

		}
		#notificationClose{
			font-size:11px;
			cursor:pointer;
			width:100%;
			border-bottom:1px solid black;
		}
		#notificationIn{
			padding:10px;
			font-size:11px;
			
		}
	</style>
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
      <FORM method=get name=misafirtanimla action=Aractipi.Arama.php >
      <INPUT type="hidden" name="islem" value="db_ekle">
        <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH colSpan=2> Ara� Tipi Ekleme</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Ara� Tipi Ad�:</TD>
              <TD><INPUT name=aractipadi value="" class=text_input id="a1"></TD>
            </TR>
            <TR>
              <TD width="40%" align=right></TD>
              <TD><INPUT class=button value=Ekle type=submit name=Ekle> &nbsp; <INPUT class=button value=Temizle type=submit name=Temizle id="Temizle"></TD>
            </TR>
          </TBODY>
        </TABLE>
        <H2>Bulunan Ara� Tipleri</H2>
        <TABLE class=ictablo width=572>
          <TBODY>
            <TR>
              <TH width="29" height="31">#ID</TH>
              <TH width="87" colspan="2">Ara� Ad�</TH>
            </TR>
      <TR>
             
             <? 
                $query = "select * from db_aractipleri";
                $result = mysql_query($query);
                $num_results = mysql_num_rows($result);
                for ($i=0;$i<$num_results;$i++)
                { 
                    $tipID = mysql_result($result,$i,"tipID");
                    $tipAdi = mysql_result($result,$i,"tipAdi");
                ?>
            
            <TR>
              <TD height="33" align=middle>#<? echo($tipID); ?></TD>
              <TD align=middle style="width: 304px"><? echo($tipAdi); ?></TD>
                 
              <TD align=middle>
              
              &nbsp;<input class="button small" name="Duzenle" value="D�zenle" onClick="javascript:document.location.href='Aractipi.Guncelle.php?tipID=<? echo $tipID ?>&Durum=Duzenle'" type="button" id="Sil2" />
                  <input class="button small" name="Sil" value="Sil" onClick="JavaScript:if (confirm('<? echo $tipAdi ?> Ara� Tipini \nSilmek istedi�inizden emin misin?')) javascript:document.location.href='Aractipi.Guncelle.php?tipID=<? echo $tipID ?>&Durum=Sil'" type="button" id="Sil" />
              </TD>
            </TR>
            
            <? } ?>
          </TBODY>
        </TABLE>

<br>
<div class="page-navigation clearfix">
<div class="wp-pagenavi">
  <div align="center">
  </div>
</div>
</div>
      </FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>

<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "integer", {isRequired:false, validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "time", {isRequired:false, validateOn:["change"], format:"HH:mm:ss"});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "time", {isRequired:false, validateOn:["change"], format:"HH:mm:ss"});
//-->
</script>
		
</BODY></HTML>
