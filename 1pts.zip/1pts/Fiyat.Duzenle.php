<?
@session_start();
include_once("Guvenlik.Filtre.php");


//*****************************************//
//**********PCC ELEKTRON�K*****************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$ekle=mysql_real_escape_string($_POST['ekle']);
$olay=mysql_real_escape_string($_GET['Olay']);
$SID2=mysql_real_escape_string($_GET['SID']);

$sistemadi=htmlspecialchars(trim(mysql_real_escape_string($_POST['sistemadi'])));
$sistemparola=htmlspecialchars(trim(mysql_real_escape_string($_POST['sistemparola'])));
$sistemparola2=$_POST['sistemparola2'];
$sistemparola3=$_POST['sistemli_artis'];
$sistemparola4=$_POST['sistemli_artis2'];
$sistemparola5=$_POST['sistemparola3'];



if($olay=="Sil"){
	

mysql_query("DELETE FROM db_fiyatlar WHERE id='$SID2'")or die(mysql_error());;
	
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$SID2 Numaral� Fiyat Bilgisi Silindi', NOW(),'$user')");
	
}

if($ekle=="Ekle"){
    $tipID = $_POST['tipID'];
	
	if(($sistemadi>' ')&&($sistemparola>' ')){
	$ekle="INSERT INTO `db_fiyatlar` (
`id` ,
`baslangic` ,
`bitis` ,
`ucret`,
`sistemli`,
`tipID`,
`birimzaman`,
`carpan`
)
VALUES (
NULL , '$sistemadi', '$sistemparola', '$sistemparola2', '$sistemparola3',  '$tipID' , '$sistemparola4', '$sistemparola5'
)";

	mysql_query($ekle)or die(mysql_error());

	@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$sistemparola Ad�nda bir fiyat bilgisi olu�turuldu', NOW(),'$user')");
	$uyari="Fiyat Bilgisi Eklendi!";
	}//if bo� de�ilse
}//if ekle ise

?>


<? 
$query = "select * from db_aractipleri";
$result = mysql_query($query);
$num_results = mysql_num_rows($result);
?>
                
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
      <FORM method=post name=misafirtanimla action=Fiyat.Duzenle.php>
      <INPUT 
      type="hidden" name="ekle" value="duzenle">
        <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH colSpan=2>Fiyat Bilgisi Ekle</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Ara� Tipi :</TD>
              <TD><span id="sprytextfield0">
                <SELECT id=tipIDlist  name="tipID">
                <?
                for ($i=0;$i<$num_results;$i++)
                { 
                    $tipID = mysql_result($result,$i,"tipID");
                    $tipAdi = mysql_result($result,$i,"tipAdi");
                ?>
                <option value=<? echo($tipID) ?>><? echo($tipAdi); ?></option>
                <?
                }?>
                </SELECT>
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span>
            </TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Ba�lang�� S�resi (Dakika) :</TD>
              <TD><span id="sprytextfield1">
                <input name=sistemadi class=text_input id="sistemadi">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Biti� S�resi (Dakika)  :</TD>
              <TD><span id="sprytextfield2">
                <input name=sistemparola class=text_input id="sistemparola">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD align=right>�cret : </TD>
              <TD><input name=sistemparola2 class=text_input id="sistemparola2"> </TD>
            </TR>
            <TR>
              <TD align=right>�arpan: </TD>
              <TD><input name=sistemparola3 class=text_input id="sistemparola3" disabled></TD>
            </TR>
            <TR>
              <TD align=right>Bu Aral�kta Sistemli Fiyatland�r:</TD>
              <TD>
                                           <script>
function Secimyap(secim)
{
 
if(secim == 'e')
{
	document.getElementById("sistemparola3").disabled=false;
}else{
	document.getElementById("sistemparola3").disabled=true;

}
}
</script>
              <SELECT id=a5  name="sistemli_artis" onChange="Secimyap(this.value)">
                <option value="h" <? if($uu[5]=="h"){ echo "selected='selected'";} ?>>Hay�r</option>
                <option value="e" <? if($uu[5]=="e"){ echo "selected='selected'";} ?>>Evet</option>
              </SELECT></TD>
            </TR>
            <TR>
              <TD align=right>Birim Zaman: </TD>
              <TD><SELECT id=sistemli_artis  name="sistemli_artis2">
                <option value="d" <? if($tt[8]=="d"){ echo "selected='selected'";} ?>>Dakika</option>
                <option value="g" <? if($tt[8]=="g"){ echo "selected='selected'";} ?>>G�n</option>
              </SELECT></TD>
            </TR>
            <TR>
              <TD width="40%" align=right></TD>
              <TD><INPUT class=button value=Ekle type=submit name=ekle>
                &nbsp; </TD>
            </TR>
          </TBODY>
        </TABLE>
        <H2>Fiyat Bilgileri</H2>
        <table class=ictablo width=569>
          <tbody>
            <tr>
              <th width="24">#ID</th>
              <th width="70">Ara� Tipi</th>
              <th width="68">Ba�lang��</th>
              <th width="70">Biti�</th>
              <th width="60">�cret (TL)</th>
              <th width="70">Birim</th>
              <th width="37">�arpan</th>
              <th width="39">Sistem</th>
              <th width="114">��lemler</th>
            </tr>
            <?
$tablo2="SELECT * FROM db_fiyatlar order by baslangic";
$sorgu2=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 
    $query2 = "SELECT * from db_aractipleri WHERE tipID=".$xxd[7];
    $result2 = mysql_query($query2);
    $num_results = mysql_num_rows($result2);
    if ($num_results)
    {
        $tipAdi2 = mysql_result($result2,0,"tipAdi");
    }else $tipAdi2 = "";
?>
            <tr>
              <td><div align="center"><? echo $xxd[0]; ?></div></td>
              <td><div align="center"><? echo $tipAdi2; ?></div></td>
              <td><div align="center"><? echo $xxd[1]; ?></div></td>
              <td><div align="center"><? echo $xxd[2]; ?></div></td>
              <td><div align="center"><? echo $xxd[3]." TL"; ?></div></td>
              <td align=middle><div align="center">
                  <? if($xxd[8]=="g"){echo "G�n";}else{echo"Dakika";}; ?>
              </div></td>
              <td align=middle><div align="center"><? echo $xxd[9];?></div></td>
              <td align=middle><div align="center">
                  <? if($xxd[4]=='e'){echo '<img src="images/icons/tick.png" width="16" height="16">';}else{echo '<img src="images/icons/exclamation.png" width="16" height="16">';} ?>
              </div></td>
              <td align=middle><input value="<? echo $xxd[0]; ?>" type=hidden name="sistem">
                  <input class="button small" name="Duzenle" value="D�zenle" onClick="javascript:document.location.href='Fiyat.Guncelle.php?SID=<? echo $xxd['id'] ?>'" type="button" id="Sil" />
                  <input class="button small" name="Sil" value="Sil" onClick="JavaScript:if (confirm('Silmek istedi�inizden emin misin?')) javascript:document.location.href='Fiyat.Duzenle.php?&SID=<? echo $xxd['id'] ?>&Olay=Sil'" type="button" id="Sil2" />
              </td>
            </tr>
            <? 
} //sistemler son fetch
?>
          </tbody>
        </table>
        <p>&nbsp;</p>
      </FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
//-->
</script>
</BODY></HTML>
