<?
@session_start();
include_once("Guvenlik.Filtre.php");

include ("fpdf/fpdf.php"); // fpdf.php dosyas�n�n yerine ba�l� 
$pdf = new FPDF();  

function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}


//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];

$tablo = "select * from db_super_users where username='$user' and password='$sifre' and (yetki='1' or yetki='4' or yetki='3') "; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}
$islem=trim(mysql_real_escape_string($_GET['Islem']));

$AUID=trim(mysql_real_escape_string($_GET['AUID']));
$AUID2=trim(mysql_real_escape_string($_POST['AUID']));
$arac_bilgi=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE id='$AUID' or id='$AUID2'"));
$sahipid=$arac_bilgi["kullaniciid"];
$sahibi_kim_ki=@mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='$sahipid'"));

$ekle=mysql_real_escape_string($_POST['ekle']);
$ekle2=mysql_real_escape_string($_POST['ekle2']);

$a1=trim(mysql_real_escape_string(strtoupper($_POST['a1'])));
$a1 = str_replace(" ","",$a1);
$a2=trim(mysql_real_escape_string($_POST['a2']));
$a3=trim(mysql_real_escape_string($_POST['a3']));
$a4=trim(mysql_real_escape_string($_POST['a4']));
$a5=trim(mysql_real_escape_string($_POST['a5']));
$a6=trim(mysql_real_escape_string($_POST['a6']));
$a7=trim(mysql_real_escape_string($_POST['a7']));
$a8=trim(mysql_real_escape_string($_POST['a8']));
$a10=trim(mysql_real_escape_string($_POST['a10']));

if($a7=="on") $a7=1;
else $a7=0;

$toplam_ucretim=0;
if($ekle2=="Uzat"){
 		###########UCRET �IKAR###################
		$birim_arac_ucreti=mysql_fetch_array(mysql_query("SELECT * FROM db_abonelikturleri WHERE id='$a2'"));
	    $a2_2=$birim_arac_ucreti[2];
	    $birim_ucretim=$birim_arac_ucreti[3]; //TL cinsinden fiyat d�ner
 		$toplam_ucretim=$toplam_ucretim+$birim_ucretim;
   		#########################################

		 $abonelik_bitisi2= $arac_bilgi["abonelikbitis"];
		 $ekle_sorgu2= "SELECT TIMEDIFF('$abonelik_bitisi2','$tarih $zaman')";
		 $SQL_tarih_ekle2=mysql_fetch_array(mysql_query($ekle_sorgu2));
		 $cikan_saat=(int)$SQL_tarih_ekle2[0];
		 $cikan_saat;
		 if($cikan_saat<0)  ##abonelik s�resi bitmi�
		 {
		 $x=1;
		 $ekle_sorgu3="SELECT ADDDATE( '$tarih $zaman', INTERVAL ".$a2_2." DAY )";
		 $SQL_tarih_ekle3=mysql_fetch_array(mysql_query($ekle_sorgu3));
		 $cikan_gun3=$SQL_tarih_ekle3[0];
		 mysql_query("UPDATE `db_araclar` SET `abonelikbitis` = '$cikan_gun3' ,UID='1' WHERE `db_araclar`.`id` ='$AUID2' LIMIT 1 ")or die(mysql_error());

		 }
		 else if($cikan_saat=="0")  ##abonelik s�resi bitmi�
		 {
		 $x=2;
		 $ekle_sorgu4="SELECT ADDDATE(NOW(), INTERVAL ".$a2_2." DAY )";
		 $SQL_tarih_ekle4=mysql_fetch_array(mysql_query($ekle_sorgu4));
		 $cikan_gun3=$SQL_tarih_ekle4[0];
		 $yap_ulan="UPDATE `db_araclar` SET `abonelikbitis` = '$cikan_gun3'  ,UID='1' WHERE `db_araclar`.`id` ='$AUID2'";
		// echo $yap_ulan;
		 mysql_query($yap_ulan)or die(mysql_error());

		 }
		 else if($cikan_saat>0)  ##hala aboneli�i var
		 {
		 $x=3;
		 $ekle_sorgu3="SELECT ADDDATE( '$abonelik_bitisi2', INTERVAL ".$a2_2." DAY )";
		 $SQL_tarih_ekle3=mysql_fetch_array(mysql_query($ekle_sorgu3));
		 $cikan_gun3=$SQL_tarih_ekle3[0];
		 mysql_query("UPDATE `db_araclar` SET `abonelikbitis` = '$cikan_gun3'  ,UID='1' WHERE `db_araclar`.`id` ='$AUID2' LIMIT 1 ")or die(mysql_error());
		
		 }
	$toplam_ucretim=$toplam_ucretim-$toplam_ucretim*$sahibi_kim_ki['uyeindirim'];
	
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$AUID2 NOlu Ara� Abonelik s�resi $a2_2 g�n Uzat�ld�:  $cikan_gun3', NOW(),'$user')");
if($toplam_ucretim>0){
$aracPlaka = $arac_bilgi["plaka"];
$operatorid = $idm;

mysql_query("INSERT INTO `db_odemeler` (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`, `plaka` , `abonesure` , `operatorid`, `dosyaadi`)VALUES (NULL , '$sahipid', '$toplam_ucretim','0',NOW(),'' , '$aracPlaka' ,$a2_2 , $operatorid , '')"); 
$iddd=mysql_insert_id();
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$iddd NOlu $toplam_ucretim TL\'lik �cret bilgisi olu�turuldu', NOW(),'$user')")or die(mysql_error());


$lastSql="SELECT * from `db_odemeler` order by `tarihzaman` DESC LIMIT 0,1";
$lastResult = @mysql_query($lastSql);
$numResult = mysql_num_rows($lastResult);
$lastVal = @mysql_fetch_assoc($lastResult);

	if ($numResult>0)
	{
		$idValue=$lastVal['id'];
		$pdf->AddPage('P', 'A5');
		$tarih_zaman = $tarih." ".$zaman;
		$pdf->SetFont('Arial','B',18);
		$pdf->Text(10,5,'									');
		$pdf->Text(10,12,'--------------------------------------------------');
		$pdf->Text(10,19,$otoparkadi);
		$pdf->Text(10,26,'--------------------------------------------------');
		$pdf->Text(10,33,'-----ABONE BILGILERI-----');
		$pdf->Text(10,40,"Arac Plaka: ".$aracPlaka);
		$pdf->Text(10,47,"Islem Tarihi: ".$tarih_zaman);
		$pdf->Text(10,54,"A.Bitis: ".$cikan_gun3);
		$pdf->Text(10,61,"A.S�resi: ".$a2_2." g�n");
		$pdf->Text(10,68,"Odeme Tutar: ".$toplam_ucretim." TL");
		$pdf->Text(10,75,'--------------------------------------------------');
		$pdf->Text(10,82,'									');
		$pdf->Text(10,89,'									');
		

		$file="abonePDF/".$idValue."_abone.pdf";
		$pdf->Output($file); 

		mysql_query("UPDATE `db_odemeler` SET `dosyaadi` = '$file'  WHERE `id` =$idValue ")or die(mysql_error());

	}
}


		 @header("Location: Arac.Guncelle.php?AUID=$AUID2&Durum=cOk&CikanZaman=$cikan_saat&x=$x"); 

}


if($ekle=="Guncelle"){
	
	 $kontrolll=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE plaka='$a1' "));

	//if($kontrol[0]<1)
	//{
		//@header("Location: Arac.Guncelle.php?AUID=$AUID2&Durum=YetkiDisiAlan");
	//}
	//else if($kontrol[0]>0)
	//{
		$kontrol2=mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM db_araclar WHERE plaka='$a1' AND id!='$AUID2'"));
		
		if($kontrol2[0]<1)
		{
		
			$ekle="UPDATE `db_araclar` SET 
			`marka` = '$a3',
			`model` = '$a4',
			`renk` = '$a5',
			`UID` = '$a10',
			`plaka` = '$a1', abonelikTipi= '$a7', AbonelikSaat= '$a8' WHERE `db_araclar`.`id` ='$AUID2' LIMIT 1 ";
			$uyari="Ara� G�ncellendi!";
			if(($a10=="1")&&($kontrolll['UID']!="1")){
			@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$a1 Plakal� arac�n bilgileri d�zenlendi. Ara� ABONE olarak de�i�tirildi!', NOW(),'$user')");
			}
			else if(($a10!="1")&&($kontrolll['UID']=="1")){
			@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$a1 Plakal� arac�n bilgileri d�zenlendi. Ara� ABONEnelikten ��kar�ld�!', NOW(),'$user')");
			
			}
			else {
			
			@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$a1 Plakal� arac�n bilgileri d�zenlendi. Abonelik bilgisi de�i�tirilmedi!', NOW(),'$user')");
			
			}
			mysql_query($ekle)or die(mysql_error());

			@header("Location: Arac.Guncelle.php?AUID=$AUID2&Durum=Ok&AboDur=".$kontrolll['UID']."");
		
		}
		else if($kontrol2[0]>0)
		{	
		
		@header("Location: Arac.Guncelle.php?AUID=$AUID2&Durum=YetkiDisiAlan2");
		
		}
		
		
		
	//}
	
	
	
	
	
	
}//if ekle ise




if($_GET['Durum']=="Sil"){

	
$silid=trim(mysql_real_escape_string($_GET['KID']));

mysql_query("DELETE FROM db_araclar WHERE id='$silid'")or die(mysql_error());
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$silid Numaral� Ara� Sistemden Silindi', NOW(),'$user')");

@header("Location: Arac.Duzenle.php");
	
}


$limit = 10;
$sayfa = $_GET["sayfa"];
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
$satirsayisi = mysql_num_rows(mysql_query("SELECT * FROM db_araclar"));
$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;
$sonucum=$_GET['Durum'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
    <div align="center"><span class="solmenu"><?
	if($sonucum=="YetkiDisiAlan2"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Bu plaka �nceden kay�t edilmi�!<br>";}
    if($sonucum=="Ok"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ara� Ba�ar�yla G�ncellendi!<br>";}
    if($sonucum=="cOk"){echo "<img src='images/icons/accept.png' width='16' height='16'> Abonelik S�resi Ba�ar�yla Yenilendi!<br>";}

	?>
    </span></div>
      <FORM method=post name=misafirtanimla action=Arac.Guncelle.php>
      <INPUT 
      type="hidden" name="ekle" value="duzenle">
       <INPUT 
      type="hidden" name="AUID" value="<? echo $AUID; ?>">
      <!---------------------->
      <? if($islem!="AbonelikUzat"){ ?>
        <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH colSpan=2>Ara� G�ncelle</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Ara&ccedil; Plakas�:</TD>
              <TD><span id="sprytextfield1">
              <input name=a1 class=text_input value="<? echo $arac_bilgi["plaka"]; ?>" id="a1">
              <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD align=right>Ara� Ba�l� Bulundu�u Ki�i: </TD>
              <TD><input name=a6 value="<? echo  $sahibi_kim_ki[1]; ?> <? echo  $sahibi_kim_ki[2]; ?>" disabled class=text_input id="a6"></TD>
            </TR>
            <TR>
              <TD align=right>Marka:</TD>
              <TD>
              <input name=a3 class=text_input id="a3" value="<? echo $arac_bilgi["marka"]; ?>">              </TD>
            </TR>
            <TR>
              <TD align=right>Model:</TD>
              <TD>
              <input name=a4 class=text_input id="a4" value="<? echo $arac_bilgi["model"]; ?>">           </TD>
            </TR>
            <TR>
              <TD align=right>Renk: </TD>
              <TD>
              <input name=a5 class=text_input id="a5" value="<? echo $arac_bilgi["renk"]; ?>">             </TD>
            </TR>
			 <TD align=right>G�nl�k Abonelik: </TD>
              <TD><input name=a7 type="checkbox" <? if($arac_bilgi["abonelikTipi"]==1) echo"checked"; ?> />
                </TD>
            </TR>
			 <TR>
              <TD align=right>G�nl�k Saat: </TD>
              <TD><input name=a8 value="<? echo $arac_bilgi["AbonelikSaat"]; ?>" class=text_input id="a8"> 
                Saat</TD>
            </TR>
            <TR>
            <? 	if($arac_bilgi["kullaniciid"]!=''){ ?>
            <TR>
              <TD height="27" align=right>Abonelik Durumu: </TD>
              <TD>    <?
		if($arac_bilgi["UID"]=="1"){
		
		 $abonelik_bitisi= $arac_bilgi["abonelikbitis"];		
		 $ekle_sorgu= "SELECT DATEDIFF('$abonelik_bitisi','$tarih $zaman')";
	   	 $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
	     $cikan_gun=(int)$SQL_tarih_ekle[0];	
		 $abonelik_bitmesi = convert_datetime($abonelik_bitisi);		 
		 $suan= convert_datetime("$tarih $zaman");
		 $cikan_gunA=$abonelik_bitmesi-$suan;

		 if($cikan_gunA<=0){
		 $yazdir= "G�n �nce Doldu ". '<img src="images/icons/stop.png" width="16" height="16">';
		 }
		 else if(($cikan_gunA>0)&&((int)$cikan_gunA!=0)){
		 $yazdir= "G�n Kald� ". '<img src="images/icons/tick.png" width="16" height="16">';
		 }
		 $cikan_gun = str_replace("-", "", $cikan_gun);
		 echo $cikan_gun." ".$yazdir;
		
		}
		
		if($arac_bilgi["UID"]!="1"){
		
		echo "Abone De�il ".'<img src="images/icons/information.png" width="16" height="16">' ;
		
		}
		 
		  ?></TD>
            </TR>
            <TR>
              <TD height="30" align=right>Abonelik Bitme S�resi: </TD>
              <TD><?
			  if($arac_bilgi["UID"]=="1"){
			   echo $arac_bilgi["abonelikbitis"]; 
			   
			   }
			   
			   if($arac_bilgi["UID"]!="1"){
			   echo "Tan�ml� De�il".'<img src="images/icons/information.png" width="16" height="16">';
			   
			   } ?></TD>
            </TR>
            <TR>
              <TD align=right>Abonelik Durumu: </TD>
              <TD><input name="a10" type="checkbox" <? if($arac_bilgi["UID"]=="1"){echo"checked";} ?> id="a10" value="1"></TD>
            </TR>
            <? }//kullaniciid!='' ?>
            <TR>
              <TD width="40%" align=right></TD>
              <TD><INPUT class=button value=Guncelle type=submit name=ekle>
                &nbsp; </TD>
            </TR>
          </TBODY>
        </TABLE>
        <? } ?>
<? if($islem=="AbonelikUzat"){ ?>
        <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH colSpan=2>Abone �yeli�ini Uzat</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Yeni Paket Ekle:</TD>
              <TD>
                <SELECT id=a2  name=a2>
                  <?
			$sorgula=mysql_query("SELECT * FROM db_abonelikturleri ORDER BY id");
			while($sistem=mysql_fetch_array($sorgula)){
			  ?>
                  <option value="<? echo $sistem[0]; ?>"><? echo $sistem[1]."  (".$sistem[2].")"; ?> </option>
                  <? } //while sorgul ?>
                </SELECT>
               </TD>
            </TR>

            <TR>
              <TD width="40%" align=right></TD>
              <TD><INPUT class=button value=Uzat type=submit name=ekle2>
                &nbsp; </TD>
            </TR>
</TBODY>
          <TBODY>
          </TBODY>
        </TABLE>
        <? } //islem ?>
   
      </FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
//-->
</script>
</BODY></HTML>
