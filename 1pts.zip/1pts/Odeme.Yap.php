<? 
header('content-type: text/html; charset=iso-8859-9');

include("includes/veritabani.php");


$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and (yetki='1' or yetki='4')"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$odeme_no=mysql_real_escape_string($_GET['IDX']);

$odenecek=mysql_real_escape_string($_POST['odenecek']);
$odenecek = str_replace(",", ".", $odenecek);
$orderid=mysql_real_escape_string($_POST['ORDERID']);

$odeme_id=mysql_fetch_array(mysql_query("SELECT * FROM db_odemeler WHERE id='$odeme_no'"));
$userim_benim=$odeme_id['kullaniciid'];
$user_detay=mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='$userim_benim'"));
$borcum= $odeme_id['borc']; 
//$odemem_gereken_tutar=($odeme_id['borc']-($odeme_id['borc']*$user_detay['uyeindirim']));
$odemem_gereken_tutar=$odeme_id['borc'];
$borcum2=$odemem_gereken_tutar-$odeme_id[3];

if($gonder=="G�ncelle"){
$odeme_idd=mysql_fetch_array(mysql_query("SELECT * FROM db_odemeler WHERE id='$orderid'"));

$userim_benim=$odeme_idd['kullaniciid'];
$status = $odeme_idd['status'];
$plaka = $odeme_idd['plaka'];
$abone_sure = $odeme_idd['abonesure'];

if ($odeme_idd['borc'] == $odeme_idd['odenen']+$odenecek)
{
    mysql_query("DELETE FROM db_odemeler WHERE id='$orderid'");
}else
{
    mysql_query("UPDATE `db_odemeler` SET db_odemeler.`odenen` = db_odemeler.odenen+$odenecek WHERE `db_odemeler`.`id` ='$orderid' LIMIT 1 ");
}
$query = "INSERT INTO `db_odemeler` (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`,`plaka` , `abonesure` , `operatorid`)VALUES (NULL , $userim_benim, $odenecek,$odenecek,NOW(),'$status','$plaka' , $abone_sure , $idm)";
//echo($query);
//exit();
mysql_query($query);
@header("Location: Kullanici.Odeme.Goster.php?KUID=".$odeme_idd[1]."&Durum=OdemeAlindi");
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$orderid NOlu fatura i�in $odenecek TL �deme yap�ld�', NOW(),'$user')")or die(mysql_error());
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9" />
    <meta name="robots" content="noindex,nofollow">
    <link rel="stylesheet" href="stil.css" type="text/css">
    <title><? echo $ttt[1]; ?></title>
    <link href="stil.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
<!--
.style3 {font-size: 14px; font-weight: bold; }
.style4 {font-size: 14px}
-->
    </style>
</head>
<body>
<form name="giris" action="Odeme.Yap.php" method="POST">
<input type="hidden" name="ORDERID" value="<? echo $odeme_no;?>" >
  <table border="0"  class="ictablo" > <tr>
      <th width="372" colspan="2" align="center"> Fatura Tahsilat� Yap<span class="style3"></span></th>
    </tr>
    
    <tr>
      <td align="center" colspan="2"><TABLE width=393 height="178" class=ictablo>
        <TBODY>
          <TR>
            <TD width="112" height="27" align=middle><div align="left"><strong>�deme No:</strong></div></TD>
            <TD width="269" align=middle><div align="left" class="style3 style4">
              <div align="left"><strong>#<? echo  $odeme_no; ?></strong></div>
            </div></TD>
            </TR>
          <TR>
            <TD height="27" align=middle><div align="left"><strong>Kullan�c� :</strong></div></TD>
            <TD align=middle><div align="left" class="style4"><strong><? echo $user_detay[1]." ".$user_detay[2]; ?></strong></div></TD>
          </TR>
          <TR>
            <TD height="27" align=middle><div align="left"><strong>Kullan�c� �zel �ndirimi:</strong></div></TD>
            <TD align=middle><div align="left" class="style4"><strong><? echo $user_detay['uyeindirim']; ?></strong></div></TD>
          </TR>
          <TR>
            <TD height="27" align=middle><div align="left"><strong>Bor� Tutar�:</strong></div></TD>
            <TD align=middle><div align="left" class="style3">
			<? if($borcum>$odemem_gereken_tutar){ ?>
            <STRIKE>
            
			<? echo $borcum; ?>  
            
            </STRIKE>
            <? } ?>
			<? echo  $odemem_gereken_tutar; ?> TL
            
            </div></TD>
            </TR>
          <TR>
            <TD height="27" align=middle><div align="left"><strong>�denen Tutar:</strong></div></TD>
            <TD align=middle><div align="left" class="style3"><? echo  $odeme_id[3]; ?> TL</div></TD>
            </TR>
          <TR>
            <TD height="27" align=middle><div align="left"><strong>�denilecek Tutar:</strong></div></TD>
            <TD align=middle><span class="style3">
              <label>              </label>
            </span>              <span class="style3">
            <label></label>
            </span>            <span class="style4"><strong>
            <label></label>
            </strong></span>
            <div align="left" class="style3">
                <input type="text" name="odenecek" value="<?  echo $borcum2;?>" id="textfield">
               TL</div>
            </TD>
            </TR>
        </TBODY>
      </TABLE>        
        
        <input type="submit" name="gonder" id="button" value="G�ncelle">
        <input type="reset" onclick='closeMessage();return false' name="button" id="button2" value="Kapat"></td>
    </tr>
  </table>
</form>
  </body>
</html>
