<?
include_once("includes/Sayfalama.Fonk.php");
include_once("Guvenlik.Filtre.php");


//*****************************************//
//**********PCC ELEKTRON�K*****************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//
function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}
//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='4' or yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$KID=trim(mysql_real_escape_string($_GET['KID']));
$KID2=trim(mysql_real_escape_string($_POST['KID']));


$ekle=mysql_real_escape_string($_['ekle']);
$a1=trim(mysql_real_escape_string($_GET['a1']));
$a2=trim(mysql_real_escape_string($_GET['a2']));
$a3=trim(mysql_real_escape_string($_GET['a3']));
$a4=trim(mysql_real_escape_string($_GET['a4']));
$a5=trim(mysql_real_escape_string($_GET['a5']));
$a6=trim(mysql_real_escape_string($_GET['a6']));
$a7=trim(mysql_real_escape_string($_GET['a7']));
$a8=trim(mysql_real_escape_string($_GET['a8']));
$a9=trim(mysql_real_escape_string($_GET['a9']));//Grupname bas�yor
$a10=trim(mysql_real_escape_string($_GET['a10']));
$a11=trim(mysql_real_escape_string($_GET['a11']));
$a12=trim(mysql_real_escape_string($_GET['a12']));
$a13=trim(mysql_real_escape_string($_GET['a13']));
$a14=trim(mysql_real_escape_string($_GET['a14']));

$Durum=trim(mysql_real_escape_string($_GET['Durum']));
$DPlaka=trim(mysql_real_escape_string($_GET['Plaka']));
if ($Durum="Disari")
{
	mysql_query("UPDATE `db_araclar` SET `db_araclar`.`aracKonum` = 'd' WHERE `db_araclar`.`plaka` ='$DPlaka'")or die(mysql_error());
	@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$DPlaka Plaka Ara� Disari Cikartildi', NOW(),'$user')");
}


if($_GET['Temizle']=="Temizle"){

@header("Location: Gorevli.Arac.Arama.php?Temizlendi");
}


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>

<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
		<script src="jquery.js" language="JavaScript" type="text/javascript"></script>

<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>

<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {color: #CC0000}
.style2 {font-size: 10px}
-->
</style>
	<style>

		#notification{
	position:absolute;
	bottom:0%;
	right:2%;
	height:122px;
	width:200px;
	border:1px solid black;
	border-bottom:0px;
	background: url('images/pts_solback.jpg') repeat-y;

		}
		#notificationClose{
			font-size:11px;
			cursor:pointer;
			width:100%;
			border-bottom:1px solid black;
		}
		#notificationIn{
			padding:10px;
			font-size:11px;
			
		}
	</style>
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580> 
        <H2>��erde Bulunan Ara&ccedil;lar</H2>
        <TABLE class=ictablo width=572>
          <TBODY>
            <TR>
              <TH width="29" height="31">#ID</TH>
              <TH width="87">Plaka</TH>
              <TH width="25">T�r</TH>
              <TH width="151">Abonelik Bilgisi </TH>
              <TH width="82">Abonelik Biti� Tarihi</TH>
              <TH width="170">��lemler</TH>
            </TR>
    <?
$a1=trim(mysql_real_escape_string(strtoupper($_GET['a1'])));//plaka
//$a1=trim(mysql_real_escape_string(strtoupper($_POST['a1'])));
$a1 = str_replace(" ","",$a1);
$a2=trim(mysql_real_escape_string($_GET['a2']));//ad�
$a3=trim(mysql_real_escape_string($_GET['a3']));//marka
$a4=trim(mysql_real_escape_string($_GET['a4']));//model
$a5=trim(mysql_real_escape_string($_GET['a5']));//renk
$a6=trim(mysql_real_escape_string($_GET['a6']));//area1
$a7=trim(mysql_real_escape_string($_GET['a7']));//area2
$a8=trim(mysql_real_escape_string($_GET['a8']));//area3
$a9=trim(mysql_real_escape_string($_GET['a9']));///Grupname bas�yor 
$a10=trim(mysql_real_escape_string($_GET['a10'])); //sadece misafirleri g�ster
$a11=trim(mysql_real_escape_string($_GET['a11']));//i�eride �u kadar saatten fazla kalan ara�lar
$a12=trim(mysql_real_escape_string($_GET['a12']));
$a13=trim(mysql_real_escape_string($_GET['a13']));//Grupname bas�yor
$a14=trim(mysql_real_escape_string($_GET['a14']));

/*echo $a9;
echo " ";
echo $a13;
echo " ";
*/

//******��eri D��ar� Durum********/


//	$sorgu = "select * FROM db_uyeler WHERE id>0 " . $kosul;
$ara=trim($_GET['Ara']);

$tablo2="SELECT * FROM db_araclar WHERE db_araclar.id>0 AND aracKonum='i'";
$sorgu222=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu222);

$limit = 2000;
$sayfa = mysql_real_escape_string($_GET["sayfa"]);
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
$satirsayisi = $kactane2;
$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;

$tablo3="SELECT * FROM db_araclar WHERE db_araclar.id>0 AND aracKonum='i' ORDER BY db_araclar.id DESC LIMIT ".$baslangic. ",".$limit."";
$sorgu2=mysql_query($tablo3)or die(mysql_error());
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 


		
?>
            <TR>
              <TD height="33" align=middle>#<? echo $xxd[0]; ?></TD>
              <TD align=middle><? echo $xxd["plaka"];?></TD>
              <TD align=middle><?
			   if($xxd["kullaniciid"]!=''){
			   
			   echo '<img src="images/icons/user.png" width="16" height="16">';
			   
			   }else{
			   
			   echo '<img src="images/icons/user_red.png" width="16" height="16">';
			   
			   }
			   
			   ?>
                </TD>
              <TD align=middle><div align="right">
                  <?
		if($xxd["UID"]=="1"){
		 $abonelik_bitisi= $xxd["abonelikbitis"];

		 $ekle_sorgu= "SELECT DATEDIFF('$abonelik_bitisi','$tarih $zaman')";
	   	 $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
	     $cikan_gun=(int)$SQL_tarih_ekle[0];	
		 $abonelik_bitmesi = convert_datetime($abonelik_bitisi);		 
		 $suan= convert_datetime("$tarih $zaman");
		 $cikan_gunA=$abonelik_bitmesi-$suan;

		 if($cikan_gunA<=0){
		 $yazdir= "G�n �nce Doldu ". '<img src="images/icons/stop.png" width="16" height="16">';
		 }
		 else if(($cikan_gunA>0)&&((int)$cikan_gunA!=0)){
		 $yazdir= "G�n Kald� ". '<img src="images/icons/tick.png" width="16" height="16">';
		 }
		 $cikan_gun = str_replace("-", "", $cikan_gun);
		 echo $cikan_gun." ".$yazdir;
		  }
		  if($xxd["UID"]!="1"){
		  echo "Abone De�il ".'<img src="images/icons/information.png" width="16" height="16">' ;
		  
		  }
		  
		  ?>
              </div></TD>
              <TD align=middle>
              <div align="center">
			  <? 
			  if($xxd["UID"]=="1"){
			  echo $xxd["abonelikbitis"];
			  }
			  if($xxd["UID"]!="1"){
			  echo "-";
			  }
			  
			  ?></div></TD>
                 <INPUT value="<? echo $xxd[0]; ?>"  type=hidden name="kamera">
              <TD align=middle>
              <input class="button small" name="Disari" value="D��ar� ��kart" onClick="JavaScript:if (confirm('<b><? echo $xxd["plaka"] ?> Plakal� Arac� \nD��ar� ��kartmak istiyor musunuz?')) javascript:document.location.href='Gorevli.Arac.Liste.php?Plaka=<? echo $xxd["plaka"] ?>&Durum=Disari'" type="button" id="Disari" />
              </TD>
            </TR>
            <? 
} //sistemler son fetch
?>
          </TBODY>
        </TABLE>

<br>
<div class="page-navigation clearfix">
<div class="wp-pagenavi">
  <div align="center">
<?
PagePrint($sayfa,$satirsayisi,$limit,"&a8=$a8&a1=$a1&a11=$a11&a13=$a13&a14=$a14&a16=$a16&a2=$a2&a3=$a3&a4=$a4&a5=$a5&a6=$a6&a7=$a7&a15=$a15&a8=$a8&a9=$a9&a20=$a20&a21=$a21&a12=$a12&a17=$a17&a10=$a10&Ara=Ara&ekle=duzenle&KID=");
?>
    
  </div>
</div>
</div>
    
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>

<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "integer", {isRequired:false, validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "time", {isRequired:false, validateOn:["change"], format:"HH:mm:ss"});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "time", {isRequired:false, validateOn:["change"], format:"HH:mm:ss"});
//-->
</script>
		
</BODY></HTML>
