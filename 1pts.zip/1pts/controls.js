function CC_noErrors() {
return true;
}

window.onerror = CC_noErrors;

function eleman(f) {
return e=document.getElementById(f);
}
function moveOver(f1,f2)  
{
var f1=eval("eleman('"+f1+"')");
var f2=eval("eleman('"+f2+"')");
var boxLength = f2.length;
var selectedItem = f1.selectedIndex;
var selectedText = f1.options[selectedItem].text;
var selectedValue = f1.options[selectedItem].value;
var i;
var isNew = true;
if (boxLength != 0) {
for (i = 0; i < boxLength; i++) {
thisitem = f2.options[i].text;
if (thisitem == selectedText) {
isNew = false;
break;
      }
   }
} 
if (isNew) {
newoption = new Option(selectedText, selectedValue, false, false);
f2.options[boxLength] = newoption;
}
f1.selectedIndex=-1;
}
function removeMe(f2,f3) {
var f2orj=f2;
var f2=eval("eleman('"+f2+"')");
var boxLength = f2.length;
arrSelected = new Array();
var count = 0;
for (i = 0; i < boxLength; i++) {
if (f2.options[i].selected) {
arrSelected[count] = f2.options[i].text;
}
count++;
}
var x;
for (i = 0; i < boxLength; i++) {
for (x = 0; x < arrSelected.length; x++) {
if (f2.options[i].text == arrSelected[x]) {
f2.options[i] = null;
   }
}
boxLength = f2.length;
   }
saveMe(f2orj,f3)
}
function saveMe(f2,f3) {
var f2=eval("eleman('"+f2+"')");
var f3=eval("eleman('"+f3+"')");
var boxLength = f2.length;
var count = 0;
if (boxLength != 0) {
for (i = 0; i < boxLength; i++) {
if (count == 0) {
strValues = f2.options[i].value;
pf = f2.options[i].text;
}
else {
strValues = strValues + "," + f2.options[i].value;
}
count++;
   }
}
else { strValues=null; }
f3.value = strValues;
}
function viewchoices(choice,f1,f2,f3) {
var f1=eval("eleman('"+f1+"')");
var f2=eval("eleman('"+f2+"')");
var f3=eval("eleman('"+f3+"')");
var sels=choice.split(',');
var opt = f2.options; 
var cont = f1.options; 
var x, clen= cont.length;
var i, len = sels.length; 
	for (i=0; i<len; i++) { 
  var selThis=sels[i];
	var selText=selThis;
   for (x=0; x<clen; x++) {
	  if(cont[x].value==selThis) {
		selText=cont[x].text } }
  opt.length=i+1;
	opt[i].text=selText;
	opt[i].value=selThis; }
f3.value=choice;
}
function foundtselected(field,val) {
var opt = eleman(field).options; 
var i, len = opt.length; 
for (i=0; i<len; i++) { 
if (opt[i].text==val) { 
opt[i].selected = true; 
break; 
} 
} 
}

function misafirGoster(){
  if (eleman("turu").selectedIndex==0){
      eleman("divDM").style.display="block";
      eleman("divGM").style.display="none";
  }
  else{
      eleman("divGM").style.display="block";
      eleman("divDM").style.display="none";
  }
}
