<?
@session_start();
include_once("Guvenlik.Filtre.php");


//*****************************************//
//**********NORON TEKNOLOJI*****************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$KUID=trim(mysql_real_escape_string($_GET['KUID']));
$KUID2=trim(mysql_real_escape_string($_POST['KUID']));





if($_GET["Durum"]=="Sil"){

@mysql_query("DELETE FROM db_super_users WHERE id='$KUID' AND yetki='4'")or die(mysql_error());

$uyari="G�revli Silindi!";
	
}

$ekle=mysql_real_escape_string($_POST['ekle']);
$duzenle=mysql_real_escape_string($_POST['duzenle']);

$a1=htmlspecialchars(trim(mysql_real_escape_string($_POST['a1'])));
$a2=htmlspecialchars(trim(mysql_real_escape_string($_POST['a2'])));
$a3=htmlspecialchars(trim(mysql_real_escape_string($_POST['a3'])));
$a4=htmlspecialchars(trim(mysql_real_escape_string($_POST['a4'])));
$a5=htmlspecialchars(trim(mysql_real_escape_string($_POST['a5'])));
$a6=htmlspecialchars(trim(mysql_real_escape_string($_POST['a6'])));
$a7=htmlspecialchars(trim(mysql_real_escape_string($_POST['a7'])));

$uye=mysql_fetch_array(mysql_query("SELECT * FROM db_super_users WHERE id='$KUID' AND yetki='4'"));


if($duzenle=="Duzenle"){
		if(($a1>' ')&&($a2>' ')&&($a6>' ')&&($a7>' ')){

		$sorgu_duzenle="UPDATE `db_super_users` SET `ad` = '$a1',
`soyad` = '$a2',
`username` = '$a6',
`password` = '$a7' WHERE `db_super_users`.`id` ='$KUID2' LIMIT 1 ";

mysql_query($sorgu_duzenle)or die(mysql_error());
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$KUID2 NOlu G�revli D�zenlendi.', NOW(),'$user')");

@header("Location: Gorevli.Duzenle.php?KUID=$KUID2&Durum=Duzenle");
	
		}//if a1 a2 a3 a4
	
}//if d�zenle


if($ekle=="Ekle"){
	
	if(($a1>' ')&&($a2>' ')&&($a6>' ')&&($a7>' ')){
	$ekle="INSERT INTO `db_super_users` (
`id` ,
`ad` ,
`soyad` ,
`mail` ,
`yetki` ,
`eklenme` ,
`username` ,
`password` ,
`songiris`
)
VALUES (
NULL , '$a1', '$a2', '', '4', '$tarih $zaman', '$a6', '$a7', '2009-12-16 13:49:29'
)";
	mysql_query($ekle)or die(mysql_error());
	@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$a1 $a2 �simli yeni g�revli eklendi.', NOW(),'$user')");

	$uyari="G�revli Eklendi!";
	}//if bo� de�ilse
}//if ekle ise

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
  <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
      <FORM method=post name=misafirtanimla action=Gorevli.Duzenle.php>
      <INPUT 
      type="hidden" name="ekle" value="duzenle">
       <INPUT 
      type="hidden" name="KUID" value="<? echo $KUID; ?>">
        <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH colSpan=2>Yeni G&ouml;revli Ekle</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>�sim:</TD>
              <TD><span id="sprytextfield1">
                <input name=a1 value="<? echo $uye[1]; ?>" class=text_input id="a1">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Soyisim:</TD>
              <TD><span id="sprytextfield2">
                <input name=a2 value="<? echo $uye[2]; ?>" class=text_input id="a2">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD align=right>Kullan�c� Ad�:</TD>
              <TD><span id="sprytextfield3">
                <input name=a6 value="<? echo $uye[6]; ?>" class=text_input id="a6">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD align=right>�ifre:</TD>
              <TD><span id="sprytextfield4">
                <input name=a7 value="<? echo $uye[7]; ?>" type="password" class=text_input id="a7">
                <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></TD>
            </TR>
            <TR>
              <TD width="40%" align=right></TD>
              <TD>
                              <? if($_GET['Durum']!="Duzenle"){ ?>

              <INPUT class=button value=Ekle type=submit name=ekle> &nbsp;
              <? } ?>
               
                <? if($_GET['Durum']=="Duzenle"){ ?>
                 <INPUT name=duzenle type=submit class=button id="duzenle" value=Duzenle>
                 <? } ?>
                </TD>
            </TR>
          </TBODY>
        </TABLE>
        <H2>Varolan G&ouml;revliler</H2>
        <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH width="32" height="25">#ID</TH>
              <TH width="76">Ad�</TH>
              <TH width="93">Soyad�</TH>
              <TH width="120">Kullan�c� Ad�</TH>
              <TH width="110">�ifre</TH>
              <TH width="111">��lemler</TH>
            </TR>
            
<?
$tablo2="SELECT * FROM db_super_users WHERE yetki='4' order by id";
$sorgu2=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 
?>
			
		
            <TR>
              <TD height="27" align=middle>#<? echo $xxd[0]; ?></TD>
              <TD align=middle><? echo $xxd[1];  ?></TD>
              <TD align=middle><? echo $xxd[2]; ?></TD>
              <TD align=middle><? echo $xxd[6]; ?></TD>
              <TD align=middle><? echo $xxd[7]; ?></TD>
              <TD align=middle>
                <INPUT value="<? echo $xxd[0]; ?>" type=hidden name="kamera">
                
                <input class="button small" name="Duzenle" value="D�zenle" onClick="javascript:document.location.href='Gorevli.Duzenle.php?KUID=<? echo $xxd['id'] ?>&Durum=Duzenle'" type="button" id="Duzenle" />
                <input class="button small" name="Sil" value="Sil" onClick="JavaScript:if (confirm('Silmek istedi�inizden emin misin?')) javascript:document.location.href='Gorevli.Duzenle.php?KUID=<? echo $xxd['id'] ?>&Durum=Sil'" type="button" id="Sil" /></TD>
            </TR>
            
<? 
} //sistemler son fetch
?>
            
          </TBODY>
        </TABLE>
        <p>&nbsp;</p>
      </FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");
//-->
</script>
</BODY></HTML>
