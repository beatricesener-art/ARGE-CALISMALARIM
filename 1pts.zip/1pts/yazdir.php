<?
// http://localhost:82/pts/yazdir.php?f=abonePDF/334_abone.pdf
$file=$HTTP_GET_VARS['f']; 
$file = "./".$file;
$filename = 'Custom file name for the.pdf'; /* Note: Always use .pdf at the end. */

header('Content-type: application/pdf');
header('Content-Disposition: inline; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Content-Length: ' . filesize($file));
header('Accept-Ranges: bytes');

@readfile($file);

?> 