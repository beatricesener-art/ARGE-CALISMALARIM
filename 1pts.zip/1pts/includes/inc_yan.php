<? 
require_once('veritabani.php');
if($durum== "2") {  
//Teknik Servis Giri�i �se 
?>
<DIV class=solmenu>
<NOBR><IMG 
      src="images/PCCikonset/PNG/Home.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle"> &nbsp;&nbsp;&nbsp;<A 
      href="Home.php">Ana Men&uuml;</A></NOBR><BR>
<NOBR><IMG 
      src="images/PCCikonset/PNG/Tools.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Sistem.Duzenle.php">Sistem D&uuml;zenle</A></NOBR><BR>
  <NOBR><IMG 
      src="images/PCCikonset/PNG/Camera.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Kamera.Duzenle.php">Kamera D&uuml;zenle</A></NOBR><BR>
<NOBR><IMG 
      src="images/PCCikonset/PNG/Camera.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Cihaz.Duzenle.php">Cihaz D&uuml;zenle</A></NOBR><BR>
<NOBR><IMG 
      src="images/PCCikonset/PNG/Camera.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Kamera.Grubu.Duzenle.php">Kamera Gruplar&#305;</A></NOBR><BR>
<!--<NOBR><img 
      src="images/PCCikonset/PNG/Tools.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle" />&nbsp;&nbsp;&nbsp;<A 
      href="Arac.Mudehale.php">Ara&ccedil; M&uuml;dehale</A></NOBR><BR>-->
<!--<NOBR><IMG 
      src="images/PCCikonset/PNG/Book.png" alt="Ara� Tan�mlama" width="36" height="36" border=0 
      style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Area.Tanimlama.php">Tan�mlama</A></NOBR><BR>-->


  
<IMG 
      src="images/PCCikonset/PNG/Settings.png" alt="Ara� Tan�mlama" width="36" height="36" border=0 
      style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Site.Ayarlari.php">Site Ayarlar&#305;</A><BR>
 	<NOBR>
    <IMG 
      src="images/PNG-48/Loading.png" alt="Ara� Tan�mlama" width="36" height="36" border=0 
      style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="SuperUser.Duzenle.php">S&uuml;per Kullan&#305;c&#305;lar</A><BR>
 	<NOBR> 	<NOBR>
    <IMG 
      src="images/PCCikonset/PNG/Database.png" alt="Ara� Tan�mlama" width="36" height="36" border=0 
      style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Database.Kontrol.php">Database Kontrol</A><BR>
 	<NOBR>

<NOBR><IMG 
      src="images/PNG-48/Exit.png" alt=Duyurular width="36" height="36" border=0 
      style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Cikis.Yap.php">��k�� Yap</A></NOBR> </DIV>
<? } //il durum==2 ?>

<? if($durum== "1") {  
?>
<DIV class=solmenu>
   <NOBR><img width="36" height="36" border="0" 
      style="VERTICAL-ALIGN: middle" 
      alt="Teknik Servis Talebi" 
      src="images/PCCikonset/PNG/Home.png" />&nbsp;&nbsp;&nbsp;<A 
      href="Home.php">Ana Men&uuml;</A></NOBR><BR>
<NOBR><img 
      src="images/PCCikonset/PNG/Search.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border="0" style="VERTICAL-ALIGN: middle" />&nbsp;&nbsp;&nbsp;<A 
      href="Gorevli.Arac.Arama.php">Ara&ccedil; Ara</A></NOBR><BR>
<NOBR><img 
      src="images/PCCikonset/PNG/Tag_add.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border="0" style="VERTICAL-ALIGN: middle" />&nbsp;&nbsp;&nbsp;<A 
      href="Aractipi.Arama.php">Ara� Tipi D�zenle</A></NOBR>
      <BR>

	<!--<NOBR><IMG 
      src="images/PCCikonset/PNG/User.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Arac.Duzenle.php">Abone  D&uuml;zenle</A></NOBR><BR>-->
	<NOBR><IMG 
      src="images/PCCikonset/PNG/User.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Kullanici.Duzenle.php">M&uuml;&#351;teri  D&uuml;zenle</A></NOBR><BR>
      		<NOBR><IMG 
      src="images/PCCikonset/PNG/Search.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Kullanici.Ara.php">M&uuml;&#351;teri Ara </A></NOBR><BR>
      	
<NOBR>

<IMG 
      src="images/PCCikonset/PNG/Tag_add.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Abonelik.Duzenle.php">Abonelik D&uuml;zenle</A></NOBR><BR>
  <NOBR><IMG 
      src="images/images.jpeg" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Fiyat.Duzenle.php">Fiyat Giri&#351;i</A></NOBR><BR>  
  <NOBR><IMG 
      src="images/odeme_goster.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Odeme.Goster.php">&Ouml;deme G&ouml;ster</A></NOBR><BR>
  <NOBR>
  <IMG 
      src="images/icon_guvenlik.jpg" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Gorevli.Duzenle.php">G&ouml;revli D&uuml;zenle</A>      </NOBR><BR>
<NOBR>
  <NOBR><IMG 
      src="images/PCCikonset/PNG/Chart.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Gorevli.Rapor.Sorgula.php">Ge�i&#351; Raporlar&#305;</A></NOBR><BR>
        <NOBR><IMG 
      src="images/yonetim_rapor.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Yonetim.Raporlari.php">Y&ouml;netim Raporlar&#305;</A></NOBR><BR>       
        <NOBR><IMG 
      src="images/pdf.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="gorevlilerin_raporu.php">G�revlilerin Raporu </A></NOBR><BR>
        <NOBR><IMG 
      src="images/PNG-48/Line Chart.png" 
      alt="��erdeki Ara�lar" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Gorevli.Arac.Liste.php">��erdeki Ara� Y�netimi</A></NOBR><BR>       
        <NOBR><BR>
		<NOBR><IMG 
      src="images/kazanc_ozeti.png" 
      alt="Yap�lan Abonelikler" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Gorevli.Abone.Liste.php">Yap�lan Abonelikler Listesi</A></NOBR><BR>       
        <NOBR><BR>
        <NOBR><IMG 
      src="images/kazanc_ozeti2.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Kazanc.Ozeti.php">Kazan&ccedil; &Ouml;zeti</A></NOBR><BR>
      

<NOBR><img 
      src="images/PNG-48/Exit.png" alt="Duyurular" width="36" height="36" border="0" 
      style="VERTICAL-ALIGN: middle" />&nbsp;&nbsp;&nbsp;<A 
      href="Cikis.Yap.php">��k�� Yap</A></NOBR> </DIV>
<? } ?>
<? if($durum== "3") {  
?>

<DIV class=solmenu>
   <NOBR><img width="36" height="36" border="0" 
      style="VERTICAL-ALIGN: middle" 
      alt="Teknik Servis Talebi" 
      src="images/PCCikonset/PNG/Home.png" />&nbsp;&nbsp;&nbsp;<A 
      href="Kullanici.Home.php">Ana Men&uuml;</A></NOBR><BR>
  <NOBR><IMG 
      src="images/PCCikonset/PNG/Symbol_Right.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Kullanici.Arac.Detay.php">Ara&ccedil;lar&#305;m</A></NOBR><BR>  
  <NOBR><IMG 
      src="images/PCCikonset/PNG/Lock.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Kullanici.Sifre.Duzenle.php">&#350;ifre &#304;&#351;lemleri</A></NOBR><BR>

  <NOBR><img 
      src="images/images.jpeg" 
      alt="Teknik Servis Talebi" width="36" height="36" border="0" style="VERTICAL-ALIGN: middle" />&nbsp;&nbsp;&nbsp;<A 
      href="Kullanici.Odeme.Detay.php">&Ouml;deme Durumu</A></NOBR><BR>  
  <NOBR><img 
      src="images/PCCikonset/PNG/Shopping_Cart_Add.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border="0" style="VERTICAL-ALIGN: middle" />&nbsp;&nbsp;&nbsp;<A 
      href="Yapim.Asamasinda.php">Kredi Yukle</A></NOBR><BR>  


 
  <NOBR>

<NOBR><img 
      src="images/PNG-48/Exit.png" alt="Duyurular" width="36" height="36" border="0" 
      style="VERTICAL-ALIGN: middle" />&nbsp;&nbsp;&nbsp;<A 
      href="Cikis.Yap.php">��k�� Yap</A></NOBR> </DIV>
<? } ?>
<? if($durum== "4") {  
?>

<DIV class=solmenu>
   <NOBR><img width="36" height="36" border="0" 
      style="VERTICAL-ALIGN: middle" 
      alt="Teknik Servis Talebi" 
      src="images/PCCikonset/PNG/Home.png" />&nbsp;&nbsp;&nbsp;<A 
      href="Home.php">Ana Men&uuml;</A></NOBR><BR>
  <NOBR>
  <?
  if($VALE_SISTEM_AKTIF)
  { ?>
<img 
      src="images/PCCikonset/PNG/Search.png" 
      alt="Ara� Arama" width="36" height="36" border="0" style="VERTICAL-ALIGN: middle" />&nbsp;&nbsp;&nbsp;<A 
      href="Vale.Arac.Arama.php">Ara&ccedil; Ara</A></NOBR><BR>	  
  <? } ?>
  
<IMG 
      src="images/odeme_goster.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Odeme.Goster.php">Mevcut &Ouml;deme G&ouml;ster</A></NOBR><BR>
<NOBR>
<IMG 
      src="images/kazanc_ozeti.png" 
      alt="Yap�lan Abonelikler Listesi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Gorevli.Abone.Liste.php">Yap�lan Abonelikler Listesi</A></NOBR><BR>
<IMG 
      src="images/kazanc_ozeti2.png" 
      alt="Teknik Servis Talebi" width="36" height="36" border=0 style="VERTICAL-ALIGN: middle">&nbsp;&nbsp;&nbsp;<A 
      href="Gorevli.Rapor.Sorgula.php">Giri&#351; Raporlar&#305;</A></NOBR><BR>
      
<NOBR><img 
      src="images/PNG-48/Exit.png" alt="Duyurular" width="36" height="36" border="0" 
      style="VERTICAL-ALIGN: middle" />&nbsp;&nbsp;&nbsp;<A 
      href="Cikis.Yap.php">��k�� Yap</A></NOBR> </DIV>
<? } ?>
<? if(($durum< 1)||($durum> 4)) {  
//Eger yetki atamasi yapilamadiysa
echo '<meta http-equiv="refresh" content="0;url=index.php?HID=2">';

}
?>