<?php
	
     /*
     ###############################################
     ####                                       ####
     ####    Author : Harish Chauhan            ####
     ####    Date   : 31 Dec,2004               ####
     ####    Updated:                           ####
     ####                                       ####
     ###############################################

     */

	 
	 /*
	 * Class is used for save the data into microsoft excel format.
	 * It takes data into array or you can write data column vise.
	 */
function wsfWriteExcel($sqlQuery,$headers=null,$filePath=null,$time=null){
		
    $sorgu2=mysql_query($sqlQuery);
    $records=mysql_num_rows($sorgu2);

    if(!$records){
        return null;
    }
    
    if(is_null($filePath))
    {
            if(!is_null($time))
                    $filePath = 'odemePDF/'.str_replace(array(' ',':'),'-',$time).".xls";
            else
                    $filePath = "odemePDF/myXls.xls";
    } 
    ob_clean();
    $excel=new ExcelWriter($filePath);
    
    if($excel==false){
            return  $excel->error;
    }
                                
    $usersNameArr = array(0=>'');
    $userQuery="SELECT `id`,`ad`,`soyad` FROM db_super_users ";
    $userValue=mysql_query($userQuery);
    while($kullanici=  mysql_fetch_assoc($userValue)){ 
            $usersNameArr[$kullanici['id']] = $kullanici['ad'].' '.$kullanici['soyad'];
    }
     
    $AutoType = array('0'=>' ' ,'1'=>'Ucretli' , '2'=>'Ucretsiz');

     $headers = array(
                "#ID",
                "Plaka",
                "Arac Tipi",
                "Borc (TL)",
                "Odenen (TL)",
                "Kalan(TL)",
                "Olusturulma",
                "Operator",
        );
     ob_clean();
    $excel->writeLine($headers);
    $excel->writeLine('');
    
    for($i=0;$i<$records;$i++){
        $xxd=array();    
        $xxd=mysql_fetch_array($sorgu2);
            $usr_inc[$xxd[8]]['odeme_durumu'] = $xxd[3]-$xxd[2];
            $odeme_durumu=$xxd[3]-$xxd[2];

            $usr_inc[$xxd[8]]['toplam_uretilen'] =$usr_inc[$xxd[8]]['toplam_uretilen']+$xxd[2];
            $toplam_uretilen=$toplam_uretilen+$xxd[2];
            $usr_inc[$xxd[8]]['toplam_odenen']=$usr_inc[$xxd[8]]['toplam_odenen']+$xxd[3];
            $toplam_odenen=$toplam_odenen+$xxd[3];

            $usr_inc[$xxd[8]]['toplam_tahsil_edilen']=$usr_inc[$xxd[8]]['toplam_tahsil_edilen']+$usr_inc[$xxd[8]]['odeme_durumu'];
            $toplam_tahsil_edilen=$toplam_tahsil_edilen+$odeme_durumu;
            $usr_inc[$xxd[8]]['toplam_net']=$usr_inc[$xxd[8]]['toplam_net']+$usr_inc[$xxd[8]]['odeme_durumu'];
            $toplam_net=$toplam_net+$odeme_durumu;
   

            $myArr=array();
			$aractipi="";
			if ($xxd["abonesure"]==0) $aractipi=getAoutoType($xxd[5]); 
			else $aractipi="Abone Kayit";
            $myArr = array(
                $xxd[0],
                $xxd[6],
                $aractipi,
                $xxd[2],
                $xxd[3],
                $odeme_durumu,
                $xxd[4],
                $usersNameArr[$xxd[8]],
              );
             $excel->writeLine($myArr);

        }
        
        $excel->writeLine(''); 
        $excel->writeLine('');
        
        $excel->writeLine( array("TOPLAM URETILEN MIKTAR:", $toplam_uretilen));
        $excel->writeLine(array("TOPLAM ODENEN MIKTAR:",$toplam_odenen));

        $excel->writeLine(array("TOPLAM TAHSIL EDILMEMIS MIKTAR:",$toplam_tahsil_edilen));
        $excel->writeLine('');
        $excel->writeLine('');
        
          if(is_array($usr_inc)){
              foreach($usr_inc as $userId=>$userIncoms){
                    $excel->writeLine(array("Kulanici :" , $usersNameArr[$userId]));
                    $excel->writeLine(array("TOPLAM URETILEN MIKTAR:", $userIncoms['toplam_uretilen']));
                    $excel->writeLine(array("TOPLAM ODENEN MIKTAR:",$userIncoms['toplam_odenen']));
                    $excel->writeLine(array("TOPLAM TAHSIL EDILMEMIS MIKTAR:",$userIncoms['toplam_tahsil_edilen']));
              }
          }
        
        $excel->close();
        return $filePath;
		
}

	Class ExcelWriter
	{
			
		var $fp=null;
		var $error;
		var $state="CLOSED";
		var $newRow=false;
		var $encoding='utf-8';
		var $direction = 'ltr';
		var $author='Site';
		
		/*
		* @Params : $file  : file name of excel file to be created.
		* @Return : On Success Valid File Pointer to file
		* 			On Failure return false	 
		*/
		 
		function ExcelWriter($file="", $encoding = NULL, $direction = NULL)
		{
			if (is_null($encoding))
				$encoding='utf-8';
			if (is_null($direction))
				$direction = 'ltr';
			$this->direction = $direction;
			$this->encoding=$encoding;
			return $this->open($file);
		}
		
		/*
		* @Params : $file  : file name of excel file to be created.
		* 			if you are using file name with directory i.e. test/myFile.xls
		* 			then the directory must be existed on the system and have permissioned properly
		* 			to write the file.
		* @Return : On Success Valid File Pointer to file
		* 			On Failure return false	 
		*/
		function open($file)
		{
			if($this->state!="CLOSED")
			{
				$this->error="Error : Another file is opend .Close it to save the file";
				return false;
			}	
			
			if(!empty($file))
			{
				$this->fp=@fopen($file,"w+");
			}
			else
			{
				$this->error="Usage : New ExcelWriter('fileName')";
				return false;
			}	
			if($this->fp==false)
			{
				$this->error="Error: Unable to open/create File.You may not have permmsion to write the file.";
				return false;
			}
			$this->state="OPENED";
			fwrite($this->fp,$this->GetHeader());
			return $this->fp;
		}
		
		function close()
		{
			if($this->state!="OPENED")
			{
				$this->error="Error : Please open the file.";
				return false;
			}	
			if($this->newRow)
			{
				fwrite($this->fp,"</tr>");
				$this->newRow=false;
			}
			
			fwrite($this->fp,$this->GetFooter());
			fclose($this->fp);
			$this->state="CLOSED";
			return ;
		}
		/* @Params : Void
		*  @return : Void
		* This function write the header of Excel file.
		*/
		 							
		function GetHeader()
		{
			if ($this->direction == 'rtl')
			{
				$dirTag = 'dir=RTL';
				$xmlTag = '<x:DisplayRightToLeft/>';
			}
			$encoding=$this->encoding;
			$author=$this->author;
			$header = <<<EOH
				<html xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:x="urn:schemas-microsoft-com:office:excel"
				xmlns="http://www.w3.org/TR/REC-html40" $dirTag>

				<head>
				<meta http-equiv=Content-Type content="text/html; charset=$encoding">
				<meta name=ProgId content=Excel.Sheet>
				<!--[if gte mso 9]><xml>
				 <o:DocumentProperties>
				  <o:LastAuthor>$author</o:LastAuthor>
				  <o:LastSaved>2005-01-02T07:46:23Z</o:LastSaved>
				  <o:Version>10.2625</o:Version>
				 </o:DocumentProperties>
				 <o:OfficeDocumentSettings>
				  <o:DownloadComponents/>
				 </o:OfficeDocumentSettings>
				</xml><![endif]-->
				<style>
				<!--table
					{mso-displayed-decimal-separator:"\.";
					mso-displayed-thousand-separator:"\,";}
				@page
					{margin:1.0in .75in 1.0in .75in;
					mso-header-margin:.5in;
					mso-footer-margin:.5in;}
				tr
					{mso-height-source:auto;}
				col
					{mso-width-source:auto;}
				br
					{mso-data-placement:same-cell;}
				.style0
					{mso-number-format:General;
					text-align:general;
					vertical-align:bottom;
					white-space:nowrap;
					mso-rotate:0;
					mso-background-source:auto;
					mso-pattern:auto;
					color:windowtext;
					font-size:10.0pt;
					font-weight:400;
					font-style:normal;
					text-decoration:none;
					font-family:Arial;
					mso-generic-font-family:auto;
					mso-font-charset:0;
					border:none;
					mso-protection:locked visible;
					mso-style-name:Normal;
					mso-style-id:0;}
				td
					{mso-style-parent:style0;
					padding-top:1px;
					padding-right:1px;
					padding-left:1px;
					mso-ignore:padding;
					color:windowtext;
					font-size:10.0pt;
					font-weight:400;
					font-style:normal;
					text-decoration:none;
					font-family:Arial;
					mso-generic-font-family:auto;
					mso-font-charset:0;
					mso-number-format:General;
					text-align:general;
					vertical-align:bottom;
					border:none;
					mso-background-source:auto;
					mso-pattern:auto;
					mso-protection:locked visible;
					white-space:nowrap;
					mso-rotate:0;}
				.xl24
					{mso-style-parent:style0;
					white-space:normal;}
				-->
				</style>
				<!--[if gte mso 9]><xml>
				 <x:ExcelWorkbook>
				  <x:ExcelWorksheets>
				   <x:ExcelWorksheet>
					<x:Name>$author</x:Name>
					<x:WorksheetOptions>
					 <x:Selected/>
					 <x:ProtectContents>False</x:ProtectContents>
					 <x:ProtectObjects>False</x:ProtectObjects>
					 <x:ProtectScenarios>False</x:ProtectScenarios>
					 $xmlTag
					</x:WorksheetOptions>
				   </x:ExcelWorksheet>
				  </x:ExcelWorksheets>
				  <x:WindowHeight>10005</x:WindowHeight>
				  <x:WindowWidth>10005</x:WindowWidth>
				  <x:WindowTopX>120</x:WindowTopX>
				  <x:WindowTopY>135</x:WindowTopY>
				  <x:ProtectStructure>False</x:ProtectStructure>
				  <x:ProtectWindows>False</x:ProtectWindows>
				 </x:ExcelWorkbook>
				</xml><![endif]-->
				</head>

				<body link=blue vlink=purple>
				<table x:str border=0 cellpadding=0 cellspacing=0 style='border-collapse: collapse;table-layout:fixed;'>
EOH;
			return $header;
		}

		function GetFooter()
		{
			return "</table>\r\n</body>\r\n</html>";
		}
		
		/*
		* @Params : $line_arr: An valid array 
		* @Return : Void
		*/
		 
		function writeLine($line_arr)
		{
			if($this->state!="OPENED")
			{
				$this->error="Error : Please open the file.";
				return false;
			}	
			if(!is_array($line_arr))
			{
				$this->error="Error : Argument is not valid. Supply an valid Array.";
				return false;
			}
			fwrite($this->fp,"<tr>\r\n");
			
			if ($this->direction == 'rtl')
				$dirTag = 'dir=RTL';
			
			foreach($line_arr as $col)
				fwrite($this->fp,"<td class=xl24 width=64 ".$dirTag.">$col</td>\r\n");
			fwrite($this->fp,"</tr>\r\n");
		}

		/*
		* @Params : Void
		* @Return : Void
		*/
		function writeRow()
		{
			if($this->state!="OPENED")
			{
				$this->error="Error : Please open the file.";
				return false;
			}	
			if($this->newRow==false)
				fwrite($this->fp,"<tr>");
			else
				fwrite($this->fp,"</tr><tr>");
			$this->newRow=true;	
		}

		/*
		* @Params : $value : Coloumn Value
		* @Return : Void
		*/
		function writeCol($value)
		{
			if($this->state!="OPENED")
			{
				$this->error="Error : Please open the file.";
				return false;
			}	
			if ($this->direction == 'rtl')
				$dirTag = 'dir=RTL';
			
			fwrite($this->fp,"<td class=xl24 width=64 ".$dirTag.">$value</td>");
		}
	}
?>