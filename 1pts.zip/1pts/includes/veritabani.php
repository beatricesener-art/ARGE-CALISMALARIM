<?
		 $db_host = "192.168.1.250"; 
		 $db_user = "remote";  
		 $db_pass = "123123";	
		 $db_name = "otoparksentez";	 	
		 mysql_connect($db_host,$db_user,$db_pass)or die("Veritabanina Ba�lan�lamyor");
		 mysql_select_db($db_name) or die("Veritabanyna Ba�lan�ld� ancak Veritaban� Ad� Se�ilemedi") ;
		 mysql_query("SET NAMES latin1");  
		 mysql_query("SET CHARACTER SET latin1");  
		 mysql_query("SET COLLATION_CONNECTION = latin1_swedish_ci");   
		$saatfarki = "0"; 
	    $farki = (date("H") + ($saatfarki));
		$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
		$tarih = date("Y-m-d",$gerial);
 		$zaman = date("H:i:s",$gerial);
		$ttt=mysql_fetch_array(mysql_query("SELECT * FROM db_siteayar WHERE id=1"));
		$otoparkadi="UCRETLI OTOPARK";
		$vale_URL="http://127.0.0.1/PTS";
		$vale_Kamera_ID='2';
		$vale_sistem_AD='sistem';
		$vale_sistem_Parola='123123';
		$vale_Sebep="VALE CIKIS";
		$MAKS_CIKIS_SURESI=30;
		$VALE_SISTEM_AKTIF=1;
		$UCRETSIZ_OTO_CIKIS=1;
		$TEK_KAPI_GIRIS_CIKIS=0;
		$GIRIS_LOG_TIMEOUT=10;
		$GUNLUK_ZAMAN_LIMIT_DK=60; //tan�ml� s�re i�in gir - ��k ile �cretsiz s�re varsa kullanabilir
		$UCRETIZ_SAAT=1; //3 saatte kadar ucretsiz olabilir. istenen �cretsiz
		$ABONE_ARAC_ESZAMANLI=0; // abonelik durumuda, e� zamanl� abonelik kullan�m�
		$MAKS_ARAC_SAYISI=5000;



		?>