<?php
define('OTOPARK_NAME1','OTOPARKIMIZ');
define('OTOPARK_NAME2','HAYIRLI YOLCULUKLAR DILER');
define('OTOPARK_NAME3','OTOPARK PTS SISTEMI');
define('OTOPARK_NAME4','PLAKA');
define('OTOPARK_NAME5','-- Z RAPORU --');
include_once("includes/pdf.class.inc.php");
function wsfWritePdf($sqlQuery,$filePath=null,$headers=null,$orient='p',$outType='I')
{
        global $_GET;
        $sqlQueryResult = mysql_query($sqlQuery);
        $between = explode('BETWEEN', $sqlQuery);
        $between = explode('ORDER', $between[1]);
        $sqlQueryResArac =  mysql_query("SELECT count(*) as `icerde` FROM `db_araclar` where `aracKonum` ='i' limit 0,1");
        $rowArac = mysql_fetch_assoc($sqlQueryResArac );
        $icerdeArac = $rowArac['icerde'];

    //    $sqlQueryResAracCikis =  mysql_query("SELECT count(*) as `cikisyapan` FROM `db_odemeler` where `tarihzaman` BETWEEN {$between[0]} AND `status`<> 1 AND `status`<> 2   limit 0,1");
    //    $rowAracCikis = mysql_fetch_assoc($sqlQueryResAracCikis);
    //    $cikanArac = $rowAracCikis['cikisyapan'];

	if ($sqlQueryResult!==false){
			while ($rowItem = mysql_fetch_assoc($sqlQueryResult)) {
				$rows[]=$rowItem;
                                                                        $_GET['userName'] = $rowItem['userName'];
			}
	}
	
//                $filePath = "odemePDF/".date().".pdf";
                 $asd = time();
                $filePath = "odemePDF/".$asd.".pdf";
	if(is_null($filePath))
	{
		if(is_array($rows))
			$filePath = 'odemePDF/'.$_GET['userName'].".pdf";
		else
			$filePath = "odemePDF/myPdf.pdf";
	} 
	ob_clean();

	$pdf=new FPDF($orient);
	$pdf->AddPage();

	$pdf->SetFont('times','B',14);
	$pdf->Image('images/watermak.gif',10,8,20);
	$pdf->Cell(80);
	$pdf->Cell(80);
	$pdf->Cell(80);
	$pdf->Cell(0,9,'',0,1,'C');
	$pdf->Cell(0,9,cpfStringtoNormal(OTOPARK_NAME1),0,1,'C');
	$pdf->Cell(0,9,cpfStringtoNormal(OTOPARK_NAME2),0,1,'C');
	$pdf->Cell(0,9,cpfStringtoNormal(OTOPARK_NAME3),0,1,'C');
	$pdf->Cell(0,9,cpfStringtoNormal(OTOPARK_NAME4),0,1,'C');
	$pdf->Cell(0,9,cpfStringtoNormal(OTOPARK_NAME5),0,1,'C');
	$pdf->Cell(0,9,cpfStringtoNormal("�deme Noktas�: \t".$_GET['odemenokta']."\t Gorevli : \t".$_GET['ad']."\t\t".$_GET['soyad']),0,1,'L');
	$pdf->Cell(0,9,"Bas [".$_GET['start']."]",0,1,'L');
	$pdf->Cell(0,9,"Bitis [".$_GET['end']."]",0,1,'L');
	$pdf->Ln(20);
	if(is_array($rows))
	{
		if(is_null($headers) && !$_GET['is_short'] )
		{
			foreach($rows[0] as $colName=>$colValue)
					$headers[]=$colName;
            //$pdf->Cell(0,9,cpfStringtoNormal(implode("\t|\t",$headers)),1,1,'L');
            $pdf->Cell(0,9,cpfStringtoNormal("ID  ODENEN  TARIH-ZAMAN  PLAKA  A.SURE"),1,1,'L');
		    $pdf->Ln(1);
		    $pdf->SetFont('times','B',14);
		}
				$uretilen = 0;
				$odenen = 0;
				$edilmemis = 0;
				$ucretliArac = 0;
				$ucretsizArac  = 0;
				$abonelikSayisi  = 0;
				$abonelikOcret  = 0;
				$abonelikDegeri  = 50;
                $cikanArac = 0;
			foreach($rows as $row)
			{
				unset($myArr);
				$myArr = $row;
				$uretilen += $row['borc'];
                                                                       if($row['status']==1){
                                                                           $ucretliArac +=1;
                                                                       }
                                                                       if($row['status']==2){
                                                                           $ucretsizArac +=1;
                                                                       }
                                                                       if(!$row['status'] && $row['abonesure']==0){
                                                                           $cikanArac +=1;
                                                                       }
                                                                       if($row['abonesure']>0){
                                                                           $abonelikSayisi +=1;
                                                                           $abonelikOcret +=$row['odenen'];
                                                                       }
				$uretilen += $row['borc'];
				$odenen += $row['odenen'];
				$edilmemis += ($row['borc']-$row['odenen']);
				if(!$_GET['is_short']){
					//$pdf->Cell(0,9,cpfStringtoNormal(implode("\t|\t",$myArr)),1,1,'L');
                    $pdf->Cell(0,9,cpfStringtoNormal("\t{$row['id']} - \t{$row['odenen']} - \t{$row['tarihzaman']} - \t{$row['plaka']} - \t{$row['abonesure']}"),1,1,'L');
				}
			}
$otoparkUcret = $odenen-$abonelikOcret;
				$pdf->Cell(0,9,cpfStringtoNormal("Iptal Edilen Arac Odemesi: \t{$cikanArac}"),0,1,'L');
				$pdf->Cell(0,9,cpfStringtoNormal("Otopark Ucreti :\t{$otoparkUcret}  TL"),0,1,'L');
				$pdf->Cell(0,9,cpfStringtoNormal("Toplam Arac sayisi :\t {$icerdeArac}"),0,1,'L');
				$pdf->Cell(0,9,cpfStringtoNormal("Yeni Abonelik sayisi :\t {$abonelikSayisi}"),0,1,'L');
				$pdf->Cell(0,9,cpfStringtoNormal("Abonelik Ucret:\t {$abonelikOcret}  TL"),0,1,'L');
				$pdf->Cell(0,9,cpfStringtoNormal("�cretli Arac Sayisi :\t {$ucretliArac}"),0,1,'L');
				$pdf->Cell(0,9,cpfStringtoNormal("Tanimsiz & Ucretsiz Arac :\t {$ucretsizArac}"),0,1,'L');
				$pdf->Cell(0,9,"",0,1,'L');
				
				$pdf->Cell(0,9,cpfStringtoNormal("TOPLAM �DENEN M�KTAR:{$odenen}  TL"),0,1,'L');
//				$pdf->Cell(0,9,cpfStringtoNormal("TOPLAM �RET�LEN M�KTAR:\t{$uretilen}"),0,1,'L');
		 $pdf->Output($filePath,$outType);
		
	}	
if('F'==$outType)
    return $filePath;
else
    download($filePath);

	
}
//function wsfWritePdf($sqlQuery,$filePath=null,$headers=null,$orient='p')
//{
//	global $_GET;
//	$sqlQueryResult = mysql_query($sqlQuery);
//
//	if ($sqlQueryResult!==false){
//			while ($rowItem = mysql_fetch_array($sqlQueryResult,MYSQL_ASSOC)) {
//				$rows[]=$rowItem;
//			}
//	}
//	
//	if(is_null($filePath))
//	{
//		if(is_array($rows))
//			$filePath = 'odemePDF/'.$_GET['userName'].".pdf";
//		else
//			$filePath = "odemePDF/myPdf.pdf";
//	} 
//	ob_clean();
//	$pdf=new FPDF($orient);
//	$pdf->AddPage();
//
//	$pdf->SetFont('times','B',14);
//	$pdf->Image('images/watermak.gif',10,8,20);
//	$pdf->Cell(80);
//	$pdf->Cell(80);
//	$pdf->Cell(0,9,cpfStringtoNormal($_GET['ad']."\t\t".$_GET['soyad']),1,1,'C');
//	$pdf->Cell(0,9,$_GET['start']."\t\t".$_GET['end'],1,1,'C');
//	$pdf->Ln(30);
//	if(is_array($rows))
//	{
//		if(is_null($headers) && !$_GET['is_short'] )
//		{
//			foreach($rows[0] as $colName=>$colValue)
//					$headers[]=$colName;
//		$pdf->Cell(0,10,cpfStringtoNormal(implode("\t|\t",$headers)),1,1,'C');
//		$pdf->Ln(1);
//		$pdf->SetFont('times','B',14);
//		}
//				$uretilen = 0;
//				$odenen = 0;
//				$edilmemis = 0;
//
//			foreach($rows as $row)
//			{
//				unset($myArr);
//				$myArr = $row;
//				$uretilen += $row['borc'];
//				$odenen += $row['odenen'];
//				$edilmemis += ($row['borc']-$row['odenen']);
//				if(!$_GET['is_short']){
//					$pdf->Cell(0,9,cpfStringtoNormal(implode("\t|\t",$myArr)),1,1,'C');
//				}
//			}
//
//				$pdf->Cell(0,9,cpfStringtoNormal("TOPLAM �RET�LEN M�KTAR:{$uretilen}"),1,1,'C');
//				$pdf->Cell(0,9,cpfStringtoNormal("TOPLAM �DENEN M�KTAR:{$odenen}"),1,1,'C');
//				$pdf->Cell(0,9,cpfStringtoNormal("TOPLAM TAHS�L ED�LMEM�� M�KTAR:{$edilmemis}"),1,1,'C');
//		$pdf->Output($filePath,'I');
//		
//	}	
//
//	//ob_clean();
//	download($filePath);
//	
//}
function cpfStringtoNormal($s)
{
	$needle = array('�','�','�','�','�','I','�','�','�','�','�','�','�');
	$replace = array('c','C','g','G','i','I','I','o','O','s','S','u','U');
	return str_replace($needle,$replace,$s);
}
function download($file,$customName=null)
{
    //First, see if the file exists
    if (!is_file($file)) { die("<b>404 File not found!</b>"); }
    //Gather relevent info about file
    $len = filesize($file);
    $filename = basename($file);
    $file_extension = strtolower(substr(strrchr($filename,"."),1));

    if (!is_null($customName)) {
        $filename=$customName;
        }

    //This will set the Content-Type to the appropriate setting for the file
    switch( $file_extension )
    {
        case "pdf": $ctype="application/pdf"; break;
        default: $ctype="application/force-download";
    }

    //Begin writing headers
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: public");
    header("Content-Description: File Transfer");

    //Use the switch-generated Content-Type
    header("Content-Type: $ctype");
    //Force the download


    $header="Content-Disposition: attachment; filename=".$filename.";";
    header($header );
    header("Content-Transfer-Encoding: binary");
    header("Content-Length: ".$len);
    @readfile($file);
    exit;
}
	?>