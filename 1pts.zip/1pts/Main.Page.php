<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type><LINK 
rel=stylesheet type=text/css 
href="stil.css"><LINK rel=stylesheet 
type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>

<META name=GENERATOR content="MSHTML 8.00.7600.16466"></HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
  <CAPTION align=top>
  <DIV class=headspot align=right>Okan1 Civelek1 <IMG border=0 alt=kullan�c� 
  src="images/icon_kullanici.png"> 
  </DIV></CAPTION>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top>
      <DIV class=solmenu><NOBR><IMG style="VERTICAL-ALIGN: middle" border=0 
      alt="Bilgilerimi D�zenle" 
      src="images/icon_kisi.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/bilgiduzenle.php">Bilgilerimi 
      D�zenle</A></NOBR><BR><NOBR><IMG style="VERTICAL-ALIGN: middle" border=0 
      alt=Duyurular 
      src="images/icon_duyuru.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/duyurular.php">Duyurular</A></NOBR><BR><NOBR><IMG 
      style="VERTICAL-ALIGN: middle" border=0 alt="Ara� Tan�mlama" 
      src="images/icon_arac.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/aractanimla.php">Ara�lar�m</A></NOBR><BR><NOBR><IMG 
      style="VERTICAL-ALIGN: middle" border=0 alt="Ara� S�n�rland�rma" 
      src="images/icon_arac.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/aracsinirlandirma.php">Ara� 
      S�n�rland�rma</A></NOBR><BR><NOBR><IMG style="VERTICAL-ALIGN: middle" 
      border=0 alt="Misafir Tan�mlama" 
      src="images/icon_misafir.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/misafirtanimla.php">Misafirlerim</A></NOBR><BR><NOBR><IMG 
      style="VERTICAL-ALIGN: middle" border=0 alt="Kara Liste" 
      src="images/icon_karaliste.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/karaliste.php">Kara 
      Liste</A></NOBR><BR><NOBR><IMG style="VERTICAL-ALIGN: middle" border=0 
      alt="Teknik Servis Talebi" 
      src="images/icon_teknikservis.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/teknikservis.php">Teknik Servis 
      �stiyorum</A></NOBR><BR><NOBR><IMG style="VERTICAL-ALIGN: middle" border=0 
      alt="Dilek ve �ikayetler" 
      src="images/icon_dilek.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/dilekvesikayet.php">Dilek ve 
      �ikayet Bildir</A></NOBR><BR><NOBR><IMG style="VERTICAL-ALIGN: middle" 
      border=0 alt=Raporlar 
      src="images/icon_rapor.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/rapor.php">Rapor</A></NOBR><BR><BR><BR><NOBR><IMG 
      style="VERTICAL-ALIGN: middle" border=0 alt=Duyurular 
      src="images/icon_logout.jpg"><A 
      href="http://www.noron.com.tr/plakatanima/cikis.php">��k�� Yap</A></NOBR> 
      </DIV></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
      <FORM method=post name=misafirtanimla action=misafirtanimla.php><INPUT 
      type=hidden name=pl> 
      <TABLE class=ictablo width=570>
        <TBODY>
        <TR>
          <TH colSpan=2>Misafir Ekle</TH></TR>
        <TR>
          <TD style="COLOR: red" colSpan=2 align=middle></TD></TR>
        <TR>
          <TD width="40%" align=right>Misafir Ad� Soyad� :</TD>
          <TD><INPUT class=text_input name=misAdSoyad></TD></TR>
        <TR>
          <TD width="40%" align=right>Ara� Plakas� :</TD>
          <TD><INPUT class=text_input name=misPlaka></TD></TR>
        <TR>
          <TD width="40%" align=right>Ara� Markas� :</TD>
          <TD><INPUT class=text_input name=misMarka></TD></TR>
        <TR>
          <TD width="40%" align=right>Ara� Modeli :</TD>
          <TD><INPUT class=text_input name=misModel></TD></TR>
        <TR>
          <TD width="40%" align=right>Ara� Rengi :</TD>
          <TD><INPUT class=text_input name=misRenk></TD></TR>
        <TR>
          <TD align=right>Misafir T�r� :</TD>
          <TD><SELECT id=turu onchange=misafirGoster() name=turu> <OPTION 
              selected value=dm>Daimi Misafir</OPTION> <OPTION value=gm>Tek 
              Seferlik Misafir</OPTION></SELECT> </TD></TR>
        <TR>
          <TD colSpan=2>
            <DIV style="DISPLAY: none" id=divDM>
            <TABLE class=ictablo width="100%">
              <TBODY>
              <TR>
                <TD width="20%" align=right>G�nler :</TD>
                <TD><LABEL><INPUT id=izinliGunler[] value=1 type=checkbox 
                  name=izinliGunler[]>Pazartesi</LABEL> <LABEL><INPUT 
                  id=izinliGunler[] value=2 type=checkbox 
                  name=izinliGunler[]>Sal�</LABEL> <LABEL><INPUT 
                  id=izinliGunler[] value=3 type=checkbox 
                  name=izinliGunler[]>�ar�amba</LABEL> <LABEL><INPUT 
                  id=izinliGunler[] value=4 type=checkbox 
                  name=izinliGunler[]>Per�embe</LABEL> <LABEL><INPUT 
                  id=izinliGunler[] value=5 type=checkbox 
                  name=izinliGunler[]>Cuma</LABEL> <LABEL><INPUT 
                  id=izinliGunler[] value=6 type=checkbox 
                  name=izinliGunler[]>Cumartesi</LABEL> <LABEL><INPUT 
                  id=izinliGunler[] value=7 type=checkbox 
                  name=izinliGunler[]>Pazar</LABEL> </TD></TR></TBODY></TABLE></DIV>
            <DIV style="DISPLAY: none" id=divGM>
            <TABLE class=ictablo width="100%">
              <TBODY>
              <TR>
                <TD width="40%" align=right>Tarih :</TD>
                <TD><INPUT style="WIDTH: 75px" id=tarih value=14-12-2009 
                  readOnly maxLength=10 name=tarih> <A 
                  onclick="document.getElementById('div_tarih').style.display='inline'" 
                  href="javascript:void(0)"><IMG title="Tarih Se�" border=0 
                  alt="Calendar.jpg, 0 kB" 
                  src="images/Calendar.jpg" 
                  width=15 height=15></A> 
                  <DIV 
                  style="Z-INDEX: 2; POSITION: absolute; FILTER: alpha(opacity=80); DISPLAY: none; BACKGROUND: #ffffff" 
                  id=div_tarih><IFRAME id=takvim height=210 
                  src="images/takvim.htm" 
                  frameBorder=no width=200 scrolling=no></IFRAME></DIV></TD></TR>
              <TR>
                <TD width="40%" align=right>Saat :</TD>
                <TD><SELECT name=saat1> <OPTION selected 
                    value=00:00>00:00</OPTION> <OPTION 
                    value=00:15>00:15</OPTION> <OPTION 
                    value=00:30>00:30</OPTION> <OPTION 
                    value=00:45>00:45</OPTION> <OPTION 
                    value=01:00>01:00</OPTION> <OPTION 
                    value=01:15>01:15</OPTION> <OPTION 
                    value=01:30>01:30</OPTION> <OPTION 
                    value=01:45>01:45</OPTION> <OPTION 
                    value=02:00>02:00</OPTION> <OPTION 
                    value=02:15>02:15</OPTION> <OPTION 
                    value=02:30>02:30</OPTION> <OPTION 
                    value=02:45>02:45</OPTION> <OPTION 
                    value=03:00>03:00</OPTION> <OPTION 
                    value=03:15>03:15</OPTION> <OPTION 
                    value=03:30>03:30</OPTION> <OPTION 
                    value=03:45>03:45</OPTION> <OPTION 
                    value=04:00>04:00</OPTION> <OPTION 
                    value=04:15>04:15</OPTION> <OPTION 
                    value=04:30>04:30</OPTION> <OPTION 
                    value=04:45>04:45</OPTION> <OPTION 
                    value=05:00>05:00</OPTION> <OPTION 
                    value=05:15>05:15</OPTION> <OPTION 
                    value=05:30>05:30</OPTION> <OPTION 
                    value=05:45>05:45</OPTION> <OPTION 
                    value=06:00>06:00</OPTION> <OPTION 
                    value=06:15>06:15</OPTION> <OPTION 
                    value=06:30>06:30</OPTION> <OPTION 
                    value=06:45>06:45</OPTION> <OPTION 
                    value=07:00>07:00</OPTION> <OPTION 
                    value=07:15>07:15</OPTION> <OPTION 
                    value=07:30>07:30</OPTION> <OPTION 
                    value=07:45>07:45</OPTION> <OPTION 
                    value=08:00>08:00</OPTION> <OPTION 
                    value=08:15>08:15</OPTION> <OPTION 
                    value=08:30>08:30</OPTION> <OPTION 
                    value=08:45>08:45</OPTION> <OPTION 
                    value=09:00>09:00</OPTION> <OPTION 
                    value=09:15>09:15</OPTION> <OPTION 
                    value=09:30>09:30</OPTION> <OPTION 
                    value=09:45>09:45</OPTION> <OPTION 
                    value=10:00>10:00</OPTION> <OPTION 
                    value=10:15>10:15</OPTION> <OPTION 
                    value=10:30>10:30</OPTION> <OPTION 
                    value=10:45>10:45</OPTION> <OPTION 
                    value=11:00>11:00</OPTION> <OPTION 
                    value=11:15>11:15</OPTION> <OPTION 
                    value=11:30>11:30</OPTION> <OPTION 
                    value=11:45>11:45</OPTION> <OPTION 
                    value=12:00>12:00</OPTION> <OPTION 
                    value=12:15>12:15</OPTION> <OPTION 
                    value=12:30>12:30</OPTION> <OPTION 
                    value=12:45>12:45</OPTION> <OPTION 
                    value=13:00>13:00</OPTION> <OPTION 
                    value=13:15>13:15</OPTION> <OPTION 
                    value=13:30>13:30</OPTION> <OPTION 
                    value=13:45>13:45</OPTION> <OPTION 
                    value=14:00>14:00</OPTION> <OPTION 
                    value=14:15>14:15</OPTION> <OPTION 
                    value=14:30>14:30</OPTION> <OPTION 
                    value=14:45>14:45</OPTION> <OPTION 
                    value=15:00>15:00</OPTION> <OPTION 
                    value=15:15>15:15</OPTION> <OPTION 
                    value=15:30>15:30</OPTION> <OPTION 
                    value=15:45>15:45</OPTION> <OPTION 
                    value=16:00>16:00</OPTION> <OPTION 
                    value=16:15>16:15</OPTION> <OPTION 
                    value=16:30>16:30</OPTION> <OPTION 
                    value=16:45>16:45</OPTION> <OPTION 
                    value=17:00>17:00</OPTION> <OPTION 
                    value=17:15>17:15</OPTION> <OPTION 
                    value=17:30>17:30</OPTION> <OPTION 
                    value=17:45>17:45</OPTION> <OPTION 
                    value=18:00>18:00</OPTION> <OPTION 
                    value=18:15>18:15</OPTION> <OPTION 
                    value=18:30>18:30</OPTION> <OPTION 
                    value=18:45>18:45</OPTION> <OPTION 
                    value=19:00>19:00</OPTION> <OPTION 
                    value=19:15>19:15</OPTION> <OPTION 
                    value=19:30>19:30</OPTION> <OPTION 
                    value=19:45>19:45</OPTION> <OPTION 
                    value=20:00>20:00</OPTION> <OPTION 
                    value=20:15>20:15</OPTION> <OPTION 
                    value=20:30>20:30</OPTION> <OPTION 
                    value=20:45>20:45</OPTION> <OPTION 
                    value=21:00>21:00</OPTION> <OPTION 
                    value=21:15>21:15</OPTION> <OPTION 
                    value=21:30>21:30</OPTION> <OPTION 
                    value=21:45>21:45</OPTION> <OPTION 
                    value=22:00>22:00</OPTION> <OPTION 
                    value=22:15>22:15</OPTION> <OPTION 
                    value=22:30>22:30</OPTION> <OPTION 
                    value=22:45>22:45</OPTION> <OPTION 
                    value=23:00>23:00</OPTION> <OPTION 
                    value=23:15>23:15</OPTION> <OPTION 
                    value=23:30>23:30</OPTION> <OPTION 
                  value=23:45>23:45</OPTION></SELECT> <SELECT name=saat2> 
                    <OPTION selected value=00:00>00:00</OPTION> <OPTION 
                    value=00:15>00:15</OPTION> <OPTION 
                    value=00:30>00:30</OPTION> <OPTION 
                    value=00:45>00:45</OPTION> <OPTION 
                    value=01:00>01:00</OPTION> <OPTION 
                    value=01:15>01:15</OPTION> <OPTION 
                    value=01:30>01:30</OPTION> <OPTION 
                    value=01:45>01:45</OPTION> <OPTION 
                    value=02:00>02:00</OPTION> <OPTION 
                    value=02:15>02:15</OPTION> <OPTION 
                    value=02:30>02:30</OPTION> <OPTION 
                    value=02:45>02:45</OPTION> <OPTION 
                    value=03:00>03:00</OPTION> <OPTION 
                    value=03:15>03:15</OPTION> <OPTION 
                    value=03:30>03:30</OPTION> <OPTION 
                    value=03:45>03:45</OPTION> <OPTION 
                    value=04:00>04:00</OPTION> <OPTION 
                    value=04:15>04:15</OPTION> <OPTION 
                    value=04:30>04:30</OPTION> <OPTION 
                    value=04:45>04:45</OPTION> <OPTION 
                    value=05:00>05:00</OPTION> <OPTION 
                    value=05:15>05:15</OPTION> <OPTION 
                    value=05:30>05:30</OPTION> <OPTION 
                    value=05:45>05:45</OPTION> <OPTION 
                    value=06:00>06:00</OPTION> <OPTION 
                    value=06:15>06:15</OPTION> <OPTION 
                    value=06:30>06:30</OPTION> <OPTION 
                    value=06:45>06:45</OPTION> <OPTION 
                    value=07:00>07:00</OPTION> <OPTION 
                    value=07:15>07:15</OPTION> <OPTION 
                    value=07:30>07:30</OPTION> <OPTION 
                    value=07:45>07:45</OPTION> <OPTION 
                    value=08:00>08:00</OPTION> <OPTION 
                    value=08:15>08:15</OPTION> <OPTION 
                    value=08:30>08:30</OPTION> <OPTION 
                    value=08:45>08:45</OPTION> <OPTION 
                    value=09:00>09:00</OPTION> <OPTION 
                    value=09:15>09:15</OPTION> <OPTION 
                    value=09:30>09:30</OPTION> <OPTION 
                    value=09:45>09:45</OPTION> <OPTION 
                    value=10:00>10:00</OPTION> <OPTION 
                    value=10:15>10:15</OPTION> <OPTION 
                    value=10:30>10:30</OPTION> <OPTION 
                    value=10:45>10:45</OPTION> <OPTION 
                    value=11:00>11:00</OPTION> <OPTION 
                    value=11:15>11:15</OPTION> <OPTION 
                    value=11:30>11:30</OPTION> <OPTION 
                    value=11:45>11:45</OPTION> <OPTION 
                    value=12:00>12:00</OPTION> <OPTION 
                    value=12:15>12:15</OPTION> <OPTION 
                    value=12:30>12:30</OPTION> <OPTION 
                    value=12:45>12:45</OPTION> <OPTION 
                    value=13:00>13:00</OPTION> <OPTION 
                    value=13:15>13:15</OPTION> <OPTION 
                    value=13:30>13:30</OPTION> <OPTION 
                    value=13:45>13:45</OPTION> <OPTION 
                    value=14:00>14:00</OPTION> <OPTION 
                    value=14:15>14:15</OPTION> <OPTION 
                    value=14:30>14:30</OPTION> <OPTION 
                    value=14:45>14:45</OPTION> <OPTION 
                    value=15:00>15:00</OPTION> <OPTION 
                    value=15:15>15:15</OPTION> <OPTION 
                    value=15:30>15:30</OPTION> <OPTION 
                    value=15:45>15:45</OPTION> <OPTION 
                    value=16:00>16:00</OPTION> <OPTION 
                    value=16:15>16:15</OPTION> <OPTION 
                    value=16:30>16:30</OPTION> <OPTION 
                    value=16:45>16:45</OPTION> <OPTION 
                    value=17:00>17:00</OPTION> <OPTION 
                    value=17:15>17:15</OPTION> <OPTION 
                    value=17:30>17:30</OPTION> <OPTION 
                    value=17:45>17:45</OPTION> <OPTION 
                    value=18:00>18:00</OPTION> <OPTION 
                    value=18:15>18:15</OPTION> <OPTION 
                    value=18:30>18:30</OPTION> <OPTION 
                    value=18:45>18:45</OPTION> <OPTION 
                    value=19:00>19:00</OPTION> <OPTION 
                    value=19:15>19:15</OPTION> <OPTION 
                    value=19:30>19:30</OPTION> <OPTION 
                    value=19:45>19:45</OPTION> <OPTION 
                    value=20:00>20:00</OPTION> <OPTION 
                    value=20:15>20:15</OPTION> <OPTION 
                    value=20:30>20:30</OPTION> <OPTION 
                    value=20:45>20:45</OPTION> <OPTION 
                    value=21:00>21:00</OPTION> <OPTION 
                    value=21:15>21:15</OPTION> <OPTION 
                    value=21:30>21:30</OPTION> <OPTION 
                    value=21:45>21:45</OPTION> <OPTION 
                    value=22:00>22:00</OPTION> <OPTION 
                    value=22:15>22:15</OPTION> <OPTION 
                    value=22:30>22:30</OPTION> <OPTION 
                    value=22:45>22:45</OPTION> <OPTION 
                    value=23:00>23:00</OPTION> <OPTION 
                    value=23:15>23:15</OPTION> <OPTION 
                    value=23:30>23:30</OPTION> <OPTION 
                  value=23:45>23:45</OPTION></SELECT> 
            aras�nda</TD></TR></TBODY></TABLE></DIV></TD>
        <TR>
        <TR>
          <TD width="40%" align=right>Not :</TD>
          <TD><TEXTAREA rows=7 cols=27 name=misNotlar></TEXTAREA></TD></TR>
        <TR>
          <TD width="40%" align=right></TD>
          <TD><INPUT class=button value=Ekle type=submit name=ekle>&nbsp; 
        </TD></TR></TBODY></TABLE></FORM>
      <H2>Misafirleriniz</H2>
      <TABLE class=ictablo width=570>
        <TBODY>
        <TR>
          <TH>Plaka</TH>
          <TH>Misafir Adi</TH>
          <TH>Marka</TH>
          <TH>Model</TH>
          <TH>Renk</TH>
          <TH>��lemler</TH></TR>
        <TR>
          <TD>111</TD>
          <TD>Okan</TD>
          <TD>111</TD>
          <TD>111</TD>
          <TD>111</TD>
          <TD align=middle>
            <FORM method=post><INPUT value=111 type=hidden name=pl><INPUT class=button value=D�zenle type=submit name=detay></FORM></TD></TR>
        <TR>
          <TD>34MI2000</TD>
          <TD>misafir1</TD>
          <TD>ASD</TD>
          <TD>SAD</TD>
          <TD>asdsad</TD>
          <TD align=middle>
            <FORM method=post><INPUT value=34MI2000 type=hidden name=pl><INPUT class=button value=D�zenle type=submit name=detay></FORM></TD></TR>
        <TR>
          <TD>34MI2001</TD>
          <TD>miaF�R1</TD>
          <TD>DSD</TD>
          <TD>SD</TD>
          <TD>wewe</TD>
          <TD align=middle>
            <FORM method=post><INPUT value=34MI2001 type=hidden name=pl><INPUT class=button value=D�zenle type=submit name=detay></FORM></TD></TR></TBODY></TABLE>
      <SCRIPT language=javasciprt type=text/javascript>misafirGoster()</SCRIPT>
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right>Interface Programming by 
  Teknoart</TD></TR></TBODY></TABLE></BODY></HTML>
