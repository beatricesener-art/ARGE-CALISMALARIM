function GetXmlHttpObject(){
  xHRObject = false;
  if (window.XMLHttpRequest){
    xHRObject = new XMLHttpRequest();
  }
  else if (window.ActiveXObject){
    xHRObject = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xHRObject;
}
  
function blok(deger){
  xmlHttp=GetXmlHttpObject();
  if (xmlHttp){
    var url="bolumler.php?t=b";
    url=url+"&b="+deger;
    //alert(url);
    xmlHttp.open("GET",url,true);
    xmlHttp.onreadystatechange=goster;
    xmlHttp.send(null);
  }    
}
function katlar(deger){
  xmlHttp=GetXmlHttpObject();
  if (xmlHttp){
    var url="bolumler.php?t=k";
    url=url+"&k="+deger;
    //alert(url);
    xmlHttp.open("GET",url,true);
    xmlHttp.onreadystatechange=goster2;
    xmlHttp.send(null);
  }    
}
function daireler(deger){
  xmlHttp=GetXmlHttpObject();
  if (xmlHttp){
    var url="bolumler.php?t=d";
    url=url+"&d="+deger;
    alert(url);
    xmlHttp.open("GET",url,true);
    xmlHttp.onreadystatechange=goster3;
    xmlHttp.send(null);
  }    
}

function goster(){
  if (xmlHttp.readyState==4){
    document.getElementById('divbolum').innerHTML=xmlHttp.responseText;
  }
}  

function goster2(){
  if (xmlHttp.readyState==4){
    document.getElementById('divbolum2').innerHTML=xmlHttp.responseText;
  }
} 
function goster3(){
  if (xmlHttp.readyState==4){
    document.getElementById('divbolum3').innerHTML=xmlHttp.responseText;
  }
} 
