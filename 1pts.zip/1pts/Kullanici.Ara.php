<?
include_once("includes/Sayfalama.Fonk.php");
include_once("Guvenlik.Filtre.php");

//*****************************************//
//**********PCC ELEKTRON�K*****************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//
function degistir($deger) { 
$bul = array('u','i','c','o','s','g','U','�','C','O','S','G'); 
$degis = array('�','i','�','�','�','�','�','i','�','�','�','�'); 
$gonder = str_replace($bul, $degis, $deger);
return $gonder;
}
function degistir2($deger) { 
$bul = array('u','i','c','o','s','g','U','�','C','O','S','G'); 
$degis = array('�','i','�','�','�','�','�','i','�','�','�','�'); 
$gonder = str_replace($degis, $bul, $deger);
return $gonder;
}


//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];

$tablo = "select * from db_super_users where username='$user' and password='$sifre' and (yetki='1' or yetki='4' or yetki='2')"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$KID=trim(mysql_real_escape_string($_GET['KID']));
$KID2=trim(mysql_real_escape_string($_POST['KID']));


$ekle=mysql_real_escape_string($_['ekle']);
$a1=trim(mysql_real_escape_string($_GET['a1']));
$a2=trim(mysql_real_escape_string($_GET['a2']));
$a3=trim(mysql_real_escape_string($_GET['a3']));
$a4=trim(mysql_real_escape_string($_GET['a4']));
$a5=trim(mysql_real_escape_string($_GET['a5']));
$a6=trim(mysql_real_escape_string($_GET['a6']));
$a7=trim(mysql_real_escape_string($_GET['a7']));





if($_GET['Temizle']=="Temizle"){

@header("Location: Kullanici.Ara.php?Temizlendi");
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>

<META name=GENERATOR content="MSHTML 8.00.7600.16466"></HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
      <FORM method=get name=misafirtanimla action=Kullanici.Ara.php>
      <INPUT 
      type="hidden" name="ekle" value="duzenle">
       <INPUT 
      type="hidden" name="KID" value="<? echo $KID; ?>">
        <TABLE class=ictablo width=605>
          <TBODY>
            <TR>
              <TH colSpan=2>Kullan�c� Arama</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>�sim:</TD>
              <TD><INPUT name=a1 class=text_input value="<? echo $a1; ?>"  id="a1"></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Soyisim:</TD>
              <TD><INPUT name=a2 class=text_input value="<? echo $a2; ?>"  id="a2"></TD>
            </TR>
            <TR>
              <TD align=right>E-mail Adresi</TD>
              <TD><INPUT name=a6 class=text_input id="a6" value="<? echo $a6; ?>" ></TD>
            </TR>
            <TR>
              <TD width="40%" align=right></TD>
              <TD><INPUT class=button value=Ara type=submit name=Ara>
                &nbsp; <INPUT class=button value=Temizle type=submit name=Temizle id="Temizle"></TD>
            </TR>
          </TBODY>
        </TABLE>
        <H2>Bulunan Kullan�c�lar</H2>
        <TABLE class=ictablo width=607>
          <TBODY>
              <TR>
              <TH width="30" height="31"><div align="center">#ID</div></TH>
              <TH width="103"><div align="center">Ad�</div></TH>
              <TH width="74"><div align="center">Soyad�</div></TH>
              <TH width="67"><div align="center">Ara� Say�s�</div></TH>
              <TH width="55"><div align="center">Max Ara�</div></TH>
              <TH width="148"><div align="center"></div></TH>
              <TH width="98">��lemler</TH>
            </TR>
            
<?
$a1=trim(mysql_real_escape_string($_GET['a1']));
$a2=trim(mysql_real_escape_string($_GET['a2']));
$a3=trim(mysql_real_escape_string($_GET['a3']));
$a4=trim(mysql_real_escape_string($_GET['a4']));
$a5=trim(mysql_real_escape_string($_GET['a5']));
$a6=trim(mysql_real_escape_string($_GET['a6']));
$a7=trim(mysql_real_escape_string($_GET['a7']));
//echo degistir2($a1);
	$kosul='';
	if($a1>' '){$kosul = $kosul. ' and kAdi LIKE \'%'.$a1.'%\' OR kAdi LIKE \'%'.degistir($a1).'%\''  ;}
	if($a2>' '){$kosul = $kosul. ' and kSoyadi LIKE \'%'.$a2.'%\'' ;}

	if($a6>' '){$kosul = $kosul. ' and kMail LIKE \'%'.$a6.'%\'' ;}

//	$sorgu = "select * FROM db_uyeler WHERE id>0 " . $kosul;
$ara=trim($_GET['Ara']);
if($ara=="Ara"){
$tablo2="SELECT * FROM db_musteriler WHERE id>0 ". $kosul;
}else{
$tablo2="SELECT * FROM db_musteriler WHERE id<0 ". $kosul;
}

if(($a1<' ')&&($a2<' ')&&($a6<' ')&&($a7<' ')&&($a3=="0")&&($a4=="0")&&($a5=="0")){
	
	$tablo2="SELECT * FROM db_musteriler WHERE id<0 ". $kosul;

}
//echo $tablo2;
#######################################################################
$TABLOM22="SELECT * FROM db_musteriler ".$join_ek." WHERE db_musteriler.id>0 ". $kosul. " ORDER BY db_musteriler.id";

$sorgu222=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu222);

$limit = 10;
$sayfa = mysql_real_escape_string($_GET["sayfa"]);
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
$satirsayisi = $kactane2;
$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;

$tablo3=$tablo2."ORDER BY db_musteriler.id DESC LIMIT ".$baslangic. ",".$limit."";
#######################################################################
$sorgu2=mysql_query($tablo3)or die(mysql_query());
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 
?>
			
		
      <TR>
              <TD align=middle><div align="center">#<? echo $xxd[0]; ?></div></TD>
              <TD align=middle><div align="center"><? echo $xxd[1];  ?></div></TD>
              <TD align=middle><div align="center"><? echo $xxd[2]; ?></div></TD>
              <TD align=middle><div align="center"><? $kac_araci_var=@mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM db_araclar WHERE kullaniciid='".$xxd[0]."'")); echo (int)$kac_araci_var[0];?></div></TD>
              <TD align=middle><div align="center"><? echo $xxd['maxarac']; ?></div></TD>
              <TD align=middle><div align="center">
                <input class="button small" name="Duzenle2" value="Ara� Ekle" onClick="javascript:document.location.href='Arac.Duzenle.php?KUID=<? echo $xxd['id'] ?>'" type="button" id="Duzenle2" />
                <input class="button small" name="Duzenle3" value="Ara� G�r" onClick="javascript:document.location.href='Kullanici.Arac.Gor.php?KUID=<? echo $xxd['id'] ?>'" type="button" id="Duzenle3" />
              </div></TD>
              <TD align=middle>
                  <input class="button small" name="Duzenle" value="D�zenle" onClick="javascript:document.location.href='Kullanici.Guncelle.php?KUID=<? echo $xxd['id'] ?>'" type="button" id="Duzenle" />
                <input class="button small" name="Sil" value="Sil" onClick="JavaScript:if (confirm('Silmek istedi�inizden emin misin?')) javascript:document.location.href='Kullanici.Guncelle.php?KUID=<? echo $xxd['id'] ?>&Durum=Sil'" type="button" id="Sil" /></TD>
            </TR>
            
<? 
} //sistemler son fetch
?>
          </TBODY>
        </TABLE>

      </FORM>
      <br>
<div class="page-navigation clearfix">
<div class="wp-pagenavi">
  <div align="center">
<?
PagePrint($sayfa,$satirsayisi,$limit,"&a8=$a8&a1=$a1&a11=$a11&a13=$a13&a14=$a14&a16=$a16&a2=$a2&a3=$a3&a4=$a4&a5=$a5&a6=$a6&a7=$a7&a15=$a15&a8=$a8&a9=$a9&a20=$a20&a21=$a21&a12=$a12&a17=$a17&a10=$a10&Ara=Ara&ekle=duzenle&KID=");
?>
    
  </div>
</div>
</div>
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE></BODY></HTML>
