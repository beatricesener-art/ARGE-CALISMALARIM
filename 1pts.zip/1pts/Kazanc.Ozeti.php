<?
@session_start();
include_once("Guvenlik.Filtre.php");


//*****************************************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//
function getAoutoType($id)
{
    $AutoType = array('0'=>' ' ,'1'=>'Ucretsiz' , '2'=>'Ucretli');
    return $AutoType[$id];
}
function getUsersName()
{
    $userArray = array(0=>'');
    $userQuery="SELECT `id`,`ad`,`soyad` FROM db_super_users ";
    $userValue=mysql_query($userQuery);
    while($kullanici=  mysql_fetch_assoc($userValue)){ 
       
            $userArray[$kullanici['id']] = $kullanici['ad'].' '.$kullanici['soyad'];
    }
    return $userArray;

}
//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');
require_once("includes/excelwriter.inc.php");

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}


$KID=trim(mysql_real_escape_string($_GET['KID']));
$KID2=trim(mysql_real_escape_string($_POST['KID']));


$ekle=mysql_real_escape_string($_GET['ekle']);
$xls=mysql_real_escape_string($_GET['indir']);
$pdf=mysql_real_escape_string($_GET['indir2']);

$sil=mysql_real_escape_string($_GET['sil']);

$a1=trim(mysql_real_escape_string($_GET['a1']));

if($_GET['Temizle']=="Temizle"){

@header("Location: Kazanc.Ozeti.php?Temizlendi");
}

if($_GET['action']=='excel'){
        $hour_1=(!empty($_GET['hour_1']))? trim(mysql_real_escape_string($_GET['hour_1'])):'00:00:00';
        $hour_2=(!empty($_GET['hour_2']))? trim(mysql_real_escape_string($_GET['hour_2'])):'23:59:59';
        $a20=trim(mysql_real_escape_string($_GET['a20']));
        $a21=trim(mysql_real_escape_string($_GET['a21']));
		$a22=trim(mysql_real_escape_string($_GET['a22']));

        $kosul='';

        if($a20>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman>= \''.$a20.' '.$hour_1.'\'' ;}
        if($a21>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman<= \''.$a21.' '.$hour_2.' \'' ;}
		if ($a22>0) {$kosul = $kosul. ' and db_odemeler.operatorid= \''.$a22.'\'';}
        $sqlQuery="SELECT * FROM db_odemeler ".$join_ek." WHERE db_odemeler.id>0 ". $kosul. " ORDER BY db_odemeler.id";

        if(($a20=='')&&($a21=='')){
            $sqlQuery="SELECT * FROM db_odemeler ".$join_ek." WHERE db_odemeler.id<0 ". $kosul. " ORDER BY db_odemeler.id";
        }
        ob_clean();
        $pdfFile = wsfWriteExcel($sqlQuery,null,null, ($a20.' '.$hour_1.' '.$a21.' '.$hour_2));
        if(is_file($pdfFile)){
            $script =  "<script>  
            window.location = '{$pdfFile}'; 
            </script>";
        }
}

if($_GET['action']=='pdf'){
        $hour_1=(!empty($_GET['hour_1']))? trim(mysql_real_escape_string($_GET['hour_1'])):'00:00:00';
        $hour_2=(!empty($_GET['hour_2']))? trim(mysql_real_escape_string($_GET['hour_2'])):'23:59:59';
        $a20=trim(mysql_real_escape_string($_GET['a20']));
        $a21=trim(mysql_real_escape_string($_GET['a21']));
		$a22=trim(mysql_real_escape_string($_GET['a22']));

        $kosul='';

        if($a20>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman>= \''.$a20.' '.$hour_1.'\'' ;}
        if($a21>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman<= \''.$a21.' '.$hour_2.' \'' ;}
		if ($a22>0) {$kosul = $kosul. ' and db_odemeler.operatorid= \''.$a22.'\'';}
        $sqlQuery="SELECT * FROM db_odemeler ".$join_ek." WHERE db_odemeler.id>0 ". $kosul. " ORDER BY db_odemeler.id";

        if(($a20=='')&&($a21=='')){
            $sqlQuery="SELECT * FROM db_odemeler ".$join_ek." WHERE db_odemeler.id<0 ". $kosul. " ORDER BY db_odemeler.id";
        }
        ob_clean();
        $pdfFile = wsfWriteExcel($sqlQuery,null,null, ($a20.' '.$hour_1.' '.$a21.' '.$hour_2));
        if(is_file($pdfFile)){
            $script =  "<script>  
            window.location = '{$pdfFile}'; 
            </script>";
        }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
  <link rel="STYLESHEET" type="text/css" href="takvim/codebase/dhtmlxcalendar.css">
<?php 
echo $script;
?>
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
	<script type="text/javascript">
	function verify(ver){
		
		if(ver){
			// Confirmed message, i.e. clicked on "Yes"
			alert('Message confirmed');
		}else{
			// Clicked on "No"
			alert('Message not confirmed');
		}
	}
	</script>
	<link rel="stylesheet" href="css/modal-message.css" type="text/css">
	<script type="text/javascript" src="js/ajax.js"></script>
	<script type="text/javascript" src="js/modal-message.js"></script>
	<script type="text/javascript" src="js/ajax-dynamic-content.js"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">

<style type="text/css">
<!--
.style1 {color: #CC0000}
-->
</style>
	<script type="text/javascript" src="jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="fancybox/jquery.fancybox-1.2.6.css" media="screen" />
	<script type="text/javascript" src="fancybox/jquery.fancybox-1.2.6.pack.js"></script>
	

<script src="js/jquery.maskedinput-1.2.2.js" type="text/javascript"></script>
<script type="text/javascript">
		$(document).ready(function() {
			$("a.zoom").fancybox();

			$("a.zoom1").fancybox({
				'overlayOpacity'	:	0.7,
				'overlayColor'		:	'#FFF'
			});

			$("a.zoom2").fancybox({
				'zoomSpeedIn'		:	300,
				'zoomSpeedOut'		:	300
			});
                                                    $("#hour_1").mask("99:99:99");
                                                    $("#hour_2").mask("99:99:99");
		});
	</script>
<script>
      window.dhx_globalImgPath="../../codebase/imgs/";
</script>
<script  src="takvim/codebase/dhtmlxcommon.js"></script>
<script  src="takvim/codebase/dhtmlxcalendar.js"></script>
	<script>
	var cal1, cal2, mCal, mDCal, newStyleSheet;

	var dateFrom = null;
	var dateTo = null;
	
	window.onload = function () {
		cal1 = new dhtmlxCalendarObject('calInput1');
	    cal1 = new dhtmlxCalendarObject('calInput2');
	}
	

	
	
</script>
    <style type="text/css">
<!--
.style2 {color: #000000}
-->
    </style>
    </HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580><div align="center"><span class="solmenu"><?
	if($sonucum=="AracEklendi"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ara� Eklendi!<br>";}
    if($sonucum=="AracOncedenEklenmis"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Bu Ara� Sistemde Kay�tl�!<br>";}

	?>
    </span></div>
<FORM method=get name=kazancozeti action=Kazanc.Ozeti.php>
  <INPUT 
      type="hidden" name="ekle" value="duzenle">
  <INPUT 
      type="hidden" name="KUID" value="<? echo $KUID; ?>">
  <!---------------------->
  <!------------->
  <H2>Kazan� Sorgulama Ekran�</H2>
  <TABLE class=ictablo width=594>
    <TBODY>
      <TR>
        <TH colSpan=2> Kay�t Arama</TH>
      </TR>
      <TR>
        <TD style="COLOR: red" colSpan=2 align=middle></TD>
      </TR>

      <!--<TR>
            <TD align=right>Sadece Abone Ara�lar� G�ster:</TD>
            <TD><input name="a10" type="checkbox" <? if($a10=="2"){echo"checked";} ?> id="a11" value="2"></TD>
          </TR>-->
      <TR>
        <TD align=right>Rapor Tarih Aral��� Belirle: </TD>
        <TD>
            <input name=a20 id="calInput1" value="<? echo $_GET['a20']; ?>"  readonly="true"  size="20" maxlength="30">
             saat:<input name="hour_1" id="hour_1" value="<? echo $_GET['hour_1']; ?>"   size="10" maxlength="10">
          ile
          <input name=a21 id="calInput2"  readonly="true"  value="<? echo $_GET['a21']; ?>" size="20" maxlength="30">
           saat:<input name="hour_2" id="hour_2"  value="<? echo $_GET['hour_2']; ?>" size="10" maxlength="10">
          aras�</TD>
      </TR>
	  <TR>
        <TD align=right>Personel: </TD>
        <TD>
            <select name="a22" id="calInput3">
			<option value="0">Se�iniz</option>
			<?
			$sorgula=mysql_query("select * from db_super_users where yetki=4 OR yetki=1");
			while($listeid=mysql_fetch_array($sorgula))
			{
				echo "<option value=".$listeid[id].">".$listeid[ad]." ".$listeid[soyad]."</option>";
			}
			?>
			</select>
        </TD>
      </TR>
      <TR>
        <TD width="40%" align=right></TD>
        <TD><INPUT class=button value=Ara type=submit name=Ara>
            <INPUT class=button value=Temizle type=submit name=Temizle id="Temizle">
           <!-- <INPUT name=indir type=submit class=button id="indir" value=Excel �ndir>
            <INPUT name=indir2 type=submit class=button id="indir2" value=PDF �ndir>--></TD>
      </TR>
	  
    </TBODY>
    <TBODY>
    </TBODY>
  </TABLE>
  <br>
  <H5 align="center">
              <div align="center">
                            <a href="<?php echo "?action=excel&a20={$a20}&hour_1={$hour_1}&a21={$a21}&hour_2={$hour_2}&a22={$a22}"?>">
                                <img src="images/excel.png" alt="" >
                            </a>
							<a href="<?php echo "?action=pdf&a20={$a20}&hour_1={$hour_1}&a21={$a21}&hour_2={$hour_2}&a22={$a22}"?>">
                                <img src="images/pdf.png" alt="" >
                            </a>
            </div>
          </H5>
  <br>
  <TABLE class=ictablo width=594>
    <TBODY>
      <TR>
        <TH width="30">#ID</TH>
        <TH width="110">Plaka</TH>
        <TH width="110">Ara� Tipi</TH>
        <TH width="110">Bor� (TL)</TH>
        <TH width="108">�denen (TL)</TH>
        <TH width="105">Kalan(TL)</TH>
        <TH width="147">Olu�turulma</TH>
        <TH width="66">Operator</TH>
        <TH width="66">Durum</TH>
        </TR>
      
  <?
$a2=trim(mysql_real_escape_string($_GET['a2']));
$a3=trim(mysql_real_escape_string($_GET['a3']));
$a4=trim(mysql_real_escape_string($_GET['a4']));
$a5=trim(mysql_real_escape_string($_GET['a5']));
$a6=trim(mysql_real_escape_string($_GET['a6']));
$a7=trim(mysql_real_escape_string($_GET['a7']));
$a9=trim(mysql_real_escape_string($_GET['a9']));
$a15=trim(mysql_real_escape_string($_GET['a15']));
$a10=trim(mysql_real_escape_string($_GET['a10']));//misafirse 1
$a12=trim(mysql_real_escape_string($_GET['a12']));//ge�iciyse 0 g�nderir
$a17=trim(mysql_real_escape_string($_GET['a17']));//ki�iselse 1 g�nderir
$a20=trim(mysql_real_escape_string($_GET['a20']));
$hour_1=(!empty($_GET['hour_1']))? trim(mysql_real_escape_string($_GET['hour_1'])):'00:00:00';
$hour_2=(!empty($_GET['hour_2']))? trim(mysql_real_escape_string($_GET['hour_2'])):'23:59:59';
$a21=trim(mysql_real_escape_string($_GET['a21']));
$a22=trim(mysql_real_escape_string($_GET['a22']));

$kosul='';

if($a20>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman>= \''.$a20.' '.$hour_1.'\'' ;}
if($a21>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman<= \''.$a21.' '.$hour_2.' \'' ;}
if ($a22>0) {$kosul = $kosul. ' and db_odemeler.operatorid= \''.$a22.'\'';}
$TABLOM22="SELECT * FROM db_odemeler ".$join_ek." WHERE db_odemeler.id>0 ". $kosul. " ORDER BY db_odemeler.id";

if(($a20=='')&&($a21=='')){
$TABLOM22="SELECT * FROM db_odemeler ".$join_ek." WHERE db_odemeler.id<0 ". $kosul. " ORDER BY db_odemeler.id";
}


$toplam_uretilen=0;
$toplam_odenen=0;
$toplam_tahsil_edilen=0;
$toplam_net=0;

//$tablo2="SELECT * FROM db_odemeler WHERE borc!='0' ORDER BY id DESC";
//echo $TABLOM22;
$sorgu2=mysql_query($TABLOM22);
$kactane2=mysql_num_rows($sorgu2);
$usersNameArr = getUsersName();
	while($xxd=mysql_fetch_array($sorgu2)){ 
		//$kullanici=mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='".$xxd[8]."'"));
		$usr_inc[$xxd[8]]['odeme_durumu'] = $xxd[3]-$xxd[2];
                                    $odeme_durumu=$xxd[3]-$xxd[2];
                                    
		$usr_inc[$xxd[8]]['toplam_uretilen'] =$usr_inc[$xxd[8]]['toplam_uretilen']+$xxd[2];
		$toplam_uretilen=$toplam_uretilen+$xxd[2];
		$usr_inc[$xxd[8]]['toplam_odenen']=$usr_inc[$xxd[8]]['toplam_odenen']+$xxd[3];
		$toplam_odenen=$toplam_odenen+$xxd[3];
                
		$usr_inc[$xxd[8]]['toplam_tahsil_edilen']=$usr_inc[$xxd[8]]['toplam_tahsil_edilen']+$usr_inc[$xxd[8]]['odeme_durumu'];
		$toplam_tahsil_edilen=$toplam_tahsil_edilen+$odeme_durumu;
		$usr_inc[$xxd[8]]['toplam_net']=$usr_inc[$xxd[8]]['toplam_net']+$usr_inc[$xxd[8]]['odeme_durumu'];
		$toplam_net=$toplam_net+$odeme_durumu;

?>
      
      
      <TR>
        <TD height="32" align=middle>#<? echo $xxd[0]; ?></TD>
        <TD align=middle><div align="center"><? echo $xxd[6];?></div></TD>
        <TD align=middle><div align="center"><? if ($xxd["abonesure"]==0) echo getAoutoType($xxd[5]); else echo("Abone Kay�t"); ?></div></TD>
        <TD align=middle><div align="center"><? echo $xxd[2];?></div></TD>
        <TD align=middle><div align="center"><? echo $xxd[3];?></div></TD>
        <TD align=middle><div align="center"><?  echo $odeme_durumu;?></div></TD>
        <TD align=middle><div align="center"><? echo $xxd[4];?></div></TD>
        <TD align=middle><div align="center"><? echo $usersNameArr[$xxd[8]]?></div></TD>
        <TD align=middle><div align="center">
          <?
        $odeme_durumu=$xxd[3]-$xxd[2];
		//echo $odeme_durumu;
		if($odeme_durumu>=0){
		echo '<img src="images/icons/tick.png" width="16" height="16">';
		}
		else if($odeme_durumu<0){
		?>
		<a href="#" onClick="displayMessage('Odeme.Yap.php?IDX=<? echo $xxd[0]; ?>');return false"><img border='0' src='images/icons/error.png' width='16' height='16'></a>
		<?
        }
		?>
        </div></TD>
        </TR>
      
  <? 
} //sistemler son fetch
?>
      </TBODY>
    </TABLE>
          <p class="style1"><strong><span class="style2">TOPLAM �RET�LEN M�KTAR:</span><? echo $toplam_uretilen; ?></strong></p>
          <p class="style1"><strong><span class="style2">TOPLAM �DENEN M�KTAR:</span><? echo $toplam_odenen; ?></strong></p>
          <p class="style1"><strong><span class="style2">TOPLAM TAHS�L ED�LMEM�� M�KTAR:</span><? echo $toplam_tahsil_edilen; ?></strong></p>
          <H5 align="center">&nbsp;</H5>
          <?php
          if(is_array($usr_inc)):
              foreach($usr_inc as $userId=>$userIncoms):
          ?>
          <H5>Kulanici : <? echo $usersNameArr[$userId] ?></H5>
          <p class="style1"><strong><span class="style2">TOPLAM �RET�LEN M�KTAR:</span><? echo $userIncoms['toplam_uretilen']; ?></strong></p>
          <p class="style1"><strong><span class="style2">TOPLAM �DENEN M�KTAR:</span><? echo $userIncoms['toplam_odenen']; ?></strong></p>
          <p class="style1"><strong><span class="style2">TOPLAM TAHS�L ED�LMEM�� M�KTAR:</span><? echo $userIncoms['toplam_tahsil_edilen']; ?></strong></p>
          <H5 align="center">&nbsp;</H5>
          <?php endforeach;?>
          <?php endif;?>
<p class="inputara"><img src="images/icons/tick.png" width="16" height="16">-�deme Yap�ld�<br><img src="images/icons/error.png" width="16" height="16">-�deme Tamamlanmad�!</p>
          <H5 align="center">&nbsp;</H5>
          
          
</FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom", {validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "custom");
var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6");
var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7");
var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8");
//-->
</script>
<script type="text/javascript">
messageObj = new DHTML_modalMessage();	// We only create one object of this class
messageObj.setShadowOffset(5);	// Large shadow


function displayMessage(url)
{
	
	messageObj.setSource(url);
	messageObj.setCssClassMessageBox(false);
	messageObj.setSize(400,250);
	messageObj.setShadowDivVisible(true);	// Enable shadow for these boxes
	messageObj.display();
}

function displayStaticMessage(messageContent,cssClass)
{
	messageObj.setHtmlContent(messageContent);
	messageObj.setSize(300,150);
	messageObj.setCssClassMessageBox(cssClass);
	messageObj.setSource(false);	// no html source since we want to use a static message here.
	messageObj.setShadowDivVisible(false);	// Disable shadow for these boxes	
	messageObj.display();
	
	
}

function closeMessage()
{
	messageObj.close();	
}


</script>
</BODY></HTML>
