<?

include_once("includes/Sayfalama.Fonk.php");
include_once("Guvenlik.Filtre.php");


//*****************************************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//
function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}

function abonelik_yapan($operator_id)
{
	$sqlsorgula=mysql_query("select * from db_super_users where id=$operator_id");
	$listeid=mysql_fetch_array($sqlsorgula);
	return $listeid[ad]." ".$listeid[soyad];
}
//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');
require_once("includes/excelwriter2.inc.php");

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='4' or yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$KID=trim(mysql_real_escape_string($_GET['KID']));
$KID2=trim(mysql_real_escape_string($_POST['KID']));


$ekle=mysql_real_escape_string($_['ekle']);
$a1=trim(mysql_real_escape_string($_GET['a1']));
$a2=trim(mysql_real_escape_string($_GET['a2']));
$a3=trim(mysql_real_escape_string($_GET['a3']));
$a4=trim(mysql_real_escape_string($_GET['a4']));
$a5=trim(mysql_real_escape_string($_GET['a5']));
$a6=trim(mysql_real_escape_string($_GET['a6']));
$a7=trim(mysql_real_escape_string($_GET['a7']));
$a8=trim(mysql_real_escape_string($_GET['a8']));
$a9=trim(mysql_real_escape_string($_GET['a9']));//Grupname bas�yor
$a10=trim(mysql_real_escape_string($_GET['a10']));
$a11=trim(mysql_real_escape_string($_GET['a11']));
$a12=trim(mysql_real_escape_string($_GET['a12']));
$a13=trim(mysql_real_escape_string($_GET['a13']));
$a14=trim(mysql_real_escape_string($_GET['a14']));
$a20=trim(mysql_real_escape_string($_GET['a20']));
$a21=trim(mysql_real_escape_string($_GET['a21']));
$a22=trim(mysql_real_escape_string($_GET['a22']));

$hour_1=(!empty($_GET['hour_1']))? trim(mysql_real_escape_string($_GET['hour_1'])):'00:00:00';
$hour_2=(!empty($_GET['hour_2']))? trim(mysql_real_escape_string($_GET['hour_2'])):'23:59:59';


if($_GET['action']=='excel'){
        $hour_1=(!empty($_GET['hour_1']))? trim(mysql_real_escape_string($_GET['hour_1'])):'00:00:00';
        $hour_2=(!empty($_GET['hour_2']))? trim(mysql_real_escape_string($_GET['hour_2'])):'23:59:59';
        $a20=trim(mysql_real_escape_string($_GET['a20']));
        $a21=trim(mysql_real_escape_string($_GET['a21']));
		$a22=trim(mysql_real_escape_string($_GET['a22']));

	
        $kosul='';
		if($a20>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman>= \''.$a20.' '.$hour_1.'\'' ;}
		if($a21>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman<= \''.$a21.' '.$hour_2.' \'' ;}
		if ($a22>0) {$kosul = $kosul. ' and db_odemeler.operatorid= \''.$a22.'\'';}

		$sqlQuery="SELECT * FROM db_odemeler ".$join_ek." WHERE db_odemeler.abonesure>0 ". $kosul. " ORDER BY db_odemeler.id";
		
        ob_clean();
        $pdfFile = wsfWriteExcel2($sqlQuery,null,null, ($a20.' '.$hour_1.' '.$a21.' '.$hour_2));
        if(is_file($pdfFile))
		{
            $script =  "<script>  
            window.location = '{$pdfFile}'; 
            </script>";
        }
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">

<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
		<script src="jquery.js" language="JavaScript" type="text/javascript"></script>
  <link rel="STYLESHEET" type="text/css" href="takvim/codebase/dhtmlxcalendar.css">
  <?php 
echo $script;
?>

<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
	<script type="text/javascript">
	function verify(ver){
		
		if(ver){
			// Confirmed message, i.e. clicked on "Yes"
			alert('Message confirmed');
		}else{
			// Clicked on "No"
			alert('Message not confirmed');
		}
	}
	</script>
	<link rel="stylesheet" href="css/modal-message.css" type="text/css">
	<script type="text/javascript" src="js/ajax.js"></script>
	<script type="text/javascript" src="js/modal-message.js"></script>
	<script type="text/javascript" src="js/ajax-dynamic-content.js"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">

<style type="text/css">
<!--
.style1 {color: #CC0000}
-->
</style>
	<script type="text/javascript" src="jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="fancybox/jquery.fancybox-1.2.6.css" media="screen" />
	<script type="text/javascript" src="fancybox/jquery.fancybox-1.2.6.pack.js"></script>
	

<script src="js/jquery.maskedinput-1.2.2.js" type="text/javascript"></script>
<script type="text/javascript">
		$(document).ready(function() {
			$("a.zoom").fancybox();

			$("a.zoom1").fancybox({
				'overlayOpacity'	:	0.7,
				'overlayColor'		:	'#FFF'
			});

			$("a.zoom2").fancybox({
				'zoomSpeedIn'		:	300,
				'zoomSpeedOut'		:	300
			});
                                                    $("#hour_1").mask("99:99:99");
                                                    $("#hour_2").mask("99:99:99");
		});
	</script>
<script>
      window.dhx_globalImgPath="../../codebase/imgs/";
</script>
<script  src="takvim/codebase/dhtmlxcommon.js"></script>
<script  src="takvim/codebase/dhtmlxcalendar.js"></script>
	<script>
	var cal1, cal2, mCal, mDCal, newStyleSheet;

	var dateFrom = null;
	var dateTo = null;
	
	window.onload = function () {
		cal1 = new dhtmlxCalendarObject('calInput1');
	    cal1 = new dhtmlxCalendarObject('calInput2');
	}
	

	
	
</script>

<style type="text/css">
<!--
.style1 {color: #CC0000}
.style2 {color: #000000}
-->
</style>
	<style>

		#notification{
	position:absolute;
	bottom:0%;
	right:2%;
	height:122px;
	width:200px;
	border:1px solid black;
	border-bottom:0px;
	background: url('images/pts_solback.jpg') repeat-y;

		}
		#notificationClose{
			font-size:11px;
			cursor:pointer;
			width:100%;
			border-bottom:1px solid black;
		}
		#notificationIn{
			padding:10px;
			font-size:11px;
			
		}
	</style>
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580> 
	<FORM method=get name=kazancozeti action=Gorevli.Abone.Liste.php>
	<H2>Abonelik Sorgulama Ekran�</H2>
  <TABLE class=ictablo width=594>
    <TBODY>
      <TR>
        <TH colSpan=2> Kay�t Arama</TH>
      </TR>
      <TR>
        <TD style="COLOR: red" colSpan=2 align=middle></TD>
      </TR>

      <!--<TR>
            <TD align=right>Sadece Abone Ara�lar� G�ster:</TD>
            <TD><input name="a10" type="checkbox" <? if($a10=="2"){echo"checked";} ?> id="a11" value="2"></TD>
          </TR>-->
      <TR>
        <TD align=right>Rapor Tarih Aral��� Belirle: </TD>
        <TD>
            <input name=a20 id="calInput1" value="<? echo $_GET['a20']; ?>"  readonly="true"  size="20" maxlength="30">
             saat:<input name="hour_1" id="hour_1" value="<? echo $_GET['hour_1']; ?>"   size="10" maxlength="10">
          ile
          <input name=a21 id="calInput2"  readonly="true"  value="<? echo $_GET['a21']; ?>" size="20" maxlength="30">
           saat:<input name="hour_2" id="hour_2"  value="<? echo $_GET['hour_2']; ?>" size="10" maxlength="10">
          aras�</TD>
      </TR>
	  <TR>
        <TD align=right>Personel: </TD>
        <TD>
            <select name="a22" id="calInput3">
			<option value="0">Se�iniz</option>
			<?
			$sorgula=mysql_query("select * from db_super_users where yetki=4 OR yetki=1");
			while($listeid=mysql_fetch_array($sorgula))
			{
				echo "<option value=".$listeid[id].">".$listeid[ad]." ".$listeid[soyad]."</option>";
			}
			?>
			</select>
        </TD>
      </TR>
      <TR>
        <TD width="40%" align=right></TD>
        <TD><INPUT class=button value=Ara type=submit name=Ara>
            <INPUT class=button value=Temizle type=submit name=Temizle id="Temizle">
           <INPUT name=action type=submit class=button id="indir" value=excel>
           </TD>
      </TR>
	  
    </TBODY>
    <TBODY>
    </TBODY>
  </TABLE>
  </FORM>
        <H2>Yap�lan Abone ��lemleri</H2>
        <TABLE class=ictablo width=594>
          <TBODY>
            <TR>
              <TH width="29" height="31">#ID</TH>
              <TH width="87">Plaka</TH>
              <TH width="50">S�resi</TH>
			  <TH width="100">Abonelik Yapan</TH>
              <TH width="50">�cret</TH>
              <TH width="120">��lem Tarihi</TH>
			  <TH width="70">PDF</TH>
            </TR>
    <?
$a1=trim(mysql_real_escape_string(strtoupper($_GET['a1'])));//plaka
//$a1=trim(mysql_real_escape_string(strtoupper($_POST['a1'])));
$a1 = str_replace(" ","",$a1);
$a2=trim(mysql_real_escape_string($_GET['a2']));//ad�
$a3=trim(mysql_real_escape_string($_GET['a3']));//marka
$a4=trim(mysql_real_escape_string($_GET['a4']));//model
$a5=trim(mysql_real_escape_string($_GET['a5']));//renk
$a6=trim(mysql_real_escape_string($_GET['a6']));//area1
$a7=trim(mysql_real_escape_string($_GET['a7']));//area2
$a8=trim(mysql_real_escape_string($_GET['a8']));//area3
$a9=trim(mysql_real_escape_string($_GET['a9']));///Grupname bas�yor 
$a10=trim(mysql_real_escape_string($_GET['a10'])); //sadece misafirleri g�ster
$a11=trim(mysql_real_escape_string($_GET['a11']));//i�eride �u kadar saatten fazla kalan ara�lar
$a12=trim(mysql_real_escape_string($_GET['a12']));
$a13=trim(mysql_real_escape_string($_GET['a13']));//Grupname bas�yor
$a14=trim(mysql_real_escape_string($_GET['a14']));
$a20=trim(mysql_real_escape_string($_GET['a20']));
$a21=trim(mysql_real_escape_string($_GET['a21']));
$a22=trim(mysql_real_escape_string($_GET['a22']));


/*echo $a9;
echo " ";
echo $a13;
echo " ";
*/

//******��eri D��ar� Durum********/


//	$sorgu = "select * FROM db_uyeler WHERE id>0 " . $kosul;
$ara=trim($_GET['Ara']);

$kosul='';
if($a20>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman>= \''.$a20.' '.$hour_1.'\'' ;}
if($a21>' '){$kosul = $kosul. ' and db_odemeler.tarihzaman<= \''.$a21.' '.$hour_2.' \'' ;}
if ($a22>0) {$kosul = $kosul. ' and db_odemeler.operatorid= \''.$a22.'\'';}

$TABLOM22="SELECT * FROM db_odemeler ".$join_ek." WHERE db_odemeler.abonesure>0 ". $kosul. " ORDER BY db_odemeler.id";

//$tablo2="SELECT * FROM db_odemeler WHERE db_odemeler.abonesure > 0";
$sorgu222=mysql_query($TABLOM22);
$kactane2=mysql_num_rows($sorgu222);

$limit = 10;
$sayfa = mysql_real_escape_string($_GET["sayfa"]);
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
$satirsayisi = $kactane2;
$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;

//$tablo3="SELECT * FROM db_odemeler WHERE db_odemeler.abonesure>0 ORDER BY db_odemeler.id DESC LIMIT ".$baslangic. ",".$limit."";
$tablo3="SELECT * FROM db_odemeler WHERE db_odemeler.abonesure>0 ".$kosul." ORDER BY db_odemeler.id DESC LIMIT ".$baslangic. ",".$limit."";
$sorgu2=mysql_query($tablo3)or die(mysql_error());
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 


		
?>
            <TR>
              <TD height="33" align=middle>#<? echo $xxd[0]; ?></TD>
              <TD align=middle><? echo $xxd["plaka"];?></TD>
              <TD align=middle><? echo $xxd["abonesure"];?></TD>
			  <TD align=middle><? echo abonelik_yapan($xxd["operatorid"]) ?></TD>
              <TD align=middle><? echo $xxd["borc"];?></TD>
              <TD align=middle><div align="middle"><? echo $xxd["tarihzaman"];?></div></TD>
			  <TD align=middle><div align="middle">
			  <a href="<?php echo $xxd["dosyaadi"]; ?>"><img src="images/pdf.png" alt="" ></a></TD>
              <INPUT value="<? echo $xxd[0]; ?>"  type=hidden name="kamera">
              
            </TR>
            <? 
} //sistemler son fetch
?>
          </TBODY>
        </TABLE>

<br>
<div class="page-navigation clearfix">
<div class="wp-pagenavi">
  <div align="center">
<?
PagePrint($sayfa,$satirsayisi,$limit,"&a8=$a8&a1=$a1&a11=$a11&a13=$a13&a14=$a14&a16=$a16&a2=$a2&a3=$a3&a4=$a4&a5=$a5&a6=$a6&a7=$a7&a15=$a15&a8=$a8&a9=$a9&a20=$a20&a21=$a21&a12=$a12&a17=$a17&a10=$a10&a20=$a20&a21=$a21&a22=$a22&Ara=Ara&ekle=duzenle&KID=");
?>
    
  </div>
</div>
</div>
  
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>

<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "integer", {isRequired:false, validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "time", {isRequired:false, validateOn:["change"], format:"HH:mm:ss"});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "time", {isRequired:false, validateOn:["change"], format:"HH:mm:ss"});
//-->
</script>
		
</BODY></HTML>
