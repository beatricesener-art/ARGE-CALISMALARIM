<?
@session_start();
include_once("Guvenlik.Filtre.php");
$step=$_GET['Step'];
$sonucum=$_GET['Durum'];


if(empty($step)){

@header("Location: install.php?Step=1");

}
//*****************************************//
//**********NORON TEKNOLOJ�*****************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

//require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


		 $gonder = mysql_real_escape_string(trim($_POST['gonder']));
		 $gonder2 = mysql_real_escape_string(trim($_POST['gonder2']));
		 $db_host = mysql_real_escape_string(trim($_POST['a1']));
		 $db_user = mysql_real_escape_string(trim($_POST['a2']));
		 $db_pass = mysql_real_escape_string(trim($_POST['a3']));
		 $db_name = mysql_real_escape_string(trim($_POST['a4']));
		 $a5 = mysql_real_escape_string(trim($_POST['a5']));
		 $a6 = mysql_real_escape_string(trim($_POST['a6']));
		 $a7 = mysql_real_escape_string(trim($_POST['a7']));
		 $a8 = mysql_real_escape_string(trim($_POST['a8']));
		 $a9 = mysql_real_escape_string(trim($_POST['a9']));
		 $a10 = mysql_real_escape_string(trim($_POST['a10']));
		 $a11 = mysql_real_escape_string(trim($_POST['a11']));
		 $a12 = mysql_real_escape_string(trim($_POST['a12']));
		 $a13 = mysql_real_escape_string(trim($_POST['a13']));
		 $a14 = mysql_real_escape_string(trim($_POST['a14']));
		 
		 
if($gonder){

		$baglanti = @mysql_connect ( $db_host, $db_user, $db_pass );
		$sonuc = @mysql_select_db ( $db_name, $baglanti );
		if (!$sonuc)
		{
			$Durum="DBSecilemedi";
			$stepp="1";
		
		} 
		else 
		{
			$Durum="Ok";
			$stepp="2";
			$yazdir='<?
		 $db_host = "'.$db_host.'"; 
		 $db_user = "'.$db_user.'";  
		 $db_pass = "'.$db_pass.'";	
		 $db_name = "'.$db_name.'";	 	
		 mysql_connect($db_host,$db_user,$db_pass)or die("Veritabanina Ba�lan�lamyor");
		 mysql_select_db($db_name) or die("Veritabanyna Ba�lan�ld� ancak Veritaban� Ad� Se�ilemedi") ;
		 mysql_query("SET NAMES latin1");  
		 mysql_query("SET CHARACTER SET latin1");  
		 mysql_query("SET COLLATION_CONNECTION = latin1_swedish_ci");   
		$saatfarki = "0"; 
	    $farki = (date("H") + ($saatfarki));
		$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
		$tarih = date("Y-m-d",$gerial);
 		$zaman = date("H:i:s",$gerial);
		$ttt=mysql_fetch_array(mysql_query("SELECT * FROM db_siteayar WHERE id=1"));


		?>';
		$File = "includes/veritabani.php";
		$Handle = fopen($File, 'w');
		fwrite($Handle, $yazdir);
		fclose($Handle);
		
		//veritaban�n� include et
		 $db_host2 = $db_host;
		 $db_user2 = $db_user; 
		 $db_pass2 = $db_pass;
		 $db_name2 = $db_name;	 	
		 mysql_connect($db_host2,$db_user2,$db_pass2)or die("Veritabanina Ba�lan�lam�yor");
		 mysql_select_db($db_name2) or die("Veritabanyna Ba�lan�ld� ancak Veritaban� Se�ilemedi") ;
		 mysql_query("SET NAMES latin1");  
		 mysql_query("SET CHARACTER SET latin1");  
		 mysql_query("SET COLLATION_CONNECTION = latin1_swedish_ci");   


$table_create="CREATE TABLE `db_abonelikturleri` (
  `id` int(10) NOT NULL auto_increment,
  `abonelik_adi` varchar(1000) NOT NULL,
  `abonelik_suresi` varchar(1000) NOT NULL,
  `ucret` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11
";
$table_create2="CREATE TABLE `db_araclar` (
  `id` int(11) NOT NULL auto_increment,
  `kullaniciid` varchar(1000) NOT NULL,
  `marka` varchar(1000) NOT NULL,
  `model` varchar(1000) NOT NULL,
  `renk` varchar(1000) NOT NULL,
  `UID` varchar(1000) NOT NULL,
  `aracsurucusu` varchar(1000) NOT NULL,
  `eklenme` datetime NOT NULL,
  `plaka` varchar(60) NOT NULL,
  `aracKonum` varchar(300) NOT NULL,
  `aracParola` varchar(100) NOT NULL,
  `geciciarac` int(1) NOT NULL,
  `sondegisim` datetime NOT NULL,
  `soncamid` int(5) NOT NULL,
  `soncamgrupid` int(5) NOT NULL,
  `abonelikbaslangic` datetime NOT NULL,
  `abonelikbitis` datetime NOT NULL,
  `abonelikdurum` enum('a','p') NOT NULL,
  `test` varchar(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3
";
$table_create3="CREATE TABLE `db_araclar_temp` (
  `id` int(9) NOT NULL auto_increment,
  `plaka` varchar(30) NOT NULL,
  `puan` int(9) NOT NULL,
  `confidence` int(9) NOT NULL,
  `resimyolu` varchar(1000) NOT NULL,
  `soncamid` int(9) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1
";
$table_create4="CREATE TABLE `db_ayarlar` (
  `id` int(11) NOT NULL auto_increment,
  `area1name` varchar(100) NOT NULL,
  `area2name` varchar(100) NOT NULL,
  `area3name` varchar(100) NOT NULL,
  `resimyolu` varchar(2000) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2
";
$table_create5="CREATE TABLE `db_blacklist` (
  `id` int(11) NOT NULL auto_increment,
  `aracid` varchar(100) NOT NULL,
  `sebep` varchar(10000) NOT NULL,
  `eklenme` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5
";

$table_create6="CREATE TABLE `db_camgrup` (
  `id` int(5) NOT NULL auto_increment,
  `grupname` varchar(1000) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2
";
$table_create7="CREATE TABLE `db_fiyatlar` (
  `id` int(60) NOT NULL auto_increment,
  `baslangic` bigint(100) NOT NULL,
  `bitis` bigint(100) NOT NULL,
  `ucret` float NOT NULL,
  `sistemli` varchar(100) NOT NULL COMMENT 'e=> ''s�ral� art�yor demek''',
  `cesit` varchar(100) NOT NULL COMMENT '0->birimzaman�cretsiz, 1->birimzaman dakika 2->birim zaman g�n',
  `tolerans` varchar(100) NOT NULL,
  `ucret2` varchar(100) NOT NULL,
  `birimzaman` enum('d','g') NOT NULL COMMENT 'd=>dakika, g=> G�n',
  `carpan` int(9) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28
";
$table_create8="CREATE TABLE `db_global_ayarlar` (
  `id` int(11) NOT NULL auto_increment,
  `on_zaman` time NOT NULL,
  `son_zaman` time NOT NULL,
  `haftaici` int(11) NOT NULL,
  `haftasonu` int(11) NOT NULL,
  `otomisafir` int(1) NOT NULL,
  `ekleizin` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2
";
$table_create9="CREATE TABLE `db_kameralar` (
  `id` int(11) NOT NULL auto_increment,
  `kamera_ID` varchar(1000) NOT NULL,
  `sistem_ID` varchar(1000) NOT NULL,
  `role_ID` varchar(1000) NOT NULL,
  `kapi_ID` varchar(1000) NOT NULL,
  `kamera_Yon` varchar(1000) NOT NULL,
  `kamera_Durum` varchar(1000) NOT NULL,
  `cikisizin` int(1) NOT NULL,
  `camgrup` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7
";
$table_create10="CREATE TABLE `db_loglar` (
  `id` bigint(255) NOT NULL auto_increment,
  `plaka` varchar(100) NOT NULL,
  `kayittarihi` datetime NOT NULL,
  `kameraid` varchar(100) NOT NULL,
  `sebep` varchar(1000) NOT NULL,
  `resimyolu` varchar(1000) NOT NULL,
  `kullanici` varchar(1000) NOT NULL,
  `yerdurum` int(1) NOT NULL,
  `area1` varchar(1000) NOT NULL,
  `area2` varchar(1000) NOT NULL,
  `area3` varchar(1000) NOT NULL,
  `aracdurum` int(1) NOT NULL,
  `aracKonum` varchar(1000) NOT NULL,
  `soncamgrupid` int(10) NOT NULL,
  `ucretdurumu` enum('e','h') NOT NULL,
  `sistemid` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13
";

$table_create11="CREATE TABLE `db_musteriler` (
  `id` int(3) unsigned NOT NULL auto_increment,
  `kAdi` varchar(128) NOT NULL default '',
  `kSoyadi` varchar(128) NOT NULL default '',
  `kEvTel` varchar(24) NOT NULL default '',
  `kCepTel` varchar(24) NOT NULL default '',
  `kMail` varchar(200) NOT NULL default '',
  `kSifre` varchar(32) NOT NULL,
  `kSonIP` varchar(64) NOT NULL default '',
  `kSonGiris` datetime NOT NULL default '0000-00-00 00:00:00',
  `kDurum` enum('a','p','s') NOT NULL default 'a' COMMENT 'a=>aktif, p=>pasif, s=>silindi',
  `kKullaniciTur` varchar(10) NOT NULL,
  `keklenmetarihi` datetime NOT NULL,
  `abonelikbaslangic` datetime NOT NULL,
  `abonelikbitis` datetime NOT NULL,
  `abonelikdurum` enum('a','p') NOT NULL,
  `maxarac` int(10) NOT NULL,
  `uyeindirim` float NOT NULL default '0',
  `kredi` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16
";

$table_create12="CREATE TABLE `db_odemeler` (
  `id` int(9) NOT NULL auto_increment,
  `kullaniciid` int(9) NOT NULL,
  `borc` float NOT NULL,
  `odenen` float NOT NULL,
  `tarihzaman` datetime NOT NULL,
  `status` enum('1','2') NOT NULL,
  `plaka` text,
  `abonesure` int(6) NOT NULL default '0',
  `operatorid` int(5) NOT NULL default '1',
  `dosyaadi` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=312
";

$table_create13="CREATE TABLE `db_sistemler` (
  `id` int(11) NOT NULL auto_increment,
  `sistemadi` varchar(1000) NOT NULL,
  `parola` varchar(1000) NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19
";
$table_create14="CREATE TABLE `db_siteayar` (
  `id` int(1) NOT NULL auto_increment,
  `baslik` varchar(1000) NOT NULL,
  `footer` varchar(1000) NOT NULL,
  `header` varchar(1000) NOT NULL,
  `headerimg` varchar(1000) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2
";
$table_create15="CREATE TABLE `db_super_users` (
  `id` int(11) NOT NULL auto_increment,
  `ad` varchar(100) NOT NULL,
  `soyad` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `yetki` int(2) NOT NULL,
  `eklenme` datetime NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `songiris` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16
";
$table_create16="CREATE TABLE `db_yonetimlog` (
  `id` bigint(30) NOT NULL auto_increment,
  `olay` varchar(500) NOT NULL,
  `eklenme` datetime NOT NULL,
  `kullanici` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=666
";

$table_create17="CREATE TABLE `db_calisma_saatlari` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1
";

$table_create161="INSERT INTO `db_ayarlar` VALUES (1, '', '', '', 'E://Resimler/');
";
$table_create162="INSERT INTO `db_camgrup` VALUES (1, 'Otopark-1');
";
$table_create163="INSERT INTO `db_fiyatlar` VALUES (1, 30, 60, 0.03, 'e', '', '', '', 'd', 1);
";
$table_create164="INSERT INTO `db_fiyatlar` VALUES (2, 60, 120, 7, 'h', '', '', '', 'd', 0);
";
$table_create165="INSERT INTO `db_fiyatlar` VALUES (3, 120, 280, 10, 'h', '', '', '', 'd', 0);
";
$table_create166="INSERT INTO `db_fiyatlar` VALUES (23, 3000, 115256000, 10, 'e', '', '', '', 'g', 1);
";
$table_create167="INSERT INTO `db_fiyatlar` VALUES (26, 0, 30, 0, 'h', '', '', '', 'd', 0);
";
$table_create168="INSERT INTO `db_fiyatlar` VALUES (25, 280, 3000, 3.5, 'e', '', '', '', 'd', 60);
";
$table_create169="INSERT INTO `db_fiyatlar` VALUES (27, 280, 340, 0.1, 'e', '', '', '', 'd', 1);
";
$table_create170="INSERT INTO `db_global_ayarlar` VALUES (1, '05:12:00', '23:59:59', 1, 2, 2, 3);
";
$table_create171="INSERT INTO `db_musteriler` VALUES (1, 'Test', 'Test', '021222222', '055523131', 'test@noron.com.tr', '9174e5b543aa4e8fdc07cc9dae7b5c80', '', '2010-02-24 10:16:23', 'a', '', '2010-01-27 18:01:19', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'a', 5, 0, 95.5);
";
$table_create172='
INSERT INTO `db_sistemler` VALUES (17, "deneme", "123123", \'\\10.0.0.42\\Resimler\' );
';
$table_create173="INSERT INTO `db_siteayar` VALUES (1, 'VIDEOKERNEL PTS OTOPARK SISTEMI', 'Copyright VIDEOKERNEL-PARK', '', 'images/watermak.gif');
";


mysql_query($table_create)or die(mysql_error());
mysql_query($table_create2)or die(mysql_error());
mysql_query($table_create3)or die(mysql_error());
mysql_query($table_create4)or die(mysql_error());
mysql_query($table_create5)or die(mysql_error());
mysql_query($table_create6)or die(mysql_error());
mysql_query($table_create7)or die(mysql_error());
mysql_query($table_create8)or die(mysql_error());
mysql_query($table_create9)or die(mysql_error());
mysql_query($table_create10)or die(mysql_error());
mysql_query($table_create11)or die(mysql_error());
mysql_query($table_create12)or die(mysql_error());
mysql_query($table_create13)or die(mysql_error());
mysql_query($table_create14)or die(mysql_error());
mysql_query($table_create15)or die(mysql_error());
mysql_query($table_create16)or die(mysql_error());
mysql_query($table_create17)or die(mysql_error());

mysql_query($table_create161)or die(mysql_error());
mysql_query($table_create162)or die(mysql_error());
mysql_query($table_create163)or die(mysql_error());
mysql_query($table_create164)or die(mysql_error());
mysql_query($table_create165)or die(mysql_error());
mysql_query($table_create166)or die(mysql_error());
mysql_query($table_create167)or die(mysql_error());
mysql_query($table_create168)or die(mysql_error());
mysql_query($table_create169)or die(mysql_error());
mysql_query($table_create170)or die(mysql_error());
mysql_query($table_create171)or die(mysql_error());
mysql_query($table_create172)or die(mysql_error());
mysql_query($table_create173)or die(mysql_error());






		}
		
		
	
		
	
@header("Location: install.php?Durum=$Durum&Step=$stepp");
}


if($gonder2){

include("includes/veritabani.php");
		 $a5 = mysql_real_escape_string(trim($_POST['a5']));//kullan�c�ad�
		 $a6 = mysql_real_escape_string(trim($_POST['a6']));//�ifre
		 $a7 = mysql_real_escape_string(trim($_POST['a7']));//ad
		 $a8 = mysql_real_escape_string(trim($_POST['a8']));//soyad
		 $a9 = mysql_real_escape_string(trim($_POST['a9']));//email
		 $a10 = mysql_real_escape_string(trim($_POST['a10']));
		 $a11 = mysql_real_escape_string(trim($_POST['a11']));
		 $a12 = mysql_real_escape_string(trim($_POST['a12']));
		 $a13 = mysql_real_escape_string(trim($_POST['a13']));
		 $a14 = mysql_real_escape_string(trim($_POST['a14']));

$kekle="INSERT INTO `db_super_users` (
`id` ,
`ad` ,
`soyad` ,
`mail` ,
`yetki` ,
`eklenme` ,
`username` ,
`password` ,
`songiris`
)
VALUES (
NULL , '$a7', '$a8', '$a9', '1', '$tarih $zaman', '$a5', '$a6', '$tarih $zaman'
)";
mysql_query($kekle);
$kekle2="INSERT INTO `db_super_users` (
`id` ,
`ad` ,
`soyad` ,
`mail` ,
`yetki` ,
`eklenme` ,
`username` ,
`password` ,
`songiris`
)
VALUES (
NULL , '$a12', '$a13', '$a14', '2', '$tarih $zaman', '$a10', '$a11', '$tarih $zaman'
)";
mysql_query($kekle2);
$stepp="3";
$Durum="Kurulum Tamamlandi";

@header("Location: install.php?Durum=$Durum&Step=$stepp");


}





?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9" />
    <meta name="robots" content="noindex,nofollow">
    <link rel="stylesheet" href="stil.css" type="text/css">
    <title>Kurulum Sayfas�</title>
    <link href="stil.css" rel="stylesheet" type="text/css" />
    <script language="JavaScript" src="controls.js"></script>
    <script src="ajax.js" type="text/javascript" language="JavaScript"></script>
  <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
  <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
                      <style type="text/css">
<!--
.style1 {color: #CC0000}
-->
                      </style>
  </head>
<body>
<h1>Kurulum</h1>



<? if($step=="1"){ ?>
<form name="giris" action="install.php" method="POST">
  <table border="0" align="center" class="ictablo" width="400px;" style="margin-top:200px;">
<caption><h1>Kurulum</h1></caption>    <tr>
      <th colspan="3" align="center">
      <input type="hidden" name="p" value="<?=@$_GET['p']?>">
      <div align="center"><span >
	 <?
	if($sonucum=="AracEklendi"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ara� Eklendi!<br>";}
    if($sonucum=="DBSecilemedi"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Veritaban� Ayarlar�n�z Hatal�!<br>";}
	if($sonucum=="DBBaglanilamadi"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Veritaban� Ayarlar�n�z Hatal�!<br>";}
	?>
    </span></div></th>
    
    </tr>
    <tr>
      <td class="formleft">DB Sunucusu :</td>
      <td><span id="sprytextfield1">
        <input name="a1"  type="text" id="a1" />
      <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span> (�rn: localhost)</td>
    </tr>
    <tr>
      <td class="formleft">DB Kullan�c� Ad� :</td>
       <td><span id="sprytextfield2">
       <input name="a2" type="text" value="" id="a2">
       <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td class="formleft">DB �ifre :</td>
      <td><span id="sprytextfield2"><span id="sprytextfield3">
        <input name="a3" type="password" value="" id="a3">
      <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
  
    <tr>
      <td class="formleft">DB Ad�::</td>
      <td><span id="sprytextfield2"><span id="sprytextfield4">
        <input name="a4" type="text" value="" id="a4">
      <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td align="center" colspan="3"><input name="gonder" type="submit" class=button id="gonder"  value="Kuruluma Ba�la" /></td>
    </tr>
    <tr>
      <td align="center" colspan="3">    <div></div></td>
    </tr>
  </table>
</form>
<? }//if step 1 ise ?>

<? if($step=="2"){ ?>
<form name="giris" action="install.php" method="POST">
  <table border="0" align="center" class="ictablo" width="400px;" style="margin-top:200px;">
<caption>
<h1>Kullan�c� Ayarlar�</h1>
</caption>    <tr>
      <th colspan="3" align="center">
      <input type="hidden" name="p" value="<?=@$_GET['p']?>">
      <div align="center"><span >
	 <?
	if($sonucum=="Ok"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ba�lant� Kutuldu. Veritaban� Ayarland�!<br>";}
    if($sonucum=="DBSecilemedi"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Veritaban� Ayarlar�n�z Hatal�!<br>";}
	if($sonucum=="DBBaglanilamadi"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Veritaban� Ayarlar�n�z Hatal�!<br>";}
	?>
    </span></div></th>
    
    </tr>
    <tr>
      <td class="formleft">Site Y�neticisi K.Ad�:</td>
      <td><span id="sprytextfield1"><span id="sprytextfield5">
        <input name="a5"  type="text" id="a5" />
      </span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span> (�rn: localhost)</td>
    </tr>
    <tr>
      <td class="formleft">Site Y�neticisi �ifre:</td>
       <td><span id="sprytextfield2"><span id="sprytextfield6">
         <input name="a6" type="password" value="" id="a6">
       </span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td class="formleft">Ad :</td>
      <td><span id="sprytextfield2"><span id="sprytextfield3"><span id="sprytextfield7">
        <input name="a7" type="text" value="" id="a7">
      </span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
  
    <tr>
      <td class="formleft">Soyad :</td>
      <td><span id="sprytextfield2"><span id="sprytextfield4"><span id="sprytextfield8">
        <input name="a8" type="text" value="" id="a8">
      </span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td class="formleft">E-Mail :</td>
      <td><span id="sprytextfield2"><span id="sprytextfield10"><span id="sprytextfield9">
        <input name="a9" type="text" value="" id="a9">
      </span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td height="25" colspan="3" align="center">Sistem Y�neticisi Bilgileri</td>
    </tr>
    <tr>
      <td class="formleft">Sistem Y�neticisi K.Ad� :</td>
      <td><span id="sprytextfield2"><span id="sprytextfield11"><span id="sprytextfield10">
        <input name="a10" type="text" value="" id="a10">
      </span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td class="formleft">Sistem Y�neticisi �ifre :</td>
      <td><span id="sprytextfield2"><span id="sprytextfield12"><span id="sprytextfield11">
        <input name="a11" type="password" value="" id="a11">
      </span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td class="formleft">Ad :</td>
      <td><span id="sprytextfield2"><span id="sprytextfield14"><span id="sprytextfield12">
        <input name="a12" type="text" value="" id="a12">
      </span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td class="formleft">Soyad: </td>
      <td><span id="sprytextfield15"><span id="sprytextfield16">
        <input name="a13" type="text" value="" id="a13">
      <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"></span></span></td>
    </tr>
    
    <tr>
      <td class="formleft">E-mail: </td>
      <td><span id="sprytextfield2"><span id="sprytextfield15"><span id="sprytextfield13">
        <input name="a14" type="text" value="" id="a14">
      <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td align="center" colspan="3"><input name="gonder2" type="submit" class=button id="gonder2"  value="Ayarlar� Kaydet" /></td>
    </tr>
    <tr>
      <td align="center" colspan="3">    <div></div></td>
    </tr>
  </table>
</form>
<? }//if step 1 ise ?>

<? if($step=="3"){ ?>
<form name="giris" action="install.php" method="POST">
  <table border="0" align="center" class="ictablo" width="400px;" style="margin-top:200px;">
<caption>
<h1>Kurulum Tamamland�</h1>
</caption>    <tr>
      <th align="center">
      <input type="hidden" name="p" value="<?=@$_GET['p']?>">
      <div align="center"><span >
	 <?
	if($sonucum=="Kurulum Tamamlandi"){echo "<img src='images/icons/accept.png' width='16' height='16'> Kurulum Ba�ar�yla Tamamland�!<br>";}
    if($sonucum=="DBSecilemedi"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Veritaban� Ayarlar�n�z Hatal�!<br>";}
	if($sonucum=="DBBaglanilamadi"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Veritaban� Ayarlar�n�z Hatal�!<br>";}
	?>
    </span></div></th>
    
    </tr>
    <tr>
      <td align="center"><p>&nbsp;</p>
        <p>Sistem Ba�ar�yla Kuruldu. Mevcut �ifreleriniz ile sisteme giri� yapabilirsiniz.</p>
        <p> �nemli Not: ana dizin �zerindeki <span class="style1">install.php</span> dosyas�n�<strong> tamamen</strong> silmeyi unutmay�n�z.</p>
        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td align="center">    <div>[ <a href="index.php">Giri�</a> ]</div></td>
    </tr>
  </table>
</form>
<? }//if step 1 ise ?>


  <script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "custom");
var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5", "custom");
var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6", "custom");
var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7", "custom");
var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8", "custom");
var sprytextfield9 = new Spry.Widget.ValidationTextField("sprytextfield9", "custom");
var sprytextfield10 = new Spry.Widget.ValidationTextField("sprytextfield10", "custom");
var sprytextfield11 = new Spry.Widget.ValidationTextField("sprytextfield11", "custom");
var sprytextfield12 = new Spry.Widget.ValidationTextField("sprytextfield12", "custom");
var sprytextfield14 = new Spry.Widget.ValidationTextField("sprytextfield14", "custom");
var sprytextfield15 = new Spry.Widget.ValidationTextField("sprytextfield15", "custom");
var sprytextfield16 = new Spry.Widget.ValidationTextField("sprytextfield16", "custom");
var sprytextfield13 = new Spry.Widget.ValidationTextField("sprytextfield13");
//-->
</script>
</body>
</html>
