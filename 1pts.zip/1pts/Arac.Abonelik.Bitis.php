<?
@session_start();
include_once("Guvenlik.Filtre.php");

function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}


require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];

$tablo = "select * from db_super_users where username='$user' and password='$sifre' and (yetki='1' or yetki='4' or yetki='3') "; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}
$islem=trim(mysql_real_escape_string($_GET['Islem']));

$AUID=trim(mysql_real_escape_string($_GET['AUID']));
$AUID2=trim(mysql_real_escape_string($_POST['AUID']));

$ekle=mysql_real_escape_string($_POST['ekle']);
$ekle2=mysql_real_escape_string($_POST['ekle2']);

$a1=trim(mysql_real_escape_string($_POST['a1']));
$a2=trim(mysql_real_escape_string($_POST['a2']));
$a3=trim(mysql_real_escape_string($_POST['a3']));
$a4=trim(mysql_real_escape_string($_POST['a4']));
$a5=trim(mysql_real_escape_string($_POST['a5']));
$a6=trim(mysql_real_escape_string($_POST['a6']));
$a10=trim(mysql_real_escape_string($_POST['a10']));

if($ekle2=="Uzat"){
    $zaman="23:59:59";
    if (strlen($a1)<11) $a1=$a1." ".$zaman;
    mysql_query("UPDATE `db_araclar` SET `abonelikbitis` = '$a1' WHERE `db_araclar`.`id` ='$AUID2' LIMIT 1 ")or die(mysql_error());
    
    $arac_bilgi=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE id='$AUID' or id='$AUID2'"));
    $sahipid=$arac_bilgi["kullaniciid"];
    $sahibi_kim_ki=@mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='$sahipid'"));

    @mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$AUID2 NOlu Ara� Abonelik s�resi $a1 tarihine Uzat�ld�.', NOW(),'$user')");
@header("Location: Kullanici.Arac.Gor.php?KUID=$sahipid"); 


}else{
    $arac_bilgi=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE id='$AUID' or id='$AUID2'"));
    $sahipid=$arac_bilgi["kullaniciid"];
    $sahibi_kim_ki=@mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='$sahipid'"));

}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>

<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>
  <link rel="STYLESHEET" type="text/css" href="takvim/codebase/dhtmlxcalendar.css">

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery.maskedinput-1.2.2.js" type="text/javascript"></script>
<script>
jQuery(function($){
   $("#a22").mask("99:99:99");
   $("#a23").mask("99:99:99");
});
</script>
	<link rel="stylesheet" type="text/css" href="fancybox/jquery.fancybox-1.2.6.css" media="screen" />
	<script type="text/javascript" src="fancybox/jquery.fancybox-1.2.6.pack.js"></script>
	

<script type="text/javascript">
		$(document).ready(function() {
			$("a.zoom").fancybox();

			$("a.zoom1").fancybox({
				'overlayOpacity'	:	0.7,
				'overlayColor'		:	'#FFF'
			});

			$("a.zoom2").fancybox({
				'zoomSpeedIn'		:	300,
				'zoomSpeedOut'		:	300
			});
		});
	</script>
<script>
      window.dhx_globalImgPath="../../codebase/imgs/";
</script>
<script  src="takvim/codebase/dhtmlxcommon.js"></script>
<script  src="takvim/codebase/dhtmlxcalendar.js"></script>

	<script>
	var cal1, cal2, mCal, mDCal, newStyleSheet;

	var dateFrom = null;
	var dateTo = null;
	
	window.onload = function () {
		cal1 = new dhtmlxCalendarObject('calInput1');
	    cal1 = new dhtmlxCalendarObject('calInput2');
	}
	
	

	
	
</script>

<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
    <div align="center"><span class="solmenu"><?
	if($sonucum=="YetkiDisiAlan2"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Bu plaka �nceden kay�t edilmi�!<br>";}
    if($sonucum=="Ok"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ara� Ba�ar�yla G�ncellendi!<br>";}
    if($sonucum=="cOk"){echo "<img src='images/icons/accept.png' width='16' height='16'> Abonelik S�resi Ba�ar�yla Yenilendi!<br>";}

	?>
    </span></div>
      <FORM method=post name=misafirtanimla action=Arac.Abonelik.Bitis.php>
      <INPUT 
      type="hidden" name="ekle" value="duzenle">
       <INPUT 
      type="hidden" name="AUID" value="<? echo $AUID; ?>">
 
       <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH colSpan=2>Abone �yeli�i Biti� Tarihini De�i�tir</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Abonelik Biti� Tarihi:</TD>
              <TD><span id="sprytextfield6"><input name=a1 id="calInput1" value="<? echo($arac_bilgi[abonelikbitis]); ?>"  readonly="true"  size="20" maxlength="30"></span></TD>
            </TR>

            <TR>
              <TD width="40%" align=right></TD>
              <TD><INPUT class=button value=Uzat type=submit name=ekle2>
                &nbsp; </TD>
            </TR>
</TBODY>
          <TBODY>
          </TBODY>
        </TABLE>
   
      </FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
//-->
</script>
</BODY></HTML>
