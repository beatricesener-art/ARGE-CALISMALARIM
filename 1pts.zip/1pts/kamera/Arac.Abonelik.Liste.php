<?php

$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);

ini_set("display_errors","off");
require_once('../includes/veritabani.php');

$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];


$sistem_AD = 'sistem';
$sistem_Parola = '123123';

//SELECT * from `db_loglar`  order by `kayittarihi` DESC LIMIT 0,1 //tarihzaman
//SELECT * FROM db_odemeler WHERE db_odemeler.abonesure>0 ORDER BY db_odemeler.id
$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
  {
  $sorgula=mysql_query("SELECT * FROM db_odemeler WHERE db_odemeler.abonesure>0 order by `tarihzaman` DESC LIMIT 0,10");
  while($listeid=mysql_fetch_array($sorgula))
  {
	echo "[RESULT][BORC:$listeid[borc]][ODENEN:$listeid[odenen]][TARIH:$listeid[tarihzaman]][PLAKA:$listeid[plaka]][SURE:$listeid[abonesure]][OPERATOR:$listeid[operatorid]]";
  }
 }
else {
	echo 'access denied';
}
?>