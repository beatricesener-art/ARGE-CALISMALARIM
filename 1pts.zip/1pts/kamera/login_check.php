<?
@session_start();
include_once("../Guvenlik.Filtre.php");

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//
@require_once('../includes/veritabani.php');


$whoInSQL = "select * from db_calisma_saatlari where end_time is null order by start_time DESC limit 0,1";
//echo $tablo;
$whoInResult= mysql_query($whoInSQL);
$workingMan = null;
if(@mysql_num_rows($whoInResult)>0){
	$workingMan = mysql_fetch_assoc($whoInResult);
	echo("login true");
}else echo("login false");
$login_durum=mysql_real_escape_string($_GET['p']);  //Giri� se�enekleri
$login_durum_2=mysql_real_escape_string($_POST['p']);  //Giri� se�enekleri
$hata=mysql_real_escape_string($_POST['HID']); 

if(empty($login_durum)){
$login_durum="4";	
}

?>