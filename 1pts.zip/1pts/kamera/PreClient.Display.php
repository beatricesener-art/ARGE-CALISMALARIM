<?
@session_start();
$ip = $_SERVER['REMOTE_ADDR']; 

include_once("../Guvenlik.Filtre.php");
require_once('../includes/veritabani.php');

$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];
$arac_Plaka = strtoupper($_POST['arac_Plaka']);
$kamera_ID = $_POST['kamera_ID'];
$log_Sebep = $_POST['log_Sebep'];
$resim_Yolu = $_POST['resim_Yolu'];
$baseurl = $_POST['baseurl'];


$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]<1)
{
  echo"access denied";
  exit();
}

 
$query = "select * from db_aractipleri";
$result = mysql_query($query);
$num_results = mysql_num_rows($result);


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>Ara� Tipi Se�im</TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>

<LINK rel=stylesheet type=text/css href="<? echo $baseurl; ?>/stil.css">
<LINK rel=stylesheet type=text/css href="stil.css">
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style3 {font-weight: bold}
-->
#container{
	
    width:593px;
    height:150px;
    /*overflow:scroll;*/
	overflow-x: hidden;
	overflow-y: scroll;
	position:fixed;
	list-style-position:inside;
	
}
</style>
<link rel="stylesheet" href="includes/modalbox.css" type="text/css" 
media="screen" />
<!--<script type="text/javascript" src="includes/prototype.js"></script>
<script type="text/javascript" src="includes/scriptaculous.js?�
    load=builder,effects"></script>
<script type="text/javascript" src="includes/modalbox.js"></script>

<link href="../styles/modal-window.css" type="text/css" rel="stylesheet" />-->
</HEAD>
<BODY>
<FORM method=post name=misafirtanimla action=<? echo $baseurl; ?>/kamera/Client.Display.php >

<INPUT type="hidden" name="sistem_AD" value="<? echo $sistem_AD; ?>">
<INPUT type="hidden" name="sistem_Parola" value="<? echo $sistem_Parola; ?>">
<INPUT type="hidden" name="resim_Yolu" id="resimyolu" value="<? echo $resim_Yolu; ?>">
<INPUT type="hidden" name="kamera_ID" value="<? echo $kamera_ID; ?>">
<INPUT type="hidden" name="arac_Plaka" value="<? echo $arac_Plaka; ?>">
<input type="hidden" name="log_Sebep" value="<? echo $log_Sebep; ?>" >
<input type="hidden" name="baseurl" value="<? echo $baseurl; ?>" >

<TABLE width=293 align="center" class=ictablo>
        <TBODY>
          <TR>
            <TH width="100%"> Ara� Tipi Se�iniz</TH>
          </TR>
          <TR>
          <TD style="COLOR: red" align=middle><div align="center">
          <SELECT id=tipIDlist  name="tipID">
                <?
                for ($i=0;$i<$num_results;$i++)
                { 
                    $tipID = mysql_result($result,$i,"tipID");
                    $tipAdi = mysql_result($result,$i,"tipAdi");
                ?>
                <option value=<? echo($tipID) ?>><? echo($tipAdi); ?></option>
                <?
                }?>
          </SELECT>
          </div>    
            <div align="center">
            <? //echo "�cretim".$ucretim; ?>
            <br>
              <input class=button value="Sonraki ��lem" type=submit name=Gonder>
          </div>
          </TD>          
          </TR>
        </TBODY>
      </TABLE>
    </FORM>
    <script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
//-->
</script>
</BODY></HTML>
 