<?
@session_start();
include_once("../Guvenlik.Filtre.php");


$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('../includes/veritabani.php');

$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];
$arac_Plaka = $_POST['arac_Plaka'];
$kamera_ID = $_POST['kamera_ID'];
$sebep = $_POST['log_Sebep'];
$resim_yolu = $_POST['resim_Yolu'];
$base_url = $_POST['baseurl'];

$a2=trim(mysql_real_escape_string($_POST['a2']));
$a6=trim(mysql_real_escape_string($_POST['a6']));
$a7=trim(mysql_real_escape_string($_POST['a7']));
$a8=trim(mysql_real_escape_string($_POST['a8']));
$sonucum=trim(mysql_real_escape_string($_POST['sonucum']));
$Ara2=trim(mysql_real_escape_string($_POST['Ara2']));


/*
$base_url="http://127.0.0.1/PTS";
$arac_Plaka="34TY346";
$kamera_ID = '2';
$sistem_AD = 'sistem';
$sistem_Parola = '123123';
$resim_yolu="34ET3602_20091221181450234_1.jpg";
//$sebep="<<<16;11;8>>>;Siemens Ev Aletleri";
//$sebebim="<<<".$a6.";".$a7.";".$a8.">>>;".$a2;
*/


$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]<1)
{
  echo"access denied";
  exit();
}

			
		 $kontrol_plaka=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' "));
		 $kontrol_plaka_gecici=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' AND geciciarac='1' "));

		 $sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' "));
		 
		 $surucu_Id=$sorguplaka["kullaniciid"];

		 


?>
<!--<frameset cols="30%,*">
<frame src="List.Plate.php" name="plateFrame">
</frameset>-->
<?
$whoInSQL = "select * from db_calisma_saatlari where end_time is null order by start_time DESC limit 0,1";
//echo $tablo;
$whoInResult= mysql_query($whoInSQL);
$workingMan = null;
if(@mysql_num_rows($whoInResult)>0){
	//$workingMan = mysql_fetch_assoc($whoInResult);
}else {
	echo("G�REVL�N�N KAYIT OLMASI GEREKL�!");
	exit();
}
?>

<? 
	$icerde_kactane=mysql_num_rows(mysql_query("select * from db_araclar where aracKonum='i'  "));
?>
��ERDEK� ARA� SAYISI: <? echo($icerde_kactane); ?>
<br>
<FORM method=post name=Client.Send action=<? echo $base_url; ?>/kamera/Client.Display.php >
<INPUT type="hidden" name="sistem_AD" value="<? echo $sistem_AD; ?>">
<INPUT type="hidden" name="sistem_Parola" value="<? echo $sistem_Parola; ?>">
<INPUT type="hidden" name="resim_Yolu" id="resimyolu" value="<? echo $resim_yolu; ?>">
<INPUT type="hidden" name="kamera_ID" value="<? echo $kamera_ID; ?>">
Kamera No: <? echo $kamera_ID; ?><br /><br />
Plaka No: <input  name="arac_Plaka" id="aracplaka" value="<? echo $arac_Plaka; ?>"  ><br />
<input type="radio" checked="checked" name="ImgOption" id="resim1" value="1" />
 1.Resim
<input type="radio" name="ImgOption"  value="" />

2.Resim<br />
<input type="hidden" name="log_Sebep" value="<? echo $a2; ?>" >
<input type="hidden" name="baseurl" value="<? echo $base_url; ?>" >
<input class=button value="Ge�ici Ara� Giris Islemini Yap" id="GeciciBaslat" type="submit" name=Gonder>
</FORM>