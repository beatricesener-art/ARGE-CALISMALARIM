<?php
//$outname="Arac.Sorgu.ini";
//header("Content-Disposition: text; filename=\"$outname\";\n\n");
//header ("Content-type: text/ini");

$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);

function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}

ini_set("display_errors","off");
require_once('../includes/veritabani.php');

function dateDiff($d1, $d2=null, $format="all"){
    if($d2==null){
        $d2=$d1;
        $d1=time();
    }

    if(!is_int($d1)) $d1=strtotime($d1);
    if(!is_int($d2)) $d2=strtotime($d2);
    $d=abs($d1-$d2);

    $format=strtolower($format);
    if(empty($format) || $format=="*") $format="all";
    if(strrpos($format, 's')==strlen($format)-1){
        $format=substr($format, 0, strlen($format)-1);
    }

    $result = array();

    if($format=="all" || $format=="day")    $result["day"]   = floor($d/(60*60*24));
    if($format=="all" || $format=="month")  $result["month"] = floor($d/(60*60*24*30));
    if($format=="all" || $format=="year")   $result["year"]  = floor($d/(60*60*24*365));
    if($format=="all" || $format=="week")   $result["week"]  = floor($d/(60*60*24*7));
    if($format=="all" || $format=="hour")   $result["hour"]  = floor($d/(60*60));
    if($format=="all" || $format=="minute") $result["minute"]= floor($d/60);

    if($format!="all") return $result[$format];
    else return $result;
}

$arac_Plaka = $_POST['arac_Plaka'];
$kamera_ID = $_POST['kamera_ID'];
$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];
$sorgu_tur=$_POST['sorguturu'];

/*
$arac_Plaka ="34LU4529";
$kamera_ID = '3';
$sistem_AD = 'sistem';
$sistem_Parola = '123123';
$sorgu_tur="1";
*/

function AracYeniMiCikti($a_Plaka, $cam_id)
{
	$lastSql="SELECT * from `db_loglar` WHERE plaka = '$a_Plaka' order by `kayittarihi` DESC LIMIT 0,1";
	$lastResult = @mysql_query($lastSql);
	$numResult = mysql_num_rows($lastResult);
	$lastVal = @mysql_fetch_assoc($lastResult);
	if ($numResult>0)
	{
		$seconds = strtotime("".$tarih." ".$zaman."") - strtotime($lastVal['kayittarihi']);
		if ($seconds>60 || $cam_id ==$lastVal['kameraid']) return 0;
		else return 1;	
	}else return 0;
}

function AracDahaOnceCiktiMi($a_Plaka,$bugun)
{
	$zamanbas="00:00:00";
	$zamanbit="23:59:59";
	$lastSql="SELECT * from `db_loglar` WHERE plaka = '$a_Plaka' AND kayittarihi>'$bugun $zamanbas' AND kayittarihi<'$bugun $zamanbit' order by `kayittarihi` ASC";
  
	$lastResult = @mysql_query($lastSql);
	$numResult = mysql_num_rows($lastResult);
	$dizi_zaman;
	$dizi_arac_yon;
	$sure=0;
	$k=0;
	if ($numResult>0)
	{
		while($listeid=mysql_fetch_array($lastResult))
		{
			$dizi_zaman[$k]=$listeid[kayittarihi];
			$dizi_arac_yon[$k]=$listeid[aracKonum];
			++$k;
		}
		for ($i = 0; $i < $k; $i++) 
		{
			if($dizi_arac_yon[$i]=="i" && $dizi_arac_yon[$i+1]=="d") 
			{	
				$sure_arasi=strtotime($dizi_zaman[$i+1]) - strtotime($dizi_zaman[$i]);
				$sure=$sure+$sure_arasi;
			}
		}
		return $sure;
	
	}else return 0;
}


function ekrana_bas ($girisdurum, $girissebebi, $karalistedurum, $karalistesebep, $plakadurum,  $area1, $area2 ,$area3, $ad, $soyad ,$sorgu_tur2,$baski1,$baski2,$baski3,$plakam) {

		if($sorgu_tur2!="1")
		{
		echo "[RESULT]
		ARAC_GIRIS_DURUM:".$girisdurum." 
		ARAC_GIRIS_BILGI:".$girissebebi."  
		KARA_LISTE_DURUM:".$karalistedurum."  
		KARA_LISTE_SEBEP:".$karalistesebep." 
		ARAC_PLAKA_DURUM:".$plakadurum." 
		ARAC_SAHIBI_AD:".$ad." 
		ARAC_SAHIBI_SOYAD:".$soyad." 
		ARAC_SAHIBI_AREA1:".$area1." 
		ARAC_SAHIBI_AREA2:".$area2." 
		ARAC_SAHIBI_AREA3:".$area3."";
		}
		else if($sorgu_tur2=="1")
		{
		$bas="";
		$bas1="ARAC_GIRIS_DURUM:".$girisdurum."\n
		<<<\n".$plakam."\n";
		$bas2="".$girissebebi."\n
";
$bas3="
SEBEP: ".$karalistesebep."";	
$bas4="".$plakadurummm.
		$bas5=">>>";
		if($baski1=="1"){
		$bas=$bas1.$bas2;
		}
		if($baski2=="1"){
		$bas=$bas.$bas3;
		}
		if($baski3=="1"){
		$bas=$bas.$bas4;
		}
		$bas=$bas.$bas5;

		echo $bas;


		}

}


$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
{
	$kam=mysql_fetch_array(mysql_query("select * from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	$kamkontrol=mysql_fetch_array(mysql_query("select COUNT(*) from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	
	if($kamkontrol[0]<1)
	{
		
		echo "[RESULT]e_yok"; //kamerayi bulamadim
		
	}
	elseif($kamkontrol[0]>0)
	{
		if($TEK_KAPI_GIRIS_CIKIS)
		{
			if (AracYeniMiCikti($arac_Plaka, $kamera_ID)==1)
			{
				ekrana_bas("3","Arac Yeni Girdi - Cikti","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);	
				exit();
			}
		}
	    $kontrol_plaka1=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka'")); 
	    $kontrol_plaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' AND UID='1'"));
		if($kam[5]=="c")   // G�R�� KAMERASINDAYIZ
		{ 	#
			if($kontrol_plaka1[0]<1) #ara� kayitsiz
			{
						
				ekrana_bas("1","Abone Olmayan Ara�","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);	
				//ekrana_bas("3","Giri�CamAbone Olmayan Ara�","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);	

			}		
			if($kontrol_plaka1[0]>0) #ara� kay�tl�
			{
				if ($ABONE_ARAC_ESZAMANLI==1 && $kontrol_plaka[0]>0) // abone arac ise ve eszamanli aktif ise
				{
					$kullanici_id=$kontrol_plaka['kullaniciid'];
					$kullanici_bilgisi=mysql_fetch_array(mysql_query("select * from db_musteriler where id='$kullanici_id'"));
					$maxarac=0;
					$icerdeki_araclar=0;
					if ($kullanici_bilgisi[0]>0)
					{
						$maxarac=$kullanici_bilgisi['maxarac'];
						$musteri_plakalar=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where kullaniciid='$kullanici_id' AND geciciarac='2' AND aracKonum='i' AND tipID>0"));
						$icerdeki_araclar=$musteri_plakalar[0];
						if($kontrol_plaka['aracKonum']=="i" && $kontrol_plaka['tipID']>0) $icerdeki_araclar=$icerdeki_araclar-1; //giris yapacak arac icerde gorunurse; 1 azalt
						if ($maxarac>$icerdeki_araclar)
						{
							ekrana_bas("2","Abone Arac Limit Yeterli","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);	
							$suan= convert_datetime("$tarih $zaman");
							mysql_query("update db_araclar set tipID='1' , barkod='$suan' where plaka='$arac_Plaka'");
							exit();
						}else
						{
							ekrana_bas("2","Abone Arac Ucretli Girdi","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);
							$suan= convert_datetime("$tarih $zaman");
							mysql_query("update db_araclar set tipID='0' , barkod='$suan' where plaka='$arac_Plaka'");
							exit();
						}
					}
				}
				
				ekrana_bas("2","Ara� Kay�t� Var","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);
				$suan= convert_datetime("$tarih $zaman");
				mysql_query("update db_araclar set tipID='1' , barkod='$suan' where plaka='$arac_Plaka'");
				exit();
			}					  
		}	
		if($kam[5]=="g"){  // �IKI� KAMERASINDAYIZ
		
			 $kontrol_plaka_gecici=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' AND UID='1' AND geciciarac!='1'"));
			 $sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' "));
			 
			 if ($sorguplaka['id']<1){
				ekrana_bas("3","Arac Kayiti Yok","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
				exit();
			 }	
			 $sorguplaka2=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' AND aracKonum='i'"));
			 $abonelik_bitisi=$sorguplaka['abonelikbitis'];
			 
			 ##########-----abonelik bitimen ne kadar kalm��------###############
			 $ekle_sorgu= "SELECT DATEDIFF('$abonelik_bitisi','$tarih $zaman')";
			 $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
			 $cikan_gun=$SQL_tarih_ekle[0];
			 ####################################################################
			 #27 Ocak �arsamba 2010  13:07
			 $abonelik_bitmesi = convert_datetime($abonelik_bitisi);		 
			 $suan= convert_datetime("$tarih $zaman");
			 $cikan_gunA=$abonelik_bitmesi-$suan; 
			 ####################################################################
		 
		    $sorgu_ne_kadar_kalmis=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE plaka='$arac_Plaka'"));
		    //$sonuc_zaman=dateDiff("$tarih $zaman", $sorgu_ne_kadar_kalmis['sondegisim'], "minute");
		    $sondegisim=$sorgu_ne_kadar_kalmis['sondegisim'];
			$arackonumum=$sorgu_ne_kadar_kalmis['aracKonum'];
		    $ekle_sorgu= "SELECT TIMEDIFF('$tarih $zaman','$sondegisim')";
		    $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
		    $cikan_saat=$SQL_tarih_ekle[0];
			$dilimler = explode(":", $cikan_saat);
			$saatim=(int)$dilimler[0];
			if($saatim[0]=="0"){$saatim = (int)str_replace("0","",$saatim);};
			$dakikam=(int)$dilimler[1];
			$saniyem=(int)$dilimler[2];
			$aracTipId=$sorguplaka['tipID'];
			
			////////////////////////////////////////
			$kaldigim_dakika=(($saatim*60)+$dakikam);

			$ucret_sorgu=mysql_fetch_array(mysql_query("SELECT * FROM db_fiyatlar WHERE tipID=$aracTipId AND baslangic<='$kaldigim_dakika' AND bitis>='$kaldigim_dakika' ORDER BY id DESC LIMIT 1"));
			$varmidir=mysql_num_rows(mysql_query("SELECT * FROM db_fiyatlar WHERE tipID=$aracTipId AND baslangic<='$kaldigim_dakika' AND bitis>='$kaldigim_dakika' ORDER BY id DESC LIMIT 1"));
			$sistemli_mi_artiyor=$ucret_sorgu['sistemli'];
			$fiyat_ne_kadar=$ucret_sorgu['ucret'];
			$birim_zaman_ne=$ucret_sorgu['birimzaman']; //d->60Dakika    g->G�n (1440Dakika)
			$birim_carpan=$ucret_sorgu['carpan'];
			
			
			if($birim_zaman_ne=='d'){
			
					if($sistemli_mi_artiyor=='e')
					{
						$kal_artan = $kaldigim_dakika%$birim_carpan;  //kalan
						$kal_bolum = (int)($kaldigim_dakika/$birim_carpan); //b�l�m
						$birim_ucretim = $ucret_sorgu[3];
						$ucret_cikar= (($kal_bolum+1)*$birim_ucretim );
					
					}
					if($sistemli_mi_artiyor=='h')
					{
					
						$ucret_cikar=$ucret_sorgu[3];
					
					}
					
			}
			
			if($birim_zaman_ne=='g'){
			
					if($sistemli_mi_artiyor=='e')
					{
						$kal_artan = $kaldigim_dakika%(1440*$birim_carpan);  //kalan
						$kal_bolum = (int)($kaldigim_dakika/(1440*$birim_carpan)); //b�l�m
						$birim_ucretim = $ucret_sorgu[3];
						$ucret_cikar= (($kal_bolum+1)*$birim_ucretim );
					
					}
					if($sistemli_mi_artiyor=='h')
					{
					
						$ucret_cikar=$ucret_sorgu[3];
					
					}
			}

			$ucret_cikar=intval($ucret_cikar);
			$gunluk_limit_asim=0;
			if ($ucret_cikar==0)
			{
				if ($sorguplaka['id']<1) $ucret_cikar=0.1;
				if ($saatim>$UCRETIZ_SAAT-1) $ucret_cikar=0.1;
				else{
					$toplamsure=$kaldigim_dakika+( AracDahaOnceCiktiMi($arac_Plaka,$tarih)/60 );
					if($toplamsure>$GUNLUK_ZAMAN_LIMIT_DK) 
					{	
						$ucret_cikar=0.1;
						$gunluk_limit_asim=1;
					}
				}
			}
			
			if(!$UCRETSIZ_OTO_CIKIS)
			{
				$ucret_cikar=1;
			}

			/////////////////////////////////////////////
			if($VALE_SISTEM_AKTIF)
			{
				if ($kontrol_plaka1['odeme_durum']>0 && $kaldigim_dakika<$MAKS_CIKIS_SURESI)
				 {
					mysql_query("update db_araclar set odeme_durum=0 where plaka='$arac_Plaka'");
					mysql_query("update db_araclar set vale_arac=0 where plaka='$arac_Plaka'");
					ekrana_bas("2","Vale �demeli Arac: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
					exit();
				 }else if($kontrol_plaka1['vale_arac']>0)
				 {
					ekrana_bas("2","Vale Kay�tl� Arac: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
					exit();
				 }


				if($kaldigim_dakika<$MAKS_CIKIS_SURESI && $kontrol_plaka1['aracKonum']=="d")
				{
					ekrana_bas("2","Vale Cikis Suresideki Arac: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
					exit();
				}
			}
		 
			 if($kontrol_plaka[0]<1) 
			 {
				if ($ucret_cikar>0)
				{
					#Abone ara� de�il
					if ($sorguplaka2['id']<1)
						ekrana_bas("3","Abone Olmayan Ara�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
					else
					{
						if($gunluk_limit_asim==0)
							ekrana_bas("1","Abone Olmayan Ara�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
						else
							ekrana_bas("1","Gunluk Limit Asim: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
					}
				}
				else{
					if ($sorguplaka['aracKonum']=='i')
					{
						ekrana_bas("2","Abone Olmayan Ara� - �cret Yok: $saatim Saat, $dakikam Dakika","0","","�cretsiz ��k��",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
						
					}else {
						ekrana_bas("3","Ara� D��ar�da G�r�n�yor - �cret Kontrol: $saatim Saat, $dakikam Dakika","0","","�cretsiz ��k��",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
					}
				}
				
				/*
				#Abone ara� de�il
				if ($sorguplaka2['id']>0)
					ekrana_bas("3","Abone Olmayan Ara�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
				else
					ekrana_bas("1","Abone Olmayan Ara�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
				// ekrana_bas("3","Abone Olmayan Ara�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
				*/
			 }
			 elseif($kontrol_plaka[0]>0)
			 {
			 #echo "kay�tl� ara�";
			 
			 
					###############ara� �yeli�ini otopark i�erisinde yapt�rm��###############################
	
					##########################ara� �yeli�ini �nceden yapt�rm��###############################
			
					if($cikan_gunA<0)#suresi bitmi� izin verme
					{
						if ($ucret_cikar>0)
						{
							ekrana_bas("3","Abone Ara� S�resi Bitmi�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
							//	ekrana_bas("3","Abone Ara� S�resi Bitmi�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
						}else
						{
							ekrana_bas("2","Abone Ara� S�resi Bitmi� - �cret Yok: $saatim Saat, $dakikam Dakika","0","","�cretsiz ��k��",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
						}
					}
					if($cikan_gunA>0)#suresi var sal gitsin
					{
						if($kontrol_plaka["abonelikTipi"]==1)
						{
							if($kontrol_plaka["AbonelikSaat"]>$saatim)
							{
								ekrana_bas("2","Abone Ara�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
							}else{
								ekrana_bas("3","Abone Ara� - Giri� Saat Limiti Dolmu�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
							}
						}else{
							if($ABONE_ARAC_ESZAMANLI==0)
							{
								ekrana_bas("2","Abone Ara�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
							}else
							{
								if ($sorguplaka['tipID']>0)
									ekrana_bas("2","Abone Ara�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
								else
								{
									if ($ucret_cikar>0)
										ekrana_bas("3","Abone Arac Limit Dolu Ucretli: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
									else
										ekrana_bas("2","Abone Ara� - �cret Yok: $saatim Saat, $dakikam Dakika","0","","�cretsiz ��k��",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
								}	
							}
						}
					}		 
			 
			 } 
		
		
		
		}
	
	}

}//sistem parolasi dogru ise
else echo '[RESULT]
access denied
';

?>
