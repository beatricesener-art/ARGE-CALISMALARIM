<?php
$outname="Kamera.Sorgu.ini";
//header("Content-Disposition: text; filename=\"$outname\";\n\n");
//*****************************************//
//*****************************************//
//*****************************************//

ini_set("display_errors","off");
require_once('../includes/veritabani.php');

$kamera_ID = $_POST['kamera_ID'];
$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];


/*$kamera_ID = '1';
$sistem_AD = 'dene4me';
$sistem_Parola = '123123';
*/


$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
  {
  $kam=mysql_fetch_array(mysql_query("select * from db_cihazlar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
  if($kam)  
    echo "[RESULT]
KAMERA_ID:$kam[kamera_ID]
KAPI_ID:$kam[kapi_ID]
ROLE_ID:$kam[role_ID]
KAMERA_YON:$kam[cihaz_Yon]
KAMERA_DURUM:$kam[cihaz_Durum]
CIKIS_IZIN:$kam[cikisizin]
IPADRES:$kam[ipAdres]
CIHAZ_TIPI:$kam[cihaztipi]
PORT:$kam[port]
      ";
  else echo '[RESULT]
e_yok';
  }
else echo '[RESULT]
access denied';
?>