<?php
//$outname="Arac.Sorgu.ini";
//header("Content-Disposition: text; filename=\"$outname\";\n\n");
//header ("Content-type: text/ini");
//*****************************************//
//**********NORON ELEKTRONIK*****************//
//********Plaka Tanima Sistemi*************//
//*****************************************//
//*****************************************//
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);

function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}

ini_set("display_errors","off");
require_once('../includes/veritabani.php');


function dateDiff($d1, $d2=null, $format="all"){
    if($d2==null){
        $d2=$d1;
        $d1=time();
    }

    if(!is_int($d1)) $d1=strtotime($d1);
    if(!is_int($d2)) $d2=strtotime($d2);
    $d=abs($d1-$d2);

    $format=strtolower($format);
    if(empty($format) || $format=="*") $format="all";
    if(strrpos($format, 's')==strlen($format)-1){
        $format=substr($format, 0, strlen($format)-1);
    }

    $result = array();

    if($format=="all" || $format=="day")    $result["day"]   = floor($d/(60*60*24));
    if($format=="all" || $format=="month")  $result["month"] = floor($d/(60*60*24*30));
    if($format=="all" || $format=="year")   $result["year"]  = floor($d/(60*60*24*365));
    if($format=="all" || $format=="week")   $result["week"]  = floor($d/(60*60*24*7));
    if($format=="all" || $format=="hour")   $result["hour"]  = floor($d/(60*60));
    if($format=="all" || $format=="minute") $result["minute"]= floor($d/60);

    if($format!="all") return $result[$format];
    else return $result;
}

$kart_Kartno = $_POST['kart_Kartno'];
$kapi_ID = $_POST['kapi_ID'];
$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];
$sorgu_tur = $_POST['sorguturu'];

/*
$kart_Kartno ="0123456789";
$kapi_ID = '10000001';
$sistem_AD = 'sistem';
$sistem_Parola = '123123';
$sorgu_tur="1";
*/

$sorguAracPlaka=mysql_fetch_array(mysql_query("select * from db_araclar where barkod='$kart_Kartno' "));
if($sorguAracPlaka["id"]>0)
{
	$arac_Plaka=$sorguAracPlaka["plaka"];
}else{
	ekrana_bas("1","Barkod Kayitli Degil","0","yok","Bilinmiyor","YOK","YOK","YOK","YOK","YOK",1,1,0,1,$sorguAracPlaka["plaka"]);	
	exit();
}

$sorguKameraId=mysql_fetch_array(mysql_query("select * from db_cihazlar where kapi_ID='$kapi_ID' "));
if($sorguKameraId["id"]>0)
{
	$kamera_ID=$sorguKameraId["kamera_ID"];
}else{
	echo "[RESULT]
e_yok"; //kamerayi bulamadim
	exit();
}


function AracYeniMiCikti($a_Plaka, $cam_id)
{
	$ttt=mysql_fetch_array(mysql_query("SELECT * FROM db_siteayar WHERE id='1'"));
	$arac_gir_cik=$ttt['arac_gircik'];
	if ($arac_gir_cik==0)
	{
		$lastSql="SELECT * from `db_loglar` WHERE plaka = '$a_Plaka' order by `kayittarihi` DESC LIMIT 0,1";
		$lastResult = @mysql_query($lastSql);
		$numResult = mysql_num_rows($lastResult);
		$lastVal = @mysql_fetch_assoc($lastResult);
		if ($numResult>0)
		{
			$seconds = strtotime("".$tarih." ".$zaman."") - strtotime($lastVal['kayittarihi']);
			if ($seconds>60 || $cam_id ==$lastVal['kameraid']) return 0;
			else return 1;
		
		}else return 0;
	}else return 0;
}


function ekrana_bas ($girisdurum, $girissebebi, $karalistedurum, $karalistesebep, $plakadurum,  $area1, $area2 ,$area3, $ad, $soyad ,$sorgu_tur2,$baski1,$baski2,$baski3,$plakam) {

		if($sorgu_tur2!="1")
		{
		echo "[RESULT]
		ARAC_GIRIS_DURUM:".$girisdurum." 
		ARAC_GIRIS_BILGI:".$girissebebi."  
		KARA_LISTE_DURUM:".$karalistedurum."  
		KARA_LISTE_SEBEP:".$karalistesebep." 
		ARAC_PLAKA_DURUM:".$plakadurum." 
		ARAC_SAHIBI_AD:".$ad." 
		ARAC_SAHIBI_SOYAD:".$soyad." 
		ARAC_SAHIBI_AREA1:".$area1." 
		ARAC_SAHIBI_AREA2:".$area2." 
		ARAC_SAHIBI_AREA3:".$area3."";
		}
		else if($sorgu_tur2=="1")
		{
		$bas="";
		$bas1="ARAC_GIRIS_DURUM:".$girisdurum."\n
		<<<\n".$plakam."\n";
		$bas2="".$girissebebi."\n
";
$bas3="
SEBEP: ".$karalistesebep."";	
$bas4="".$plakadurummm.
		$bas5=">>>";
		if($baski1=="1"){
		$bas=$bas1.$bas2;
		}
		if($baski2=="1"){
		$bas=$bas.$bas3;
		}
		if($baski3=="1"){
		$bas=$bas.$bas4;
		}
		$bas=$bas.$bas5;

		echo $bas;


		}

}


$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
{
	$kam=mysql_fetch_array(mysql_query("select * from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	$kamkontrol=mysql_fetch_array(mysql_query("select COUNT(*) from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	
	if($kamkontrol[0]<1)
	{
		
		echo "[RESULT]e_yok"; //kamerayi bulamadim
		
	}
	elseif($kamkontrol[0]>0)
	{
		if($TEK_KAPI_GIRIS_CIKIS)
		{
			if (AracYeniMiCikti($arac_Plaka, $kamera_ID)==1)
			{
				ekrana_bas("1","Arac Yeni Girdi - Cikti","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);	
				exit();
			}
		}
	    $kontrol_plaka1=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka'")); 
	    $kontrol_plaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' AND UID='1'"));
		if($kam[5]=="c")   // G�R�� KAMERASINDAYIZ
		{ 	#
			if($kontrol_plaka1[0]<1) #ara� kayitsiz
			{
						
				ekrana_bas("1","Abone Olmayan Ara�","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);	
				//ekrana_bas("3","Giri�CamAbone Olmayan Ara�","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);	

			}		
			if($kontrol_plaka1[0]>0) #ara� kay�tl�
			{
				ekrana_bas("1","Ara� Kay�t� Var","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$arac_Plaka);
				$suan= convert_datetime("$tarih $zaman");
				//mysql_query("update db_araclar set tipID='1' , barkod='$suan' where plaka='$arac_Plaka'");
				exit();
			}					  
		}	
		if($kam[5]=="g"){  // �IKI� KAMERASINDAYIZ
		
			 $kontrol_plaka_gecici=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' AND UID='1' AND geciciarac!='1'"));
			 $sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' "));
			 
			 if ($sorguplaka['id']<1){
				ekrana_bas("3","Arac Kayiti Yok","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
				exit();
			 }	
			 $sorguplaka2=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' AND aracKonum='i'"));
			 $abonelik_bitisi=$sorguplaka['abonelikbitis'];
			 
			 ##########-----abonelik bitimen ne kadar kalm��------###############
			 $ekle_sorgu= "SELECT DATEDIFF('$abonelik_bitisi','$tarih $zaman')";
			 $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
			 $cikan_gun=$SQL_tarih_ekle[0];
			 ####################################################################
			 #27 Ocak �arsamba 2010  13:07
			 $abonelik_bitmesi = convert_datetime($abonelik_bitisi);		 
			 $suan= convert_datetime("$tarih $zaman");
			 $cikan_gunA=$abonelik_bitmesi-$suan; 
			 ####################################################################
		 
		    $sorgu_ne_kadar_kalmis=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE plaka='$arac_Plaka'"));
		    //$sonuc_zaman=dateDiff("$tarih $zaman", $sorgu_ne_kadar_kalmis['sondegisim'], "minute");
		    $sondegisim=$sorgu_ne_kadar_kalmis['sondegisim'];
			$arackonumum=$sorgu_ne_kadar_kalmis['aracKonum'];
		    $ekle_sorgu= "SELECT TIMEDIFF('$tarih $zaman','$sondegisim')";
		    $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
		    $cikan_saat=$SQL_tarih_ekle[0];
			$dilimler = explode(":", $cikan_saat);
			$saatim=(int)$dilimler[0];
			if($saatim[0]=="0"){$saatim = (int)str_replace("0","",$saatim);};
			$dakikam=(int)$dilimler[1];
			$saniyem=(int)$dilimler[2];
			$aracTipId=$sorguplaka['tipID'];
			
			////////////////////////////////////////
			$kaldigim_dakika=(($saatim*60)+$dakikam);

			if ($kontrol_plaka1['odeme_durum']>0 && $kaldigim_dakika<$MAKS_CIKIS_SURESI)
			{
				mysql_query("update db_araclar set odeme_durum=0 where plaka='$arac_Plaka'");
				mysql_query("update db_araclar set vale_arac=0 where plaka='$arac_Plaka'");
				ekrana_bas("2","Barkod Kayitli Arac: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
			}else
			{
				ekrana_bas("1","Barkod Zaman Asimi: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$arac_Plaka);
			}
		
		}
	
	}

}//sistem parolasi dogru ise
else echo '[RESULT]
access denied
';

?>
