<?php
$outname="Giris.Log.ini";
//header("Content-Disposition: text; filename=\"$outname\";\n\n");
//*****************************************//
//*****************************************//

ini_set("display_errors","off");
require_once('../includes/veritabani.php');

function permayap($deger) {
$turkce=array("�","�","�","(",")","'","�","�","�","�","�","�","/","*","?","�","�","�","�","�","�","�","�","�","�","�","�");
$duzgun=array("s","S","i","","","","u","U","o","O","c","C","-","-","","s","S","i","g","G","I","o","O","C","c","u","U");
$deger=str_replace($turkce,$duzgun,$deger);
return $deger;
}
####################################################
/*function acilma_suresi (){
$time = explode( " ", microtime());
$usec = (double)$time[0];
$sec = (double)$time[1];
return $sec + $usec;
}
$saymaya_basla = acilma_suresi();*/
###################################################

function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}

function dateDiff($d1, $d2=null, $format="all"){
    if($d2==null){
        $d2=$d1;
        $d1=time();
    }

    if(!is_int($d1)) $d1=strtotime($d1);
    if(!is_int($d2)) $d2=strtotime($d2);
    $d=abs($d1-$d2);

    $format=strtolower($format);
    if(empty($format) || $format=="*") $format="all";
    if(strrpos($format, 's')==strlen($format)-1){
        $format=substr($format, 0, strlen($format)-1);
    }

    $result = array();

    if($format=="all" || $format=="day")    $result["day"]   = floor($d/(60*60*24));
    if($format=="all" || $format=="month")  $result["month"] = floor($d/(60*60*24*30));
    if($format=="all" || $format=="year")   $result["year"]  = floor($d/(60*60*24*365));
    if($format=="all" || $format=="week")   $result["week"]  = floor($d/(60*60*24*7));
    if($format=="all" || $format=="hour")   $result["hour"]  = floor($d/(60*60));
    if($format=="all" || $format=="minute") $result["minute"]= floor($d/60);

    if($format!="all") return $result[$format];
    else return $result;
}

function haftanin_gunu($tarih2)
{
	$gunler = array();
	$gunler[0] = "Pz";
	$gunler[1] = "Pts";
	$gunler[2] = "Sal";
	$gunler[3] = "Car";
	$gunler[4] = "Per";
	$gunler[5] = "Cum";
	$gunler[6] = "Cts";
 
	return $gunler[strftime("%w",strtotime($tarih2))];
}

function AracYeniMiCikti($a_Plaka, $cam_id, $maks_sure)
{
	echo($GIRIS_LOG_TIMEOUT);
	$GIRIS_LOG_TIMEOUT=100;
	$lastSql="SELECT * from `db_loglar` WHERE plaka = '$a_Plaka' AND kameraid='$cam_id' order by `kayittarihi` DESC LIMIT 0,1";
	$lastResult = @mysql_query($lastSql);
	$numResult = mysql_num_rows($lastResult);
	$lastVal = @mysql_fetch_assoc($lastResult);
	if ($numResult>0)
	{
		$seconds = strtotime("".$tarih." ".$zaman."") - strtotime($lastVal['kayittarihi']);
		if ($seconds>$maks_sure) return 0;
		else return 1;
	
	}else return 0;
}


$kart_Kartno = $_POST['kart_Kartno'];
$kapi_ID = $_POST['kapi_ID'];
$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];
$sebep = $_POST['log_Sebep'];
$resim_yolu = $_POST['resim_Yolu'];

/*
$kart_Kartno="0123456789";
$kapi_ID = '10000001';
$sistem_AD = 'sistem';
$sistem_Parola = '123123';
$resim_yolu="";
$sebep="TestGirsin";
*/
$sorguAracPlaka=mysql_fetch_array(mysql_query("select * from db_araclar where barkod='$kart_Kartno' "));
if($sorguAracPlaka["id"]>0)
{
	$arac_Plaka=$sorguAracPlaka["plaka"];
}else{
	echo "[RESULT]
e_yok"; //kamerayi bulamadim
	exit();
}

$sorguKameraId=mysql_fetch_array(mysql_query("select * from db_cihazlar where kapi_ID='$kapi_ID' "));
if($sorguKameraId["id"]>0)
{
	$kamera_ID=$sorguKameraId["kamera_ID"];
}else{
	echo "[RESULT]
e_yok"; //kamerayi bulamadim
	exit();
}


//$arac_Plaka = $_POST['arac_Plaka'];
//$kamera_ID = $_POST['kamera_ID'];

$a6 = $_POST['a6'];
$a7 = $_POST['a7'];
$a8 = $_POST['a8'];

#zaman ayarlari
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);


#sebep al 
$string=$sebep;
$sonuc=strpos($string, ";");
$names = explode(';', $string); 



$sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' "));
$aracvarmidirsorgula=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' "));
$aracvarmidir=$aracvarmidirsorgula[0];
$user_id=$sorguplaka["kullaniciid"];

$userim=permayap($userim);
$sebep=permayap($sebep);
$aracdurumum=$sorguplaka[5];



$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
{
	$kam=mysql_fetch_array(mysql_query("select * from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	$kamkontrol=mysql_fetch_array(mysql_query("select COUNT(*) from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	
	if($kamkontrol[0]<1)
	{
		
		echo "[RESULT]
e_yok"; //kamerayi bulamadim
		
	}
	elseif($kamkontrol[0]>0)
	{
	
			#hemen logla
			
			#ara� ne tarafta i�eride mi d��ar�da m� ?
			
			$kapi=$kam['kamera_ID'];
			$camgrup=$kam['camgrup'];
			$yon=$kam['kamera_Yon'];
			$kapi_sistem=$kam['sistem_ID'];
			($yon=='c') ? $konum='i' : $konum='d'; //($yon=='c') ? $konum='i' : $konum='d';
			$aracDurum='e_yok';
			
			#D�ZENLEME otomatik ge�isi a�ikmala olarak not al
			if($yon=='g'){
			
			$sebep=$sebep." Otomatik Ge�is Yapildi.";
			
			}
			
			if($aracvarmidir>0){
			
			$aracdurumum=$sorguplaka['UID'];
			
			}
			if($aracvarmidir<1){
			
			$aracdurumum="0"; //Ge�ici ara� hocam
			
			}
			
			if (AracYeniMiCikti($arac_Plaka, $kamera_ID,$GIRIS_LOG_TIMEOUT)==0) // birden fazla log engelle
			{
			
			$log_ekle="INSERT INTO `db_loglar` (
			`id` ,
			`plaka` ,
			`kayittarihi` ,
			`kameraid` ,
			`sebep` ,
			`resimyolu`, 
			`kullanici`,
			`area1` ,
			`area2` ,
			`area3` ,
			`aracdurum` ,
			`aracKonum` ,
			`soncamgrupid` ,
			`sistemid`
			)
			VALUES (
			NULL , '$arac_Plaka', '$tarih $zaman', '".$kapi."', '$sebep', '$resim_yolu','$userim','$aream1','$aream2','$aream3','$aracdurumum','$konum','$camgrup','$sistem_AD'
			)";
			
		    	mysql_query($log_ekle)or die(mysql_error());
			}
			


			#loglara eklenmi� ise
			
			if(mysql_insert_id()>0) echo '[RESULT]
OK';
			#arac sistemde kay�tl�d�r
			if($aracvarmidir>0){
			
			#kay�tl�ysa zaten kay�tl�
			##var olani g�ncelle
			
			//mysql_query("UPDATE `db_araclar` SET `kullaniciid` = '$kullanicimbenim' WHERE `db_araclar`.`plaka` ='$arac_Plaka' LIMIT 1 ");
			
			}
			#arac kay�ts�z sisteme ge�ici ara� olarak ekle
			if($aracvarmidir<1){
			
				$suan= convert_datetime("$tarih $zaman");
				$ekle="INSERT INTO `db_araclar` (
				`id` ,
				`kullaniciid` ,
				`marka` ,
				`model` ,
				`renk` ,
				`UID` ,
				`aracsurucusu` ,
				`eklenme` ,
				`plaka`,
				`geciciarac`,
				`barkod`
				)
				VALUES (
				NULL , '$kullanicimbenim', '', '', '', '', '', '$tarih $zaman', '$arac_Plaka', '1' , $suan
				)";
					mysql_query($ekle)or die(mysql_error());
			
			}
			
			mysql_query("update db_araclar set aracKonum='$konum' where plaka='$arac_Plaka'");
			mysql_query("update db_araclar set sondegisim='$tarih $zaman' where plaka='$arac_Plaka'");
			mysql_query("update db_araclar set soncamid='$kapi' where plaka='$arac_Plaka'");
			mysql_query("update db_araclar set soncamgrupid='$camgrup' where plaka='$arac_Plaka'");
			
			
			/*mysql_query("INSERT INTO `db_giriscikis` (
`id` ,
`plaka` ,
`soncamid` ,
`soncamgrupid` ,
`arackonum` ,
`sondegisim`
)
VALUES (
NULL , '$arac_Plaka', '$kapi', '$camgrup', '$konum', '$tarih $zaman'
)");*/
	
	}

}//sistem parolasi dogru ise
else echo '[RESULT]
access denied';
mysql_close();
##################################################################
/*$saymayi_bitir = acilma_suresi(); 
$basla = $saymayi_bitir - $saymaya_basla; 
echo " " . substr($basla, 0, 5) . "\n";

$logtut = "Olusturulma: " . substr($basla, 0, 5) . " " . $_SERVER['HTTP_USER_AGENT'] . "<br>";
$fopen = fopen("Logs_Sure.html", "a");
fwrite($fopen, $logtut);
fclose($fopen);*/
##################################################################

?>
