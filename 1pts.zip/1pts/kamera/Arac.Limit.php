<?php

/** Genel De�i�kenler ve Tan�mlamalar */

require_once('../includes/veritabani.php');

$db_server =  $db_host;  /**Veri Taban� Sunucusu */
$db_db= $db_name;  /**Veri Taban� Ad� */
$gecikme_zamani = 0 ; /** Bu De�er Yada �st�nde Ekrana Basar */

/**  */

function tarihFarki($d1, $d2=null, $format="*"){
    if($d2==null){
        $d2=$d1;
        $d1=time();
    }
 
    if(!is_int($d1)) $d1=strtotime($d1);
    if(!is_int($d2)) $d2=strtotime($d2);
    $d=abs($d1-$d2);
 
    $format=strtolower($format);
    if(empty($format)) $format="*";
 
    $result = array();
 
    if($format=="*" || $format=="gun")    $result["gun"]   = floor($d/(60*60*24));
    if($format=="*" || $format=="ay")     $result["ay"] = floor($d/(60*60*24*30));
    if($format=="*" || $format=="yil")    $result["yil"]  = floor($d/(60*60*24*365));
    if($format=="*" || $format=="hafta")  $result["hafta"]  = floor($d/(60*60*24*7));
    if($format=="*" || $format=="saat")   $result["saat"]  = floor($d/(60*60));
    if($format=="*" || $format=="dakika") $result["dakika"]= floor($d/60);
 
    if($format!="*") return $result[$format];
    else return $result;
}
/** Fonksiyon Sonu **/
$baglanti = mysqli_connect($db_server,$db_user,$db_pass,$db_db);
if (!$baglanti){
	die ("Ba�lant� Sorunlu".mysql_error());
}
if(isset($_REQUEST['act']))
	switch($_REQUEST['act']){
		case 'cikar':
			$plaka	= mysql_real_escape_string($_REQUEST['plaka']);
			$q	= "update db_araclar set aracKonum = 'd' where plaka='$plaka'";
			mysqli_query ($baglanti,$q);
	}
$sorgu = "SELECT * FROM db_araclar WHERE aracKonum LIKE 'i'";
$sorgu_gonder = mysqli_query ($baglanti,$sorgu);
$satir_sayisi = mysqli_num_rows($sorgu_gonder);

echo($MAKS_ARAC_SAYISI-$satir_sayisi);
?>