<?php
ini_set("display_errors","off");
require_once('../includes/veritabani.php');

$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];

/*
$sistem_AD = 'deneme';
$sistem_Parola = '123123';
*/
//SELECT * from `db_loglar`  order by `kayittarihi` DESC LIMIT 0,1 //tarihzaman

$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
  {
  $sorgula=mysql_query("select * from db_aractipleri ORDER BY tipID");
  while($listeid=mysql_fetch_array($sorgula))
  {
	echo "[RESULT][ID:$listeid[tipID]][AD:$listeid[tipAdi]]";
  }
 }
else {
	echo 'access denied';
}
?>