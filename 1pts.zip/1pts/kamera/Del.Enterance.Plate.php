<?
@session_start();
include_once("../Guvenlik.Filtre.php");


$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('../includes/veritabani.php');

$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];
$arac_Plaka = $_POST['arac_Plaka'];
$arac_Plaka_Yeni = $_POST['arac_Plaka_Yeni'];
$kamera_ID = $_POST['kamera_ID'];
$aracAciklama = $_POST['aracAciklama'];

/*
$sistem_AD="deneme";
$sistem_Parola="123123";
$kamera_ID = "1";
$arac_Plaka="34TY3462";
$arac_Plaka_Yeni="34TY34620";
$aracAciklama = "onemli giris";
*/

$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]<1)
{
  echo"access denied";
  exit();
}

			
	mysql_query("DELETE FROM db_araclar WHERE plaka='$arac_Plaka' ORDER BY id desc LIMIT 1");
	mysql_query("DELETE FROM db_loglar WHERE plaka='$arac_Plaka' ORDER BY id desc LIMIT 1");
	
?>