<?

require_once('../includes/veritabani.php');

$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);

function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = @mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}

function getDifference($startDate,$endDate)
{
$ilk_zaman=convert_datetime($startDate);
$son_zaman=convert_datetime($endDate);
$cikan_saniye=(int)($ilk_zaman-$son_zaman);

$kalan_saniye=($cikan_saniye%60);
$cikan_saat=floor($cikan_saniye/(60*60)); //kac saat oldu�u=27
$cikan_dakika=floor(($cikan_saniye-($cikan_saat*60*60))/60); //2800 saniye--46 dakika
$cikan_saniye=$cikan_saniye-(($cikan_saat*60*60)+($cikan_dakika*60));
$sonuc=(int)$cikan_saat.":".(int)$cikan_dakika.":".(int)$cikan_saniye;
return $sonuc;
//return $sonuc;  //1234:24:23  => Saat:Dakika:Saniye                 
}

$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];
$arac_Plaka = $_POST['arac_Plaka'];

/*
$sistem_AD="deneme";
$sistem_Parola="123123";
$arac_Plaka="34ET300";
*/

$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]<1)
{
  echo"access denied";
  exit();
}

$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);

$sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' and aracKonum='i' order by id DESC LIMIT 1"));			
$sondegisim=$sorguplaka['sondegisim'];
$tipID=$sorguplaka['tipID'];
					
$cikan_saat=getDifference("$tarih $zaman","$sondegisim");
//echo $cikan_saat_new;
$dilimler = explode(":", $cikan_saat);
$saatim=(int)$dilimler[0];
if($saatim[0]=="0"){$saatim = (int)str_replace("0","",$saatim);};
$dakikam=(int)$dilimler[1];
$saniyem=(int)$dilimler[2];
$toplam_dakika_kaldi=($saatim*60)+$dakikam;
				
//echo "SAAT<".$saatim.">,".$dakikam." Dakika";
					
$saatim=(int)$saatim;
$yeni_saat=(int)($saatim+1);
$kaldigim_dakika=(($saatim*60)+$dakikam);
			

$ucret_sorgu=mysql_fetch_array(mysql_query("SELECT * FROM db_fiyatlar WHERE baslangic<='$kaldigim_dakika' AND tipID=$tipID AND bitis>='$kaldigim_dakika' ORDER BY id DESC LIMIT 1"));
$varmidir=mysql_num_rows(mysql_query("SELECT * FROM db_fiyatlar WHERE baslangic<='$kaldigim_dakika' AND tipID=$tipID AND bitis>='$kaldigim_dakika' ORDER BY id DESC LIMIT 1"));
$sistemli_mi_artiyor=$ucret_sorgu['sistemli'];
$fiyat_ne_kadar=$ucret_sorgu['ucret'];
$birim_zaman_ne=$ucret_sorgu['birimzaman']; //d->60Dakika    g->G�n (1440Dakika)
$birim_carpan=$ucret_sorgu['carpan'];
if($birim_zaman_ne=='d'){
		if($sistemli_mi_artiyor=='e')
		{
			if ($birim_carpan!=0) $kal_artan = $kaldigim_dakika%$birim_carpan;  //kalan
			if ($birim_carpan!=0) $kal_bolum = (int)($kaldigim_dakika/$birim_carpan); //b�l�m
			$birim_ucretim = $ucret_sorgu[3];
			$ucret_cikar= (($kal_bolum+1)*$birim_ucretim );
		
		}
		if($sistemli_mi_artiyor=='h')
		{
		
			$ucret_cikar=$ucret_sorgu[3];
		
		}
		
}
if($birim_zaman_ne=='g'){

		if($sistemli_mi_artiyor=='e')
		{
			$kal_artan = $kaldigim_dakika%(1440*$birim_carpan);  //kalan
			$kal_bolum = (int)($kaldigim_dakika/(1440*$birim_carpan)); //b�l�m
			$birim_ucretim = $ucret_sorgu[3];
			$ucret_cikar= (($kal_bolum+1)*$birim_ucretim );
		
		}
		if($sistemli_mi_artiyor=='h')
		{
		
			$ucret_cikar=$ucret_sorgu[3];
		
		}
}

//echo $ucret_cikar. " TL";



 $sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' "));
 $abonelik_bitisi=$sorguplaka['abonelikbitis'];
 
 ##########-----abonelik bitimen ne kadar kalm��------###############
 $ekle_sorgu= "SELECT DATEDIFF('$abonelik_bitisi','$tarih $zaman')";
 $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
 $cikan_gun=$SQL_tarih_ekle[0];
 ####################################################################
 #27 Ocak �arsamba 2010  13:07
 $abonelik_bitmesi = convert_datetime($abonelik_bitisi);		 
 $suan= convert_datetime("$tarih $zaman");
 $cikan_gunA=$abonelik_bitmesi-$suan; 
 ####################################################################
// echo("Abonelik Bitis".$cikan_gunA);

echo "[RESULT]
SAAT:$saatim
DAKIKA:$dakikam
UCRET:$ucret_cikar
ABONELIK:$cikan_gunA
      ";
	 
	
?>