<?php
//$outname="Arac.Sorgu.ini";
//header("Content-Disposition: text; filename=\"$outname\";\n\n");
//header ("Content-type: text/ini");
//*****************************************//
//*****************************************//
//*****************************************//
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);

function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}

ini_set("display_errors","off");
require_once('../includes/veritabani.php');


function dateDiff($d1, $d2=null, $format="all"){
    if($d2==null){
        $d2=$d1;
        $d1=time();
    }

    if(!is_int($d1)) $d1=strtotime($d1);
    if(!is_int($d2)) $d2=strtotime($d2);
    $d=abs($d1-$d2);

    $format=strtolower($format);
    if(empty($format) || $format=="*") $format="all";
    if(strrpos($format, 's')==strlen($format)-1){
        $format=substr($format, 0, strlen($format)-1);
    }

    $result = array();

    if($format=="all" || $format=="day")    $result["day"]   = floor($d/(60*60*24));
    if($format=="all" || $format=="month")  $result["month"] = floor($d/(60*60*24*30));
    if($format=="all" || $format=="year")   $result["year"]  = floor($d/(60*60*24*365));
    if($format=="all" || $format=="week")   $result["week"]  = floor($d/(60*60*24*7));
    if($format=="all" || $format=="hour")   $result["hour"]  = floor($d/(60*60));
    if($format=="all" || $format=="minute") $result["minute"]= floor($d/60);

    if($format!="all") return $result[$format];
    else return $result;
}

/*
$kart_numarasi ="96927FF4";
$kapi_ID = '10000005';
$sistem_AD = 'sistem';
$sistem_Parola = '123123';
$sorgu_tur="1";
*/


$kart_numarasi = $_POST['kart_Kartno'];
$kapi_ID = $_POST['kapi_ID'];
$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];
$sorgu_tur=$_POST['sorguturu'];


function ekrana_bas ($girisdurum, $girissebebi, $karalistedurum, $karalistesebep, $kartnodurum,  $area1, $area2 ,$area3, $ad, $soyad ,$sorgu_tur2,$baski1,$baski2,$baski3,$kartnom) 
{
	if($sorgu_tur2=="1")
	{
		echo "[RESULT]
		KART_GIRIS_DURUM:".$girisdurum." 
		KART_GIRIS_BILGI:".$girissebebi."  
		KARA_LISTE_DURUM:".$karalistedurum."  
		KARA_LISTE_SEBEP:".$karalistesebep." 
		KART_NO_DURUM:".$kartnodurum." 
		KART_SAHIBI_AD:".$ad." 
		KART_SAHIBI_SOYAD:".$soyad." 
		KART_SAHIBI_AREA1:".$area1." 
		KART_SAHIBI_AREA2:".$area2." 
		KART_SAHIBI_AREA3:".$area3."";	
	}
}

$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
{
	//$kam=mysql_fetch_array(mysql_query("select * from db_cihazlar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	$kamkontrol=mysql_fetch_array(mysql_query("select * from db_cihazlar where kapi_ID='$kapi_ID' and sistem_ID='$sistem_AD'"));
	
	if($kamkontrol[0]<1)
	{
		
		echo "[RESULT]e_yok"; //kamerayi bulamadim
		
	}
	elseif($kamkontrol[0]>0)
	{
	    $kontrol_kartNosu=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$kart_numarasi' AND UID='1'")); 
		$kontrol_kartBilgi=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$kart_numarasi'")); 
		$sorgu_kullanici=mysql_fetch_array(mysql_query("select * from db_musteriler where id='$kontrol_kartBilgi[kullaniciid]'"));
		if($kamkontrol[cihaz_Yon]=="g")   // �IKI� KAMERASINDAYIZ
		{ 	#
		
			if($kontrol_kartNosu[0]<1) #Kart kayitsiz
			{
						
				ekrana_bas("1","Abone Olmayan Kart","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$kart_numarasi);	
				//ekrana_bas("3","Giri�CamAbone Olmayan Kart","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$kart_numarasi);	

			}		
			if($kontrol_kartNosu[0]>0) #Kart kay�tl�
			{
			
				ekrana_bas("2","Kayitli Kart","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$kart_numarasi);	
				//ekrana_bas("3","Giri�CamAbone Kart","0",$sorgukaraliste["sebep"],"Bilinmiyor",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,1,$kart_numarasi);	

			}					  
		}	
		if($kamkontrol[cihaz_Yon]=="c"){  // G�R�� KAMERASINDAYIZ
		
			 $kontrol_kartNosu_gecici=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$kart_numarasi' AND UID='1' AND gecicikart!='1'"));
			 $sorgukartNosu=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$kart_numarasi' "));
			 $abonelik_bitisi=$sorgukartNosu['abonelikbitis'];
			 
			 ##########-----abonelik bitimen ne kadar kalm��------###############
			 $ekle_sorgu= "SELECT DATEDIFF('$abonelik_bitisi','$tarih $zaman')";
			 $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
			 $cikan_gun=$SQL_tarih_ekle[0];
			 ####################################################################
			 #27 Ocak �arsamba 2010  13:07
			 $abonelik_bitmesi = convert_datetime($abonelik_bitisi);		 
			 $suan= convert_datetime("$tarih $zaman");
			 $cikan_gunA=$abonelik_bitmesi-$suan; 
			 ####################################################################
		 
		    $sorgu_ne_kadar_kalmis=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE plaka='$kart_numarasi'"));
		    //$sonuc_zaman=dateDiff("$tarih $zaman", $sorgu_ne_kadar_kalmis['sondegisim'], "minute");
		    $sondegisim=$sorgu_ne_kadar_kalmis['sondegisim'];
			$kartKonumum=$sorgu_ne_kadar_kalmis['kartKonum'];
		    $ekle_sorgu= "SELECT TIMEDIFF('$tarih $zaman','$sondegisim')";
		    $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
		    $cikan_saat=$SQL_tarih_ekle[0];
			$dilimler = explode(":", $cikan_saat);
			$saatim=(int)$dilimler[0];
			if($saatim[0]=="0"){$saatim = (int)str_replace("0","",$saatim);};
			$dakikam=(int)$dilimler[1];
			$saniyem=(int)$dilimler[2];
		 
			 if($kontrol_kartNosu[0]<1) 
			 {
			 #Abone Kart de�il
			 

			 ekrana_bas("1","Abone Olmayan Kart: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$kart_numarasi);
			// ekrana_bas("3","Abone Olmayan Kart: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone De�il",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$kart_numarasi);

			 }
			 elseif($kontrol_kartNosu[0]>0)
			 {
					$seconds = strtotime("".$tarih." ".$zaman."") - strtotime($sondegisim);

					##########################Kart �yeli�ini �nceden yapt�rm��###############################
					//kartKonum
			
					if($cikan_gunA<0)#suresi bitmi� izin verme
					{
					
						ekrana_bas("1","Abone Kart S�resi Bitmi�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$kart_numarasi);
					//	ekrana_bas("3","Abone Kart S�resi Bitmi�: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$kart_numarasi);

					}
					
					if($cikan_gunA>0)#suresi var sal gitsin
					{
						ekrana_bas("2","Abone Kart: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$kart_numarasi);
						/* anti passback i�in
						if ($kartKonumum=="i" && $seconds<43200)
							ekrana_bas("3","Abone Kart: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$kart_numarasi);
						else
							ekrana_bas("2","Abone Kart: $saatim Saat, $dakikam Dakika","0",$sorgukaraliste["sebep"],"Abone",$area1name[1],$area2name[1],$area3name[1],$sorgu_kullanici[1],$sorgu_kullanici[2],$sorgu_tur,1,0,0,$kart_numarasi);
						*/
					}		 
			 
			 } 
		}
	
	}

}//sistem parolasi dogru ise
else echo '[RESULT]
access denied
';

?>