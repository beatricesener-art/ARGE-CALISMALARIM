<?
@session_start();
$ip = $_SERVER['REMOTE_ADDR']; 


function getDifference($startDate,$endDate)
{
$ilk_zaman=convert_datetime($startDate);
$son_zaman=convert_datetime($endDate);
$cikan_saniye=(int)($ilk_zaman-$son_zaman);

$kalan_saniye=($cikan_saniye%60);
$cikan_saat=floor($cikan_saniye/(60*60)); //kac saat oldu�u=27
$cikan_dakika=floor(($cikan_saniye-($cikan_saat*60*60))/60); //2800 saniye--46 dakika
$cikan_saniye=$cikan_saniye-(($cikan_saat*60*60)+($cikan_dakika*60));
$sonuc=(int)$cikan_saat.":".(int)$cikan_dakika.":".(int)$cikan_saniye;
return $sonuc;
//return $sonuc;  //1234:24:23  => Saat:Dakika:Saniye

                 
}

function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = @mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}

include_once("../Guvenlik.Filtre.php");
//*****************************************//
//*****************************************//
//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

function permayap ( $fonktmp ) {
    $returnstr = "";
    $turkcefrom = array("/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/");
    $turkceto   = array("G","U","S","I","O","C","g","u","s","i","o","c");
    $fonktmp = preg_replace("/[^0-9a-zA-Z�z������������]/"," ",$fonktmp);
    // T�rk�e harfleri ingilizceye �evir
    $fonktmp = preg_replace($turkcefrom,$turkceto,$fonktmp);
    // Birden fazla olan bo�luklar� tek bo�luk yap
    $fonktmp = preg_replace("/ +/"," ",$fonktmp);
    // Bo�uklar� - i�aretine �evir
    //$fonktmp = preg_replace("/ /","-",$fonktmp);
    // T�m beyaz karekterleri sil
    //$fonktmp = preg_replace("/\s/","",$fonktmp);
    // Karekterleri k���lt
    //$fonktmp = strtolower($fonktmp);
    // Ba�ta ve sonda - i�areti kald�ysa yoket
    $fonktmp = preg_replace("/^-/","",$fonktmp);
    $fonktmp = preg_replace("/-$/","",$fonktmp);
    $returnstr = $tmpdate . $fonktmp;
    return $returnstr;
}//sef url i�in fonksiyon 

require_once('../includes/veritabani.php');

$islem = $_GET['Islem'];

if ($islem=="valearaccikis")
{
	$base_url=$vale_URL;//"http://127.0.0.1/PTS";
	//$arac_Plaka="34ERH3";
	$kamera_ID = $vale_Kamera_ID; //'2';
	$sistem_AD = $vale_sistem_AD; //'sistem';
	$sistem_Parola = $vale_sistem_Parola; //'123123';
	$resim_yolu="";
	$sebep=$vale_Sebep; //"VALE CIKIS";
	$sebebim=$vale_Sebep; //"VALE CIKIS ISLEMI";
}else{
	$sistem_AD = $_POST['sistem_AD'];
	$sistem_Parola = $_POST['sistem_Parola'];
	$kamera_ID = $_POST['kamera_ID'];
	$sebep = $_POST['log_Sebep'];
	$resim_yolu = $_POST['resim_Yolu'];
	$base_url = $_POST['baseurl'];
}

$OpId=$_GET['OpId'];

if($islem=="valearaccikis")
	$arac_Plaka = strtoupper($_GET['arac_Plaka']);
else
	$arac_Plaka = strtoupper($_POST['arac_Plaka']);

//valearaccikis

$box=$_POST['aracid'];  //hangi ara� yanl�� girilmi�

$servis_durumu=trim(mysql_real_escape_string($_POST['servis_durumu']));

$operator=@mysql_fetch_array(mysql_query("select `user_id` from db_calisma_saatlari where end_time is null order by start_time DESC limit 0,1"));
if ($operator[0]<1)
{
	echo("Aktif operat�r yok!");
	exit();
}

if($_POST['yenile']=="Yenile"){

############hatal� okuma giri� d�zenlemesi############################
while (list ($key,$val) = @each ($box)) {
	if(!empty($val)){
	//echo"X_<br>";
	
		$val=strtoupper($val);
		
		$kontrol_arac_varmi=mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM db_araclar WHERE plaka='$arac_Plaka'"));
		$varmidir=$kontrol_arac_varmi[0];
		$yanlis_arac_bilgi=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE plaka='$val'")); 
		
		$updatim="UPDATE `db_araclar` SET 
		`aracKonum` = 'i',
		`sondegisim` = '".$yanlis_arac_bilgi['sondegisim']."',
		`soncamid` = '".$yanlis_arac_bilgi['soncamid']."',
		`soncamgrupid` = '".$yanlis_arac_bilgi['soncamgrupid']."',`test` = 'hoba' WHERE `db_araclar`.`plaka` ='$arac_Plaka' LIMIT 1 ";
		
			
		##arac yoksa insert yap
		$eklem="INSERT INTO `db_araclar` (
		`id` ,
		`kullaniciid` ,
		`marka` ,
		`model` ,
		`renk` ,
		`UID` ,
		`aracsurucusu` ,
		`eklenme` ,
		`plaka` ,
		`aracKonum` ,
		`aracParola` ,
		`geciciarac` ,
		`sondegisim` ,
		`soncamid` ,
		`soncamgrupid` ,
		`abonelikbaslangic` ,
		`abonelikbitis` ,
		`abonelikdurum`
		)
		VALUES (NULL , '', '', '', '', '', '', '".$yanlis_arac_bilgi['eklenme']."', '$arac_Plaka', 'i', '', '1', '".$yanlis_arac_bilgi['sondegisim']."', '".$yanlis_arac_bilgi['soncamid']."', '".$yanlis_arac_bilgi['soncamgrupid']."', '', '', '".$yanlis_arac_bilgi['abonelikdurum']."'
		)";
		//echo $eklem;
		if($varmidir>0){
		//echo $updatim;
		mysql_query($updatim);
		}
		else if($varmidir=='0'){
		//echo $eklem;
		mysql_query($eklem);
		}
		
		#######Giri� Log UPDATE#########################
		##�imdilik B�yle yap�yoruz
		$sorgu_loglarim=mysql_fetch_array(mysql_query("SELECT MAX(id) as max_id FROM db_loglar WHERE db_loglar.plaka='$val' GROUP by db_loglar.plaka LIMIT 1"));
		$guncelle_log_id=$sorgu_loglarim['max_id'];
		//echo $guncelle_log_id;
		$soru_sorgu="UPDATE `db_loglar` SET `plaka` = '$arac_Plaka' WHERE `db_loglar`.`id` ='$guncelle_log_id' LIMIT 1 ";
		//echo $soru_sorgu;
		mysql_query($soru_sorgu);
		################################################
		
		mysql_query("DELETE FROM db_araclar WHERE plaka='$val'")or die(mysql_error());
		
	}//empty val

}

############### ARA� T�P� ��LEM� ###############
		
	$soru_sorgu2="UPDATE db_araclar SET tipID = $servis_durumu WHERE plaka='$arac_Plaka' LIMIT 1 ";
	mysql_query($soru_sorgu2);
		
}//yenile
######################################################################

//////////////TIP BILGISI ALMA YER�
$arac_bilgisi=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE plaka='$arac_Plaka'"));
if ($arac_bilgisi[0]>0)
{
	$arac_tipId=$arac_bilgisi['tipID'];
	if ($arac_tipId>-1)
	{
		$arac_tip_bilgisi=mysql_fetch_array(mysql_query("SELECT * FROM db_aractipleri WHERE tipID='$arac_tipId'"));
		$arac_tipAdi=$arac_tip_bilgisi['tipAdi'];
	}
}else{
	$arac_tipId=0;
	$arac_tipAdi="TANIMSIZ";
}
////////////////////////////////////////

$kam2=@mysql_fetch_array(mysql_query("select * from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));

$a2=trim(mysql_real_escape_string($_POST['a2']));
$a6=trim(mysql_real_escape_string($_POST['a6']));
$a7=trim(mysql_real_escape_string($_POST['a7']));
$a8=trim(mysql_real_escape_string($_POST['a8']));
$servis_durumu=$arac_tipAdi;

$ucret_durumum=trim(mysql_real_escape_string($_POST['ucret_durumu']));
$ucretim=trim(mysql_real_escape_string($_POST['ucretim']));

$sebep=$sebep. " Arac Tipi:" .$servis_durumu;

if($_GET['plate']){
    $_GET['plate']= str_replace(" ","",strtoupper($_GET['plate']));
    $findCam = mysql_query('select * from db_kameralar Where `kamera_ID`= "'.$_GET['canal'].'"');
    if(0<@mysql_num_rows($findCam) ){
        $camRes = mysql_fetch_assoc($findCam);
        $camGroup = $camRes['camgrup'];
        $sistem_AD = $camRes['sistem_ID'];

    }
    $isPlateInside = mysql_query('select * from db_araclar Where `plaka`= "'.$_GET['plate'].'"');
    $aracIcerde = false;
    if(0<@mysql_num_rows($isPlateInside ) ){
        $aracRes = mysql_fetch_assoc($isPlateInside);
        if($aracRes['aracKonum']=='i'){
            $aracIcerde = true;
            $aracEDRes = true;
        }
        if(!$aracIcerde ){
                $aracEkle="UPDATE `db_araclar` 
                                            set `sondegisim`='{$_GET['date']}'
                                            ,`plaka`='{$_GET['plate']}' 
                                            ,`soncamid`='{$_GET['canal']}'
                                            ,`soncamgrupid`='{$camGroup}'
                                            ,`aracKonum` = 'i'
											,`tipID` = '{$_GET['tipID']}'
                        where `id`={$aracRes['id']}";
            $aracEDRes = mysql_query($aracEkle)or die(mysql_error());
        }
    }else{
        
        $aracRes = mysql_fetch_assoc($isPlateInside);
        $ekle="INSERT INTO `db_araclar` (
				`id` ,
				`kullaniciid` ,
				`marka` ,
				`model` ,
				`renk` ,
				`UID` ,
				`aracsurucusu` ,
				`aracKonum` ,
				`plaka`,
				`geciciarac`,
				`sondegisim`,
				`eklenme`,
				`soncamgrupid`,
				`soncamid`,
				`tipID`
				)
				VALUES (
				NULL , '$kullanicimbenim', '', '', '', '', '', 'i', '{$_GET['plate']}', '1',
                                                                        '".$_GET['date']."','".date("Y-m-d H:i:s")."','{$camGroup}','{$_GET['canal']}','{$_GET['tipID']}'
				)";
    $aracEDRes = mysql_query($ekle)or die(mysql_error());
        
    }
    if(!$aracIcerde ){
    $log_ekle="INSERT INTO `db_loglar` (
			`id` ,
			`plaka` ,
			`kayittarihi` ,
			`kameraid` ,
			`sebep` ,
			`resimyolu`, 
			`kullanici`,
			`area1` ,
			`area2` ,
			`area3` ,
			`aracdurum` ,
			`aracKonum` ,
			`soncamgrupid`,
			`ucretdurumu`,
			`sistemid`
			)
			VALUES (
			NULL , '{$_GET['plate']}', '".date("Y-m-d H:i:s")."', '{$_GET['canal']}', '{$_GET['description']}', '','','','','','$aracdurumum','$konum','$camGroup','','$sistem_AD'
			)";
                        
			mysql_query($log_ekle)or die(mysql_error());
    }
    $jsonRes = '0';
       if($aracEDRes){
           $jsonRes = '1';
       }
       ob_clean();
       echo $jsonRes;
exit();
}

$ucretim=trim(mysql_real_escape_string($_POST['hesap_cikar']));
$whoInSQL = "select * from db_calisma_saatlari where end_time is null order by start_time DESC limit 0,1";
//echo $tablo;
$whoInResult= mysql_query($whoInSQL);
$operator=@mysql_fetch_array(mysql_query("select `user_id` from db_calisma_saatlari where end_time is null order by start_time DESC limit 0,1"));
if(($ucret_durumum=="1")&&($_POST['Ara'])){

$sebep=$sebep. " �cret Al�nd�. ($ucretim TL)";
$ucret_alindimi="e";
			####fatura olu�tur######################
		   // $birim_arac_ucreti=mysql_fetch_array(mysql_query("SELECT * FROM db_abonelikturleri WHERE abonelik_suresi='$a2'"));
	       // $birim_ucretim=$birim_arac_ucreti[3]; //TL cinsinden fiyat d�ner
 		   // $toplam_ucretim=$toplam_ucretim+$birim_ucretim;

$o_status=$arac_tipId;
		   
mysql_query("INSERT INTO `db_odemeler` (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`,`plaka` , `abonesure` , `operatorid`)VALUES (NULL , '0', '$ucretim','$ucretim',NOW(),'$o_status','$arac_Plaka' , 0 , $operator[0])"); 
$iddd=mysql_insert_id();
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$iddd NOlu $ucretim TL\'lik �cret bilgisi olu�turuldu', NOW(),'$ip')")or die(mysql_error());

			########################################

}
if(($ucret_durumum=='')&&$_POST['Ara']){

$sebep=$sebep. " �cret ALINMADI! ($ucretim TL)";
$ucret_alindimi="h";
			####fatura olu�tur######################
		    //$birim_arac_ucreti=mysql_fetch_array(mysql_query("SELECT * FROM db_abonelikturleri WHERE abonelik_suresi='$a2'"));
	      	//$birim_ucretim=$birim_arac_ucreti[3]; //TL cinsinden fiyat d�ner
 		    //$toplam_ucretim=$toplam_ucretim+$birim_ucretim;
		
$o_status=$arac_tipId;
mysql_query("INSERT INTO `db_odemeler` (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`,`plaka`)VALUES (NULL , '0', '$ucretim','0',NOW(),'$o_status','$arac_Plaka')"); 
$iddd=mysql_insert_id();
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$iddd NOlu $ucretim TL\'lik �cret bilgisi olu�turuldu', NOW(),'$ip')")or die(mysql_error());

			########################################
}

$sonucum=trim(mysql_real_escape_string($_POST['sonucum']));
$Ara2=trim(mysql_real_escape_string($_POST['Ara2']));

$systemsQuery = "select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'";
//print_r($systemsQuery );die();
$kontrol=mysql_fetch_row(mysql_query($systemsQuery));
if($kontrol[0]<1)
{
  echo"access denied";
  exit();
}
			
		 $kontrol_plaka=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' "));
		 $kontrol_plaka_gecici=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' AND geciciarac='1' "));
		 $kontrol_plaka_gecici1=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' AND UID='1' "));
		 $kontrol_plaka_gecici2=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' AND aracKonum='i' "))or die(mysql_error());

		 $sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' "));
		 $kontrol_karaliste=mysql_fetch_row(mysql_query("select COUNT(*) from db_blacklist where aracid='$arac_Plaka' "));
		 $sorgukaraliste=mysql_fetch_array(mysql_query("select * from db_blacklist where aracid='$arac_Plaka' "));
		 
		 $surucu_Id=$sorguplaka["kullaniciid"];

		/* $kontrol_kullanici=mysql_fetch_row(mysql_query("select COUNT(*) from db_kullanicilar where id='$surucu_Id' "));
		 $sorgu_kullanici=mysql_fetch_array(mysql_query("select * from db_kullanicilar where id='$surucu_Id' "));
		 
		 $area1name=mysql_fetch_array(mysql_query("SELECT * FROM db_area_1 where id='$sorgu_kullanici[3]' order by id limit 1"));
		 $area2name=mysql_fetch_array(mysql_query("SELECT * FROM db_area_2 where id='$sorgu_kullanici[4]' order by id limit 1"));
		 $area3name=mysql_fetch_array(mysql_query("SELECT * FROM db_area_3 where id='$sorgu_kullanici[5]' order by id limit 1"));
		 */
 
		 
if($_POST['Ara']=="G�nder"){

$sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' "));
$aracvarmidirsorgula=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$arac_Plaka' "));
$aracvarmidir=$aracvarmidirsorgula[0];
$user_id=$sorguplaka["kullaniciid"]; 

$operator=@mysql_fetch_array(mysql_query("select `user_id` from db_calisma_saatlari where end_time is null order by start_time DESC limit 0,1"));

$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
{
	$kam=mysql_fetch_array(mysql_query("select * from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	$kamkontrol=mysql_fetch_array(mysql_query("select COUNT(*) from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	
	if($kamkontrol[0]<1)
	{
		
		$Sonuc="Kamera Yap�land�r�lmas� Hatal�!";
		
	}
	if(($kamkontrol[0]>0)&&($kayityapma!="1"))
	{
	
			#hemen logla
			
			#ara� ne tarafta i�eride mi dy?aryda my ?
			
			$kapi=$kam['kamera_ID'];
			$camgrup=$kam['camgrup'];
			$yon=$kam['kamera_Yon'];
			$kamera_izin=$kam['cikisizin'];//0 sa ��k�� 1 se giri� kameras�
			($yon=='c') ? $konum='i' : $konum='d'; //($yon=='c') ? $konum='i' : $konum='d';
			$aracDurum='e_yok';
			
					if($aracvarmidir>0){
					
					$aracdurumum=$sorguplaka['UID'];
					
					}
					if($aracvarmidir<1){
					
					$aracdurumum="0"; //Ge�ici ara� hocam
					
					}
			
			
			$log_ekle="INSERT INTO `db_loglar` (
			`id` ,
			`plaka` ,
			`kayittarihi` ,
			`kameraid` ,
			`sebep` ,
			`resimyolu`, 
			`kullanici`,
			`area1` ,
			`area2` ,
			`area3` ,
			`aracdurum` ,
			`aracKonum` ,
			`soncamgrupid`,
			`ucretdurumu`,
			`sistemid`
			)
			VALUES (
			NULL , '$arac_Plaka', '$tarih $zaman', '".$kapi."', '$sebep', '$resim_yolu','$userim','$aream1','$aream2','$aream3','$aracdurumum','$konum','$camgrup','$ucret_alindimi','$sistem_AD'
			)";
			//echo "Log ekledim";
			
			mysql_query($log_ekle)or die(mysql_error());
			

			#loglara eklenmi? ise
			
			if(mysql_insert_id()>0) 		$Sonuc="Kay�t ��lemi Ba�ar�l�!OK";

			#arac sistemde kayytlydyr
			if($aracvarmidir>0){
			
			#kayytlyysa zaten kayytly
			
			}
			#arac kayytsyz sisteme ge�ici ara� olarak ekle
			if($aracvarmidir<1){
			
				$ekle="INSERT INTO `db_araclar` (
				`id` ,
				`kullaniciid` ,
				`marka` ,
				`model` ,
				`renk` ,
				`UID` ,
				`aracsurucusu` ,
				`eklenme` ,
				`plaka`,
				`geciciarac`
				)
				VALUES (
				NULL , '$kullanicimbenim', '', '', '', '', '', '$tarih $zaman', '$arac_Plaka', '1'
				)";
					mysql_query($ekle)or die(mysql_error());
			
			}
			
			##ara� gecici ve o an ba�ka birine gelmi�se onu o ara� i�in yetkili ki�i yap:
			 // Ge�ici ara� ise yetkilisini de�i�tir
			#if($sorguplaka[11]=="1") mysql_query("update db_araclar set kullaniciid='".$sorguuser3[0]."' where plaka='$arac_Plaka'");
			
			mysql_query("update db_araclar set aracKonum='$konum' where plaka='$arac_Plaka'");
			mysql_query("update db_araclar set vale_arac=0 , odeme_durum=1 where plaka='$arac_Plaka'");
			//echo "update yapt�m ohhh";
			mysql_query("update db_araclar set sondegisim='$tarih $zaman' where plaka='$arac_Plaka'");
			mysql_query("update db_araclar set soncamid='$kapi' where plaka='$arac_Plaka'");
			mysql_query("update db_araclar set soncamgrupid='$camgrup' where plaka='$arac_Plaka'");
			
			
			/*mysql_query("INSERT INTO `db_giriscikis` (
`id` ,
`plaka` ,
`soncamid` ,
`soncamgrupid` ,
`arackonum` ,
`sondegisim`
)
VALUES (
NULL , '$arac_Plaka', '$kapi', '$camgrup', '$konum', '$tarih $zaman'
)");*/
	
	}

}//sistem parolasi dogru ise
if($kontrol[0]<1){
$Sonuc="Eri�im �zniniz Yok!";
}
}

if($_POST['yenile']=="Yenile"){

//echo "yenile";

}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>

<LINK rel='stylesheet' type='text/css' href="<? echo $base_url; ?>/stil.css">
<LINK rel='stylesheet' type='text/css' href="stil.css">
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script src="interface/js/jquery.js" type="text/javascript"></script>
<script src="interface/js/facebox.js" type="text/javascript"></script>
<script  src="../takvim/codebase/dhtmlxcommon.js"></script>
<script  src="../takvim/codebase/dhtmlxcalendar.js"></script>

<link href="interface/css/facebox.css" rel="stylesheet" type="text/css">
<link href="../takvim/codebase/dhtmlxcalendar.css" rel="stylesheet" type="text/css" >
<script src="../js/jquery.maskedinput-1.2.2.js" type="text/javascript"></script>
<script>
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
         loadingImage : 'interface/images/loading.gif',
            closeImage   : 'interface/images/closelabel.png'
      });
    /* $('#addPlate').bind('click', function() {
        document.getElementById('addPlate').click();
        return false;
    });
     /*$("input[name='yenile']").bind('click', function() {
        document.getElementById('yenile').click();
        return false;
    });
     $('#facebox .close').bind('click', function() {
        document.getElementById('closed').click();
        return false;
    });*/
     $('#addPlate').click(function(){
             document.getElementById('node').click();
             $(".popup").find("#hour_edit").mask("99:99:99");
        });
    });


    function duzenlen(){
            editedPlate = jQuery('.popup #plate_edit').val();
            if( editedPlate!='' && editedPlate!='undefined' ){
                if(checkInputs()){
                    return false;
                }
                sendData();
            }
        }
        
        function sendData()
        {
            var obj = getValues();

           jQuery.get("Vale.Client.Display.php",
                    {plate:obj.plate,canal:obj.canal,tipID:obj.tipID,date:obj.date,description:obj.description}, 
                    function(respond) {
                        //console.log(typeof respond);
                        if(respond!='1'){
                            alert('bir hata olu\u015ftu tekrar deneyin');
                        }
                        
                        jQuery("#a1").val(obj.plate);
                        //console.log(respond);
                       // jQuery("input[name='yenile']").trigger('click');
                       // jQuery('#facebox .close').trigger('click');
                         document.getElementById('closed').click();
                        document.getElementById('yenile').click();
            });
        }
        
        function getValues(){
           var obj = new Object();
           
            obj.plate = jQuery(".popup").find("#plate_edit").val().replace(" ", "");
         //  alert(jQuery(".popup").find("#plate_edit").val());
           obj.date= jQuery(".popup").find("#date_edit").val()+" "+jQuery(".popup").find("#hour_edit").val();
           obj.time=jQuery(".popup").find("#hour_edit").val();
            obj.canal = jQuery(".popup").find("#canal_edit").val();
			obj.tipID = jQuery(".popup").find("#tipid_edit").val();
            obj.description = jQuery(".popup").find("#description").val();
           // alert( jQuery(".popup #description").val());
 
            return obj;
        }
        
        function setDate(own){
           var a= new dhtmlxCalendarObject(own);
            //setTime();
        }
        function setTime(){
           //jQuery(".popup #hour_edit").mask("99:99:99");
        }
        
        function checkInputs(){
            var obj = getValues();
                
                 if(obj.plate.length>10 || obj.plate.length<5){
                     alert('plaka bilgileri 5 ve 10 karakter arasinda olmali');
                     return true;
                 }
                 if( (obj.date=='' || obj.date== 'undefined') || (obj.canal =='' || obj.canal== 'undefined')|| (obj.time =='' || obj.time== 'undefined')){
                     alert('tarih, saat ve kanal bilgileri gereklidir');
                     return true;
                 }
                 return false;
            
        }
        
    //$.noConflict();

</script>

<style type="text/css">
<!--
.style3 {font-weight: bold}
-->
#container{
	
    width:593px;
    height:150px;
    /*overflow:scroll;*/
	overflow-x: hidden;
	overflow-y: scroll;
	position:fixed;
	list-style-position:inside;
	
}
</style>
<link rel="stylesheet" href="includes/modalbox.css" type="text/css" 
media="screen" />
</HEAD>

<a rel='facebox' href='#AllNodeBox' id="node"></a>
<div style="display: none;" id='AllNodeBox'>
    <div>Plaka :<input type="text" id="plate_edit" name="plate_edit"/></div>
    <div>Tarih :<input type="text" id="date_edit" name="date_edit" onclick="setDate(this);" readonly="readonly"/>
        saat:<input name="hour_edit" id="hour_edit"   size="10" maxlength="10">
    </div>
    <div>Kanal :<select id="canal_edit" name="canal_edit">
        <option ></option>
        <?php 
        $kameraResult =  mysql_query("select * from db_kameralar where `kamera_Yon`='c';");
        while($rowItem = mysql_fetch_assoc($kameraResult)){
            ?>
        <option value="<?php echo $rowItem['kamera_ID']?>" ><?php echo $rowItem['kamera_ID']?></option>
                <?php
        }
        ?>
    </select></div>
    <div>A�iklama :<textarea name="description" id="description"></textarea></div>
	<div>Ara� Tipi :<select id="tipid_edit" name="tipid_edit">
        <option ></option>
        <?php 
        $kameraResult =  mysql_query("select * from db_aractipleri");
        while($rowItem = mysql_fetch_assoc($kameraResult)){
            ?>
        <option value="<?php echo $rowItem['tipID']?>" ><?php echo $rowItem['tipAdi']?></option>
                <?php
        }
        ?>
    </select></div>
    <div><input  type="button" onclick="duzenlen();"name="submit_duzet" value="Ekle"/></div>

</div>
<BODY>


<!-----sonuc bo� d�nmezise---->
<? if(!$Sonuc){ ?>

<FORM method=post name=misafirtanimla action=<? echo $base_url; ?>/kamera/Vale.Client.Display.php >
<TABLE class=maintable border=1 width=592 align=center>

  <TBODY>

  <TR>
    <td width="10"><TD Align=top width=343> 
    
    <TABLE class=ictablo width=305>
      <TBODY>
        <TR>
          <TH colSpan=2> Ara� Ge�i� Kontrol</TH>
        </TR>
        <TR>
          <TD style="COLOR: red" colSpan=2 align=middle>
         	<INPUT type="hidden" name="baseurl" value="<? echo $base_url; ?>">
            <INPUT type="hidden" name="sistem_AD" value="<? echo $sistem_AD; ?>">
            <INPUT type="hidden" name="sistem_Parola" value="<? echo $sistem_Parola; ?>">
            <INPUT type="hidden" name="resim_Yolu" value="<? echo $resim_yolu; ?>">
            <INPUT type="hidden" name="kamera_ID" value="<? echo $kamera_ID; ?>">          
			<INPUT type="hidden" name="tarih_zaman" id="tarih" value="<? echo $tarih." ".$zaman; ?>">          
			</TD>
        </TR>
        <TR>
          <TD width="16%" align=right><strong><span class="style3">Plaka</span>:</strong></TD>
          <TD width="84%">
        <span id="sprytextfield1">
             <input name="arac_Plaka"  value="<? echo $arac_Plaka; ?>" class=text_input3 id="a1"> <span class="textfieldRequiredMsg"><img src="../images/icons/exclamation.png" width="16" height="16"></span></span>
           <input class=button value=Yenile type="submit" id="yenile" name=yenile>
           <!--<input class=button value=Yenile type="button" name=yenile>--></TD>
        </TR>
        <TR>
          <TD align=right><strong>A��klama :</strong></TD>
          <TD><input name="log_Sebep" value="<? echo $a2; ?>" class=text_input3 id="a2"></TD>
        </TR>
        <TR>
        <? 
		if($kam2[5]=="g")#��k�� kameras�y�m
			{ ?>
         <TR>
          <TD align=right><strong>�cret Tahsil Edildi :</strong></TD>
          <TD><input name="ucret_durumu" type="checkbox"  checked id="ucret_durumu" value="1"></TD>
        </TR>
        <? } ?>
         <? 
		if($kam2[5]=="g")#��k�� kameras�y�m
			{ ?>
        <!---otopark d�zenlemesi--->
         <TR>
          <TD align=right><strong>Kullan�lan Servis  :</strong></TD>
		  <TD width="81%" id="servisdurum">
		  <SELECT id=a5  name="servis_durumu">
		  <? $sorgulam=mysql_query("select * from db_aractipleri ORDER BY tipID");
		  while($listeid2=mysql_fetch_array($sorgulam))
		  {  ?>
                <option <? if ($listeid2[tipID]==$arac_tipId) echo("selected=selected"); ?> value="<? echo($listeid2[tipID]); ?>"><? echo($listeid2[tipAdi]); ?></option>
			<? } ?>
                </SELECT>
				<input class=button value=Yenile type="submit" id="yenile" name=yenile></TD>
        </TR>
        <? } ?>
        
        <!------------------------->     
        <TR>
          <TD width="16%" align=right></TD>
          <TD>
          <input class=button value=G�nder type="submit" name=Ara> 
        <input class=button value=Yazd�r type="button" id="PrintOK" name=Print>
        <input class=button value='Ara� Ekle' type="button" id="addPlate" name=Print>
		  </TD>
        </TR>
      </TBODY>  
      <INPUT type="hidden" name="sistem_AD2" value="<? echo $sistem_AD; ?>">
      <INPUT type="hidden" name="sistem_Parola2" value="<? echo $sistem_Parola; ?>">
      <INPUT type="hidden" name="resim_Yolu2" value="<? echo $resim_yolu; ?>">
            </TD>
    </TABLE>

    
    <TD 
    style="" 
    vAlign=top width=328><TABLE class=ictablo width=293>
        <TBODY>
          <TR>
            <TH colSpan=2> Ara� Bilgileri</TH>
          </TR>
          <!--<TR>
          <TD style="COLOR: red" colSpan=2 align=middle><? echo $Sonuc; ?> <a href="../List.Plaka.php" title="Ara� Sorgulama" onClick="
Modalbox.show(this.href, {title: this.title, width: 600}); return false;
"> Ara� Sorgula</a>
  
          </TR>-->
          <TR>
            <TD width="19%" height="33" align=right><strong>Plaka:</strong></TD>
            <TD width="81%" id="plakatext"><? echo $arac_Plaka; ?></TD>
          </TR>
		  <TR>
            <TD width="19%" height="33" align=right><strong>Bilgi:</strong></TD>
            <TD width="81%"><? 
			 if($kontrol_plaka_gecici2[0]<1 && $kontrol_plaka_gecici1[0]<1){
			 echo "  (Bu Plakada Ara� Bulunamad�) ".'<img src="../images/icons/error.png" width="16" height="16">';
			 $liste_dok=1;
			 }
			?>
              </TD>
          </TR>
          <TR>
            <TD height="33" align=right><strong>S�re Bilgisi:</strong></TD>
            <TD id="toplam_sure"><?
			if($kontrol_plaka_gecici2[0]>0 || $kontrol_plaka_gecici1[0]>0){
			$kam=mysql_fetch_array(mysql_query("select * from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
			$kamkontrol=mysql_fetch_array(mysql_query("select COUNT(*) from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
			//echo "b<br>";
			if($kam[5]=="g")#��k�� kameras�y�m
			{
					if ($kontrol_plaka_gecici1[0]>0)
						$sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' and UID='1' order by id DESC LIMIT 1"));
					else
						$sorguplaka=mysql_fetch_array(mysql_query("select * from db_araclar where plaka='$arac_Plaka' and aracKonum='i' order by id DESC LIMIT 1"));
					$sondegisim=$sorguplaka['sondegisim'];
					$abonelik_bitim_tarihi=$sorguplaka['abonelikbitis'];
					################################################
					$abonelik_bitme_timestamp=convert_datetime($abonelik_bitim_tarihi);
					$suan_timestamp=convert_datetime("$tarih $zaman");					
					$abonelik_ne_olmus=(int)($abonelik_bitme_timestamp-$suan_timestamp);    //----------->>Hala abone mi bak�yoruz  $abonelik_ne_olmus>0 ise hala abone
					################################################
					//$ekle_sorgu2= "SELECT TIMEDIFF('$tarih $zaman','$abonelik_bitim_tarihi')";
					//$SQL_tarih_ekle2=mysql_fetch_array(mysql_query($ekle_sorgu2));
					$cikan_saat2=getDifference("$tarih $zaman","$abonelik_bitim_tarihi");
					$dilimler2 = explode(":", $cikan_saat2);
					$saatim2=(int)$dilimler2[0];
					//echo "Cikan Saat: ".$cikan_saat2."<br>";
					if($saatim2[0]=="0"){$saatim2 = (int)str_replace("0","",$saatim2);};
					$dakikam2=(int)$dilimler2[1];
					//echo "Dakikam2:".$dakikam2."<br>";
					$zamanim=(int)($saatim2.$dakikam2);
					//$ekle_sorgu= "SELECT TIMEDIFF('$tarih $zaman','$sondegisim')";
					$abonemiymis=$sorguplaka['UID'];
					//$real_cikan_dakika=getDifference(date("Y-m-d G:i:s"),'$sondegisim',1);
					#################################################
					//$ekle_sorgu5= "SELECT TIMEDIFF('$abonelik_bitim_tarihi','$sondegisim')";
					//echo $ekle_sorgu;
					//$SQL_tarih_ekle5=mysql_fetch_array(mysql_query($ekle_sorgu5));
					$cikan_saat5=getDifference("$abonelik_bitim_tarihi","$sondegisim");
					$dilimler5 = explode(":", $cikan_saat5);
					$saatim5=(int)$dilimler5[0];
					if($saatim5[0]=="0"){$saatim5 = (int)str_replace("0","",$saatim5);};
					$dakikam5=(int)$dilimler5[1];
					$zamanim5=(int)($saatim5.$dakikam5);
					################################################
					$sondegisim_timestamp=convert_datetime($sondegisim);					
					$aboneyken_mi_girmis=(int)($abonelik_bitme_timestamp-$sondegisim_timestamp);    //----------->>Abone iken mi gir� yapm�� >0 ise aboneyken girmi�
					
			
			
					if(($abonemiymis==1)&&((int)$abonelik_ne_olmus<0)&&((int)$aboneyken_mi_girmis>0)) ##ara� abone ve abonelik tarihi ge�mi�se ve aboneiken giri� yapm��sa
					{

						//	$ekle_sorgu= "SELECT TIMEDIFF('$tarih $zaman','$abonelik_bitim_tarihi')";
						echo "Abonelik D��� ". $saatim2." Saat ".$dakikam2." Dakika ";
				
					}
					/*###abone iken girmi� abone iken ��km��
					if(($abonemiymis==1)&&((int)$abonelik_ne_olmus<0)&&((int)$aboneyken_mi_girmis>0))
					{
					
					
					
					}*/
					if(($abonemiymis==1)&&((int)$abonelik_ne_olmus>0)&&((int)$aboneyken_mi_girmis>0)) ##ara� abone ve abonelik tarihi ge�mi�se �crete o �ekilde yans�t
					{
					
					echo "Aboneli�i Devam Eden Ara� ";
					
					
					}
							

					//$SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
					//$cikan_saat=$SQL_tarih_ekle[0];
					//echo "Kald��� Dakika:".$real_cikan_dakika."!\n";
					##########-------------------------------------------###############
					//echo $cikan_saat." Saat ��eride Kald�!<br>";
					$cikan_saat=getDifference("$tarih $zaman","$sondegisim");
					//echo $cikan_saat_new;
					$dilimler = explode(":", $cikan_saat);
					$saatim=(int)$dilimler[0];
					if($saatim[0]=="0"){$saatim = (int)str_replace("0","",$saatim);};
					$dakikam=(int)$dilimler[1];
					$saniyem=(int)$dilimler[2];
					$toplam_dakika_kaldi=($saatim*60)+$dakikam;
					
					echo "".$saatim." Saat,".$dakikam." Dakika";
		
			}			
			
			}
			 ?></TD>
          </TR>
          <? if($kam[5]=="g")#��k�� kameras�y�m
			{ ?>
          <TR>
            <TD height="33" align=right><strong>�cret Bilgisi:</strong></TD>
            <TD>
			<?
			$saatim=(int)$saatim;
			$yeni_saat=(int)($saatim+1);
			$kaldigim_dakika=(($saatim*60)+$dakikam);
			if ($sorguplaka["abonelikTipi"]>0 && $kaldigim_dakika>($sorguplaka["AbonelikSaat"]*60) && ($abonemiymis==1)&&((int)$abonelik_ne_olmus>0)&&((int)$aboneyken_mi_girmis>0))
			{
				$kaldigim_dakika=$kaldigim_dakika-($sorguplaka["AbonelikSaat"]*60);
			}else{
				if(($abonemiymis==1)&&((int)$abonelik_ne_olmus<0)&&((int)$aboneyken_mi_girmis>0)) ##ara� abone ve abonelik tarihi ge�mi�se �crete o �ekilde yans�t
				{
					$saatim=(int)$saatim2;
					$yeni_saat=(int)($saatim2+1);
					$kaldigim_dakika=(($saatim2*60)+$dakikam2);
				}
				if(($abonemiymis==1)&&((int)$abonelik_ne_olmus>0)&&((int)$aboneyken_mi_girmis>0)) ##ara� abone ve abonelik tarihi ge�mi�se �crete o �ekilde yans�t
				{
					$saatim=(int)$saatim2;
					$yeni_saat=(int)($saatim2+1);
					$kaldigim_dakika=(($saatim2*60)+$dakikam2);
				
				}
			}
			
			//echo (int)$yeni_saat."<br>";
			//echo $kaldigim_dakika;
			$ucret_sorgu=mysql_fetch_array(mysql_query("SELECT * FROM db_fiyatlar WHERE baslangic<='$kaldigim_dakika' AND tipID=$arac_tipId AND bitis>='$kaldigim_dakika' ORDER BY id DESC LIMIT 1"));
			$varmidir=mysql_num_rows(mysql_query("SELECT * FROM db_fiyatlar WHERE baslangic<='$kaldigim_dakika' AND tipID=$arac_tipId AND bitis>='$kaldigim_dakika' ORDER BY id DESC LIMIT 1"));
			$sistemli_mi_artiyor=$ucret_sorgu['sistemli'];
			$fiyat_ne_kadar=$ucret_sorgu['ucret'];
			$birim_zaman_ne=$ucret_sorgu['birimzaman']; //d->60Dakika    g->G�n (1440Dakika)
			$birim_carpan=$ucret_sorgu['carpan'];
			if($birim_zaman_ne=='d'){
			
					if($sistemli_mi_artiyor=='e')
					{
						if ($birim_carpan!=0) $kal_artan = $kaldigim_dakika%$birim_carpan;  //kalan
						if ($birim_carpan!=0) $kal_bolum = (int)($kaldigim_dakika/$birim_carpan); //b�l�m
						$birim_ucretim = $ucret_sorgu[3];
						$ucret_cikar= (($kal_bolum+1)*$birim_ucretim );
					
					}
					if($sistemli_mi_artiyor=='h')
					{
					
						$ucret_cikar=$ucret_sorgu[3];
					
					}
					
			}
			if($birim_zaman_ne=='g'){
			
					if($sistemli_mi_artiyor=='e')
					{
						$kal_artan = $kaldigim_dakika%(1440*$birim_carpan);  //kalan
						$kal_bolum = (int)($kaldigim_dakika/(1440*$birim_carpan)); //b�l�m
						$birim_ucretim = $ucret_sorgu[3];
						$ucret_cikar= (($kal_bolum+1)*$birim_ucretim );
					
					}
					if($sistemli_mi_artiyor=='h')
					{
					
						$ucret_cikar=$ucret_sorgu[3];
					
					}
			}

			
            //echo $ucret_sorgu[3]. " TL";
		
			?>
                  <INPUT id="fiyat" type="text" disabled class="text_warn" id="Ucret" name="ucretim" value="<? echo $ucret_cikar;?>"> TL</TD><INPUT type="hidden"  name="hesap_cikar" value="<? echo $ucret_cikar;  ?>" >
          </TR>
          <? } ?>
        </TBODY>
      </TABLE>      </TD>
      </TR>
     <?  
	// echo $liste_dok;
	// echo $kam; 
	// echo $kamera_ID;
	 $kam=mysql_fetch_array(mysql_query("select * from db_kameralar where kamera_ID='$kamera_ID' and sistem_ID='$sistem_AD'"));
	// echo $kam;
	 ?>
        <? if(($liste_dok==1)&&($kam[5]=="g")){ ?>
        <TR>
    <td colspan="5">
    <div align="center">
    <div  id="container">
<?  include("../List.Plaka.php"); ?> 
	</div>
    </div>
      
    </TR>
      <? } ?>
  </TBODY>
  </TABLE>
  <!-----sonuc bo� d�nmezise---->
  
</Form>
 
<? } ?>
<? if($Sonuc){ ?>
<FORM method=post name=misafirtanimla action=<? echo $base_url; ?>/Vale.Arac.Arama.php >

<TABLE width=293 align="center" class=ictablo>
        <TBODY>
          <TR>
            <TH width="100%"> Sonu� </TH>
          </TR>
          <TR>
          <TD style="COLOR: red" align=middle><div align="center"><LABEL id="result"><? echo $Sonuc; ?></LABEL></div>    
            <div align="center">
            <? //echo "�cretim".$ucretim; ?>
            <br>
              <INPUT type="hidden" name="arac_Plaka" value="<? echo strtoupper($arac_Plaka); ?>">           
              <INPUT type="hidden" name="baseurl" value="<? echo $base_url; ?>">
              <INPUT type="hidden" name="sistem_AD" value="<? echo $sistem_AD; ?>">
              <INPUT type="hidden" name="sistem_Parola" value="<? echo $sistem_Parola; ?>">
              <INPUT type="hidden" name="resim_Yolu" value="<? echo $resim_yolu; ?>">
              <INPUT type="hidden" name="kamera_ID" value="<? echo $kamera_ID; ?>">
              <input class=button  id="btnKapat2" value=Geri type=submit name=btnGeri>
              <input class=button id="ButtonOK" value=Kapat type=submit name=ButtonOK>
          </div>          </TR>
        </TBODY>
      </TABLE>
<? } ?>
    </FORM>
    <script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
//-->
</script>
</BODY></HTML>
 