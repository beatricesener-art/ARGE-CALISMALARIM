<?php
ini_set("display_errors","off");
require_once('../includes/veritabani.php');

$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];
$arac_Plaka = $_POST['arac_Plaka'];
$kamera_ID = $_POST['kamera_ID'];
$aracTipi = $_POST['aracTipi'];
$aracIslem = $_POST['aracIslem'];

/*
$sistem_AD = 'deneme';
$sistem_Parola = '123123';
$arac_Plaka="34ET315";
$kamera_ID = '1';
$aracTipi = '2';
$aracIslem = '2'; // 0- update izin ver et 1- update et d��arda g�ster 2-sil
*/

//SELECT * from `db_loglar`  order by `kayittarihi` DESC LIMIT 0,1 //tarihzaman

$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
{
	if ($aracIslem=='1'){
		mysql_query("update db_araclar set aracKonum='d' where plaka='$arac_Plaka'");
		echo("OK");
	}
	else if ($aracIslem=='2'){
		mysql_query("DELETE FROM db_araclar where plaka='$arac_Plaka'")or die(mysql_error());
		echo("OK");
	}else{
		mysql_query("update db_araclar set tipID='$aracTipi' where plaka='$arac_Plaka'");
		echo("OK");
	}
 }
else {
	echo 'access denied';
}
?>