<?php
ini_set("display_errors","off");
require_once('../includes/veritabani.php');

$payment_ID = $_POST['pid']; // 0-suanki 1- bir �ncesi - 2-iki �ncesi
$sistem_AD = $_POST['sistem_AD'];
$sistem_Parola = $_POST['sistem_Parola'];

/*
$payment_ID = 0;
$sistem_AD = 'deneme';
$sistem_Parola = '123123';
*/

//SELECT * from `db_loglar`  order by `kayittarihi` DESC LIMIT 0,1 //tarihzaman

$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_sistemler where sistemadi='$sistem_AD' and parola='$sistem_Parola'"));
if($kontrol[0]>0)
  {
  $odeme=mysql_fetch_array(mysql_query("select * from db_odemeler order by `tarihzaman` DESC LIMIT $payment_ID,1"));
  if ($odeme)
  {
	  $aracbilgi=mysql_fetch_array(mysql_query("select * from db_loglar where plaka='$odeme[plaka]' and aracKonum='d' order by `kayittarihi` DESC LIMIT 0,1"));
	  $aracgiris=mysql_fetch_array(mysql_query("select * from db_loglar where plaka='$odeme[plaka]' and aracKonum='i' order by `kayittarihi` DESC LIMIT 0,1")); 
	  $seconds = strtotime($odeme[tarihzaman]) - strtotime($aracgiris[kayittarihi]);
	  $dakika=(int)($seconds/60);
	  $dakika = $dakika + 1;
			echo "[RESULT]
		ODENEN:$odeme[odenen]
		GIRIS_TARIH:$aracgiris[kayittarihi]
		CIKIS_TARIH:$odeme[tarihzaman]
		PLAKA:$odeme[plaka]
		RESIMYOLU:$aracgiris[resimyolu]
		SURE:$dakika dk
			  ";
   }
  else echo '[RESULT]
e_yok';
  }
else echo '[RESULT]
access denied';
?>