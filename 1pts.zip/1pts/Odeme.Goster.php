<?
include_once("Guvenlik.Filtre.php");
include_once("includes/Sayfalama.Fonk.php");

//*****************************************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');


$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];

$post_pointid=$_POST['pointid'];  //pointid
if(empty($post_pointid)) $post_pointid=1;

$tablo = "select * from db_super_users where username='$user' and password='$sifre' and (yetki='1' or yetki='4')"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$operator=@mysql_fetch_array(mysql_query("select * from db_calisma_saatlari where end_time is null and pointID=$post_pointid order by start_time DESC limit 0,1"));
if ($operator[1]<1)
{
    //echo("�uan Aktif g�revli yok, g�revli giri� yapt���nda g�rebilirsiniz!");
	//exit();
}
$operator_detay=@mysql_fetch_array(mysql_query("select * from db_super_users where id='$operator[1]'"));
$operator_adsoyad = $operator_detay[1]." ".$operator_detay[1];

$limit = 10;
$sayfa = $_GET["sayfa"];
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
     
$tutar_1=mysql_query("SELECT * FROM db_odemeler WHERE pointID=$post_pointid and borc!='0' and tarihzaman  >= '$operator[3]'");
$satirsayisi = mysql_num_rows($tutar_1);

$toplam_kazanc = 0;
while($tutar_r=mysql_fetch_array($tutar_1))
{ 
        $toplam_kazanc = $toplam_kazanc + $tutar_r[3];
}
        

$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css">

<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
	<script type="text/javascript">
	function verify(ver){
		
		if(ver){
			// Confirmed message, i.e. clicked on "Yes"
			alert('Message confirmed');
		}else{
			// Clicked on "No"
			alert('Message not confirmed');
		}
	}
	</script>
	<link rel="stylesheet" href="css/modal-message.css" type="text/css">
	<script type="text/javascript" src="js/ajax.js"></script>
	<script type="text/javascript" src="js/modal-message.js"></script>
	<script type="text/javascript" src="js/ajax-dynamic-content.js"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">

</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580><div align="center"><span class="solmenu"><?
	if($sonucum=="AracEklendi"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ara� Eklendi!<br>";}
    if($sonucum=="AracOncedenEklenmis"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Bu Ara� Sistemde Kay�tl�!<br>";}

	?>
    </span></div>
  <H2>�deme Raporlar�</H2>
  <H2><form action="Odeme.Goster.php" method="POST">
  �deme Noktas�: <select  name=pointid size="1" id=pointid onchange="this.form.submit()">
<option value="0" >Se&ccedil;iniz </option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
</select></form></H2>
  <H2>�deme Noktas�: <? echo($post_pointid); ?> Operat�r Ad�: <? echo($operator_adsoyad); ?> Ba�lang��: <? echo($operator[3]); ?></H2>
  <TABLE class=ictablo width=585>
    <TBODY>
      <TR>
        <TH width="30">#ID</TH>
        <TH width="90">Kullan�c�</TH>
        <TH width="60">Plaka</TH>
        <TH width="60">Bor� (TL)</TH>
        <TH width="60">�denen (TL)</TH>
        <TH width="60">Kalan(TL)</TH>
        <TH width="100">Olu�turulma</TH>
        <TH width="40">Durum</TH>
        <? if ($durum==1) { ?>
        <TH width="40">��lem</TH>
        <? } ?>
        </TR>
      
  <?
 if ($operator[1]<1) exit();  // bu �deme noktas� aktif de�ilse ��k
$tablo2="SELECT * FROM db_odemeler WHERE pointID=$post_pointid and borc!='0' and tarihzaman  >= '$operator[3]' ORDER BY id DESC LIMIT ".$baslangic."," .$limit."";
$sorgu2=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 
		$kullanici=mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='".$xxd[1]."'"));


?>
      
      
      <TR>
        <TD height="32" align=middle>#<? echo $xxd[0]; ?></TD>
        <TD align=middle><div align="left"><a href="Kullanici.Odeme.Goster.php?KUID=<? echo $xxd[1]; ?>"><? 
		//echo $xxd[1];
		echo $kullanici[1]." ".$kullanici[2];
		
		if($kullanici[1]==''){
		echo "Kay�ts�z Kullan�c�";
		
		}
		?></a></div></TD>
        <TD align=middle><div align="center"><? echo $xxd[6];?></div></TD>
        <TD align=middle><div align="center"><? echo $xxd[2];?></div></TD>
        <TD align=middle><div align="center"><? echo $xxd[3];?></div></TD>
        <TD align=middle><div align="center"><? $odeme_durumu=$xxd[3]-$xxd[2]; echo $odeme_durumu;?></div></TD>
        <TD align=middle><div align="center"><? echo $xxd[4];?></div></TD>
        <TD align=middle><div align="center">
          <?
        $odeme_durumu=$xxd[3]-$xxd[2];
		//echo $odeme_durumu;
		if($odeme_durumu>=0){
		echo '<img src="images/icons/tick.png" width="16" height="16">';
		}
		else if($odeme_durumu<0){
		?>
		<a href="#" onClick="displayMessage('Odeme.Yap.php?IDX=<? echo $xxd[0]; ?>');return false"><img border='0' src='images/icons/error.png' width='16' height='16'></a>
		<?
        }
		?>
        </div></TD>
        <? if ($durum==1) { ?>
        <TD align=middle><div align="center"><a href="#" onClick="displayMessage('odeme.degistir.php?IDX=<? echo $xxd[0]; ?>');return false">De�i�tir</a></div></TD>
        <? } ?>
        </TR>
      
  <? 
} //sistemler son fetch
?>
      </TBODY>
    </TABLE>
          <p class="inputara"><img src="images/icons/tick.png" width="16" height="16">-�deme Yap�ld�<br><img src="images/icons/error.png" width="16" height="16">-�deme Tamamlanmad�!</p>

<br>
<div class="page-navigation clearfix">
<div class="wp-pagenavi">
  <div align="center">
<?
PagePrint($sayfa,$satirsayisi,$limit,"");
?>
    
  </div>
</div>
</div>
     
   <H2>Toplam Toplanan �deme: <? echo $toplam_kazanc?> TL</H2>
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom", {validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "custom");
var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6");
var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7");
var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8");
//-->
</script>
<script type="text/javascript">
messageObj = new DHTML_modalMessage();	// We only create one object of this class
messageObj.setShadowOffset(5);	// Large shadow


function displayMessage(url)
{
	
	messageObj.setSource(url);
	messageObj.setCssClassMessageBox(false);
	messageObj.setSize(400,250);
	messageObj.setShadowDivVisible(true);	// Enable shadow for these boxes
	messageObj.display();
}

function displayStaticMessage(messageContent,cssClass)
{
	messageObj.setHtmlContent(messageContent);
	messageObj.setSize(300,150);
	messageObj.setCssClassMessageBox(cssClass);
	messageObj.setSource(false);	// no html source since we want to use a static message here.
	messageObj.setShadowDivVisible(false);	// Disable shadow for these boxes	
	messageObj.display();
	
	
}

function closeMessage()
{
	messageObj.close();	
}


</script>
</BODY></HTML>
