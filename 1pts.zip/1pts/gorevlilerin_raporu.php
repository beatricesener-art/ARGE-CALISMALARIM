<?
@session_start();
include_once("Guvenlik.Filtre.php");
include_once("includes/extendsFPDFV1.class.inc.php");

//*****************************************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//

require_once('includes/veritabani.php');


$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}


if($_GET['action']=='pdf'){
	$getFromIdSql ="SELECT * FROM db_calisma_saatlari as CS JOIN db_super_users as SU on(SU.id = CS.user_id) WHERE CS.end_time is not null AND CS.id = '{$_GET['id']}' ORDER BY CS.id DESC";
	$getFromResult=mysql_query($getFromIdSql);
	if(0<mysql_num_rows($getFromResult)){
		$rowFromId=mysql_fetch_array($getFromResult,MYSQL_ASSOC);
		$_GET['start'] = $rowFromId['start_time'];
		$_GET['end'] = $rowFromId['end_time'];
		$_GET['ad'] = $rowFromId['ad'];
		$_GET['soyad'] = $rowFromId['soyad'];
        $_GET['odemenokta'] = $_GET['pointid'];
		$sqlQuery = "SELECT * FROM db_odemeler  WHERE db_odemeler.id>0 AND db_odemeler.tarihzaman  BETWEEN '{$_GET['start']}' AND '{$_GET['end']}' ORDER BY db_odemeler.id";
		$pdfFile = wsfWritePdf($sqlQuery,null,null,'p','F');
               $script =  "<script>  window.location = '{$pdfFile}'; </script>";
	}
//
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
  <link rel="STYLESHEET" type="text/css" href="takvim/codebase/dhtmlxcalendar.css">
<?php 
echo $script;
?>
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
	<script type="text/javascript">
	function verify(ver){
		
		if(ver){
			// Confirmed message, i.e. clicked on "Yes"
			alert('Message confirmed');
		}else{
			// Clicked on "No"
			alert('Message not confirmed');
		}
	}
	</script>
	<link rel="stylesheet" href="css/modal-message.css" type="text/css">
	<script type="text/javascript" src="js/ajax.js"></script>
	<script type="text/javascript" src="js/modal-message.js"></script>
	<script type="text/javascript" src="js/ajax-dynamic-content.js"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">

<style type="text/css">
<!--
.style1 {color: #CC0000}
-->
</style>

    <style type="text/css">
<!--
.style2 {color: #000000}
-->
    </style>
    </HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580><div align="center"><span class="solmenu"><?
	if($sonucum=="AracEklendi"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ara� Eklendi!<br>";}
    if($sonucum=="AracOncedenEklenmis"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Bu Ara� Sistemde Kay�tl�!<br>";}

	?>
    </span></div>
  <!---------------------->
  <!------------->
  <H2>Gorevlilerin �ali�ma Raporu</H2>
  <TABLE class=ictablo width=594>
    <TBODY>
    </TBODY>
  </TABLE>
  <br>
  <TABLE class=ictablo width=594>
    <TBODY>
      <TR>
        <TH width="30">#ID</TH>
        <TH width="110">g�revl� adi</TH>
        <TH width="108">ba�langi�</TH>
        <TH width="105">biti�</TH>
        <TH width="147">dosiya</TH>
        </TR>
      
  <?

$tablo2="SELECT * FROM db_calisma_saatlari WHERE end_time is not null ORDER BY id DESC";
$sorgu2=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu2);

	while($xxd=mysql_fetch_array($sorgu2)){ 
		
?>
      
      
      <TR>
        <TD height="32" align=middle>#<? echo $xxd[0]; ?></TD>
        <TD align=middle><div align="center"><? echo $xxd[2];?></div></TD>
        <TD align=middle><div align="center"><? echo $xxd[3];?></div></TD>
        <TD align=middle><div align="center"><? echo $xxd[4];?></div></TD>
        <TD align=middle><div align="center">
				<a href="<?php echo "gorevlilerin_raporu.php?action=pdf&id={$xxd[0]}&pointid={$xxd[5]}"?>"><img src="images/pdf.png" alt="" ></a>
				<a href="<?php echo "gorevlilerin_raporu.php?action=pdf&is_short=1&id={$xxd[0]}&pointid={$xxd[5]}"?>"><img src="images/action_save.png" alt="" width="%50"></a>
			</div>
		</TD>
        </TR>
      
  <? 
} //sistemler son fetch
?>
      </TBODY>
    </TABLE>
          
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>

</BODY>
</HTML>
