<?PHP
//require_once('includes/veritabani.php');
//$post_plaka=strtoupper($_POST['arac_Plaka']);
$post_plaka=$arac_Plaka;
$post_buton=$_POST['button'];
//if($post_buton=='Ara')
//{

	mysql_query("TRUNCATE TABLE `db_araclar_temp` ");
	$tablo2="SELECT * FROM db_araclar WHERE aracKonum='i' AND UID!=1 order by `sondegisim` DESC LIMIT 0,20";
    $sorgu2=mysql_query($tablo2);
    $kactane2=@mysql_num_rows($sorgu2);
   	while($xxd=@mysql_fetch_array($sorgu2)){ 

		$lev_puan = levenshtein($post_plaka, $xxd['plaka']);
		if (1)
		{
			//echo $lev_puan;
			$insert_query="INSERT INTO `db_araclar_temp` (`id` ,`plaka` ,`resimyolu` ,`puan`,`soncamid`)VALUES (NULL , '".$xxd['plaka']."', '".$xxd['resimyolu']."', '$lev_puan','".$xxd['soncamid']."')";
			mysql_query($insert_query)or die(mysql_error());	
			$deg_tarih[$xxd['plaka']]=$xxd['sondegisim'];
		}
	}
//}
?>
<script type="text/javascript" src="../webtoolkit.scrollabletable.js"></script>
<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script type="text/javascript" src="../jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../fancybox/jquery.fancybox-1.2.6.css" media="screen" />
<script type="text/javascript" src="../fancybox/jquery.fancybox-1.2.6.pack.js"></script>
	<LINK rel=stylesheet type=text/css href="../stil.css">
	

<script type="text/javascript">
		$(document).ready(function() {
			$("a.zoom").fancybox();

			$("a.zoom1").fancybox({
				'overlayOpacity'	:	0.7,
				'overlayColor'		:	'#FFF'
			});

			$("a.zoom2").fancybox({
				'zoomSpeedIn'		:	300,
				'zoomSpeedOut'		:	300
			});
		});
	</script>
<script>
      window.dhx_globalImgPath="../../codebase/imgs/";
</script>

<center>

<TABLE width=580 align="center" class=ictablo  id="myScrollTable">
  
  <thead>
    <TR>
      <TH width="61"><div align="center">#ID</div></TH>
      <TH width="89"><div align="center">Plaka</div></TH>
      <TH width="116"><div align="center">Resim</div></TH>
      <TH width="108"><div align="center">Benze&#351;im</div></TH>
	  <TH width="108"><div align="center">G.Tarih</div></TH>
      <TH width="182"><div align="center">Se&ccedil;im</div></TH>
    </TR>
  </thead>
  <TBODY>
    <?
    //$tablo2="SELECT * FROM db_araclar_temp INNER JOIN  db_loglar  ON ( db_araclar_temp.plaka = db_loglar.plaka )  GROUP by db_araclar_temp.plaka  ORDER by  db_araclar_temp.puan asc";
	//echo $tablo2;
	$tablo2=" SELECT MAX( db_loglar.id ) , db_araclar_temp.soncamid, db_loglar.resimyolu, db_loglar.plaka, db_araclar_temp.puan
FROM db_araclar_temp
INNER JOIN db_loglar ON ( db_araclar_temp.plaka = db_loglar.plaka )
GROUP BY db_araclar_temp.plaka
ORDER BY db_araclar_temp.puan"; 
    $sorgu2=mysql_query($tablo2)or die(mysql_error());
    $kactane2=@mysql_num_rows($sorgu2);
    	while($xxd=@mysql_fetch_array($sorgu2)){ 
		++$b;
	$resim_yol="";
	$camid= $xxd['soncamid']; 
	$sorsor="SELECT * FROM db_kameralar WHERE kamera_ID='$camid'";
	//echo $sorsor;
	$cam_sistem_bilgisi=mysql_fetch_row(mysql_query($sorsor));
	$sistem_bilgisi=mysql_fetch_array(mysql_query("SELECT * FROM db_sistemler WHERE sistemadi='".$cam_sistem_bilgisi[2]."'"));
	$tt=mysql_fetch_array(mysql_query("SELECT * FROM db_ayarlar WHERE id='1'"));
	$resim_yol=$sistem_bilgisi[3];
	$resim=strstr($xxd['resimyolu'], '_');
	$resim = str_replace("_", "", $resim);


	$yil = substr($resim, 0, 4); 
	$ay = substr($resim, 4, 2);  
	$gun = substr($resim, 6, 2); 

	/*echo $yil." ".$ay." ".$gun;
	echo "<br>";
	echo $resim;
	*/
	$resim_yol=$resim_yol.$yil."/".$ay."/".$gun."/".$xxd['resimyolu'];
    ?>
    <TR>
      <TD><div align="center"><? echo $b; ?></div></TD>
      <TD><div align="center"><? echo $xxd['plaka']; ?></div></TD>
      <TD align=middle><div align="center"><a class="zoom2" title="<? echo $xxd['plaka']; ?>" href="Resim.Goster.php?w=700&img=<? echo $resim_yol; ?>">RESM� G�STER</a></div></TD>
      <TD align=middle><div align="center"><? echo "% ".round((((8-$xxd['puan'])*100)/8),2); ?></div></TD>
	  <TD><div align="center"><? echo $deg_tarih[$xxd['plaka']]; ?></div></TD>
      <TD align=middle><div align="center"> 
      <script language="javascript">


function kontrol(chk)
{
var kontrol=chk.id;
if(chk.checked==true){
for (var i = 0; i < chk.form.length; i++){

if(chk.form[i].id!=kontrol) {
chk.form[i].checked=false;
}
}
}
}
</script> 
      <input type="checkbox"  name="aracid[]" value="<? echo $xxd['plaka']; ?>"  id="chk_<? echo $xxd[0]; ?>" onclick="kontrol(this);">
      </div>
      </TD>
    </TR>
    <? 
	  } 
	 ?>
  </TBODY>
</TABLE>
</center>


