<?
@session_start();
include_once("Guvenlik.Filtre.php");

include ("fpdf/fpdf.php"); // fpdf.php dosyas�n�n yerine ba�l� 
$pdf = new FPDF();  


function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');


$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and (yetki='1' or yetki='4')"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$KUID=htmlspecialchars(trim(mysql_real_escape_string($_GET['KUID'])));
$sonucum=htmlspecialchars(trim(mysql_real_escape_string($_GET['Sonuc'])));
$ekle=mysql_real_escape_string($_POST['ekle']);
$a1=htmlspecialchars(trim(mysql_real_escape_string(strtoupper($_POST['a1']))));
$a1 = str_replace(" ","",$a1);
$a2=htmlspecialchars(trim(mysql_real_escape_string($_POST['a2'])));
$a3=htmlspecialchars(trim(mysql_real_escape_string($_POST['a3'])));
$a4=htmlspecialchars(trim(mysql_real_escape_string($_POST['a4'])));
$a5=htmlspecialchars(trim(mysql_real_escape_string($_POST['a5'])));
$a6=htmlspecialchars(trim(mysql_real_escape_string($_POST['a6'])));

$a7=htmlspecialchars(trim(mysql_real_escape_string($_POST['a7'])));
$a8=htmlspecialchars(trim(mysql_real_escape_string($_POST['a8'])));

if($a7=="on") $a7=1;
else $a7=0;

$KUID2=htmlspecialchars(trim(mysql_real_escape_string($_POST['KUID'])));



if($ekle="Ekle"){
	
	if($a1>' '){
		
		//plaka �nceden ekli mi?
$kontrol=mysql_fetch_row(mysql_query("select COUNT(*) from db_araclar where plaka='$a1'"));
$toplam_ucretim=0;
if($kontrol[0]<1)
{
		if($a2=="E"){
			$uidim="";
		
		}
		if($a2!="E"){
			$uidim=1;
			$birim_arac_ucreti=mysql_fetch_array(mysql_query("SELECT * FROM db_abonelikturleri WHERE id='$a2'"));
			$a2_2=$birim_arac_ucreti[2];
			$ekle_sorgu="SELECT ADDDATE( '$tarih $zaman', INTERVAL ".$a2_2." DAY )";
			$SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
			$cikan_gun=$SQL_tarih_ekle[0];
			####fatura olu�tur######################
		    $birim_arac_ucreti=mysql_fetch_array(mysql_query("SELECT * FROM db_abonelikturleri WHERE id='$a2'"));
			$a2_2=$birim_arac_ucreti[2];
	        $birim_ucretim=$birim_arac_ucreti[3]; //TL cinsinden fiyat d�ner
 		    $toplam_ucretim=$toplam_ucretim+$birim_ucretim;
			mysql_query("INSERT INTO `db_odemeler` (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`, `plaka` , `abonesure` , `operatorid` , `dosyaadi`)VALUES (NULL , '$KUID2', '$toplam_ucretim','0',NOW(),'' , '$a1' , '$a2_2' , $idm, '')");
$iddd=mysql_insert_id();
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$iddd NOlu $toplam_ucretim TL\'lik �cret bilgisi olu�turuldu', NOW(),'$user')")or die(mysql_error());

$lastSql="SELECT * from `db_odemeler` order by `tarihzaman` DESC LIMIT 0,1";
$lastResult = @mysql_query($lastSql);
$numResult = mysql_num_rows($lastResult);
$lastVal = @mysql_fetch_assoc($lastResult);

	if ($numResult>0)
	{
       $idValue=$lastVal['id'];
		$pdf->AddPage('P', 'A5');
		$tarih_zaman = $tarih." ".$zaman;
		$pdf->SetFont('Arial','B',18);
		$pdf->Text(10,5,'									');
		$pdf->Text(10,12,'--------------------------------------------------');
		$pdf->Text(10,19,$otoparkadi);
		$pdf->Text(10,26,'--------------------------------------------------');
		$pdf->Text(10,33,'-----ABONE BILGILERI-----');
		$pdf->Text(10,40,"Arac Plaka: ".$aracPlaka);
		$pdf->Text(10,47,"Islem Tarihi: ".$tarih_zaman);
		$pdf->Text(10,54,"A.Bitis: ".$cikan_gun3);
		$pdf->Text(10,61,"A.S�resi: ".$a2_2." g�n");
		$pdf->Text(10,68,"Odeme Tutar: ".$toplam_ucretim." TL");
		$pdf->Text(10,75,'--------------------------------------------------');
		$pdf->Text(10,82,'									');
		$pdf->Text(10,89,'									');
		
		$file="abonePDF/".$idValue."_abone.pdf";
		$pdf->Output($file); 

		mysql_query("UPDATE `db_odemeler` SET `dosyaadi` = '$file'  WHERE `id` =$idValue ")or die(mysql_error());

	}
	
			########################################
		}

	//echo $cikan_gun;
		$ekle="INSERT INTO `db_araclar` (
		`id` ,
		`kullaniciid` ,
		`marka` ,
		`model` ,
		`renk` ,
		`UID` ,
		`aracsurucusu` ,
		`eklenme` ,
		`plaka`,
		`geciciarac`,
		`abonelikbaslangic`,
		`abonelikbitis`,
		`abonelikdurum`,
		`abonelikTipi`,
		`AbonelikSaat`
		)
		VALUES (
		NULL , '$KUID2', '$a3', '$a4', '$a5', '$uidim', '', '$tarih $zaman', '$a1', '2', NOW(), '$cikan_gun', 'a' , '$a7' , '$a8'
		)";
		mysql_query($ekle)or die(mysql_error());

		@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$a1 Plakal� Ara� Eklendi', NOW(),'$user')");

		$uyari="Arac Eklendi!";
	   @header("Location: Arac.Duzenle.php?KUID=$KUID2&Sonuc=AracEklendi");
	//?KUID=1&Durum=AracEkle

	
}else if($kontrol[0]>0){
	
	@header("Location: Arac.Duzenle.php?Sonuc=AracOncedenEklenmis&KUID=$KUID2&Durum=AracEkle");


	
}
	}//if bo� de�ilse
}//if ekle ise



$limit = 10;
$sayfa = $_GET["sayfa"];
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
$satirsayisi = mysql_num_rows(mysql_query("SELECT * FROM db_araclar WHERE kullaniciid='$KUID'"));
$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;

$sahibi_kim_ki=@mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='$KUID'"));
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580><div align="center"><span class="solmenu"><?
	if($sonucum=="AracEklendi"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ara� Eklendi!<br>";}
    if($sonucum=="AracOncedenEklenmis"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Bu Ara� Sistemde Kay�tl�!<br>";}

	?>
    </span></div>
<FORM method=post name=misafirtanimla action=Arac.Duzenle.php>
  <INPUT 
      type="hidden" name="ekle" value="duzenle">
  <INPUT 
      type="hidden" name="KUID" value="<? echo $KUID; ?>">
  <!---------------------->
  
  
  <TABLE class=ictablo width=570>
    <TBODY>
      <TR>
        <TH colSpan=2>Yeni Ara&ccedil; Ekle</TH>
        </TR>
      <TR>
        <TD style="COLOR: red" colSpan=2 align=middle></TD>
        </TR>
      <TR>
        <TD width="40%" align=right>Ara&ccedil; Plakas�:</TD>
        <TD><span id="sprytextfield5">
          <input name=a1 class=text_input id="a1">
          <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></TD>
        </TR>
      <TR>
        <TD align=right>Ara� Ba�l� Bulundu�u Ki�i: </TD>
        <TD><input name=a6 value="<? echo  $sahibi_kim_ki[1]; ?> <? echo  $sahibi_kim_ki[2]; ?>" disabled class=text_input id="a6"></TD>
      </TR>
      <TR>
        <TD align=right>Marka:</TD>
        <TD>
          <input name=a3 class=text_input id="a3">         </TD>
        </TR>
      <TR>
        <TD align=right>Model:</TD>
        <TD>
          <input name=a4 class=text_input id="a4">          </TD>
        </TR>
      <TR>
        <TD align=right>Renk: </TD>
        <TD>
          <input name=a5 class=text_input id="a5">          </TD>
        </TR>
      <TR>
	  <TR>
              <TD align=right>G�nl�k Abonelik: </TD>
              <TD><input name=a7 type="checkbox"  />
                </TD>
            </TR>
			 <TR>
              <TD align=right>G�nl�k Saat: </TD>
              <TD><input name=a8 value="" class=text_input id="a8"> 
                Saat</TD>
            </TR>
            <TR>
        <TD align=right>Abonelik T�r�?</TD>
        <TD><SELECT id=a2  name=a2>
        <option value="E">Abonelik Atama</option>
          <?
			$sorgula=mysql_query("SELECT * FROM db_abonelikturleri ORDER BY id");
			while($sistem=mysql_fetch_array($sorgula)){
			  ?>
           <option value="<? echo $sistem[0]; ?>"><? echo $sistem[1]."  (".$sistem[2].")"; ?> </option>
          <? } //while sorgul ?>
        </SELECT></TD>
        </TR>
      <TR>
        <TD width="40%" align=right></TD>
        <TD><INPUT class=button value=Ekle type=submit name=ekle>
          &nbsp; </TD>
        </TR>
      </TBODY>
    </TABLE>
  
  
  <!------------->
  <H2>Kullan�c�n�n Di�er Ara�lar�</H2>
  <TABLE class=ictablo width=582>
    <TBODY>
      <TR>
        <TH width="34">#ID</TH>
        <TH width="86">Plaka</TH>
        <TH width="143">Abonelik Bilgisi </TH>
        <TH width="133">Abonelik Biti� Tarihi</TH>
        <TH width="162">��lemler</TH>
        </TR>
      
  <?
$tablo2="SELECT * FROM db_araclar WHERE kullaniciid='".$sahibi_kim_ki[0]."' order by id desc";
$sorgu2=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 
?>
      
      
      <TR>
        <TD align=middle>#<? echo $xxd[0]; ?></TD>
        <TD align=middle><? echo $xxd["plaka"];?></TD>
        <TD align=middle><div align="right">
          <?
		if($xxd["UID"]=="1"){
		 $abonelik_bitisi= $xxd["abonelikbitis"];

		 $ekle_sorgu= "SELECT DATEDIFF('$abonelik_bitisi','$tarih $zaman')";
	   	 $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
	     $cikan_gun=(int)$SQL_tarih_ekle[0];	
		 $abonelik_bitmesi = convert_datetime($abonelik_bitisi);		 
		 $suan= convert_datetime("$tarih $zaman");
		 $cikan_gunA=$abonelik_bitmesi-$suan;

		 if($cikan_gunA<=0){
		 $yazdir= "G�n �nce Doldu ". '<img src="images/icons/stop.png" width="16" height="16">';
		 }
		 else if(($cikan_gunA>0)&&((int)$cikan_gunA!=0)){
		 $yazdir= "G�n Kald� ". '<img src="images/icons/tick.png" width="16" height="16">';
		 }
		 $cikan_gun = str_replace("-", "", $cikan_gun);
		 echo $cikan_gun." ".$yazdir;
		  }
		  if($xxd["UID"]!="1"){
		  echo "Abone De�il ".'<img src="images/icons/information.png" width="16" height="16">' ;
		  
		  }
		  ?>
        </div></TD>
        <TD align=middle><div align="center"><? echo $xxd["abonelikbitis"];?></div></TD>
        <TD align=middle>
          <INPUT value="<? echo $xxd[0]; ?>" type=hidden name="kamera">
          <input class="button small" name="Sil2" value="Uzat" onClick="javascript:document.location.href='Arac.Guncelle.php?AUID=<? echo $xxd['id'] ?>&Islem=AbonelikUzat'" type="button" id="Sil3" />
          <input class="button small" name="Duzenle" value="D�zenle" onClick="javascript:document.location.href='Arac.Guncelle.php?AUID=<? echo $xxd['id'] ?>'" type="button" id="Sil2" />
          <input class="button small" name="Sil" value="Sil" onClick="JavaScript:if (confirm('Silmek istedi�inizden emin misin?')) javascript:document.location.href='Arac.Guncelle.php?KID=<? echo $xxd['id'] ?>&Durum=Sil'" type="button" id="Sil" /></TD>
        </TR>
      
  <? 
} //sistemler son fetch
?>
      </TBODY>
    </TABLE>
          <H5 align="center">&nbsp;</H5>
</FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom", {validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "custom");
var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5");
var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6");
var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7");
var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8");
//-->
</script>
</BODY></HTML>
