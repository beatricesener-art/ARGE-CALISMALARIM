<?
@session_start();
include_once("Guvenlik.Filtre.php");


//*****************************************//
//**********PCC ELEKTRON�K*****************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//
@require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];

$login_durum=mysql_real_escape_string($_GET['p']);  //Giri� se�enekleri
$login_durum_2=mysql_real_escape_string($_POST['p']);  //Giri� se�enekleri
$hata=mysql_real_escape_string($_POST['HID']); 

if(empty($login_durum)){
$login_durum="1";	
}

if($login_durum=="1"){
$tip="Park Y�neticisi Giri�i";
$sql_ek="and yetki='1'";
	//Site/Sistem Y�neticisi
}
if($login_durum=="2"){
$tip="Sistem Y�netcisi Giri�i";
$sql_ek="and yetki='2'";
	//Teknik Destek
}
if($login_durum=="3"){
$tip="Site Kullan�c�s� Giri�i";
$sql_ek="and yetki='3'";
	//Site Kullan�c�s�
}
if($login_durum=="4"){
$tip="G�revli Giri�i";
$sql_ek="and yetki='4'";
	//Site Kullan�c�s�
}


if($login_durum_2=="1"){
$tip="Site/Sistem Y�neticisi Giri�i";
$sql_ek="and yetki='1'";
	//Site/Sistem Y�neticisi
}
if($login_durum_2=="2"){
$tip="Teknik Destek Giri�i";
$sql_ek="and yetki='2'";
	//Teknik Destek
}
if($login_durum_2=="3"){
$tip="Site Kullan�c�s� Giri�i";
$sql_ek="and yetki='3'";
	//Site Kullan�c�s�
}
if($login_durum_2=="4"){
$tip="G�revli Giri�i";
$sql_ek="and yetki='4'";
	//Site Kullan�c�s�
}


/*$tablo = "select * from db_super_users where username='$user' and password='$sifre'  ";
$sorgu= mysql_query($tablo);
if (@mysql_num_rows($sorgu) > 0 ) {
header("Location: Home.php"); //e�er �nceden loginse direk y�nlendir 
}*/


$buton_gonder=$_POST['gonder'];  
$post_username=$_POST['username'];  //K.ad�
$post_password=$_POST['password'];  //�ire


if($buton_gonder){ //e�er butona t�klarsam

$tablo = "select * from db_super_users where username='$post_username' and password='$post_password' ".$sql_ek;
//echo $tablo;
$sorgu= mysql_query($tablo);
	if (@mysql_num_rows($sorgu) > 0 ) {
		$kullaniciadi1 = @mysql_result($sorgu,0,"username");
		$ad = @mysql_result($sorgu,0,"ad");
		$ids = @mysql_result($sorgu,0,"id");
		$sifre = @mysql_result($sorgu,0,"password");
		$admin_durum = @mysql_result($sorgu,0,"yetki");
		setcookie("akullaniciadi", $kullaniciadi1);
		setcookie("asifre" , $sifre);
		setcookie("aid" , $ids);
		setcookie("adurum" , $admin_durum);
		mysql_query("UPDATE db_super_users SET songiris='$tarih $zaman' WHERE username='$kullaniciadi1'");
		@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$kullaniciadi1 Y�netim paneline giri� yapt�.', NOW(),'$kullaniciadi1')");

		//echo $kullaniciadi1;
		//echo $sifre;
		@header("Location: Home.php"); //e�er �nceden loginse direk y�nlendir 
	
	
	}
	if (@mysql_num_rows($sorgu) < 1 ) {
	@header("Location: index.php?p=$login_durum_2&HID=1"); //HID=1 eri�im izni yok 
	//echo $tablo;
	@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$post_username ismi ile y�netim paneline giri� yap�lmaya �al���ld�. ��lem ba�ar�s�z oldu.', NOW(),'---')");
	}
	
	
}


if($_GET['HID']=="2"){
$ikaz="Yetki D��� Alana Eri�emezsiniz";
}
if($_GET['HID']=="1"){
$ikaz="Ge�ersiz Kullan�c� Ad�/ �ifre";
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9" />
    <meta name="robots" content="noindex,nofollow">
    <link rel="stylesheet" href="stil.css" type="text/css">
    <title><? echo $ttt[1]; ?></title>
    <link href="stil.css" rel="stylesheet" type="text/css" />
    <script language="JavaScript" src="controls.js"></script>
    <script src="ajax.js" type="text/javascript" language="JavaScript"></script>
  <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
  <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
  </head>
<body>
<?
if (isset($_SESSION['birincil'])) header("home.php");
else{
?>
<h1><? echo $ttt[1]; ?></h1>
<form name="giris" action="index.php" method="POST">
  <table border="0" align="center" class="ictablo" width="400px;" style="margin-top:200px;">
<caption><h1><?=$tip?></h1></caption>    <tr>
      <th colspan="3" align="center">Giri�
      <input type="hidden" name="p" value="<?=@$_GET['p']?>">
      </th>
    </tr>
    <tr>
      <TD colspan="2" align="center" style="color:red"><?=@$ikaz?></td>
    </tr>
    <tr>
      <td class="formleft">Kullan�c� Ad� :</td>
      <td><span id="sprytextfield1">
        <input name="username"  type="text" />
      <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td class="formleft">�ifre :</td>
       <td><span id="sprytextfield2">
       <input name="password" type="password" value="">
       <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span></span></td>
    </tr>
    <tr>
      <td colspan="2" align="center">
        <label></label></td>
    </tr>
  
    <tr>
      <td align="center" colspan="3"><input name="gonder" type="submit" class=button id="gonder"  value="Giri&#351; Yap" /></td>
    </tr>
    <tr>
      <td align="center" colspan="3">   
		  <div><a href="index.php?p=1">Park Y&ouml;neticis</a>i ||
			  <a href="index.php?p=2">Sistem Y&ouml;neticisi</a> || 
			  <a href="index.php?p=4">Park G�revlisi</a> ||
			  <a href="Kullanici.Giris.php">Kullan�c� Giri�i</a>
		  </div>
	  </td>
    </tr>
    <tr>
      <td align="center" colspan="3">   
		  <div>
			  <a href="gorev_baslat.php"><h2>Gorevini Ba�lat</h2></a> </a>
		  </div>
	  </td>
    </tr>

  </table>
  </form>
<? } ?>
  <script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
//-->
  </script>
</body>
</html>
