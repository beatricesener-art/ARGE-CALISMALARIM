<?
include_once("includes/Sayfalama.Fonk.php");
include_once("Guvenlik.Filtre.php");


//*****************************************//
//*****************************************//
function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}
//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='4' or yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$KID=trim(mysql_real_escape_string($_GET['KID']));
$KID2=trim(mysql_real_escape_string($_POST['KID']));


$ekle=mysql_real_escape_string($_['ekle']);
$a1=trim(mysql_real_escape_string($_GET['a1']));
$a2=trim(mysql_real_escape_string($_GET['a2']));
$a3=trim(mysql_real_escape_string($_GET['a3']));
$a4=trim(mysql_real_escape_string($_GET['a4']));
$a5=trim(mysql_real_escape_string($_GET['a5']));
$a6=trim(mysql_real_escape_string($_GET['a6']));
$a7=trim(mysql_real_escape_string($_GET['a7']));
$a8=trim(mysql_real_escape_string($_GET['a8']));
$a9=trim(mysql_real_escape_string($_GET['a9']));//Grupname bas�yor
$a10=trim(mysql_real_escape_string($_GET['a10']));
$a11=trim(mysql_real_escape_string($_GET['a11']));
$a12=trim(mysql_real_escape_string($_GET['a12']));
$a13=trim(mysql_real_escape_string($_GET['a13']));
$a14=trim(mysql_real_escape_string($_GET['a14']));
$a20=trim(mysql_real_escape_string($_GET['a20']));


if($_GET['Temizle']=="Temizle"){

@header("Location: Gorevli.Arac.Arama.php?Temizlendi");
}


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>

<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
		<script src="jquery.js" language="JavaScript" type="text/javascript"></script>

<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>

<META name=GENERATOR content="MSHTML 8.00.7600.16466">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {color: #CC0000}
.style2 {font-size: 10px}
-->
</style>
	<style>

		#notification{
	position:absolute;
	bottom:0%;
	right:2%;
	height:122px;
	width:200px;
	border:1px solid black;
	border-bottom:0px;
	background: url('images/pts_solback.jpg') repeat-y;

		}
		#notificationClose{
			font-size:11px;
			cursor:pointer;
			width:100%;
			border-bottom:1px solid black;
		}
		#notificationIn{
			padding:10px;
			font-size:11px;
			
		}
	</style>
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580>
      <FORM method=get name=misafirtanimla action=Gorevli.Arac.Arama.php >
      <INPUT 
      type="hidden" name="ekle" value="duzenle">
       <INPUT 
      type="hidden" name="KID" value="<? echo $KID; ?>">
        <TABLE class=ictablo width=570>
          <TBODY>
            <TR>
              <TH colSpan=2> Ara� Arama</TH>
            </TR>
            <TR>
              <TD style="COLOR: red" colSpan=2 align=middle></TD>
            </TR>
            <TR>
              <TD align=right>Ara� No(#ID):</TD>
              <TD><INPUT name=a6 value="<? echo $a6; ?>" class=text_input id="a6"></TD>
            </TR>
            <TR>
              <TD width="40%" align=right>Plaka:</TD>
              <TD><INPUT name=a1 value="<? echo $a1; ?>" class=text_input id="a1"></TD>
            </TR>
            <TR>
              <TD align=right>Ara&ccedil; Marka:</TD>
              <TD><INPUT name=a3 value="<? echo $a3; ?>" class=text_input id="a3"></TD>
            </TR>
            <TR>
              <TD align=right>Ara&ccedil; Model:</TD>
              <TD><INPUT name=a4 value="<? echo $a4; ?>" class=text_input id="a4"></TD>
            </TR>
            <TR>
              <TD align=right>Ara&ccedil; Renk:</TD>
              <TD><INPUT name=a5 value="<? echo $a5; ?>" class=text_input id="a5"></TD>
            </TR>
            <TR>
              <TD align=right class="style1">Giri� ��k�� Pozisyonuna G�re Arama:</TD>
              <TD>
                <SELECT  name=a9 size="1" id=a9>
                <option value="0">L�tfen Se�iniz</option>
                  <?
			$sorgula=mysql_query("SELECT * FROM db_camgrup ORDER BY id");
			while($sistem=mysql_fetch_array($sorgula)){
			  ?>
                  <option <? if($a9==$sistem[0]){echo'selected';} ?> value="<? echo $sistem[0]; ?>"><? echo $sistem[1]; ?></option>
                  <? } //while sorgul ?>
                  <option value="b" <? if($a9=="b"){echo'selected';} ?>>Herhangi Bir Sistem</option>
                </SELECT>
                 <span class="style1">Hareket:</span>
                 <select  name=a15 size="1" id=a15>
                  <option value="0" >Se&ccedil;iniz </option>
                  <option  value="i" <? if($a15=="i"){echo'selected';} ?> >Girmi�</option>
                  <option value="d" <? if($a15=="d"){echo'selected';} ?> >��km��</option>
                </select>           </TD>
            </TR>
            
            <TR>
              <TD align=right>Sadece Abone Ara�lar� G�ster:</TD>
              <TD><input name="a10" type="checkbox" <? if(($a10=="1")&&($a2!="1")){echo"checked";} ?> id="a10" value="1"></TD>
            </TR>
            <TR>
              <TD align=right>Sadece Abone Olmayan Ara�lar� G�ster:</TD>
              <TD><input name="a2" type="checkbox" <? if(($a2=="1")&&($a10!="1")){echo"checked";} ?> id="a2" value="1"></TD>
            </TR>
			<TR>
              <TD align=right>Aboneli�i 15 g�nden az kalanlar� g�ster:</TD>
              <TD><input name="a20" type="checkbox" <? if($a20=="1"){echo"checked";} ?> id="a20" value="1"></TD>
            </TR>
            <!--<TR>
              <TD align=right>Saat Bilgisine G�re Arama:</TD>
              <TD><span id="sprytextfield3">
                <input name=a14  id="a14" value="<? echo $a14; ?>" size="20" maxlength="20">
                <span class="textfieldInvalidFormatMsg">Saat Format� Hatal�.</span>                </span><span class="textfieldInvalidFormatMsg">D�zg�n Formatta De�il!!</span> <span class="style1">**               </span></TD>
            </TR>
            <TR>
              <TD align=right>Giri� ��k�� S�resine G�re Arama:</TD>
              <TD>
                <input name=a11 value="<? echo $a11; ?>" class=text_input id="a11">
                <span class="textfieldInvalidFormatMsg">Say� Giriniz</span> <span class="style1">**</span> <br></TD>
            </TR>-->
            <TR>
              <TD width="40%" align=right></TD>
              <TD><INPUT class=button value=Ara type=submit name=Ara>
                &nbsp; <INPUT class=button value=Temizle type=submit name=Temizle id="Temizle"></TD>
            </TR>
          </TBODY>
        </TABLE>
        <p class="solmenu style2">**Giri� ��k�� Pozisyon Bilgisi Girilmelidir!       <br>
        <br>
        <img src="images/icons/user.png" width="16" height="16">-Kay�tl� Kullan�c�  <img src="images/icons/user_red.png" width="16" height="16"> -Ge�ici Kullan�c�</p>
       
        <H2>Bulunan Ara&ccedil;lar</H2>
        <TABLE class=ictablo width=572>
          <TBODY>
            <TR>
              <TH width="29" height="31">#ID</TH>
              <TH width="87">Plaka</TH>
              <TH width="25">T�r</TH>
              <TH width="151">Abonelik Bilgisi </TH>
              <TH width="82">Abonelik Biti� Tarihi</TH>
              <TH width="170">��lemler</TH>
            </TR>
    <?
$a1=trim(mysql_real_escape_string(strtoupper($_GET['a1'])));//plaka
//$a1=trim(mysql_real_escape_string(strtoupper($_POST['a1'])));
$a1 = str_replace(" ","",$a1);
$a2=trim(mysql_real_escape_string($_GET['a2']));//ad�
$a3=trim(mysql_real_escape_string($_GET['a3']));//marka
$a4=trim(mysql_real_escape_string($_GET['a4']));//model
$a5=trim(mysql_real_escape_string($_GET['a5']));//renk
$a6=trim(mysql_real_escape_string($_GET['a6']));//area1
$a7=trim(mysql_real_escape_string($_GET['a7']));//area2
$a8=trim(mysql_real_escape_string($_GET['a8']));//area3
$a9=trim(mysql_real_escape_string($_GET['a9']));///Grupname bas�yor 
$a10=trim(mysql_real_escape_string($_GET['a10'])); //sadece misafirleri g�ster
$a11=trim(mysql_real_escape_string($_GET['a11']));//i�eride �u kadar saatten fazla kalan ara�lar
$a12=trim(mysql_real_escape_string($_GET['a12']));
$a13=trim(mysql_real_escape_string($_GET['a13']));//Grupname bas�yor
$a14=trim(mysql_real_escape_string($_GET['a14']));
$a20=trim(mysql_real_escape_string($_GET['a20']));

/*echo $a9;
echo " ";
echo $a13;
echo " ";
*/

	$kosul='';
	$join_ek='';
	if($a1>' '){$kosul = $kosul. ' and plaka LIKE \'%'.$a1.'%\'' ;}
	

	if($a5>' '){$kosul = $kosul. ' and db_araclar.renk LIKE \'%'.$a5.'%\'' ; $join_ek='';}
	if($a4>' '){$kosul = $kosul. ' and db_araclar.model LIKE \'%'.$a4.'%\'' ; $join_ek='';}
	if($a3>' '){$kosul = $kosul. ' and db_araclar.marka LIKE \'%'.$a3.'%\'' ; $join_ek='';}
	if($a10>' '){$kosul = $kosul. ' and db_araclar.UID = \''.$a10.'\'' ; $join_ek='';}
    if($a2>' '){$kosul = $kosul. ' and db_araclar.UID != \''.$a2.'\'' ; $join_ek='';}
	if($a6>' '){$kosul = $kosul. ' and db_araclar.id = \''.$a6.'\'' ; $join_ek='';}

/*
		if($a6!="0"){$kosul = $kosul. ' and db_kullanicilar.area1=\''.$a6.'\'' ; $join_ek='LEFT JOIN (
db_kullanicilar
) ON ( db_kullanicilar.id = db_araclar.kullaniciid) ';}
		if($a7!="0"){$kosul = $kosul. ' and db_kullanicilar.area2=\''.$a7.'\'' ; $join_ek='LEFT JOIN (
db_kullanicilar
) ON ( db_kullanicilar.id = db_araclar.kullaniciid) ';}
		
		if($a8!="0"){$kosul = $kosul. ' and db_kullanicilar.area3=\''.$a8.'\'' ; $join_ek='LEFT JOIN (
db_kullanicilar
) ON ( db_kullanicilar.id = db_araclar.kullaniciid) ';}
		if($a10>' '){$kosul = $kosul. ' and db_araclar.UID=\''.$a10.'\'' ; $join_ek='LEFT JOIN (
db_kullanicilar
) ON ( db_kullanicilar.id = db_araclar.kullaniciid) ';}
		if($a12=="1"){$kosul = $kosul. ' and db_araclar.geciciarac=\''.$a12.'\'' ; $join_ek='LEFT JOIN (
db_kullanicilar
) ON ( db_kullanicilar.id = db_araclar.kullaniciid) ';}
		//******��eri D��ar� Durum********/
		if(($a9!="0")&&($a15!="0")){
		
			if($a9=="b")
			{
			
$kosul = $kosul. ' and db_araclar.aracKonum=\''.$a15.'\' and db_araclar.soncamgrupid>="0" '  ; $join_ek='';
			
			}
			if($a9!="b")
			{
			
$kosul = $kosul. ' and db_araclar.aracKonum=\''.$a15.'\' and db_araclar.soncamgrupid=\''.$a9.'\''  ; $join_ek=' ';
			
			}
			
		



}
if(($a9!="0")&&($a15!="0"))

		//******��eri D��ar� Durum********/

if(($a11>' ')&&($a9!="0")&&($a15!="0")){
$saatfarki2 = $a11; 
$rest = substr($a11, 1, 1);  // returns "abcde"
	if($rest=="0"){

	$saatfarki3= $a11*60;
	$farki2 = (date("i") - ($saatfarki3));
	$gerial2 = mktime( date("H"), $farki2, date("s"), date("m"), date("d"), date("Y"));
	$tarih2 = date("Y-m-d",$gerial2);
	$zaman2 = date("H:i:s",$gerial2);
	}
	if($rest!="0"){
	///echo "saat";
	$farki2 = (date("H") - ($saatfarki2));
	$gerial2 = mktime( $farki2 , date("i"), date("s"), date("m"), date("d"), date("Y"));
	$tarih2 = date("Y-m-d",$gerial2);
	$zaman2 = date("H:i:s",$gerial2);
	}


$kosul = $kosul. 'and db_araclar.sondegisim<=\''.$tarih2." ".$zaman2.'\'' ; $join_ek='';}//if $a11

if(($a14>' ')&&($a9!="0")&&($a15!="0")){
$kosul = $kosul. ' and db_araclar.sondegisim>=\''.$tarih." ".$a14.'\'' ; $join_ek='';}//if $a11

//	$sorgu = "select * FROM db_uyeler WHERE id>0 " . $kosul;
$ara=trim($_GET['Ara']);
if($ara=="Ara"){
$tablo2="SELECT * FROM db_araclar ".$join_ek." WHERE db_araclar.id>0 ". $kosul;
}else{
$tablo2="SELECT * FROM db_araclar ".$join_ek." WHERE db_araclar.id<0 ". $kosul;
}

if(($a1<' ')&&($a3<' ')&&($a4<' ')&&($a6<' ')&&($a5<' ')&&($a10<' ')&&($a2<' ')&&($a9=="0")&&($a15=="0")&&($a11<' ')&&($a14<' ')){
	
$tablo2="SELECT * FROM db_araclar ".$join_ek." WHERE db_araclar.id<0 ". $kosul;

}

$TABLOM22="SELECT * FROM db_araclar ".$join_ek." WHERE db_araclar.id>0 ". $kosul. " ORDER BY db_araclar.id";

$sorgu222=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu222);

if($a20!="1")
	$limit = 10;
else
	$limit = 1000;
$sayfa = mysql_real_escape_string($_GET["sayfa"]);
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
$satirsayisi = $kactane2;
$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;

$tablo3=$tablo2."ORDER BY db_araclar.id DESC LIMIT ".$baslangic. ",".$limit."";

$sorgu2=mysql_query($tablo3)or die(mysql_error());
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 

	if($xxd["UID"]=="1"){
		 $abonelik_bitisi= $xxd["abonelikbitis"];
		 $ekle_sorgu= "SELECT DATEDIFF('$abonelik_bitisi','$tarih $zaman')";
	   	 $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
	     $cikan_gun=(int)$SQL_tarih_ekle[0];	
		 $abonelik_bitmesi = convert_datetime($abonelik_bitisi);		 
		 $suan= convert_datetime("$tarih $zaman");
		 $cikan_gunA=$abonelik_bitmesi-$suan;
	}
	
	if($xxd["UID"]!="1" && $a20=="1"){
		continue;
	}else if($xxd["UID"]=="1" && $a20=="1"){
		if($cikan_gunA>15) continue;
	}
	
		
?>
            <TR>
              <TD height="33" align=middle>#<? echo $xxd[0]; ?></TD>
              <TD align=middle><? echo $xxd["plaka"];?></TD>
              <TD align=middle><?
			   if($xxd["kullaniciid"]!=''){
			   
			   echo '<img src="images/icons/user.png" width="16" height="16">';
			   
			   }else{
			   
			   echo '<img src="images/icons/user_red.png" width="16" height="16">';
			   
			   }
			   
			   ?>
                </TD>
              <TD align=middle><div align="right">
                  <?
		if($xxd["UID"]=="1"){

		 if($cikan_gunA<=0){
		 $yazdir= "G�n �nce Doldu ". '<img src="images/icons/stop.png" width="16" height="16">';
		 }
		 else if(($cikan_gunA>0)&&((int)$cikan_gunA!=0)){
		 $yazdir= "G�n Kald� ". '<img src="images/icons/tick.png" width="16" height="16">';
		 }
		 $cikan_gun = str_replace("-", "", $cikan_gun);
		 echo $cikan_gun." ".$yazdir;
		  }
		  if($xxd["UID"]!="1"){
		  echo "Abone De�il ".'<img src="images/icons/information.png" width="16" height="16">' ;
		  
		  }
		  
		  ?>
              </div></TD>
              <TD align=middle>
              <div align="center">
			  <? 
			  if($xxd["UID"]=="1"){
			  echo $xxd["abonelikbitis"];
			  }
			  if($xxd["UID"]!="1"){
			  echo "-";
			  }
			  
			  ?></div></TD>
                 <INPUT value="<? echo $xxd[0]; ?>"  type=hidden name="kamera">
              <TD align=middle>
              
              <? if(1){ ?>
           
                  <input  <? // if($xxd["UID"]!="1"){
				  if($xxd["kullaniciid"]==''){
			  echo "disabled";
			  }?>  class="button small" name="Sil2" value="Uzat" onClick="javascript:document.location.href='Arac.Guncelle.php?AUID=<? echo $xxd['id'] ?>&Islem=AbonelikUzat'" type="button" id="Sil3" />
                  <input class="button small" name="Duzenle" value="D�zenle" onClick="javascript:document.location.href='Arac.Guncelle.php?AUID=<? echo $xxd['id'] ?>'" type="button" id="Sil2" />
                  <? if($xxd["UID"]!="1") { ?>
                  <input class="button small" name="Sil" value="Sil" onClick="JavaScript:if (confirm('<b><? echo $xxd["plaka"] ?> Plakal� Arac� \nSilmek istedi�inizden emin misin?')) javascript:document.location.href='Arac.Guncelle.php?KID=<? echo $xxd['id'] ?>&Durum=Sil'" type="button" id="Sil" />
                  <? } ?>
              <? } ?>                  </TD>
            </TR>
            <? 
} //sistemler son fetch
?>
          </TBODY>
        </TABLE>

<br>
<div class="page-navigation clearfix">
<div class="wp-pagenavi">
  <div align="center">
<?
PagePrint($sayfa,$satirsayisi,$limit,"&a8=$a8&a1=$a1&a11=$a11&a13=$a13&a14=$a14&a16=$a16&a2=$a2&a3=$a3&a4=$a4&a5=$a5&a6=$a6&a7=$a7&a15=$a15&a8=$a8&a9=$a9&a20=$a20&a21=$a21&a12=$a12&a17=$a17&a10=$a10&Ara=Ara&ekle=duzenle&KID=");
?>
    
  </div>
</div>
</div>
      </FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>

<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "integer", {isRequired:false, validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "time", {isRequired:false, validateOn:["change"], format:"HH:mm:ss"});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "time", {isRequired:false, validateOn:["change"], format:"HH:mm:ss"});
//-->
</script>
		
</BODY></HTML>
