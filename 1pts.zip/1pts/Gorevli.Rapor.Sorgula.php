<?
include_once("includes/Sayfalama.Fonk.php");
include_once("Guvenlik.Filtre.php");




//*****************************************//
//**********PCC ELEKTRON�K*****************//
//********Plaka Tan�ma Sistemi*************//
//*****************************************//

//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');


$a2=trim(mysql_real_escape_string($_GET['a2']));
$a3=trim(mysql_real_escape_string($_GET['a3']));
$a4=trim(mysql_real_escape_string($_GET['a4']));
$a5=trim(mysql_real_escape_string($_GET['a5']));
$a6=trim(mysql_real_escape_string($_GET['a6']));
$a7=trim(mysql_real_escape_string($_GET['a7']));
$a9=trim(mysql_real_escape_string($_GET['a9']));
$a15=trim(mysql_real_escape_string($_GET['a15']));
$a10=trim(mysql_real_escape_string($_GET['a10']));//misafirse 1
$a12=trim(mysql_real_escape_string($_GET['a12']));//ge�iciyse 0 g�nderir
$a17=trim(mysql_real_escape_string($_GET['a17']));//ki�iselse 1 g�nderir
$a20=trim(mysql_real_escape_string($_GET['a20']));
$a21=trim(mysql_real_escape_string($_GET['a21']));

$a22=trim(mysql_real_escape_string($_GET['a22']));
$a23=trim(mysql_real_escape_string($_GET['a23']));

function permayap( $fonktmp ) {
    $returnstr = "";
    $turkcefrom = array("/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/","/�/");
    $turkceto   = array("G","U","S","I","O","C","g","u","s","i","o","c");
    $fonktmp = preg_replace("/[^0-9a-zA-Z�z������������]/"," ",$fonktmp);
    // T�rk�e harfleri ingilizceye �evir
    $fonktmp = preg_replace($turkcefrom,$turkceto,$fonktmp);
    // Birden fazla olan bo�luklar� tek bo�luk yap
    $fonktmp = preg_replace("/ +/"," ",$fonktmp);
    // Bo�uklar� - i�aretine �evir
    //$fonktmp = preg_replace("/ /","-",$fonktmp);
    // T�m beyaz karekterleri sil
    //$fonktmp = preg_replace("/\s/","",$fonktmp);
    // Karekterleri k���lt
    //$fonktmp = strtolower($fonktmp);
    // Ba�ta ve sonda - i�areti kald�ysa yoket
    $fonktmp = preg_replace("/^-/","",$fonktmp);
    $fonktmp = preg_replace("/-$/","",$fonktmp);
    $returnstr = $tmpdate . $fonktmp;
    return $returnstr;
}//sef url i�in fonksiyon 

$kosul='';
if($a2>' '){$kosul = $kosul. ' and db_loglar.plaka LIKE \'%'.$a2.'%\'' ;}
//if(($a3>' ')&&($a3!="0")){$kosul = $kosul. ' and area1 LIKE \''.$a3.'\'' ;}
//if(($a4>' ')&&($a4!="0")){$kosul = $kosul. ' and area2 LIKE \''.$a4.'\'' ;}
//if(($a5>' ')&&($a5!="0")){$kosul = $kosul. ' and area3 LIKE \''.$a5.'\'' ;}
if(($a10>' ')&&($a12!="0")&&($a17!="1")){$kosul = $kosul. ' and db_loglar.aracdurum =\''.$a10.'\'' ;}
if(($a12>' ')&&($a10!="1")&&($a17!="1")){$kosul = $kosul. ' and db_loglar.aracdurum=\''.$a12.'\'' ;}
if(($a17>' ')&&($a10!="1")&&($a12!="0")){$kosul = $kosul. ' and db_loglar.aracdurum=1' ;}
if(($a10>' ')&&($a12>' ')){$kosul = $kosul. ' and db_loglar.aracdurum=\''.$a12.'\'  or  db_loglar.aracdurum=\''.$a10.'\' '  ;}

if(($a20>' ')&&(empty($a22))) {$kosul = $kosul. ' and db_loglar.kayittarihi>= \''.$a20.' 00:00:00 \'' ;}
if(($a21>' ')&&(empty($a23))) {$kosul = $kosul. ' and db_loglar.kayittarihi<= \''.$a21.' 23:59:59 \'' ;}

if(($a20>' ')&&(!empty($a22))) {$kosul = $kosul. ' and db_loglar.kayittarihi>= \''.$a20.' '.$a22.'  \'' ;}
if(($a21>' ')&&(!empty($a23))) {$kosul = $kosul. ' and db_loglar.kayittarihi<= \''.$a21.' '.$a23.'  \'' ;}

if((empty($a20))&&(!empty($a22))) {$kosul = $kosul. ' and db_loglar.kayittarihi>= \''.$tarih.' '.$a22.'  \'' ;}
if((empty($a21))&&(!empty($a23))) {$kosul = $kosul. ' and db_loglar.kayittarihi<= \''.$tarih.' '.$a23.'  \'' ;}

		//******��eri D��ar� Durum********//
		if(($a9!="0")&&($a15!="0")){
		
			if($a9=="b")
			{			
$kosul = $kosul. ' and db_loglar.aracKonum=\''.$a15.'\' and db_loglar.soncamgrupid>="0" '  ; 			
			}
			if($a9!="b")
			{			
$kosul = $kosul. ' and db_loglar.aracKonum=\''.$a15.'\' and db_loglar.soncamgrupid=\''.$a9.'\'' ;
			}
			
		
}//if(($a9!="0")&&($a15!="0"))

$join_ek="JOIN (db_kameralar) ON ( db_loglar.kameraid = db_kameralar.kamera_ID AND db_loglar.sistemid =db_kameralar.sistem_ID)";

$TABLOM22="SELECT * FROM db_loglar ".$join_ek." WHERE db_loglar.id>0 ". $kosul. " ORDER BY db_loglar.id";
//$tablo2="SELECT * FROM db_loglar order by id desc";
//echo $TABLOM22;
$sorgu222=mysql_query($TABLOM22);
$kactane2=mysql_num_rows($sorgu222);
#sayfalama
$limit = 30;
$sayfa = mysql_real_escape_string($_GET["sayfa"]);
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
$satirsayisi = $kactane2;
$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;

$tablo21="SELECT * FROM db_loglar ".$join_ek." WHERE db_loglar.id>0 ". $kosul. "ORDER BY db_loglar.id DESC";
//echo $tablo21;
$result=mysql_query($tablo21);

$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];


$tablo = "select * from db_super_users where username='$user' and password='$sifre' and yetki='4' OR yetki='1'"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$KID=trim(mysql_real_escape_string($_GET['KID']));
$KID2=trim(mysql_real_escape_string($_POST['KID']));


$ekle=mysql_real_escape_string($_GET['ekle']);
$xls=mysql_real_escape_string($_GET['indir']);
$pdf=mysql_real_escape_string($_GET['indir2']);

$sil=mysql_real_escape_string($_GET['sil']);

$a1=trim(mysql_real_escape_string($_GET['a1']));
if($sil=="Sil"){

	$saatfarki2 = $a1; 
	$farki2 = (date("d") - ($saatfarki2));
	$gerial2 = mktime( date("H") , date("i"), date("s"), date("m"), $farki2, date("Y"));
	$tarih2 = date("Y-m-d",$gerial2);
	$zaman2 = date("H:i:s",$gerial2);
	$sorgu="DELETE FROM db_loglar WHERE kayittarihi<'$tarih2 $zaman2'";
	mysql_query($sorgu)or die(mysql_error());	
	
}


if($_GET['Temizle']=="Temizle"){

@header("Location: Gorevli.Rapor.Sorgula.php?Temizlendi");
}


if($xls=="Excel"){

					//$result=mysql_query("select * from db_loglar WHERE kayittarihi>='$ilk_zaman 00:00:00' AND kayittarihi<='$son_zaman 23:59:59' order by id desc")or die(mysql_error());
					function xlsBOF() {
					echo pack("ssssss", 0x809, 0x8, 0x0, 0x10, 0x0, 0x0);
					return;
					}
					function xlsEOF() {
					echo pack("ss", 0x0A, 0x00);
					return;
					}
					function xlsWriteNumber($Row, $Col, $Value) {
					echo pack("sssss", 0x203, 14, $Row, $Col, 0x0);
					echo pack("d", $Value);
					return;
					}
					function xlsWriteLabel($Row, $Col, $Value ) {
					$L = strlen($Value);
					echo pack("ssssss", 0x204, 8 + $L, $Row, $Col, 0x0, $L);
					echo $Value;
					return;
					}
					header("Pragma: public");
					header("Expires: 0");
					header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
					header("Content-Type: application/force-download");
					header("Content-Type: application/octet-stream");
					header("Content-Type: application/download");;
					header("Content-Disposition: attachment;filename=Arac_Raporlari_".$tarih."_".$zaman.".xls ");
					header("Content-Transfer-Encoding: binary ");
					xlsBOF();
					xlsWriteLabel(0,0,"$ilk_zaman - $son_zaman ARASI GE��� RAPORLARI ($kactane)");
					xlsWriteLabel(2,0,"ID");
					xlsWriteLabel(2,1,"Plaka");
					xlsWriteLabel(2,2,"Kayit Tarihi");
					xlsWriteLabel(2,3,"KameraID");
					xlsWriteLabel(2,4,"Ge�i� Sebebi");
					xlsWriteLabel(2,5,"Resim Yolu");
					xlsWriteLabel(2,6,"Kullan�c�");

					$xlsRow = 3;
					while($row=mysql_fetch_array($result)){

					xlsWriteNumber($xlsRow,0,$row[0]);
					xlsWriteLabel($xlsRow,1,$row[1]);
					xlsWriteLabel($xlsRow,2,$row[2]);
					xlsWriteNumber($xlsRow,3,$row[3]);
					xlsWriteLabel($xlsRow,4,$row[4]);
					xlsWriteLabel($xlsRow,5,$row[5]);
					xlsWriteLabel($xlsRow,6,$row[6]);

					$xlsRow++;
					}

					xlsEOF();
					exit();

}
					if($pdf=="PDF"){
					require_once('tcpdf/config/lang/eng.php');
					require_once('tcpdf/tcpdf.php');
					require_once('includes/veritabani.php');


					/*function permayap($deger) {
					$turkce=array("�","�","�","(",")","'","�","�","�","�","�","�"," ","/","*","?","�","�","�","�","�","�","�","�","�","�","�","�");
					$duzgun=array("s","S","i","","","","u","U","o","O","c","C"," ","-","-","","s","S","i","g","G","I","o","O","C","c","u","U");
					$deger=str_replace($turkce,$duzgun,$deger);
					return $deger;
					}*/

					$pdf = new TCPDF("P", "mm", "A4", true, 'UTF-8', false); 
					$pdf->SetCreator(PDF_CREATOR);
					$pdf->SetAuthor('localhost/');
					$pdf->SetTitle('PTS ARA� GE�IS KONTROLLERI');
					$pdf->SetSubject('http://www.noron.com.tr');
					$pdf->SetHeaderData("../../images/3deyesPTSlogoSITE.png", 22, permayap($ttt[2]), permayap($ttt[1]));
					$pdf->setHeaderFont(Array('helvetica', '', 10));
					$pdf->setFooterFont(Array('times', '', 8));
					$pdf->SetMargins(15, 20, 5); 
					$pdf->SetHeaderMargin(10);
					$pdf->SetFooterMargin(10); 
					$pdf->SetAutoPageBreak(TRUE,0);
					$pdf->setLanguageArray($l); 
					$pdf->SetFont('freemonoi', '', 8);
					$pdf->AddPage();
					$pdf->SetLineStyle(array('width'=>0.1,'color' => array( 255,255, 255,255)));
					$pdf->SetCellPadding(1);
					//$result=mysql_query("select * from db_loglar WHERE kayittarihi>='$ilk_zaman 00:00:00' AND kayittarihi<='$son_zaman 23:59:59' order by id desc")or die(mysql_error());
					$pdf->SetFont('times', 'BU', 8);
					$pdf->MultiCell(10, 1, 'ID', 0, "L", 0,0,15, 20, true, 0, true, true );
					$pdf->MultiCell(15, 1, 'Plaka', 0, "C", 0,0,30, 20, true, 0, true, true );
					$pdf->MultiCell(38, 1, 'Tarih', 0, "C", 0,0,50, 20, true, 0, true, true );
					$pdf->MultiCell(18, 1, 'KameraID', 0, "R", 0,0,85, 20, true, 0, true, true );
					$pdf->MultiCell(18, 1, 'Not', 0, "L", 0,0,110, 20, true, 0, true, true );
					$pdf->MultiCell(38, 1, 'Kullanici', 0, "R", 0,0,155, 20, true, 0, true, true );
					$a=20;
					$sayac=0;
					while($row=mysql_fetch_array($result)){
					$sayac++;
					$a=$a+10;
					$kullanici=$row[6];
					$sebep=$row[4];
					/*$kullanici =maketr($kullanici);
					$sebep=maketr($sebep);
					*/
					$pdf->SetFont('freemonoi', '', 8);
					$sebep=str_replace(';','',$sebep);
					$pdf->MultiCell(10, 1, "$sayac", 0, "L", 0,0,15, $a, true, 0, true, true );
					$pdf->MultiCell(15, 1, "".permayap($row[1])."", 0, "C", 0,0,30, $a, true, 0, true, true );
					$pdf->MultiCell(38, 1, "".$row[2]."", 0, "C", 0,0,50, $a, true, 0, true, true );
					$pdf->MultiCell(18, 1, "".permayap($row[3])."", 0, "C", 0,0,85, $a, true, 0, true, true );
					$pdf->MultiCell(50, 1, "".permayap($sebep)."", 0, "L", 0,0,110, $a, true, 0, true, true );
					$pdf->MultiCell(38, 1, "".permayap($kullanici)."", 0, "R", 0,1,155, $a, true, 0, true, true );
					//echo maketr($sebep);

					if($a==260){

					$a=30;
					$pdf->AddPage();
					$pdf->SetFont('times', 'BU', 8);

					$pdf->MultiCell(10, 1, 'ID', 0, "L", 0,0,15, 30, true, 0, true, true );
					$pdf->MultiCell(15, 1, 'Plaka', 0, "C", 0,0,30, 30, true, 0, true, true );
					$pdf->MultiCell(38, 1, 'Tarih', 0, "C", 0,0,50, 30, true, 0, true, true );
					$pdf->MultiCell(18, 1, 'KameraID', 0, "R", 0,0,85, 30, true, 0, true, true );
					$pdf->MultiCell(18, 1, 'Not', 0, "L", 0,0,110, 30, true, 0, true, true );
					$pdf->MultiCell(38, 1, 'Kullanici', 0, "R", 0,0,155, 30, true, 0, true, true );
					}
					}
					$pdf->Output("Arac_Sorgulama_".$tarih."_".$zaman.".pdf", 'I');
}


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>
  <link rel="STYLESHEET" type="text/css" href="takvim/codebase/dhtmlxcalendar.css">
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery.maskedinput-1.2.2.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script>
jQuery(function($){
   $("#a22").mask("99:99:99");
   $("#a23").mask("99:99:99");
});
</script>
<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
	<script type="text/javascript" src="jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="fancybox/jquery.fancybox-1.2.6.css" media="screen" />
	<script type="text/javascript" src="fancybox/jquery.fancybox-1.2.6.pack.js"></script>
	

<script type="text/javascript">
		$(document).ready(function() {
			$("a.zoom").fancybox();

			$("a.zoom1").fancybox({
				'overlayOpacity'	:	0.7,
				'overlayColor'		:	'#FFF'
			});

			$("a.zoom2").fancybox({
				'zoomSpeedIn'		:	300,
				'zoomSpeedOut'		:	300
			});
		});
	</script>
<script>
      window.dhx_globalImgPath="../../codebase/imgs/";
</script>
<script  src="takvim/codebase/dhtmlxcommon.js"></script>
<script  src="takvim/codebase/dhtmlxcalendar.js"></script>

	<script>
	var cal1, cal2, mCal, mDCal, newStyleSheet;

	var dateFrom = null;
	var dateTo = null;
	
	window.onload = function () {
		cal1 = new dhtmlxCalendarObject('calInput1');
	    cal1 = new dhtmlxCalendarObject('calInput2');
	}
	
	

	
	
</script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">

<style type="text/css">
<!--
.style1 {color: #CC0000}
-->
</style>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY>
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=796 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD width="160" vAlign=top class=sol><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=632>
      <FORM method=get name=misafirtanimla action=Gorevli.Rapor.Sorgula.php>
      <!--<TABLE class=ictablo width=570>
        <TBODY>
           <? if($durum!=4){ ?>
          <TR>
            <TD style="COLOR: red" align=middle></TD>
          </TR>
          <TR> 
            <TD width="87%">
          
            <span id="sprytextfield5">
            <input name=a1  id="a1" size="10" maxlength="10">
            <span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg">[G�n Belirtiniz].</span></span><span class="textfieldRequiredMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span><span class="textfieldInvalidFormatMsg"><img src="images/icons/exclamation.png" width="16" height="16"></span> G�nden daha eski raporlar� temizle.(Not: Geri d�n��� m�mk�n de�ildir)
            <input class=button value=Sil type=submit name=sil id="sil"
            > </TD>
          </TR><? } ?>
</TBODY>
        <TBODY>
        </TBODY>
      </TABLE>-->
      <TABLE class=ictablo width=594>
        <TBODY>
          <TR>
            <TH colSpan=2> Kay�t Arama</TH>
          </TR>
          <TR>
            <TD style="COLOR: red" colSpan=2 align=middle></TD>
          </TR>
          <TR>
            <TD width="40%" align=right>Plaka:</TD>
            <TD><INPUT name=a2 value="<? echo $a2; ?>" class=text_input id="a2"></TD>
          </TR>
          <TR>
            <TD align=right class="style1">Giri� ��k�� Pozisyonuna G�re Arama:</TD>
            <TD><SELECT  name=a9 size="1" id=a10>
                <option value="0">L�tfen Se�iniz</option>
                <?
			$sorgula=mysql_query("SELECT * FROM db_camgrup ORDER BY id");
			while($sistem=mysql_fetch_array($sorgula)){
			  ?>
                <option <? if($a9==$sistem[0]){echo'selected';} ?> value="<? echo $sistem[0]; ?>"><? echo $sistem[1]; ?></option>
                <? } //while sorgul ?>
                <option value="b" <? if($a9=="b"){echo'selected';} ?>>Herhangi Bir Sistem</option>
              </SELECT>
                <span class="style1">Hareket:</span>
                <select  name=a15 size="1" id=a15>
                  <option value="0" >Se&ccedil;iniz </option>
                  <option  value="i" <? if($a15=="i"){echo'selected';} ?> >Girmi�</option>
                  <option value="d" <? if($a15=="d"){echo'selected';} ?> >��km��</option>
                </select>            </TD>
          </TR>
          <!--<TR>
            <TD align=right>Sadece Abone Ara�lar� G�ster:</TD>
            <TD><input name="a10" type="checkbox" <? if($a10=="2"){echo"checked";} ?> id="a11" value="2"></TD>
          </TR>-->

          <TR>
            <TD align=right>Rapor Tarih Aral��� Belirle: </TD>
            <TD><input name=a20 id="calInput1" value="<? echo $a20; ?>"  readonly="true"  size="20" maxlength="30"> 
              ile 
                <input name=a21 id="calInput2"  readonly="true"  value="<? echo $a21; ?>" size="20" maxlength="30"> 
                aras�</TD>
          </TR>
          <TR>
            <TD align=right>Saat Aral��� Belirle:</TD>
            <TD><span id="sprytextfield1">
              <input name=a22 id="a22" value="<? echo $a22; ?>"   size="20" maxlength="30">
              <span class="textfieldInvalidFormatMsg">Hatal� Format</span>              </span>
ile
  <span id="sprytextfield2">
  <input name=a23 id="a23" value="<? echo $a23; ?>"  size="20" maxlength="30">
  <span class="textfieldInvalidFormatMsg">Hatal� Format</span></span>
aras�</TD>
          </TR>
          <TR>
            <TD width="40%" align=right></TD>
            <TD><INPUT class=button value=Ara type=submit name=Ara> 
              <INPUT class=button value=Temizle type=submit name=Temizle id="Temizle"> <INPUT name=indir type=submit class=button id="indir" value=Excel �ndir>
              <INPUT name=indir2 type=submit class=button id="indir2" value=PDF �ndir></TD>
          </TR>
</TBODY>
        <TBODY>
        </TBODY>
      </TABLE>
      <p>
        <INPUT 
      type="hidden" name="ekle" value="duzenle">
        <INPUT 
      type="hidden" name="KID" value="<? echo $KID; ?>">
      </p>
      <H2>Bulunan Kay�tlar</H2>
        <TABLE class=ictablo width=605>
          <TBODY>
            <TR>
              <TH width="30">#ID</TH>
              <TH width="73">Plaka</TH>
              <TH width="109">Kay�t Tarihi <br></TH>
              <TH width="70">Kamera Id</TH>
              <TH width="116">A��klama</TH>
              <TH width="99">Durum</TH>
              <TH width="76">K&uuml;&ccedil;&uuml;k Resim</TH>
              </TR>
            
<?
$a2=trim(mysql_real_escape_string($_GET['a2']));
$a3=trim(mysql_real_escape_string($_GET['a3']));
$a4=trim(mysql_real_escape_string($_GET['a4']));
$a5=trim(mysql_real_escape_string($_GET['a5']));
$a6=trim(mysql_real_escape_string($_GET['a6']));
$a7=trim(mysql_real_escape_string($_GET['a7']));
$a9=trim(mysql_real_escape_string($_GET['a9']));
$a15=trim(mysql_real_escape_string($_GET['a15']));
$a10=trim(mysql_real_escape_string($_GET['a10']));//misafirse 1
$a12=trim(mysql_real_escape_string($_GET['a12']));//ge�iciyse 0 g�nderir
$a17=trim(mysql_real_escape_string($_GET['a17']));//ki�iselse 1 g�nderir
$a20=trim(mysql_real_escape_string($_GET['a20']));
$a21=trim(mysql_real_escape_string($_GET['a21']));
$a22=trim(mysql_real_escape_string($_GET['a22']));
$a23=trim(mysql_real_escape_string($_GET['a23']));





$kosul='';
if($a2>' '){$kosul = $kosul. ' and db_loglar.plaka LIKE \'%'.$a2.'%\'' ;}
//if(($a3>' ')&&($a3!="0")){$kosul = $kosul. ' and area1 LIKE \''.$a3.'\'' ;}
//if(($a4>' ')&&($a4!="0")){$kosul = $kosul. ' and area2 LIKE \''.$a4.'\'' ;}
//if(($a5>' ')&&($a5!="0")){$kosul = $kosul. ' and area3 LIKE \''.$a5.'\'' ;}
/*if($a6!="0"){$kosul = $kosul. ' and db_loglar.area1 = \''.$a6.'\'' ;}
if($a7!="0"){$kosul = $kosul. ' and db_loglar.area2 = \''.$a7.'\'' ;}
if($a8!="0"){$kosul = $kosul. ' and db_loglar.area3 =\''.$a8.'\'' ;}
*/
if(($a10>' ')&&($a12!="0")&&($a17!="1")){$kosul = $kosul. ' and db_loglar.aracdurum =\''.$a10.'\'' ;}
if(($a12>' ')&&($a10!="1")&&($a17!="1")){$kosul = $kosul. ' and db_loglar.aracdurum=\''.$a12.'\'' ;}
if(($a17>' ')&&($a10!="1")&&($a12!="0")){$kosul = $kosul. ' and db_loglar.aracdurum=1' ;}
///if(($a10>' ')&&($a12>' ')){$kosul = $kosul. ' and db_loglar.aracdurum=\''.$a12.'\'  or  db_loglar.aracdurum=\''.$a10.'\' '  ;}
if(($a20>' ')&&(empty($a22))) {$kosul = $kosul. ' and db_loglar.kayittarihi>= \''.$a20.' 00:00:00 \'' ;}
if(($a21>' ')&&(empty($a23))) {$kosul = $kosul. ' and db_loglar.kayittarihi<= \''.$a21.' 23:59:59 \'' ;}

if(($a20>' ')&&(!empty($a22))) {$kosul = $kosul. ' and db_loglar.kayittarihi>= \''.$a20.' '.$a22.'  \'' ;}
if(($a21>' ')&&(!empty($a23))) {$kosul = $kosul. ' and db_loglar.kayittarihi<= \''.$a21.' '.$a23.'  \'' ;}

if((empty($a20))&&(!empty($a22))) {$kosul = $kosul. ' and db_loglar.kayittarihi>= \''.$tarih.' '.$a22.'  \'' ;}
if((empty($a21))&&(!empty($a23))) {$kosul = $kosul. ' and db_loglar.kayittarihi<= \''.$tarih.' '.$a23.'  \'' ;}

		//******��eri D��ar� Durum********//
		if(($a9!="0")&&($a15!="0")){
		
			if($a9=="b")
			{			
$kosul = $kosul. ' and db_loglar.aracKonum=\''.$a15.'\' and db_loglar.soncamgrupid>="0" '  ; 			
			}
			if($a9!="b")
			{			
$kosul = $kosul. ' and db_loglar.aracKonum=\''.$a15.'\' and db_loglar.soncamgrupid=\''.$a9.'\'' ;
			}
			
		
}//if(($a9!="0")&&($a15!="0"))

$join_ek="JOIN (db_kameralar) ON ( db_loglar.kameraid = db_kameralar.kamera_ID AND db_loglar.sistemid =db_kameralar.sistem_ID)";

$TABLOM22="SELECT * FROM db_loglar ".$join_ek." WHERE db_loglar.id>0 ". $kosul. " ORDER BY db_loglar.id";
//$tablo2="SELECT * FROM db_loglar order by id desc";
//echo $TABLOM22;
$sorgu222=mysql_query($TABLOM22);
$kactane2=mysql_num_rows($sorgu222);
#sayfalama
$limit = 10;
$sayfa = mysql_real_escape_string($_GET["sayfa"]);
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
$satirsayisi = $kactane2;
$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;

$tablo21="SELECT * FROM db_loglar ".$join_ek." WHERE db_loglar.id>0 ". $kosul. "ORDER BY db_loglar.id DESC LIMIT ".$baslangic."," .$limit."";
$sorgu21=mysql_query($tablo21);

while($xxd=mysql_fetch_array($sorgu21)){ 


	
?>
            
            
            <TR>
              <TD align=middle>#<? echo $xxd[0]; ?></TD>
              <TD align=middle><? echo $xxd[1];  ?></TD>
              <TD align=middle><? echo $xxd[2];  ?></TD>
              <TD align=middle><? 
			  $camid= $xxd[3];  $sistemimid= $xxd[15]; 
			  echo $camid;
			  $kamera_bilgi=mysql_fetch_array(mysql_query("SELECT * FROM db_kameralar where kamera_ID='$camid'"));
			  if($kamera_bilgi[5]=="g")
			  {
			  echo "<br>(��k�� Yap�ld�)";
			  }
			  if($kamera_bilgi[5]=="c")
			  {
			  echo "<br>(Giri� Yap�ld�)";
			  }
			   ?></TD>
              <TD align=middle>
                
                <?
			echo $xxd[4];

				?>                </TD>
              <TD align=middle><? //echo $xxd[11];
			  
			  if($xxd[11]=="0"){echo "-";};
			  if($xxd[11]=="1"){echo "Kay�tl�";};
			  if($xxd[11]=="2"){echo "-";};
			   ?></TD>
              <TD align=middle>
                <? 
	$camid= $xxd[3]; 
	$sorsor="SELECT * FROM db_kameralar WHERE kamera_ID='$camid' AND sistem_ID='$sistemimid' LIMIT 1";
	//echo $sorsor;
	$cam_sistem_bilgisi=mysql_fetch_row(mysql_query($sorsor));

	$sistem_bilgisi=mysql_fetch_array(mysql_query("SELECT * FROM db_sistemler WHERE sistemadi='".$cam_sistem_bilgisi[2]."'"));
	//echo $sistem_bilgisi[3];
	//Resim yolunu al
	//$resim_yol="E://Resimler/";
	$tt=mysql_fetch_array(mysql_query("SELECT * FROM db_ayarlar WHERE id='1'"));
	$resim_yol=$sistem_bilgisi[3];
	$resim=strstr($xxd[5], '_');
	$resim = str_replace("_", "", $resim);


	$yil = substr($resim, 0, 4); 
	$ay = substr($resim, 4, 2);  
	$gun = substr($resim, 6, 2); 

	/*echo $yil." ".$ay." ".$gun;
	echo "<br>";
	echo $resim;
	*/
	$resim_yol=$resim_yol.$yil."/".$ay."/".$gun."/";

	
			  
			  ?>
                <a class="zoom2" title="<? echo $xxd[1];  ?>" href="Resim.Goster.php?w=700&img=<? echo $resim_yol; ?><? echo $xxd[5];  ?>"> <img src="Resim.Goster.php?w=40&img=<? echo $resim_yol; ?><? echo $xxd[5];  ?>" width="40" height="40" border="0" \></a>                </TD>
              </TR>
            
  <? 
} //sistemler son fetch
?>
            </TBODY>
        </TABLE>

 <br>
<div class="page-navigation clearfix">
<div class="wp-pagenavi">
  <div align="center">
<?
PagePrint($sayfa,$satirsayisi,$limit,"&a8=$a8&a2=$a2&a3=$a3&a4=$a4&a5=$a5&a6=$a6&a7=$a7&a15=$a15&a8=$a8&a9=$a9&a20=$a20&a21=$a21&a12=$a12&a17=$a17&a10=$a10&Ara=Ara&ekle=duzenle&KID=");
?>
  </div>
</div>
</div>
  <span class="inputara">Bulununan Kay�tlar: <? echo (int)$satirsayisi; ?>      </span>
      </FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>

<script type="text/javascript">
<!--
var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5", "integer", {validateOn:["change"]});
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "time", {isRequired:false, format:"HH:mm:ss"});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "time", {format:"HH:mm:ss", isRequired:false});
//-->
</script>
</BODY></HTML>

