<?
@session_start();
include_once("Guvenlik.Filtre.php");


//*****************************************//
//*****************************************//
function convert_datetime($str) {

list($date, $time) = explode(' ', $str);
list($year, $month, $day) = explode('-', $date);
list($hour, $minute, $second) = explode(':', $time);

$timestamp = mktime($hour, $minute, $second, $month, $day, $year);

return $timestamp;
}
//zaman ayarlar�
$saatfarki = "0"; 
$farki = (date("H") + ($saatfarki));
$gerial = mktime( $farki , date("i"), date("s"), date("m"), date("d"), date("Y"));
$tarih = date("Y-m-d",$gerial);
$zaman = date("H:i:s",$gerial);
//

require_once('includes/veritabani.php');


$user = $HTTP_COOKIE_VARS["akullaniciadi"];
$sifre = $HTTP_COOKIE_VARS["asifre"];
$idm = $HTTP_COOKIE_VARS["aid"];
$durum =  $HTTP_COOKIE_VARS["adurum"];

$tablo = "select * from db_super_users where username='$user' and password='$sifre' and (yetki='1' or yetki='4')"; //sistem y�neticisi
//echo $tablo;
$sorgu= mysql_query($tablo);
$tt=mysql_fetch_array($sorgu);
if (@mysql_num_rows($sorgu) < 1 ) {
@header("Location: index.php?HID=2"); //COOK�E timeout olmu�sa geriye g�nder
}

$KUID=trim(mysql_real_escape_string($_GET['KUID']));
$sonucum=trim(mysql_real_escape_string($_GET['Sonuc']));
$arac_sahip_bilgi=mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='$KUID'"));
$varmidir=mysql_num_rows(mysql_query("SELECT * FROM db_musteriler WHERE id='$KUID'"));
$ekle=mysql_real_escape_string($_POST['ekle']);
$a1=trim(mysql_real_escape_string(strtoupper($_POST['a1'])));
$a1 = str_replace(" ","",$a1);
$a2=trim(mysql_real_escape_string($_POST['a2']));
$a3=trim(mysql_real_escape_string($_POST['a3']));
$a4=trim(mysql_real_escape_string($_POST['a4']));
$a5=trim(mysql_real_escape_string($_POST['a5']));
$a6=trim(mysql_real_escape_string($_POST['a6']));
$asure=trim(mysql_real_escape_string($_POST['asure']));
$KUID2=trim(mysql_real_escape_string($_POST['KUID']));
$gonder=trim(mysql_real_escape_string($_POST['gonder']));


$limit = 10;
$sayfa = $_GET["sayfa"];
if(($sayfa=="") or !is_numeric($sayfa)){
 	 $sayfa=1; }
$satirsayisi = mysql_num_rows(mysql_query("SELECT * FROM db_araclar WHERE kullaniciid='$KUID' and geciciarac!='1'"));
$toplamsayfa = ceil($satirsayisi / $limit);
$baslangic= ($sayfa-1) * $limit;
$toplam_ucretim=0;
if($gonder=="G�nder")
{
	$box=$_POST['aracid'];
    
    if (sizeof($box)>1) 
    {
        echo("L�TFEN SADECE 1 TANE ARA� SE��M� YAPINIZ...");
        exit();
    }    
	$birim_arac_ucreti=mysql_fetch_array(mysql_query("SELECT * FROM db_abonelikturleri WHERE id='$asure'"));
	$a2_2=$birim_arac_ucreti[2];
	$birim_ucretim=$birim_arac_ucreti[3]; //TL cinsinden fiyat d�ner
	//echo $birim_ucretim;
	//echo $a2;
	switch ($a2) {
    case 'u':
        while (list ($key,$val) = @each ($box)) {
		
						 ###########UCRET �IKAR###################
						 $toplam_ucretim=$toplam_ucretim+$birim_ucretim;
						 #########################################
		
						 $arac_bilgi=mysql_fetch_array(mysql_query("SELECT * FROM db_araclar WHERE id='$val'"));
			        	 $sahipid=$arac_bilgi["kullaniciid"];
						 $sahibi_kim_ki=@mysql_fetch_array(mysql_query("SELECT * FROM db_musteriler WHERE id='$sahipid'"));
						 $abonelik_bitisi2= $arac_bilgi["abonelikbitis"];
						 $ekle_sorgu2= "SELECT TIMEDIFF('$abonelik_bitisi2','$tarih $zaman')";
						 $SQL_tarih_ekle2=mysql_fetch_array(mysql_query($ekle_sorgu2));
						 $cikan_saat=(int)$SQL_tarih_ekle2[0];
						 $cikan_saat;
						 if($cikan_saat<0)  ##abonelik s�resi bitmi�
						 {
						 $x=1;
						 $ekle_sorgu3="SELECT ADDDATE( '$tarih $zaman', INTERVAL ".$asure." DAY )";
						 $SQL_tarih_ekle3=mysql_fetch_array(mysql_query($ekle_sorgu3));
						 $cikan_gun3=$SQL_tarih_ekle3[0];
						 mysql_query("UPDATE `db_araclar` SET `abonelikbitis` = '$cikan_gun3', UID='1' WHERE `db_araclar`.`id` ='$val' LIMIT 1 ")or die(mysql_error());
				
						 }
						 else if($cikan_saat=="0")  ##abonelik s�resi bitmi�
						 {
						 $x=2;
						 $ekle_sorgu4="SELECT ADDDATE(NOW(), INTERVAL ".$a2_2." DAY )";
						 $SQL_tarih_ekle4=mysql_fetch_array(mysql_query($ekle_sorgu4));
						 $cikan_gun3=$SQL_tarih_ekle4[0];
						 $yap_ulan="UPDATE `db_araclar` SET `abonelikbitis` = '$cikan_gun3', UID='1' WHERE `db_araclar`.`id` ='$val'";
						// echo $yap_ulan;
						 mysql_query($yap_ulan)or die(mysql_error());
				
						 }
						 else if($cikan_saat>0)  ##hala aboneli�i var
						 {
						 $x=3;
						 $ekle_sorgu3="SELECT ADDDATE( '$abonelik_bitisi2', INTERVAL ".$a2_2." DAY )";
						 $SQL_tarih_ekle3=mysql_fetch_array(mysql_query($ekle_sorgu3));
						 $cikan_gun3=$SQL_tarih_ekle3[0];
						 mysql_query("UPDATE `db_araclar` SET `abonelikbitis` = '$cikan_gun3', UID='1' WHERE `db_araclar`.`id` ='$val' LIMIT 1 ")or die(mysql_error());
						
						 }
						 @mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$val NOlu Ara� Abonelik s�resi $a2_2 g�n Uzat�ld�:  $cikan_gun3', NOW(),'$user')");
		
		###ucreti yans�t####
		//mysql_query("INSERT INTO `db_ucret_test` (`id` ,`ucret`)VALUES (NULL , '$toplam_ucretim')")or die(mysql_error());

		}
$toplam_ucretim=$toplam_ucretim-$toplam_ucretim*$sahibi_kim_ki['uyeindirim'];
if($toplam_ucretim>0){
    
$aracPlaka = $arac_bilgi["plaka"];
$operatorid = $idm;

mysql_query("INSERT INTO `db_odemeler` (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status` , `plaka` , `abonesure` , `operatorid`)VALUES (NULL , '$sahipid', '$toplam_ucretim','0',NOW(),'', '$aracPlaka' ,$a2_2 , $operatorid)"); 
$iddd=mysql_insert_id();
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$iddd NOlu $toplam_ucretim TL\'lik �cret bilgisi olu�turuldu', NOW(),'$user')")or die(mysql_error());
}
        break;
    case 's':
        while (list ($key,$val) = @each ($box)) {
		mysql_query("UPDATE `db_araclar` SET `abonelikbitis` = NOW() WHERE `db_araclar`.`id` =$val LIMIT 1");
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$val NOlu ara� abonelik s�resi bitirildi', NOW(),'$user')");
		} 
        break;
    case 'a':
        while (list ($key,$val) = @each ($box)) {
		mysql_query("UPDATE `db_araclar` SET `UID` = '' WHERE `db_araclar`.`id` =$val LIMIT 1");
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$val NOlu ara� aboneli�i ask�ya al�nd�', NOW(),'$user')");
		} 
        break;
	case 'aa':
        while (list ($key,$val) = @each ($box)) {
		//echo "$val,";
		mysql_query("UPDATE `db_araclar` SET `UID` = '1' WHERE `db_araclar`.`id` =$val LIMIT 1");
@mysql_query("INSERT INTO `db_yonetimlog` (`id` ,`olay` ,`eklenme`,`kullanici`)VALUES (NULL , '$val NOlu ara� aboneli�i aktif edildi', NOW(),'$user')");

		} 
        break;
}
	
	
	//echo $a2;

}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><? echo $ttt[1]; ?></TITLE>
<META content="text/html; charset=iso-8859-9" http-equiv=Content-Type>
<LINK rel=stylesheet type=text/css href="stil.css"><LINK rel=stylesheet type=text/css href="stil.css">
<SCRIPT language=JavaScript 
src="controls.js"></SCRIPT>

<SCRIPT language=JavaScript type=text/javascript 
src="ajax.js"></SCRIPT>
<script language="JavaScript" type="text/javascript">
function HepsiniSec(divId)
{
var elmnts = document.getElementById(divId)
.getElementsByTagName('input');
for (var i = 0; i < elmnts.length; i++)
{
if (elmnts[i].id.indexOf('chkl') == 0)
{
if (elmnts[i].checked == false)
{
elmnts[i].checked = true;
}
}
}
}

function Temizle(divId)
{
var elmnts = document.getElementById(divId)
.getElementsByTagName('input');
for (var i = 0; i < elmnts.length; i++)
{
if (elmnts[i].id.indexOf('chkl') == 0)
{
if (elmnts[i].checked == true)
{
elmnts[i].checked = false;
}
}
}
}
</script>
             <script>
function Secimyap(secim)
{
 
if(secim == 'u')
{
	document.getElementById("asure").disabled=false;
}else{
	document.getElementById("asure").disabled=true;

}
}
</script>
<META name=GENERATOR content="MSHTML 8.00.7600.16466">
</HEAD>
<BODY >
<H1><? echo $ttt[1]; ?></H1>
<TABLE class=maintable border=0 width=800 align=center>
 <? include_once("includes/inc_ust.php"); ?>
  <TBODY>
  <TR>
    <TD class=sol vAlign=top><? include_once("includes/inc_yan.php"); ?></TD>
    <TD 
    style="PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; PADDING-TOP: 10px" 
    vAlign=top width=580><div align="center"><span class="solmenu">
	<?
	if($sonucum=="AracEklendi"){echo "<img src='images/icons/accept.png' width='16' height='16'> Ara� Eklendi!<br>";}
    if($sonucum=="AracOncedenEklenmis"){echo "<img src='images/icons/exclamation.png' width='16' height='16'> Bu Ara� �nceden Eklenmi�!<br>";}
 	$kontrol_odeme_plani=mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM db_odemeler WHERE db_odemeler.kullaniciid='$KUID' AND db_odemeler.borc>db_odemeler.odenen ORDER by id desc"));
	if($kontrol_odeme_plani[0]>0){
	echo "<img src='images/icons/exclamation.png' width='16' height='16'> <a href='Kullanici.Odeme.Goster.php?KUID=$KUID'>Bu kullan�c�ya ait $kontrol_odeme_plani[0] �denmemi� fatura bulunmaktad�r!</a><br>";
	}
	?>
    </span></div>
<FORM method=post name="form1"  action=<? $_GET['PHP_SELF']; ?>>
  <INPUT 
      type="hidden" name="ekle" value="duzenle">
  <INPUT 
      type="hidden" name="KUID" value="<? echo $KUID; ?>">
  <!----------------------><!------------->

  <H2>Varolan Ara&ccedil;lar</H2>
  <div id="checkBoxListesi">
  <TABLE class=ictablo width=592>
    <TBODY>
      <TR>
        <TH width="21"><p>&nbsp;</p></TH>
        <TH width="58"><div align="left">#ID</div></TH>
        <TH width="60">Plaka</TH>
        <TH width="90">Abonelik Durumu</TH>
        <TH width="110">Abonelik Biti�i</TH>
        <TH width="152">��lemler</TH>
        </TR>
      
  <?
$tablo2="SELECT * FROM db_araclar WHERE kullaniciid='$KUID' order by id desc ";
$sorgu2=mysql_query($tablo2);
$kactane2=mysql_num_rows($sorgu2);
while($xxd=mysql_fetch_array($sorgu2)){ 
?>
      
      
      <TR>
        <TD align=middle><label>
          <input type="checkbox"  name="aracid[]" value="<? echo $xxd[0]; ?>"  id="chkl_<? echo $xxd[0]; ?>">
          </label></TD>
        <TD align=middle><div align="left">#<? echo $xxd[0]; ?></div></TD>
        <TD align=middle><? echo $xxd["plaka"];
			  
			  ?></TD>
        <TD align=middle>
          <div align="right">
            <?
		
	if($xxd["UID"]=="1"){
		
		 $abonelik_bitisi= $xxd["abonelikbitis"];		
		 $ekle_sorgu= "SELECT DATEDIFF('$abonelik_bitisi','$tarih $zaman')";
	   	 $SQL_tarih_ekle=mysql_fetch_array(mysql_query($ekle_sorgu));
	     $cikan_gun=(int)$SQL_tarih_ekle[0];	
		 $abonelik_bitmesi = convert_datetime($abonelik_bitisi);		 
		 $suan= convert_datetime("$tarih $zaman");
		 $cikan_gunA=$abonelik_bitmesi-$suan;

		 if($cikan_gunA<=0){
		 $yazdir= "G�n �nce Doldu ". '<img src="images/icons/stop.png" width="16" height="16">';
		 }
		 else if(($cikan_gunA>0)&&((int)$cikan_gunA!=0)){
		 $yazdir= "G�n Kald� ". '<img src="images/icons/tick.png" width="16" height="16">';
		 }
		 $cikan_gun = str_replace("-", "", $cikan_gun);
		 echo $cikan_gun." ".$yazdir;
		
		}
		
		if($xxd["UID"]!="1"){
		
		echo "Abone De�il ".'<img src="images/icons/information.png" width="16" height="16">' ;
		
		}
		  ?>
            </div></TD>
        <TD align=middle><div align="center"><? echo $xxd["abonelikbitis"];?></div></TD>
        <TD align=middle><input  <? if($xxd["UID"]!="1"){
			  echo "disabled";
			  }?>  class="button small" name="Sil2" value="Uzat" onClick="javascript:document.location.href='Arac.Guncelle.php?AUID=<? echo $xxd['id'] ?>&Islem=AbonelikUzat'" type="button" id="Sil3" />
          <input class="button small" name="Duzenle" value="D�zenle" onClick="javascript:document.location.href='Arac.Guncelle.php?AUID=<? echo $xxd['id'] ?>'" type="button" id="Sil" />
          <input class="button small" name="Degistir" value="Abonelik" onClick="javascript:document.location.href='Arac.Abonelik.Bitis.php?AUID=<? echo $xxd['id'] ?>&Islem=AbonelikUzat'" type="button" id="Sil3" />
          <input class="button small" name="Sil" value="Sil" onClick="JavaScript:if (confirm('Silmek istedi�inizden emin misin?')) javascript:document.location.href='Arac.Guncelle.php?KID=<? echo $xxd['id'] ?>&Durum=Sil'" type="button" id="Sil" />
          <!--<input class="button small" name="Yasakla" value="Yasakla" onClick="javascript:document.location.href='Blacklist.Duzenle.php?PID=<? echo $xxd['plaka'] ?>&Durum=Yasakla'" type="button" id="Sil2" />-->          </TD>
        </TR>
      
  <? 
} //sistemler son fetch
?>


      </TBODY>
    </TABLE>
  </div>
  <? if ($durum==1)
    {?>

          <p class="inputara"><a href="#" onClick="HepsiniSec('checkBoxListesi')">Hepsini Se�</a> | <a href="#" onClick="Temizle('checkBoxListesi')">Temizle</a></p>
          <TABLE width=586 height="33" class=ictablo>
            <TBODY>

           
              <TR>
                <TD width="92" height="27" align=middle><strong>Se�ili Ara�lar�n:</strong></TD>
                <TD width="411" align=middle><div align="left">
                <script>
function Secimyap(secim)
{
 
if(secim == 'u')
{
	document.getElementById("asure").disabled=false;
}else{
	document.getElementById("asure").disabled=true;

}
}
</script>

                  <select id="secim" onChange="Secimyap(this.value)"  name=a2>
                  <option value="a">Aboneliklerini Ask�ya Al</option>
                  <option value="aa">Aboneliklerini Aktif Et</option>
                  <option value="s">Abonelik S�relerini Sona Erdir</option>
                  <option value="u">Abonelik S�resini Uzat</option>
                  </select>
                  <select id=asure  name=asure disabled>
                    <?
			$sorgula=mysql_query("SELECT * FROM db_abonelikturleri ORDER BY id");
			while($sistem=mysql_fetch_array($sorgula)){
			  ?>
                    <option value="<? echo $sistem[0]; ?>"><? echo $sistem[1]."  (".$sistem[2].")"; ?> </option>
                    <? } //while sorgul ?>
                  </select>
                     </div></TD>
                <TD width="67" align=middle><input type="submit" name="gonder" id="button" value="G�nder"></TD>
              </TR>
          </TBODY>
          </TABLE>
          <? } ?>
          <p>&nbsp;</p>
          <H5 align="center">
            <label></label>
          <!--<?
for($x=1; $x<=$toplamsayfa; $x++)
{
  if($x=="1")
  {
	  echo"<strong><a href='?sayfa=1&KUID=$KUID'><span style='font-size: x-small;'>1 </span></a>";
}
else
{ echo"<a href='?sayfa=$x&KUID=$KUID'><strong><span style='font-size: x-small;'>$x</span> </strong></a></strong> ";}
}

?>-->
        </H5>
</FORM>
     
   
    </TD></TR>
  <TR>
    <TD class=dip colSpan=2 align=right><? echo $ttt[2]; ?></TD></TR></TBODY></TABLE>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom", {validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "custom");
//-->
</script>
</BODY></HTML>
