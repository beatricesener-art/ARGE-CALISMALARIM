using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Ini;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class Main : Form
	{
		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern string DVRCONTROLDLLGetPayment();

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern string DVRCONTROLDLLGetTotalTime();

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern string DVRCONTROLDLLGetPlate();

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern string DVRCONTROLDLLGetEntTime();

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern void DVRCONTROLDLLOpenBariyer(int camno);

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int DVRCONTROLDLLIsPlateReady();

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern string DVRCONTROLDLLGetOutPlate();

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int DVRCONTROLDLLGetOutCamNo();

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern string DVRCONTROLDLLGetImgPath();

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern void DVRCONTROLDLLSetPayment(string value);

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern void DVRCONTROLDLLSetEntTime(string value);

		[DllImport("DVRControlDLL.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern void DVRCONTROLDLLSetPlate(string value);

		public Main()
		{
			this.InitializeComponent();
			this.OdemeInfoClear();
		}

		private void ConnectToMySQL()
		{
			string connectionString = string.Concat(new string[]
			{
				"server=",
				GlobalVar.DBInfo.serverip,
				";uid=",
				GlobalVar.DBInfo.username,
				";pwd=",
				GlobalVar.DBInfo.password,
				";database=",
				GlobalVar.DBInfo.dbname,
				";"
			});
			GlobalVar.conn = new MySqlConnection();
			try
			{
				GlobalVar.conn.ConnectionString = connectionString;
				GlobalVar.conn.Open();
				GlobalVar.DBConnectionStatus = true;
			}
			catch (MySqlException ex)
			{
				MessageBox.Show(ex.Message);
			}
			GlobalVar.conn2 = new MySqlConnection();
			try
			{
				GlobalVar.conn2.ConnectionString = connectionString;
				GlobalVar.conn2.Open();
			}
			catch (MySqlException ex2)
			{
				MessageBox.Show(ex2.Message);
			}
			string text = "SELECT * FROM db_sistemler WHERE sistemadi='" + GlobalVar.sistemadi + "' LIMIT 0,1";
			MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
			MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
			if (mySqlDataReader.Read())
			{
				GlobalVar.GlobalPath = mySqlDataReader["url"].ToString();
				GlobalVar.GlobalSistemName = mySqlDataReader["sistemadi"].ToString();
			}
			mySqlDataReader.Close();
			text = "SELECT * FROM db_kameralar WHERE sistem_ID='" + GlobalVar.GlobalSistemName + "' ";
			MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
			MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
			int num = 0;
			while (mySqlDataReader2.Read())
			{
				GlobalVar.camRelaysArray[num] = int.Parse(mySqlDataReader2["role_ID"].ToString());
				GlobalVar.camDirectionArray[num] = mySqlDataReader2["kamera_Yon"].ToString();
				string str;
				if (mySqlDataReader2["kamera_Yon"].ToString() == "c")
				{
					str = "Giriş";
				}
				else
				{
					str = "Çıkış";
				}
				string item = "Kamera:" + (num + 1).ToString() + " Yön:" + str;
				this.camList.Items.Add(item);
				num++;
			}
			GlobalVar.camCount = num;
			mySqlDataReader2.Close();
		}

		public void SentToLedScreen(string ucret, string tarih, string plaka)
		{
			Main.DVRCONTROLDLLSetPlate(plaka);
			Main.DVRCONTROLDLLSetEntTime(tarih);
			Main.DVRCONTROLDLLSetPayment(ucret);
		}

		private void Main_Load(object sender, EventArgs e)
		{
			string inipath = Directory.GetCurrentDirectory() + "\\settings.ini";
			IniFile iniFile = new IniFile(inipath);
			string text = iniFile.IniReadValue("DBSetting", "ServerIP");
			if (text.Length < 1)
			{
				iniFile.IniWriteValue("DBSetting", "ServerIP", "127.0.0.1");
				iniFile.IniWriteValue("DBSetting", "SystemName", "sistem");
				iniFile.IniWriteValue("DBSetting", "DBName", "otopark");
				iniFile.IniWriteValue("DBSetting", "DBUser", "root");
				iniFile.IniWriteValue("DBSetting", "DBPassword", "123123");
				iniFile.IniWriteValue("DBSetting", "PaymentCam", "1");
				iniFile.IniWriteValue("DBSetting", "WebURL", "http://127.0.0.1/pts");
				iniFile.IniWriteValue("DBSetting", "AdminPassword", "123123");
				iniFile.IniWriteValue("DBSetting", "ShowAbonelik", "1");
				iniFile.IniWriteValue("DBSetting", "ShowAutoPay", "0");
				iniFile.IniWriteValue("DBSetting", "UcretsizSure", "15");
				iniFile.IniWriteValue("DBSetting", "Etiket1", "OTOPARK");
				iniFile.IniWriteValue("DBSetting", "Etiket2", "IYI YOLCULUKLAR DILERIZ!");
				iniFile.IniWriteValue("DBSetting", "Etiket3", "SORUMLULUK KABUL EDILMEZ!");
				iniFile.IniWriteValue("DBSetting", "NoktaID", "0");
				iniFile.IniWriteValue("DBSetting", "PrgTipi", "0");
				iniFile.IniWriteValue("DBSetting", "GunlukLimit", "0");
				iniFile.IniWriteValue("DBSetting", "GunlukLimitDakika", "180");
				iniFile.IniWriteValue("DBSetting", "DelLogs", "30");
				iniFile.IniWriteValue("DBSetting", "DelHour", "2");
				iniFile.IniWriteValue("DBSetting", "DelMinute", "0");
				iniFile.IniWriteValue("DBSetting", "AutoPrint", "0");
				iniFile.IniWriteValue("DBSetting", "P_FontSize1", "26");
				iniFile.IniWriteValue("DBSetting", "P_FontSize2", "28");
				iniFile.IniWriteValue("DBSetting", "P_PageW", "600");
				iniFile.IniWriteValue("DBSetting", "P_PageH", "450");
				iniFile.IniWriteValue("DBSetting", "P_BarkodW", "550");
				iniFile.IniWriteValue("DBSetting", "P_BarkodH", "150");
				iniFile.IniWriteValue("DBSetting", "P_TopSize", "200");
				iniFile.IniWriteValue("DBSetting", "P_LeftSize", "0");
				iniFile.IniWriteValue("DBSetting", "P_LineFree", "30");
				iniFile.IniWriteValue("DBSetting", "P_LeftLine", "600");
			}
			text = iniFile.IniReadValue("DBSetting", "ServerIP");
			GlobalVar.sistemadi = iniFile.IniReadValue("DBSetting", "SystemName");
			string username = iniFile.IniReadValue("DBSetting", "DBUser");
			string password = iniFile.IniReadValue("DBSetting", "DBPassword");
			string dbname = iniFile.IniReadValue("DBSetting", "DBName");
			GlobalVar.paymentCam = int.Parse(iniFile.IniReadValue("DBSetting", "PaymentCam"));
			GlobalVar.WebURL = iniFile.IniReadValue("DBSetting", "WebURL");
			GlobalVar.adminPassword = iniFile.IniReadValue("DBSetting", "AdminPassword");
			GlobalVar.showAbonelik = int.Parse(iniFile.IniReadValue("DBSetting", "ShowAbonelik"));
			GlobalVar.showAutoPay = int.Parse(iniFile.IniReadValue("DBSetting", "ShowAutoPay"));
			GlobalVar.ucretsizSure = int.Parse(iniFile.IniReadValue("DBSetting", "UcretsizSure"));
			GlobalVar.Label1 = iniFile.IniReadValue("DBSetting", "Etiket1");
			GlobalVar.Label2 = iniFile.IniReadValue("DBSetting", "Etiket2");
			GlobalVar.Label3 = iniFile.IniReadValue("DBSetting", "Etiket3");
			GlobalVar.pointID = int.Parse(iniFile.IniReadValue("DBSetting", "NoktaID"));
			GlobalVar.prgType = int.Parse(iniFile.IniReadValue("DBSetting", "PrgTipi"));
			GlobalVar.DayLimit = int.Parse(iniFile.IniReadValue("DBSetting", "GunlukLimit"));
			GlobalVar.DayLimitMin = int.Parse(iniFile.IniReadValue("DBSetting", "GunlukLimitDakika"));
			GlobalVar.delLogsBefore = int.Parse(iniFile.IniReadValue("DBSetting", "DelLogs"));
			GlobalVar.delHour = int.Parse(iniFile.IniReadValue("DBSetting", "DelHour"));
			GlobalVar.delMinute = int.Parse(iniFile.IniReadValue("DBSetting", "DelMinute"));
			this.MAKE_AUTO_PRINT = int.Parse(iniFile.IniReadValue("DBSetting", "AutoPrint"));
			GlobalVar.FontSize1 = int.Parse(iniFile.IniReadValue("DBSetting", "P_FontSize1"));
			GlobalVar.FontSize2 = int.Parse(iniFile.IniReadValue("DBSetting", "P_FontSize2"));
			GlobalVar.PageW = int.Parse(iniFile.IniReadValue("DBSetting", "P_PageW"));
			GlobalVar.PageH = int.Parse(iniFile.IniReadValue("DBSetting", "P_PageH"));
			GlobalVar.BarkodW = int.Parse(iniFile.IniReadValue("DBSetting", "P_BarkodW"));
			GlobalVar.BarkodH = int.Parse(iniFile.IniReadValue("DBSetting", "P_BarkodH"));
			GlobalVar.TopSize = int.Parse(iniFile.IniReadValue("DBSetting", "P_TopSize"));
			GlobalVar.LeftSize = int.Parse(iniFile.IniReadValue("DBSetting", "P_LeftSize"));
			GlobalVar.LineFree = int.Parse(iniFile.IniReadValue("DBSetting", "P_LineFree"));
			GlobalVar.LeftLine = int.Parse(iniFile.IniReadValue("DBSetting", "P_LeftLine"));
			GlobalVar.SetDBValues(dbname, username, password, text);
			Protect protect = new Protect();
			if (protect.GetProtect() < 1)
			{
				int prgType = GlobalVar.prgType;
			}
			this.ConnectToMySQL();
			UsrLogin usrLogin = new UsrLogin();
			usrLogin.ShowDialog(this);
			if (!usrLogin.loginOK)
			{
				base.Close();
			}
			this.ShowPlakasiz = true;
			this.SetScreen();
			this.WebActive = false;
			this.Make2ScreenPamentForm();
			if (GlobalVar.prgType == 1)
			{
				this.odemeBariyerBtn.Enabled = false;
				this.groupBox2.Enabled = false;
				this.toolAbonelik.Enabled = false;
				this.toolPrgSettings.Enabled = false;
				this.toolPaymentScreen.Enabled = false;
				this.toolReporter.Enabled = false;
				this.toolLogs.Enabled = false;
				this.timer1.Enabled = false;
				this.timer2.Enabled = true;
				this.panel1.Enabled = false;
				this.panel2.Enabled = false;
			}
			else
			{
				this.timer1.Enabled = true;
				this.timer2.Enabled = false;
			}
		}

		public void CheckActiveUser()
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_calisma_saatlari WHERE end_time IS NULL AND pointID=" + GlobalVar.pointID.ToString();
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				string text2 = "";
				if (mySqlDataReader.Read())
				{
					text2 = mySqlDataReader["user_name"].ToString();
				}
				mySqlDataReader.Close();
				if (text2.Length <= 0)
				{
					if (GlobalVar.prgType == 0)
					{
						this.timer1.Enabled = false;
					}
					else
					{
						this.timer2.Enabled = false;
					}
					GlobalVar.activeId = 0;
					if (!this.WebActive)
					{
						UsrLogin usrLogin = new UsrLogin();
						usrLogin.ShowDialog(this);
					}
					if (GlobalVar.prgType == 0)
					{
						this.timer1.Enabled = true;
					}
					else
					{
						this.timer2.Enabled = true;
					}
				}
			}
		}

		public void WriteDbSettings()
		{
			string inipath = Directory.GetCurrentDirectory() + "\\settings.ini";
			IniFile iniFile = new IniFile(inipath);
			iniFile.IniWriteValue("DBSetting", "ServerIP", GlobalVar.DBInfo.serverip);
			iniFile.IniWriteValue("DBSetting", "DBName", GlobalVar.DBInfo.dbname);
			iniFile.IniWriteValue("DBSetting", "DBUser", GlobalVar.DBInfo.username);
			iniFile.IniWriteValue("DBSetting", "DBPassword", GlobalVar.DBInfo.password);
			iniFile.IniWriteValue("DBSetting", "PaymentCam", GlobalVar.paymentCam.ToString());
			iniFile.IniWriteValue("DBSetting", "WebURL", GlobalVar.WebURL);
			iniFile.IniWriteValue("DBSetting", "AdminPassword", GlobalVar.adminPassword);
			iniFile.IniWriteValue("DBSetting", "ShowAbonelik", GlobalVar.showAbonelik.ToString());
			iniFile.IniWriteValue("DBSetting", "ShowAutoPay", GlobalVar.showAutoPay.ToString());
			iniFile.IniWriteValue("DBSetting", "UcretsizSure", GlobalVar.ucretsizSure.ToString());
			iniFile.IniWriteValue("DBSetting", "Etiket1", GlobalVar.Label1);
			iniFile.IniWriteValue("DBSetting", "Etiket2", GlobalVar.Label2);
			iniFile.IniWriteValue("DBSetting", "Etiket3", GlobalVar.Label3);
			iniFile.IniWriteValue("DBSetting", "NoktaID", GlobalVar.pointID.ToString());
			iniFile.IniWriteValue("DBSetting", "PrgTipi", GlobalVar.prgType.ToString());
			iniFile.IniWriteValue("DBSetting", "GunlukLimit", GlobalVar.DayLimit.ToString());
			iniFile.IniWriteValue("DBSetting", "GunlukLimitDakika", GlobalVar.DayLimitMin.ToString());
			iniFile.IniWriteValue("DBSetting", "DelLogs", GlobalVar.delLogsBefore.ToString());
			iniFile.IniWriteValue("DBSetting", "DelHour", GlobalVar.delHour.ToString());
			iniFile.IniWriteValue("DBSetting", "DelMinute", GlobalVar.delMinute.ToString());
			iniFile.IniWriteValue("DBSetting", "AutoPrint", this.MAKE_AUTO_PRINT.ToString());
			iniFile.IniWriteValue("DBSetting", "P_FontSize1", GlobalVar.FontSize1.ToString());
			iniFile.IniWriteValue("DBSetting", "P_FontSize2", GlobalVar.FontSize2.ToString());
			iniFile.IniWriteValue("DBSetting", "P_PageW", GlobalVar.PageW.ToString());
			iniFile.IniWriteValue("DBSetting", "P_PageH", GlobalVar.PageH.ToString());
			iniFile.IniWriteValue("DBSetting", "P_BarkodW", GlobalVar.BarkodW.ToString());
			iniFile.IniWriteValue("DBSetting", "P_BarkodH", GlobalVar.BarkodH.ToString());
			iniFile.IniWriteValue("DBSetting", "P_TopSize", GlobalVar.TopSize.ToString());
			iniFile.IniWriteValue("DBSetting", "P_LeftSize", GlobalVar.LeftSize.ToString());
			iniFile.IniWriteValue("DBSetting", "P_LineFree", GlobalVar.LineFree.ToString());
			iniFile.IniWriteValue("DBSetting", "P_LeftLine", GlobalVar.LeftLine.ToString());
		}

		private void ShowPicSearch(string plate)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_loglar WHERE plaka = '" + plate + "' order by `kayittarihi` DESC LIMIT 0,1";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				string text2 = "";
				if (mySqlDataReader.Read())
				{
					text2 = mySqlDataReader["resimyolu"].ToString();
					this.paymentInfo.resimyolu = text2;
				}
				mySqlDataReader.Close();
				this.ShowPicLPR(text2);
			}
		}

		private void ShowPicLPR(string imgpath)
		{
			if (imgpath == "")
			{
				this.pictureSearch.Image = null;
				this.pictureSearch.SizeMode = PictureBoxSizeMode.StretchImage;
			}
			else
			{
				int num = imgpath.IndexOf("_");
				string text = string.Concat(new string[]
				{
					GlobalVar.GlobalPath,
					imgpath.Substring(num + 1, 4),
					"\\",
					imgpath.Substring(num + 5, 2),
					"\\",
					imgpath.Substring(num + 7, 2),
					"\\"
				});
				try
				{
					string imageLocation = string.Concat(new string[]
					{
						"http://",
						GlobalVar.DBInfo.serverip,
						"/pts/Resim.Goster.php?w=700&img=",
						text,
						imgpath
					});
					this.pictureSearch.ImageLocation = imageLocation;
					this.pictureSearch.SizeMode = PictureBoxSizeMode.StretchImage;
				}
				catch (Exception)
				{
				}
			}
		}

		private void ShowEnterExitWeb(string imgpath, Main.PicType pictype)
		{
			if (!(imgpath == ""))
			{
				int num = imgpath.IndexOf("_");
				string text = string.Concat(new string[]
				{
					GlobalVar.GlobalPath,
					imgpath.Substring(num + 1, 4),
					"\\",
					imgpath.Substring(num + 5, 2),
					"\\",
					imgpath.Substring(num + 7, 2),
					"\\"
				});
				try
				{
					string imageLocation = string.Concat(new string[]
					{
						"http://",
						GlobalVar.DBInfo.serverip,
						"/pts/Resim.Goster.php?w=700&img=",
						text,
						imgpath
					});
					if (pictype == Main.PicType.CIKIS)
					{
						this.plate2.ImageLocation = imageLocation;
						this.plate2.SizeMode = PictureBoxSizeMode.StretchImage;
					}
					else
					{
						this.pictureEnter.ImageLocation = imageLocation;
						this.pictureEnter.SizeMode = PictureBoxSizeMode.StretchImage;
					}
				}
				catch (Exception)
				{
				}
			}
			else if (pictype == Main.PicType.CIKIS)
			{
				this.plate2.Image = null;
				this.plate2.SizeMode = PictureBoxSizeMode.StretchImage;
			}
			else
			{
				this.pictureEnter.Image = null;
				this.pictureEnter.SizeMode = PictureBoxSizeMode.StretchImage;
			}
		}

		private void toolPrgSettings_Click(object sender, EventArgs e)
		{
			DBSettings dbsettings = new DBSettings();
			dbsettings.ShowDialog(this);
			this.WriteDbSettings();
		}

		private void toolUserChange_Click(object sender, EventArgs e)
		{
			UsrLogin usrLogin = new UsrLogin();
			usrLogin.ShowDialog(this);
		}

		private void toolPrgExit_Click(object sender, EventArgs e)
		{
			if (GlobalVar.activeId != 0)
			{
				base.Close();
			}
		}

		private void ShowEnterExitPic(string imgpath, Main.PicType pictype)
		{
			if (!(imgpath == ""))
			{
				int num = imgpath.IndexOf("_");
				string str = string.Concat(new string[]
				{
					GlobalVar.GlobalPath,
					imgpath.Substring(num + 1, 4),
					"\\",
					imgpath.Substring(num + 5, 2),
					"\\",
					imgpath.Substring(num + 7, 2),
					"\\"
				});
				try
				{
					Image image = Image.FromFile(str + imgpath);
					if (pictype == Main.PicType.CIKIS)
					{
						this.plate2.Image = image;
						this.plate2.SizeMode = PictureBoxSizeMode.StretchImage;
					}
					else
					{
						this.pictureEnter.Image = image;
						this.pictureEnter.SizeMode = PictureBoxSizeMode.StretchImage;
					}
				}
				catch (Exception)
				{
				}
			}
			else if (pictype == Main.PicType.CIKIS)
			{
				this.plate2.Image = null;
				this.plate2.SizeMode = PictureBoxSizeMode.StretchImage;
			}
			else
			{
				this.pictureEnter.Image = null;
				this.pictureEnter.SizeMode = PictureBoxSizeMode.StretchImage;
			}
		}

		private void ShowLastEnterPlate()
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_loglar WHERE aracKonum = 'i' AND sistemid='" + GlobalVar.GlobalSistemName + "'  ORDER by id DESC LIMIT 1";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn2);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				string imgpath = "";
				bool flag = false;
				if (mySqlDataReader.Read())
				{
					imgpath = mySqlDataReader["resimyolu"].ToString();
					this.PlateText1.Text = mySqlDataReader["plaka"].ToString();
					this.Time1.Text = mySqlDataReader["kayittarihi"].ToString();
					this.Cam1.Text = mySqlDataReader["kameraid"].ToString();
					flag = true;
				}
				mySqlDataReader.Close();
				if (flag)
				{
					this.ShowEnterExitWeb(imgpath, Main.PicType.GIRIS);
					if (this.PlateText1.Text.IndexOf("PLAKA") > -1 && !this.PlakasizActive && this.ShowPlakasiz)
					{
						this.PlakasizActive = true;
						new Plakasizlar
						{
							DesktopLocation = new Point(5, 100)
						}.Show(this);
					}
					if (this.MAKE_AUTO_PRINT == 1 && this.lastEnterPlate != this.PlateText1.Text)
					{
						if (this.lastEnterPlate.Length > 1)
						{
							this.lastEnterPlate = this.PlateText1.Text;
							AutoPrint autoPrint = new AutoPrint();
							autoPrint.LoadPlateDetails(this.lastEnterPlate);
							Thread.Sleep(5000);
							this.ClearAdobeApp();
						}
						else
						{
							this.lastEnterPlate = this.PlateText1.Text;
						}
					}
				}
			}
		}

		private void ShowLastExitPlate()
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_loglar WHERE aracKonum = 'd' AND sistemid='" + GlobalVar.GlobalSistemName + "' ORDER by id DESC LIMIT 1";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn2);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				string imgpath = "";
				bool flag = false;
				if (mySqlDataReader.Read())
				{
					imgpath = mySqlDataReader["resimyolu"].ToString();
					this.PlateText2.Text = mySqlDataReader["plaka"].ToString();
					this.Time2.Text = mySqlDataReader["kayittarihi"].ToString();
					this.Cam2.Text = mySqlDataReader["kameraid"].ToString();
					flag = true;
				}
				mySqlDataReader.Close();
				if (flag)
				{
					this.ShowEnterExitWeb(imgpath, Main.PicType.CIKIS);
				}
			}
		}

		private void ListPlates(int type)
		{
			DateTime now = DateTime.Now;
			string format = "yyyy-MM-dd HH:mm:ss";
			string text = now.ToString(format);
			string text2 = "";
			if (type == -1)
			{
				text2 = " ORDER by sondegisim DESC, id DESC";
			}
			else if (type == 0)
			{
				text2 = " ORDER by plaka ASC";
			}
			else if (type == 1)
			{
				text2 = " ORDER by sondegisim DESC, id DESC";
			}
			string text5;
			if (this.checkZaman.Checked)
			{
				this.enterDate.CustomFormat = "yyyy-MM-dd";
				this.exitDate.CustomFormat = "yyyy-MM-dd";
				string text3 = this.enterDate.Text + " " + this.enterTime.Text;
				string text4 = this.exitDate.Text + " " + this.exitTime.Text;
				text5 = string.Concat(new string[]
				{
					"SELECT * FROM db_araclar WHERE aracKonum = 'i' AND abonelikbitis < '",
					text,
					"' AND sondegisim BETWEEN '",
					text3,
					"' AND '",
					text4,
					"' AND plaka LIKE '%",
					this.textPlate.Text,
					"%'",
					text2
				});
			}
			else
			{
				text5 = string.Concat(new string[]
				{
					"SELECT * FROM db_araclar WHERE aracKonum = 'i' AND ( abonelikbitis < '",
					text,
					"' OR abonelikTipi=1 OR tipID<1 ) AND plaka LIKE '%",
					this.textPlate.Text,
					"%'",
					text2
				});
			}
			MySqlCommand mySqlCommand = new MySqlCommand(text5, GlobalVar.conn);
			MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
			this.listView1.Items.Clear();
			while (mySqlDataReader.Read())
			{
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = mySqlDataReader["plaka"].ToString();
				try
				{
					listViewItem.SubItems.Add(mySqlDataReader["sondegisim"].ToString());
					listViewItem.SubItems.Add(mySqlDataReader["soncamid"].ToString());
				}
				catch (Exception)
				{
					listViewItem.SubItems.Add("0000-00-00 00:00:00");
					listViewItem.SubItems.Add(mySqlDataReader["soncamid"].ToString());
				}
				this.listView1.Items.Add(listViewItem);
			}
			mySqlDataReader.Close();
		}

		private void btnSearch_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				this.ListPlates(-1);
			}
		}

		private void listView1_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count > 0)
			{
				int num = this.listView1.SelectedIndices[0];
				if (num >= 0)
				{
					string text = this.listView1.Items[num].Text;
					this.ShowPicSearch(this.listView1.Items[num].Text);
				}
			}
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			this.ShowLastEnterPlate();
			this.ShowLastExitPlate();
			this.DelLogs();
			if (GlobalVar.activeId > 0)
			{
				this.userInfo.Text = GlobalVar.activeName;
				this.userInfo.ForeColor = Color.FromArgb(0, 0, 0);
			}
			else
			{
				this.userInfo.Text = "!!! AKTIF KULLANICI YOK !!!";
				this.userInfo.ForeColor = Color.FromArgb(255, 0, 0);
			}
			this.CheckActiveUser();
		}

		public void DelLogs()
		{
			if (GlobalVar.prgType <= 0)
			{
				DateTime now = DateTime.Now;
				if (now.Hour != GlobalVar.delHour || now.Minute != GlobalVar.delMinute)
				{
					this.deletedLogs = false;
				}
				else if (!this.deletedLogs)
				{
					this.deletedLogs = true;
					int num = GlobalVar.delLogsBefore * -1;
					DateTime dateTime = now.AddDays((double)num);
					string format = "yyyy-MM-dd HH:mm:ss";
					string str = dateTime.ToString(format);
					if (GlobalVar.DBConnectionStatus)
					{
						string text = "DELETE FROM db_loglar WHERE kayittarihi < '" + str + "'";
						MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn2);
						MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
						mySqlDataReader.Close();
						text = "DELETE FROM db_araclar WHERE geciciarac=1 && aracKonum='d'";
						MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn2);
						MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
						mySqlDataReader2.Close();
					}
				}
			}
		}

		private DialogResult ShowPaymentDialogShiftedRight(Form dialog)
		{
			int num = 190;
			Rectangle workingArea = Screen.FromControl(this).WorkingArea;
			int num2 = base.Left + (base.Width - dialog.Width) / 2 + num;
			int num3 = base.Top + (base.Height - dialog.Height) / 2;
			if (num2 + dialog.Width > workingArea.Right)
			{
				num2 = workingArea.Right - dialog.Width;
			}
			if (num2 < workingArea.Left)
			{
				num2 = workingArea.Left;
			}
			if (num3 + dialog.Height > workingArea.Bottom)
			{
				num3 = workingArea.Bottom - dialog.Height;
			}
			if (num3 < workingArea.Top)
			{
				num3 = workingArea.Top;
			}
			dialog.StartPosition = FormStartPosition.Manual;
			dialog.Location = new Point(num2, num3);
			return dialog.ShowDialog(this);
		}

		private void paymentBtn_Click(object sender, EventArgs e)
		{
			if (GlobalVar.activeId != 0)
			{
				if (this.listView1.SelectedIndices.Count > 0)
				{
					int num = this.listView1.SelectedIndices[0];
					if (num >= 0)
					{
						string text = this.listView1.Items[num].Text;
						Payment dialog = new Payment
						{
							plate = text,
							odemeileBariyer = false,
							enterDateTime = this.listView1.Items[num].SubItems[1].Text
						};
						this.ShowPaymentDialogShiftedRight(dialog);
						this.OdemeInfoClear();
						this.ClearAdobeApp();
						this.listView1.Items.Clear();
					}
				}
			}
		}

		public void ClearAdobeApp()
		{
			Process[] processes = Process.GetProcesses();
			int i = 0;
			while (i < processes.Length)
			{
				Process process = processes[i];
				if (process.ProcessName.StartsWith("Acro"))
				{
					if (!process.HasExited)
					{
						process.WaitForExit(1000);
						process.Kill();
						break;
					}
					process.Kill();
					break;
				}
				else
				{
					i++;
				}
			}
		}

		private void addVehicleBtn_Click(object sender, EventArgs e)
		{
			if (GlobalVar.activeId != 0)
			{
				AddVehicle addVehicle = new AddVehicle();
				addVehicle.ShowDialog(this);
			}
		}

		public void OpenBariyer(int selID)
		{
			Main.DVRCONTROLDLLOpenBariyer(GlobalVar.camRelaysArray[selID]);
		}

		private void openBariyer_Click(object sender, EventArgs e)
		{
			if (GlobalVar.activeId != 0)
			{
				if (this.camList.SelectedIndex > -1)
				{
					Main.DVRCONTROLDLLOpenBariyer(GlobalVar.camRelaysArray[this.camList.SelectedIndex]);
					this.YoneticiLogEkle(GlobalVar.camRelaysArray[this.camList.SelectedIndex].ToString() + " Numarali bariyer acildi!");
				}
			}
		}

		public void YoneticiLogEkle(string msg)
		{
			DateTime now = DateTime.Now;
			string format = "yyyy-MM-dd HH:mm:ss";
			string text = now.ToString(format);
			if (GlobalVar.DBConnectionStatus)
			{
				msg = GlobalVar.activeName + " " + msg;
				string text2 = string.Concat(new string[]
				{
					"INSERT INTO db_yonetimlog (`id` ,`olay` ,`eklenme` ,`kullanici` ) VALUES (NULL , '",
					msg,
					"','",
					text,
					"','",
					GlobalVar.activeUser,
					"')"
				});
				MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
			}
		}

		private void OdemeInfoClear()
		{
			this.paymentInfo.cikiszaman = "";
			this.paymentInfo.giriszaman = "";
			this.paymentInfo.plaka = "";
			this.paymentInfo.resimyolu = "";
			this.paymentInfo.ucret = "";
			this.paymentInfo.sure = "";
		}

		private void odemeBariyerBtn_Click(object sender, EventArgs e)
		{
			if (GlobalVar.activeId != 0)
			{
				if (this.listView1.SelectedIndices.Count > 0)
				{
					int num = this.listView1.SelectedIndices[0];
					if (num >= 0)
					{
						string text = this.listView1.Items[num].Text;
						Payment dialog = new Payment
						{
							plate = text,
							odemeileBariyer = true,
							enterDateTime = this.listView1.Items[num].SubItems[1].Text
						};
						this.ShowPaymentDialogShiftedRight(dialog);
						this.OdemeInfoClear();
						this.ClearAdobeApp();
						this.listView1.Items.Clear();
					}
				}
			}
		}

		private void toolAbonelik_Click(object sender, EventArgs e)
		{
			if (GlobalVar.activeId != 0)
			{
				if (GlobalVar.showAbonelik == 0)
				{
					AdmLogin admLogin = new AdmLogin();
					admLogin.ShowDialog(this);
					if (admLogin.loginOK == 1)
					{
						GlobalVar.showAbonelik = 1;
					}
				}
				Abonelik abonelik = new Abonelik();
				abonelik.ShowDialog(this);
			}
		}

		private void duzeltBtn_Click(object sender, EventArgs e)
		{
			if (GlobalVar.activeId != 0)
			{
				if (this.listView1.SelectedIndices.Count > 0)
				{
					int num = this.listView1.SelectedIndices[0];
					if (num >= 0)
					{
						string text = this.listView1.Items[num].Text;
						PlakaDuzelt plakaDuzelt = new PlakaDuzelt();
						plakaDuzelt.plate = text;
						plakaDuzelt.enterDateTime = this.listView1.Items[num].SubItems[1].Text;
						plakaDuzelt.ShowDialog(this);
						this.listView1.Items[num].Text = plakaDuzelt.plate;
						this.YoneticiLogEkle(string.Concat(new string[]
						{
							"Araclara Eski Plaka:",
							text,
							" Yeni Plaka:",
							plakaDuzelt.plate,
							" Elle Düzeltildi! "
						}));
					}
				}
			}
		}

		private void toolBrowser_Click(object sender, EventArgs e)
		{
			WebTarayici webTarayici = new WebTarayici();
			this.WebActive = true;
			webTarayici.ShowDialog(this);
			this.WebActive = false;
		}

		private void toolPaymentScreen_Click(object sender, EventArgs e)
		{
			this.Make2ScreenPamentForm();
		}

		private void Make2ScreenPamentForm()
		{
			Screen[] allScreens = Screen.AllScreens;
			int num = 0;
			foreach (Screen screen in allScreens)
			{
				num++;
			}
			OdemeEkran odemeEkran = new OdemeEkran();
			if (num < 2)
			{
				odemeEkran.Show(this);
			}
			else
			{
				int left;
				if (allScreens[1].Primary)
				{
					left = allScreens[0].Bounds.Left;
				}
				else
				{
					left = allScreens[1].Bounds.Left;
				}
				odemeEkran.StartPosition = FormStartPosition.Manual;
				odemeEkran.Left = left;
				odemeEkran.Top = 0;
				odemeEkran.WindowState = FormWindowState.Maximized;
				odemeEkran.Show(this);
			}
		}

		private void SetScreen()
		{
			this.panel3.Left = (base.Width - this.panel3.Width - 16) / 2;
			this.panel3.Top = (base.Height - this.panel3.Height + 36) / 2;
		}

		private void Main_SizeChanged(object sender, EventArgs e)
		{
			this.SetScreen();
		}

		private void OnPlateCheck_Tick(object sender, EventArgs e)
		{
			if (Main.DVRCONTROLDLLIsPlateReady() == 1)
			{
				string text = Main.DVRCONTROLDLLGetOutPlate();
				if (text.Length >= 1)
				{
					if (this.dllTempPlate != text)
					{
						this.dllTempPlate = text;
						string text2 = "SELECT * FROM db_araclar WHERE plaka = '" + text + "'";
						MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
						MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
						if (!mySqlDataReader.Read())
						{
							mySqlDataReader.Close();
						}
						else
						{
							mySqlDataReader.Close();
							this.OnPlateCheck.Enabled = false;
							PaymentAuto paymentAuto = new PaymentAuto();
							paymentAuto.resimyolu = Main.DVRCONTROLDLLGetImgPath();
							paymentAuto.camno = Main.DVRCONTROLDLLGetOutCamNo();
							paymentAuto.plate = text;
							if (GlobalVar.activeId > 0 && GlobalVar.showAutoPay == 1)
							{
								this.ShowPaymentDialogShiftedRight(paymentAuto);
							}
							this.OnPlateCheck.Enabled = true;
						}
					}
				}
			}
		}

		private void Main_FormClosing(object sender, FormClosingEventArgs e)
		{
			DialogResult dialogResult = MessageBox.Show(this, "Programı Kapatmak İstiyor musunuz?", "Çıkış", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);
			if (dialogResult != DialogResult.Yes)
			{
				e.Cancel = true;
			}
		}

		private void toolReporter_Click(object sender, EventArgs e)
		{
			AdmLogin admLogin = new AdmLogin();
			admLogin.ShowDialog(this);
			if (admLogin.loginOK == 1)
			{
				VehicleReport vehicleReport = new VehicleReport();
				vehicleReport.ShowDialog(this);
			}
		}

		private void toolLogs_Click(object sender, EventArgs e)
		{
			AracLogListesi aracLogListesi = new AracLogListesi();
			aracLogListesi.ShowDialog(this);
		}

		private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
		{
			this.ListPlates(e.Column);
		}

		private void btnChnForm_Click(object sender, EventArgs e)
		{
			if (!this.formResized)
			{
				this.panel1.Visible = false;
				this.panel2.Visible = false;
				this.groupBox2.Visible = false;
				this.toolStrip1.Visible = false;
				base.Size = new Size(710, 550);
				this.groupBox1.Location = new Point(200, 30);
				this.formResized = true;
			}
			else
			{
				this.panel1.Visible = true;
				this.panel2.Visible = true;
				this.groupBox2.Visible = true;
				this.toolStrip1.Visible = true;
				base.Size = new Size(1113, 746);
				this.groupBox1.Location = new Point(399, 2);
				this.formResized = false;
				base.TopMost = true;
			}
		}

		private void vipBtn_Click(object sender, EventArgs e)
		{
			if (GlobalVar.activeId != 0)
			{
				if (this.listView1.SelectedIndices.Count > 0)
				{
					int num = this.listView1.SelectedIndices[0];
					if (num >= 0)
					{
						string text = this.listView1.Items[num].Text;
						new AracTipi
						{
							plate = text,
							enterDateTime = this.listView1.Items[num].SubItems[1].Text
						}.ShowDialog(this);
					}
				}
			}
		}

		private void barkodPayBtn_Click(object sender, EventArgs e)
		{
			if (GlobalVar.activeId != 0)
			{
				BarkodPayment barkodPayment = new BarkodPayment();
				barkodPayment.ShowDialog(this);
				this.ClearAdobeApp();
			}
		}

		private void timer2_Tick(object sender, EventArgs e)
		{
			if (GlobalVar.activeId > 0)
			{
				this.userInfo.Text = GlobalVar.activeName;
				this.userInfo.ForeColor = Color.FromArgb(0, 0, 0);
			}
			else
			{
				this.userInfo.Text = "!!! AKTIF KULLANICI YOK !!!";
				this.userInfo.ForeColor = Color.FromArgb(255, 0, 0);
			}
			this.CheckActiveUser();
		}

		public bool PlakasizActive;

		public bool ShowPlakasiz;

		public PaymentInfo paymentInfo = new PaymentInfo();

		public bool WebActive = true;

		public bool formResized;

		public string dllTempPlate = "";

		public bool deletedLogs;

		public string lastEnterPlate = "";

		public int MAKE_AUTO_PRINT;

		private enum PicType
		{
			GIRIS,
			CIKIS
		}
	}
}
