using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;

namespace ParkPay
{
	public partial class AdmLogin : Form
	{
		public AdmLogin()
		{
			this.InitializeComponent();
		}

		private void login_Click(object sender, EventArgs e)
		{
			if (this.textadminPass.Text == GlobalVar.adminPassword)
			{
				this.loginOK = 1;
				base.Close();
			}
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		public int loginOK;
	}
}
