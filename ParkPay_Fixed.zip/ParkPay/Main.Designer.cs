namespace ParkPay
{
	public partial class Main : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.Main));
			this.toolStrip1 = new global::System.Windows.Forms.ToolStrip();
			this.toolUserChange = new global::System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new global::System.Windows.Forms.ToolStripSeparator();
			this.toolAbonelik = new global::System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator2 = new global::System.Windows.Forms.ToolStripSeparator();
			this.toolPrgSettings = new global::System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator3 = new global::System.Windows.Forms.ToolStripSeparator();
			this.toolPrgExit = new global::System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator4 = new global::System.Windows.Forms.ToolStripSeparator();
			this.toolBrowser = new global::System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator5 = new global::System.Windows.Forms.ToolStripSeparator();
			this.toolPaymentScreen = new global::System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator7 = new global::System.Windows.Forms.ToolStripSeparator();
			this.toolReporter = new global::System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator6 = new global::System.Windows.Forms.ToolStripSeparator();
			this.toolLogs = new global::System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator8 = new global::System.Windows.Forms.ToolStripSeparator();
			this.toolStripLabel1 = new global::System.Windows.Forms.ToolStripLabel();
			this.userInfo = new global::System.Windows.Forms.ToolStripLabel();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.vipBtn = new global::System.Windows.Forms.Button();
			this.btnChnForm = new global::System.Windows.Forms.Button();
			this.duzeltBtn = new global::System.Windows.Forms.Button();
			this.odemeBariyerBtn = new global::System.Windows.Forms.Button();
			this.checkZaman = new global::System.Windows.Forms.CheckBox();
			this.exitTime = new global::System.Windows.Forms.DateTimePicker();
			this.exitDate = new global::System.Windows.Forms.DateTimePicker();
			this.label13 = new global::System.Windows.Forms.Label();
			this.enterTime = new global::System.Windows.Forms.DateTimePicker();
			this.enterDate = new global::System.Windows.Forms.DateTimePicker();
			this.label12 = new global::System.Windows.Forms.Label();
			this.label11 = new global::System.Windows.Forms.Label();
			this.pictureSearch = new global::System.Windows.Forms.PictureBox();
			this.paymentBtn = new global::System.Windows.Forms.Button();
			this.addVehicleBtn = new global::System.Windows.Forms.Button();
			this.label3 = new global::System.Windows.Forms.Label();
			this.listView1 = new global::System.Windows.Forms.ListView();
			this.columnHeader1 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new global::System.Windows.Forms.ColumnHeader();
			this.btnSearch = new global::System.Windows.Forms.Button();
			this.textPlate = new global::System.Windows.Forms.TextBox();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.Cam1 = new global::System.Windows.Forms.TextBox();
			this.label6 = new global::System.Windows.Forms.Label();
			this.Time1 = new global::System.Windows.Forms.TextBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.PlateText1 = new global::System.Windows.Forms.TextBox();
			this.label4 = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.pictureEnter = new global::System.Windows.Forms.PictureBox();
			this.panel2 = new global::System.Windows.Forms.Panel();
			this.Cam2 = new global::System.Windows.Forms.TextBox();
			this.label7 = new global::System.Windows.Forms.Label();
			this.Time2 = new global::System.Windows.Forms.TextBox();
			this.label8 = new global::System.Windows.Forms.Label();
			this.PlateText2 = new global::System.Windows.Forms.TextBox();
			this.label9 = new global::System.Windows.Forms.Label();
			this.label2 = new global::System.Windows.Forms.Label();
			this.plate2 = new global::System.Windows.Forms.PictureBox();
			this.groupBox2 = new global::System.Windows.Forms.GroupBox();
			this.barkodPayBtn = new global::System.Windows.Forms.Button();
			this.openBariyer = new global::System.Windows.Forms.Button();
			this.label10 = new global::System.Windows.Forms.Label();
			this.camList = new global::System.Windows.Forms.ComboBox();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.panel3 = new global::System.Windows.Forms.Panel();
			this.OnPlateCheck = new global::System.Windows.Forms.Timer(this.components);
			this.timer2 = new global::System.Windows.Forms.Timer(this.components);
			this.toolStrip1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureSearch).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			this.panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureEnter).BeginInit();
			this.panel2.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.plate2).BeginInit();
			this.groupBox2.SuspendLayout();
			this.panel3.SuspendLayout();
			base.SuspendLayout();
			this.toolStrip1.BackColor = global::System.Drawing.SystemColors.GradientActiveCaption;
			this.toolStrip1.ImageScalingSize = new global::System.Drawing.Size(48, 48);
			this.toolStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.toolUserChange,
				this.toolStripSeparator1,
				this.toolAbonelik,
				this.toolStripSeparator2,
				this.toolPrgSettings,
				this.toolStripSeparator3,
				this.toolPrgExit,
				this.toolStripSeparator4,
				this.toolBrowser,
				this.toolStripSeparator5,
				this.toolPaymentScreen,
				this.toolStripSeparator7,
				this.toolReporter,
				this.toolStripSeparator6,
				this.toolLogs,
				this.toolStripSeparator8,
				this.toolStripLabel1,
				this.userInfo
			});
			this.toolStrip1.Location = new global::System.Drawing.Point(0, 0);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new global::System.Drawing.Size(1097, 70);
			this.toolStrip1.TabIndex = 1;
			this.toolStrip1.Click += new global::System.EventHandler(this.listView1_Click);
			this.toolUserChange.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("toolUserChange.Image");
			this.toolUserChange.ImageScaling = global::System.Windows.Forms.ToolStripItemImageScaling.None;
			this.toolUserChange.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.toolUserChange.Name = "toolUserChange";
			this.toolUserChange.Size = new global::System.Drawing.Size(99, 67);
			this.toolUserChange.Text = "Kullanıcı Değiştir";
			this.toolUserChange.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageAboveText;
			this.toolUserChange.Click += new global::System.EventHandler(this.toolUserChange_Click);
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new global::System.Drawing.Size(6, 70);
			this.toolAbonelik.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("toolAbonelik.Image");
			this.toolAbonelik.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.toolAbonelik.Name = "toolAbonelik";
			this.toolAbonelik.Size = new global::System.Drawing.Size(105, 67);
			this.toolAbonelik.Text = "Abonelik İşlemleri";
			this.toolAbonelik.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageAboveText;
			this.toolAbonelik.Click += new global::System.EventHandler(this.toolAbonelik_Click);
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new global::System.Drawing.Size(6, 70);
			this.toolPrgSettings.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("toolPrgSettings.Image");
			this.toolPrgSettings.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.toolPrgSettings.Name = "toolPrgSettings";
			this.toolPrgSettings.Size = new global::System.Drawing.Size(100, 67);
			this.toolPrgSettings.Text = "Program Ayarları";
			this.toolPrgSettings.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageAboveText;
			this.toolPrgSettings.Click += new global::System.EventHandler(this.toolPrgSettings_Click);
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new global::System.Drawing.Size(6, 70);
			this.toolPrgExit.Alignment = global::System.Windows.Forms.ToolStripItemAlignment.Right;
			this.toolPrgExit.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("toolPrgExit.Image");
			this.toolPrgExit.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.toolPrgExit.Name = "toolPrgExit";
			this.toolPrgExit.Size = new global::System.Drawing.Size(93, 67);
			this.toolPrgExit.Text = "Programı Kapat";
			this.toolPrgExit.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageAboveText;
			this.toolPrgExit.Click += new global::System.EventHandler(this.toolPrgExit_Click);
			this.toolStripSeparator4.Alignment = global::System.Windows.Forms.ToolStripItemAlignment.Right;
			this.toolStripSeparator4.Name = "toolStripSeparator4";
			this.toolStripSeparator4.Size = new global::System.Drawing.Size(6, 70);
			this.toolBrowser.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("toolBrowser.Image");
			this.toolBrowser.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.toolBrowser.Name = "toolBrowser";
			this.toolBrowser.Size = new global::System.Drawing.Size(100, 67);
			this.toolBrowser.Text = "Program Ayarları";
			this.toolBrowser.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageAboveText;
			this.toolBrowser.Click += new global::System.EventHandler(this.toolBrowser_Click);
			this.toolStripSeparator5.Name = "toolStripSeparator5";
			this.toolStripSeparator5.Size = new global::System.Drawing.Size(6, 70);
			this.toolPaymentScreen.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("toolPaymentScreen.Image");
			this.toolPaymentScreen.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.toolPaymentScreen.Name = "toolPaymentScreen";
			this.toolPaymentScreen.Size = new global::System.Drawing.Size(82, 67);
			this.toolPaymentScreen.Text = "Ödeme Ekran";
			this.toolPaymentScreen.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageAboveText;
			this.toolPaymentScreen.Click += new global::System.EventHandler(this.toolPaymentScreen_Click);
			this.toolStripSeparator7.Name = "toolStripSeparator7";
			this.toolStripSeparator7.Size = new global::System.Drawing.Size(6, 70);
			this.toolReporter.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("toolReporter.Image");
			this.toolReporter.ImageAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.toolReporter.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.toolReporter.Name = "toolReporter";
			this.toolReporter.Size = new global::System.Drawing.Size(82, 67);
			this.toolReporter.Text = "Araç İşlemleri";
			this.toolReporter.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageAboveText;
			this.toolReporter.Click += new global::System.EventHandler(this.toolReporter_Click);
			this.toolStripSeparator6.Name = "toolStripSeparator6";
			this.toolStripSeparator6.Size = new global::System.Drawing.Size(6, 70);
			this.toolLogs.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("toolLogs.Image");
			this.toolLogs.ImageTransparentColor = global::System.Drawing.Color.Magenta;
			this.toolLogs.Name = "toolLogs";
			this.toolLogs.Size = new global::System.Drawing.Size(58, 67);
			this.toolLogs.Text = "Araç Log";
			this.toolLogs.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageAboveText;
			this.toolLogs.Click += new global::System.EventHandler(this.toolLogs_Click);
			this.toolStripSeparator8.Name = "toolStripSeparator8";
			this.toolStripSeparator8.Size = new global::System.Drawing.Size(6, 70);
			this.toolStripLabel1.Font = new global::System.Drawing.Font("Segoe UI", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.toolStripLabel1.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.toolStripLabel1.Name = "toolStripLabel1";
			this.toolStripLabel1.Size = new global::System.Drawing.Size(100, 67);
			this.toolStripLabel1.Text = "A. Kullanıcı:";
			this.userInfo.Font = new global::System.Drawing.Font("Segoe UI", 14.25f, global::System.Drawing.FontStyle.Bold);
			this.userInfo.Name = "userInfo";
			this.userInfo.Size = new global::System.Drawing.Size(0, 67);
			this.groupBox1.BackColor = global::System.Drawing.SystemColors.GradientInactiveCaption;
			this.groupBox1.Controls.Add(this.vipBtn);
			this.groupBox1.Controls.Add(this.btnChnForm);
			this.groupBox1.Controls.Add(this.duzeltBtn);
			this.groupBox1.Controls.Add(this.odemeBariyerBtn);
			this.groupBox1.Controls.Add(this.checkZaman);
			this.groupBox1.Controls.Add(this.exitTime);
			this.groupBox1.Controls.Add(this.exitDate);
			this.groupBox1.Controls.Add(this.label13);
			this.groupBox1.Controls.Add(this.enterTime);
			this.groupBox1.Controls.Add(this.enterDate);
			this.groupBox1.Controls.Add(this.label12);
			this.groupBox1.Controls.Add(this.label11);
			this.groupBox1.Controls.Add(this.pictureSearch);
			this.groupBox1.Controls.Add(this.paymentBtn);
			this.groupBox1.Controls.Add(this.addVehicleBtn);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.listView1);
			this.groupBox1.Controls.Add(this.btnSearch);
			this.groupBox1.Controls.Add(this.textPlate);
			this.groupBox1.Controls.Add(this.pictureBox3);
			this.groupBox1.Location = new global::System.Drawing.Point(399, 2);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(692, 522);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Araç Plakasını Giriniz";
			this.vipBtn.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.vipBtn.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.vipBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("vipBtn.Image");
			this.vipBtn.Location = new global::System.Drawing.Point(393, 423);
			this.vipBtn.Name = "vipBtn";
			this.vipBtn.Size = new global::System.Drawing.Size(125, 66);
			this.vipBtn.TabIndex = 25;
			this.vipBtn.Text = "VIP Araç Yap";
			this.vipBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.vipBtn.UseVisualStyleBackColor = false;
			this.vipBtn.Click += new global::System.EventHandler(this.vipBtn_Click);
			this.btnChnForm.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.btnChnForm.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.btnChnForm.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("btnChnForm.Image");
			this.btnChnForm.Location = new global::System.Drawing.Point(646, 422);
			this.btnChnForm.Name = "btnChnForm";
			this.btnChnForm.Size = new global::System.Drawing.Size(38, 32);
			this.btnChnForm.TabIndex = 24;
			this.btnChnForm.UseVisualStyleBackColor = false;
			this.btnChnForm.Click += new global::System.EventHandler(this.btnChnForm_Click);
			this.duzeltBtn.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.duzeltBtn.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.duzeltBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("duzeltBtn.Image");
			this.duzeltBtn.Location = new global::System.Drawing.Point(12, 423);
			this.duzeltBtn.Name = "duzeltBtn";
			this.duzeltBtn.Size = new global::System.Drawing.Size(125, 66);
			this.duzeltBtn.TabIndex = 24;
			this.duzeltBtn.Text = "Araç Düzelt";
			this.duzeltBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.duzeltBtn.UseVisualStyleBackColor = false;
			this.duzeltBtn.Click += new global::System.EventHandler(this.duzeltBtn_Click);
			this.odemeBariyerBtn.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.odemeBariyerBtn.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.odemeBariyerBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("odemeBariyerBtn.Image");
			this.odemeBariyerBtn.Location = new global::System.Drawing.Point(266, 423);
			this.odemeBariyerBtn.Name = "odemeBariyerBtn";
			this.odemeBariyerBtn.Size = new global::System.Drawing.Size(125, 66);
			this.odemeBariyerBtn.TabIndex = 23;
			this.odemeBariyerBtn.Text = "Ödeme Bariyer Aç";
			this.odemeBariyerBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.odemeBariyerBtn.UseVisualStyleBackColor = false;
			this.odemeBariyerBtn.Click += new global::System.EventHandler(this.odemeBariyerBtn_Click);
			this.checkZaman.AutoSize = true;
			this.checkZaman.Location = new global::System.Drawing.Point(373, 23);
			this.checkZaman.Name = "checkZaman";
			this.checkZaman.Size = new global::System.Drawing.Size(91, 17);
			this.checkZaman.TabIndex = 22;
			this.checkZaman.Text = "Zamana Göre";
			this.checkZaman.UseVisualStyleBackColor = true;
			this.exitTime.Format = global::System.Windows.Forms.DateTimePickerFormat.Time;
			this.exitTime.Location = new global::System.Drawing.Point(471, 104);
			this.exitTime.Name = "exitTime";
			this.exitTime.ShowUpDown = true;
			this.exitTime.Size = new global::System.Drawing.Size(92, 20);
			this.exitTime.TabIndex = 21;
			this.exitDate.Format = global::System.Windows.Forms.DateTimePickerFormat.Custom;
			this.exitDate.Location = new global::System.Drawing.Point(373, 104);
			this.exitDate.Name = "exitDate";
			this.exitDate.Size = new global::System.Drawing.Size(92, 20);
			this.exitDate.TabIndex = 20;
			this.label13.AutoSize = true;
			this.label13.Location = new global::System.Drawing.Point(370, 88);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(42, 13);
			this.label13.TabIndex = 19;
			this.label13.Text = "Çıkış Z.";
			this.enterTime.Format = global::System.Windows.Forms.DateTimePickerFormat.Time;
			this.enterTime.Location = new global::System.Drawing.Point(471, 63);
			this.enterTime.Name = "enterTime";
			this.enterTime.ShowUpDown = true;
			this.enterTime.Size = new global::System.Drawing.Size(92, 20);
			this.enterTime.TabIndex = 18;
			this.enterDate.Format = global::System.Windows.Forms.DateTimePickerFormat.Custom;
			this.enterDate.Location = new global::System.Drawing.Point(373, 63);
			this.enterDate.Name = "enterDate";
			this.enterDate.Size = new global::System.Drawing.Size(92, 20);
			this.enterDate.TabIndex = 17;
			this.label12.AutoSize = true;
			this.label12.Location = new global::System.Drawing.Point(370, 47);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(40, 13);
			this.label12.TabIndex = 16;
			this.label12.Text = "Giriş Z.";
			this.label11.AutoSize = true;
			this.label11.Location = new global::System.Drawing.Point(327, 136);
			this.label11.Name = "label11";
			this.label11.Size = new global::System.Drawing.Size(61, 13);
			this.label11.TabIndex = 15;
			this.label11.Text = "Araç Resmi";
			this.pictureSearch.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureSearch.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureSearch.Image");
			this.pictureSearch.Location = new global::System.Drawing.Point(329, 151);
			this.pictureSearch.Name = "pictureSearch";
			this.pictureSearch.Size = new global::System.Drawing.Size(355, 265);
			this.pictureSearch.TabIndex = 14;
			this.pictureSearch.TabStop = false;
			this.paymentBtn.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.paymentBtn.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.paymentBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("paymentBtn.Image");
			this.paymentBtn.Location = new global::System.Drawing.Point(139, 423);
			this.paymentBtn.Name = "paymentBtn";
			this.paymentBtn.Size = new global::System.Drawing.Size(125, 66);
			this.paymentBtn.TabIndex = 10;
			this.paymentBtn.Text = "Ödeme Yap";
			this.paymentBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.paymentBtn.UseVisualStyleBackColor = false;
			this.paymentBtn.Click += new global::System.EventHandler(this.paymentBtn_Click);
			this.addVehicleBtn.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.addVehicleBtn.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.addVehicleBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("addVehicleBtn.Image");
			this.addVehicleBtn.Location = new global::System.Drawing.Point(519, 423);
			this.addVehicleBtn.Name = "addVehicleBtn";
			this.addVehicleBtn.Size = new global::System.Drawing.Size(125, 66);
			this.addVehicleBtn.TabIndex = 9;
			this.addVehicleBtn.Text = "Araç Ekle";
			this.addVehicleBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.addVehicleBtn.UseVisualStyleBackColor = false;
			this.addVehicleBtn.Click += new global::System.EventHandler(this.addVehicleBtn_Click);
			this.label3.AutoSize = true;
			this.label3.Location = new global::System.Drawing.Point(9, 135);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(123, 13);
			this.label3.TabIndex = 7;
			this.label3.Text = "Bulunan İçerdeki Araçlar";
			this.listView1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.columnHeader1,
				this.columnHeader2,
				this.columnHeader3
			});
			this.listView1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.listView1.FullRowSelect = true;
			this.listView1.HideSelection = false;
			this.listView1.Location = new global::System.Drawing.Point(11, 152);
			this.listView1.Name = "listView1";
			this.listView1.Size = new global::System.Drawing.Size(312, 265);
			this.listView1.TabIndex = 3;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = global::System.Windows.Forms.View.Details;
			this.listView1.ColumnClick += new global::System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
			this.listView1.Click += new global::System.EventHandler(this.listView1_Click);
			this.columnHeader1.Text = "Plaka";
			this.columnHeader1.Width = 80;
			this.columnHeader2.Text = "Giriş Z.";
			this.columnHeader2.Width = 165;
			this.columnHeader3.Text = "K.No";
			this.columnHeader3.Width = 45;
			this.btnSearch.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.btnSearch.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.btnSearch.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("btnSearch.Image");
			this.btnSearch.ImageAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.btnSearch.Location = new global::System.Drawing.Point(601, 23);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new global::System.Drawing.Size(83, 103);
			this.btnSearch.TabIndex = 2;
			this.btnSearch.Text = "ARA";
			this.btnSearch.TextAlign = global::System.Drawing.ContentAlignment.BottomCenter;
			this.btnSearch.UseVisualStyleBackColor = false;
			this.btnSearch.Click += new global::System.EventHandler(this.btnSearch_Click);
			this.textPlate.Font = new global::System.Drawing.Font("Arial", 36f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPlate.Location = new global::System.Drawing.Point(77, 44);
			this.textPlate.Name = "textPlate";
			this.textPlate.Size = new global::System.Drawing.Size(274, 63);
			this.textPlate.TabIndex = 1;
			this.pictureBox3.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(12, 23);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(352, 103);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 0;
			this.pictureBox3.TabStop = false;
			this.panel1.BackColor = global::System.Drawing.SystemColors.GradientInactiveCaption;
			this.panel1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.Cam1);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.Time1);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.PlateText1);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.pictureEnter);
			this.panel1.Location = new global::System.Drawing.Point(6, 2);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(387, 315);
			this.panel1.TabIndex = 19;
			this.Cam1.Enabled = false;
			this.Cam1.Location = new global::System.Drawing.Point(341, 289);
			this.Cam1.Name = "Cam1";
			this.Cam1.ReadOnly = true;
			this.Cam1.Size = new global::System.Drawing.Size(27, 20);
			this.Cam1.TabIndex = 20;
			this.label6.AutoSize = true;
			this.label6.Location = new global::System.Drawing.Point(304, 292);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(31, 13);
			this.label6.TabIndex = 19;
			this.label6.Text = "Kam:";
			this.Time1.Enabled = false;
			this.Time1.Location = new global::System.Drawing.Point(199, 289);
			this.Time1.Name = "Time1";
			this.Time1.ReadOnly = true;
			this.Time1.Size = new global::System.Drawing.Size(99, 20);
			this.Time1.TabIndex = 18;
			this.label5.AutoSize = true;
			this.label5.Location = new global::System.Drawing.Point(152, 292);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(43, 13);
			this.label5.TabIndex = 17;
			this.label5.Text = "Zaman:";
			this.PlateText1.BackColor = global::System.Drawing.SystemColors.Window;
			this.PlateText1.Enabled = true;
			this.PlateText1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.PlateText1.ForeColor = global::System.Drawing.Color.Black;
			this.PlateText1.Location = new global::System.Drawing.Point(61, 289);
			this.PlateText1.Name = "PlateText1";
			this.PlateText1.ReadOnly = true;
			this.PlateText1.Size = new global::System.Drawing.Size(85, 20);
			this.PlateText1.TabIndex = 16;
			this.PlateText1.TabStop = false;
			this.label4.AutoSize = true;
			this.label4.Location = new global::System.Drawing.Point(18, 292);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(37, 13);
			this.label4.TabIndex = 15;
			this.label4.Text = "Plaka:";
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(19, 4);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(79, 13);
			this.label1.TabIndex = 14;
			this.label1.Text = "Son Giren Araç";
			this.pictureEnter.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureEnter.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureEnter.Image");
			this.pictureEnter.Location = new global::System.Drawing.Point(16, 20);
			this.pictureEnter.Name = "pictureEnter";
			this.pictureEnter.Size = new global::System.Drawing.Size(355, 265);
			this.pictureEnter.TabIndex = 13;
			this.pictureEnter.TabStop = false;
			this.panel2.BackColor = global::System.Drawing.SystemColors.GradientInactiveCaption;
			this.panel2.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.Cam2);
			this.panel2.Controls.Add(this.label7);
			this.panel2.Controls.Add(this.Time2);
			this.panel2.Controls.Add(this.label8);
			this.panel2.Controls.Add(this.PlateText2);
			this.panel2.Controls.Add(this.label9);
			this.panel2.Controls.Add(this.label2);
			this.panel2.Controls.Add(this.plate2);
			this.panel2.Location = new global::System.Drawing.Point(6, 318);
			this.panel2.Name = "panel2";
			this.panel2.Size = new global::System.Drawing.Size(387, 315);
			this.panel2.TabIndex = 20;
			this.Cam2.Enabled = false;
			this.Cam2.Location = new global::System.Drawing.Point(341, 290);
			this.Cam2.Name = "Cam2";
			this.Cam2.ReadOnly = true;
			this.Cam2.Size = new global::System.Drawing.Size(27, 20);
			this.Cam2.TabIndex = 26;
			this.label7.AutoSize = true;
			this.label7.Location = new global::System.Drawing.Point(304, 293);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(31, 13);
			this.label7.TabIndex = 25;
			this.label7.Text = "Kam:";
			this.Time2.Enabled = false;
			this.Time2.Location = new global::System.Drawing.Point(199, 290);
			this.Time2.Name = "Time2";
			this.Time2.ReadOnly = true;
			this.Time2.Size = new global::System.Drawing.Size(99, 20);
			this.Time2.TabIndex = 24;
			this.label8.AutoSize = true;
			this.label8.Location = new global::System.Drawing.Point(152, 293);
			this.label8.Name = "label8";
			this.label8.Size = new global::System.Drawing.Size(43, 13);
			this.label8.TabIndex = 23;
			this.label8.Text = "Zaman:";
			this.PlateText2.BackColor = global::System.Drawing.SystemColors.Window;
			this.PlateText2.Enabled = true;
			this.PlateText2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.PlateText2.ForeColor = global::System.Drawing.Color.Black;
			this.PlateText2.Location = new global::System.Drawing.Point(61, 290);
			this.PlateText2.Name = "PlateText2";
			this.PlateText2.ReadOnly = true;
			this.PlateText2.Size = new global::System.Drawing.Size(85, 20);
			this.PlateText2.TabIndex = 22;
			this.PlateText2.TabStop = false;
			this.label9.AutoSize = true;
			this.label9.Location = new global::System.Drawing.Point(18, 293);
			this.label9.Name = "label9";
			this.label9.Size = new global::System.Drawing.Size(37, 13);
			this.label9.TabIndex = 21;
			this.label9.Text = "Plaka:";
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(18, 4);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(81, 13);
			this.label2.TabIndex = 20;
			this.label2.Text = "Son Çıkan Araç";
			this.plate2.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.plate2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("plate2.Image");
			this.plate2.Location = new global::System.Drawing.Point(15, 21);
			this.plate2.Name = "plate2";
			this.plate2.Size = new global::System.Drawing.Size(356, 265);
			this.plate2.TabIndex = 19;
			this.plate2.TabStop = false;
			this.groupBox2.BackColor = global::System.Drawing.SystemColors.GradientInactiveCaption;
			this.groupBox2.Controls.Add(this.barkodPayBtn);
			this.groupBox2.Controls.Add(this.openBariyer);
			this.groupBox2.Controls.Add(this.label10);
			this.groupBox2.Controls.Add(this.camList);
			this.groupBox2.Location = new global::System.Drawing.Point(399, 531);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new global::System.Drawing.Size(692, 102);
			this.groupBox2.TabIndex = 21;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Elle Bariyer Kontrol";
			this.barkodPayBtn.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.barkodPayBtn.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.barkodPayBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("barkodPayBtn.Image");
			this.barkodPayBtn.Location = new global::System.Drawing.Point(519, 27);
			this.barkodPayBtn.Name = "barkodPayBtn";
			this.barkodPayBtn.Size = new global::System.Drawing.Size(165, 66);
			this.barkodPayBtn.TabIndex = 24;
			this.barkodPayBtn.Text = "Barkodlu Ödeme";
			this.barkodPayBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.barkodPayBtn.UseVisualStyleBackColor = false;
			this.barkodPayBtn.Click += new global::System.EventHandler(this.barkodPayBtn_Click);
			this.openBariyer.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.openBariyer.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.openBariyer.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("openBariyer.Image");
			this.openBariyer.Location = new global::System.Drawing.Point(311, 27);
			this.openBariyer.Name = "openBariyer";
			this.openBariyer.Size = new global::System.Drawing.Size(193, 66);
			this.openBariyer.TabIndex = 23;
			this.openBariyer.Text = "Seçilen Bariyeri Aç";
			this.openBariyer.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.openBariyer.UseVisualStyleBackColor = false;
			this.openBariyer.Click += new global::System.EventHandler(this.openBariyer_Click);
			this.label10.AutoSize = true;
			this.label10.Location = new global::System.Drawing.Point(33, 55);
			this.label10.Name = "label10";
			this.label10.Size = new global::System.Drawing.Size(39, 13);
			this.label10.TabIndex = 22;
			this.label10.Text = "Seçim:";
			this.camList.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.camList.Font = new global::System.Drawing.Font("Arial", 14.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.camList.FormattingEnabled = true;
			this.camList.Location = new global::System.Drawing.Point(78, 46);
			this.camList.Name = "camList";
			this.camList.Size = new global::System.Drawing.Size(225, 30);
			this.camList.TabIndex = 0;
			this.timer1.Interval = 1000;
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			this.panel3.Controls.Add(this.panel1);
			this.panel3.Controls.Add(this.groupBox2);
			this.panel3.Controls.Add(this.groupBox1);
			this.panel3.Controls.Add(this.panel2);
			this.panel3.Location = new global::System.Drawing.Point(0, 71);
			this.panel3.Name = "panel3";
			this.panel3.Size = new global::System.Drawing.Size(1096, 639);
			this.panel3.TabIndex = 22;
			this.OnPlateCheck.Enabled = true;
			this.OnPlateCheck.Tick += new global::System.EventHandler(this.OnPlateCheck_Tick);
			this.timer2.Interval = 1000;
			this.timer2.Tick += new global::System.EventHandler(this.timer2_Tick);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(1097, 708);
			base.Controls.Add(this.panel3);
			base.Controls.Add(this.toolStrip1);
			this.DoubleBuffered = true;
			base.Name = "Main";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "ParkPay Ana Ekran";
			base.TopMost = true;
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
			base.Load += new global::System.EventHandler(this.Main_Load);
			base.SizeChanged += new global::System.EventHandler(this.Main_SizeChanged);
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureSearch).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureEnter).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.plate2).EndInit();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.panel3.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.ToolStrip toolStrip1;

		private global::System.Windows.Forms.GroupBox groupBox1;

		private global::System.Windows.Forms.TextBox textPlate;

		private global::System.Windows.Forms.PictureBox pictureBox3;

		private global::System.Windows.Forms.Button btnSearch;

		private global::System.Windows.Forms.ListView listView1;

		private global::System.Windows.Forms.ColumnHeader columnHeader1;

		private global::System.Windows.Forms.ColumnHeader columnHeader2;

		private global::System.Windows.Forms.ColumnHeader columnHeader3;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.Panel panel1;

		private global::System.Windows.Forms.TextBox Cam1;

		private global::System.Windows.Forms.Label label6;

		private global::System.Windows.Forms.TextBox Time1;

		private global::System.Windows.Forms.Label label5;

		private global::System.Windows.Forms.TextBox PlateText1;

		private global::System.Windows.Forms.Label label4;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.PictureBox pictureEnter;

		private global::System.Windows.Forms.Panel panel2;

		private global::System.Windows.Forms.TextBox Cam2;

		private global::System.Windows.Forms.Label label7;

		private global::System.Windows.Forms.TextBox Time2;

		private global::System.Windows.Forms.Label label8;

		private global::System.Windows.Forms.TextBox PlateText2;

		private global::System.Windows.Forms.Label label9;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.PictureBox plate2;

		private global::System.Windows.Forms.ToolStripButton toolUserChange;

		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator1;

		private global::System.Windows.Forms.Button paymentBtn;

		private global::System.Windows.Forms.Button addVehicleBtn;

		private global::System.Windows.Forms.GroupBox groupBox2;

		private global::System.Windows.Forms.ComboBox camList;

		private global::System.Windows.Forms.Button openBariyer;

		private global::System.Windows.Forms.Label label10;

		private global::System.Windows.Forms.ToolStripButton toolAbonelik;

		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator2;

		private global::System.Windows.Forms.ToolStripButton toolPrgSettings;

		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator3;

		private global::System.Windows.Forms.ToolStripButton toolPrgExit;

		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator4;

		private global::System.Windows.Forms.Label label11;

		private global::System.Windows.Forms.PictureBox pictureSearch;

		private global::System.Windows.Forms.DateTimePicker enterDate;

		private global::System.Windows.Forms.Label label12;

		private global::System.Windows.Forms.DateTimePicker enterTime;

		private global::System.Windows.Forms.DateTimePicker exitTime;

		private global::System.Windows.Forms.DateTimePicker exitDate;

		private global::System.Windows.Forms.Label label13;

		private global::System.Windows.Forms.CheckBox checkZaman;

		private global::System.Windows.Forms.Timer timer1;

		private global::System.Windows.Forms.ToolStripLabel toolStripLabel1;

		private global::System.Windows.Forms.ToolStripLabel userInfo;

		private global::System.Windows.Forms.Button odemeBariyerBtn;

		private global::System.Windows.Forms.Button duzeltBtn;

		private global::System.Windows.Forms.ToolStripButton toolBrowser;

		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator5;

		private global::System.Windows.Forms.ToolStripButton toolPaymentScreen;

		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator6;

		private global::System.Windows.Forms.Panel panel3;

		private global::System.Windows.Forms.Timer OnPlateCheck;

		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator7;

		private global::System.Windows.Forms.ToolStripButton toolReporter;

		private global::System.Windows.Forms.ToolStripButton toolLogs;

		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator8;

		private global::System.Windows.Forms.Button btnChnForm;

		private global::System.Windows.Forms.Button vipBtn;

		private global::System.Windows.Forms.Button barkodPayBtn;

		private global::System.Windows.Forms.Timer timer2;
	}
}
