using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class AboneOdemeler : Form
	{
		public AboneOdemeler()
		{
			this.InitializeComponent();
		}

		private void login_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void AboneOdemeler_Load(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				DateTime now = DateTime.Now;
				string format = "yyyy-MM-dd HH:mm:ss";
				now.ToString(format);
				string text = "SELECT * FROM db_odemeler WHERE kullaniciid = " + this.MusteriID;
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				while (mySqlDataReader.Read())
				{
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = mySqlDataReader["plaka"].ToString();
					listViewItem.SubItems.Add(mySqlDataReader["tarihzaman"].ToString());
					listViewItem.SubItems.Add(mySqlDataReader["borc"].ToString());
					listViewItem.SubItems.Add(mySqlDataReader["abonesure"].ToString());
					this.listView1.Items.Add(listViewItem);
				}
				mySqlDataReader.Close();
			}
		}

		public int MusteriID;
	}
}
