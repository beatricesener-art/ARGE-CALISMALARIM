using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class Abonelik : Form
	{
		public Abonelik()
		{
			this.InitializeComponent();
		}

		private void musteriAraBtn_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				this.MusteriID = 0;
				string text = "SELECT * FROM db_musteriler WHERE kAdi LIKE '%" + this.textAdi.Text + "%'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				this.listMusteriler.Items.Clear();
				int num = 0;
				while (mySqlDataReader.Read())
				{
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = mySqlDataReader["id"].ToString();
					listViewItem.SubItems.Add(mySqlDataReader["kAdi"].ToString());
					listViewItem.SubItems.Add(mySqlDataReader["kSoyadi"].ToString());
					this.musteriIDArray[num] = int.Parse(listViewItem.Text);
					num++;
					this.listMusteriler.Items.Add(listViewItem);
				}
				mySqlDataReader.Close();
			}
		}

		private void ShowMusteriPlakalar(string musteriID)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				this.MusteriPlakaSayisi = 0;
				string text = "SELECT * FROM db_araclar WHERE kullaniciid = '" + musteriID + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				this.listPlakalar.Items.Clear();
				int num = 0;
				while (mySqlDataReader.Read())
				{
					ListViewItem listViewItem = new ListViewItem();
					try
					{
						listViewItem.Text = mySqlDataReader["id"].ToString();
						listViewItem.SubItems.Add(mySqlDataReader["plaka"].ToString());
						listViewItem.SubItems.Add(mySqlDataReader["abonelikbitis"].ToString());
						num++;
						this.listPlakalar.Items.Add(listViewItem);
					}
					catch (Exception)
					{
						listViewItem.SubItems.Add("ABONELIK YOK");
						num++;
						this.listPlakalar.Items.Add(listViewItem);
					}
				}
				mySqlDataReader.Close();
				if (num > 0)
				{
					this.MusteriPlakaSayisi = num;
				}
			}
		}

		private void listMusteriler_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (this.listMusteriler.SelectedIndices.Count > 0)
			{
				int num = this.listMusteriler.SelectedIndices[0];
				if (num >= 0)
				{
					string text = this.listMusteriler.Items[num].Text;
					this.MusteriAd = this.listMusteriler.Items[num].SubItems[1].Text;
					this.MusteriSoyad = this.listMusteriler.Items[num].SubItems[2].Text;
					this.MusteriID = int.Parse(this.listMusteriler.Items[num].Text);
					this.ShowMusteriPlakalar(text);
				}
			}
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void login_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void plakaAraBtn_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				this.MusteriID = 0;
				string text = "SELECT * FROM db_araclar WHERE kullaniciid != '' AND plaka LIKE '%" + this.textPlaka.Text + "%'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				this.listPlakalar.Items.Clear();
				while (mySqlDataReader.Read())
				{
					ListViewItem listViewItem = new ListViewItem();
					try
					{
						listViewItem.Text = mySqlDataReader["id"].ToString();
						listViewItem.SubItems.Add(mySqlDataReader["plaka"].ToString());
						listViewItem.SubItems.Add(mySqlDataReader["abonelikbitis"].ToString());
						this.listPlakalar.Items.Add(listViewItem);
					}
					catch (Exception)
					{
						listViewItem.SubItems.Add("ABONELIK YOK");
						this.listPlakalar.Items.Add(listViewItem);
					}
				}
				mySqlDataReader.Close();
			}
		}

		private void abonelikEkleBtn_Click(object sender, EventArgs e)
		{
			if (this.listPlakalar.SelectedIndices.Count <= 0)
			{
				MessageBox.Show("Abonelik için bir araç seçiniz!");
			}
			else
			{
				AbonelikUzat abonelikUzat = new AbonelikUzat();
				abonelikUzat.plate = this.plaka;
				abonelikUzat.plateId = this.selPlakaID;
				DateTime now = DateTime.Now;
				abonelikUzat.endDateTimeReal = now;
				if (this.aboneEndDateTime.IndexOf("YOK") > 0)
				{
					abonelikUzat.endDateTime = now;
				}
				else
				{
					DateTime dateTime = DateTime.ParseExact(this.aboneEndDateTime, "dd.MM.yyyy HH:mm:ss", null);
					int num = (int)now.Subtract(dateTime).TotalMinutes;
					if (num > 0)
					{
						abonelikUzat.endDateTime = now;
					}
					else
					{
						abonelikUzat.endDateTime = dateTime;
					}
					abonelikUzat.endDateTimeReal = dateTime;
				}
				abonelikUzat.musteriID = this.MusteriID;
				abonelikUzat.ShowDialog(this);
				Main main = (Main)base.Owner;
				main.ClearAdobeApp();
			}
		}

		private void ShowOwnerOfPlate(int id)
		{
			string text = "SELECT * FROM db_araclar WHERE id = " + id.ToString() + " ";
			MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
			MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
			int num = 0;
			if (mySqlDataReader.Read())
			{
				try
				{
					num = int.Parse(mySqlDataReader["kullaniciid"].ToString());
				}
				catch (Exception)
				{
					num = 0;
				}
			}
			mySqlDataReader.Close();
			text = "SELECT * FROM db_musteriler WHERE id =" + num.ToString() + " ";
			MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
			MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
			this.listMusteriler.Items.Clear();
			string text2 = "";
			if (mySqlDataReader2.Read())
			{
				ListViewItem listViewItem = new ListViewItem();
				text2 = mySqlDataReader2["id"].ToString();
				listViewItem.Text = text2;
				try
				{
					listViewItem.SubItems.Add(mySqlDataReader2["kAdi"].ToString());
					listViewItem.SubItems.Add(mySqlDataReader2["kSoyadi"].ToString());
				}
				catch (Exception)
				{
					listViewItem.SubItems.Add("");
					listViewItem.SubItems.Add("");
				}
				this.musteriIDArray[0] = int.Parse(text2);
				this.MusteriID = int.Parse(text2);
				this.listMusteriler.Items.Add(listViewItem);
			}
			mySqlDataReader2.Close();
		}

		private void listPlakalar_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (this.listPlakalar.SelectedIndices.Count > 0)
			{
				int num = this.listPlakalar.SelectedIndices[0];
				if (num >= 0)
				{
					string text = this.listPlakalar.Items[num].Text;
					this.selPlakaID = int.Parse(text);
					text = this.listPlakalar.Items[num].SubItems[1].Text;
					this.aboneEndDateTime = this.listPlakalar.Items[num].SubItems[2].Text;
					this.plaka = text;
					this.ShowOwnerOfPlate(this.selPlakaID);
				}
			}
		}

		private void musteriEkleBtn_Click(object sender, EventArgs e)
		{
			MusteriEkleDuzenle musteriEkleDuzenle = new MusteriEkleDuzenle();
			musteriEkleDuzenle.ShowDialog(this);
		}

		private void plakaEkleBtn_Click(object sender, EventArgs e)
		{
			if (this.listMusteriler.SelectedIndices.Count <= 0)
			{
				MessageBox.Show("Listede seçili müşteri olmalıdır!");
			}
			else
			{
				int num = this.listMusteriler.SelectedIndices[0];
				if (num >= 0)
				{
					new AboneAracEkleDuzenle
					{
						MusteriID = this.musteriIDArray[num],
						MusteriAd = this.MusteriAd,
						MusteriSoyad = this.MusteriSoyad
					}.ShowDialog(this);
				}
				else
				{
					MessageBox.Show("Bir Müşteri seçiniz!");
				}
			}
		}

		private void musteriDuzenleBtn_Click(object sender, EventArgs e)
		{
			if (this.MusteriID > 0)
			{
				new MusteriEkleDuzenle
				{
					MusteriID = this.MusteriID,
					Duzenle = true
				}.ShowDialog(this);
			}
		}

		private void musteriSilBtn_Click(object sender, EventArgs e)
		{
			if (this.MusteriID < 1)
			{
				MessageBox.Show("Silinecek Müşteri Seçilmeli!");
			}
			else if (this.MusteriPlakaSayisi > 0)
			{
				MessageBox.Show("Müşteri Adına Kayıtlı Plakalar Olmamalıdır!");
			}
			else
			{
				string text = "Seçilen Müşteri ID: " + this.MusteriID.ToString() + " Silinecek! Onaylıyor musunuz?";
				if (MessageBox.Show(text, "Müşteri Sil", MessageBoxButtons.YesNo) == DialogResult.Yes)
				{
					string text2 = "DELETE FROM db_musteriler WHERE id= " + this.MusteriID.ToString();
					MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					mySqlDataReader.Close();
					Main main = (Main)base.Owner;
					main.YoneticiLogEkle("Müsteri ID: " + this.MusteriID.ToString() + " Silindi! ");
					int index = this.listMusteriler.SelectedIndices[0];
					this.listMusteriler.Items[index].Remove();
					this.MusteriID = 0;
				}
			}
		}

		private void plakaDuzenleBtn_Click(object sender, EventArgs e)
		{
			if (this.listPlakalar.SelectedIndices.Count > 0)
			{
				int num = this.listPlakalar.SelectedIndices[0];
				if (num >= 0)
				{
					new AboneAracEkleDuzenle
					{
						MusteriID = this.musteriIDArray[num],
						MusteriAd = this.MusteriAd,
						MusteriSoyad = this.MusteriSoyad,
						plate = this.listPlakalar.Items[num].SubItems[1].Text,
						plateID = int.Parse(this.listPlakalar.Items[num].Text),
						Duzenle = true
					}.ShowDialog(this);
				}
			}
		}

		private void plakaSilBtn_Click(object sender, EventArgs e)
		{
			if (this.selPlakaID < 1 || this.listPlakalar.SelectedIndices.Count <= 0)
			{
				MessageBox.Show("Silinecek Plaka Seçilmeli!");
			}
			else
			{
				string text = "Seçilen Plaka: " + this.plaka + " Silinecek! Onaylıyor musunuz?";
				if (MessageBox.Show(text, "Müşteri Sil", MessageBoxButtons.YesNo) == DialogResult.Yes)
				{
					string text2 = "DELETE FROM db_araclar WHERE id= " + this.selPlakaID.ToString();
					MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					mySqlDataReader.Close();
					Main main = (Main)base.Owner;
					main.YoneticiLogEkle("Araclardan 1 Plaka: " + this.plaka + " Silindi! ");
					int index = this.listPlakalar.SelectedIndices[0];
					this.listPlakalar.Items[index].Remove();
					this.selPlakaID = 0;
				}
			}
		}

		private void Abonelik_Load(object sender, EventArgs e)
		{
			if (GlobalVar.showAbonelik == 0)
			{
				this.musteriDuzenleBtn.Enabled = false;
				this.musteriEkleBtn.Enabled = false;
				this.musteriSilBtn.Enabled = false;
				this.plakaDuzenleBtn.Enabled = false;
				this.plakaSilBtn.Enabled = false;
			}
		}

		private void odemelerBtn_Click(object sender, EventArgs e)
		{
			if (this.MusteriID > 0)
			{
				new AboneOdemeler
				{
					MusteriID = this.MusteriID
				}.ShowDialog(this);
			}
		}

		public string plaka;

		public int selPlakaID;

		public string aboneEndDateTime;

		public int[] musteriIDArray = new int[2000];

		public int MusteriID;

		public string MusteriAd = "";

		public string MusteriSoyad = "";

		public int MusteriPlakaSayisi;
	}
}
