namespace ParkPay
{
	public partial class AboneAracEkleDuzenle : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.AboneAracEkleDuzenle));
			this.textPlate = new global::System.Windows.Forms.TextBox();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.textSoyad = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.textAdi = new global::System.Windows.Forms.TextBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.cancel = new global::System.Windows.Forms.Button();
			this.login = new global::System.Windows.Forms.Button();
			this.lineShape1 = new global::Microsoft.VisualBasic.PowerPacks.LineShape();
			this.shapeContainer1 = new global::Microsoft.VisualBasic.PowerPacks.ShapeContainer();
			this.textMarka = new global::System.Windows.Forms.TextBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.textModel = new global::System.Windows.Forms.TextBox();
			this.label4 = new global::System.Windows.Forms.Label();
			this.textRenk = new global::System.Windows.Forms.TextBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.aboneSaatlik = new global::System.Windows.Forms.CheckBox();
			this.textASaat = new global::System.Windows.Forms.TextBox();
			this.label6 = new global::System.Windows.Forms.Label();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			base.SuspendLayout();
			this.textPlate.Font = new global::System.Drawing.Font("Arial", 36f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPlate.Location = new global::System.Drawing.Point(78, 34);
			this.textPlate.Name = "textPlate";
			this.textPlate.Size = new global::System.Drawing.Size(274, 63);
			this.textPlate.TabIndex = 23;
			this.pictureBox3.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(12, 12);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(352, 103);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 22;
			this.pictureBox3.TabStop = false;
			this.textSoyad.Enabled = false;
			this.textSoyad.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textSoyad.Location = new global::System.Drawing.Point(133, 160);
			this.textSoyad.Name = "textSoyad";
			this.textSoyad.ReadOnly = true;
			this.textSoyad.Size = new global::System.Drawing.Size(219, 22);
			this.textSoyad.TabIndex = 35;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label1.Location = new global::System.Drawing.Point(12, 163);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(61, 16);
			this.label1.TabIndex = 34;
			this.label1.Text = "Soyadı:";
			this.textAdi.Enabled = false;
			this.textAdi.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textAdi.Location = new global::System.Drawing.Point(133, 132);
			this.textAdi.Name = "textAdi";
			this.textAdi.ReadOnly = true;
			this.textAdi.Size = new global::System.Drawing.Size(219, 22);
			this.textAdi.TabIndex = 33;
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label2.Location = new global::System.Drawing.Point(12, 135);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(35, 16);
			this.label2.TabIndex = 32;
			this.label2.Text = "Adı:";
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(252, 340);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 47;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(133, 340);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 46;
			this.login.Text = "Ekle";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.lineShape1.BorderColor = global::System.Drawing.SystemColors.ControlDark;
			this.lineShape1.Name = "lineShape1";
			this.lineShape1.X1 = 11;
			this.lineShape1.X2 = 368;
			this.lineShape1.Y1 = 332;
			this.lineShape1.Y2 = 332;
			this.shapeContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.shapeContainer1.Margin = new global::System.Windows.Forms.Padding(0);
			this.shapeContainer1.Name = "shapeContainer1";
			this.shapeContainer1.Shapes.AddRange(new global::Microsoft.VisualBasic.PowerPacks.Shape[]
			{
				this.lineShape1
			});
			this.shapeContainer1.Size = new global::System.Drawing.Size(377, 378);
			this.shapeContainer1.TabIndex = 48;
			this.shapeContainer1.TabStop = false;
			this.textMarka.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textMarka.Location = new global::System.Drawing.Point(133, 188);
			this.textMarka.Name = "textMarka";
			this.textMarka.Size = new global::System.Drawing.Size(219, 22);
			this.textMarka.TabIndex = 50;
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label3.Location = new global::System.Drawing.Point(12, 191);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(55, 16);
			this.label3.TabIndex = 49;
			this.label3.Text = "Marka:";
			this.textModel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textModel.Location = new global::System.Drawing.Point(133, 216);
			this.textModel.Name = "textModel";
			this.textModel.Size = new global::System.Drawing.Size(219, 22);
			this.textModel.TabIndex = 52;
			this.label4.AutoSize = true;
			this.label4.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label4.Location = new global::System.Drawing.Point(12, 219);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(55, 16);
			this.label4.TabIndex = 51;
			this.label4.Text = "Model:";
			this.textRenk.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textRenk.Location = new global::System.Drawing.Point(133, 244);
			this.textRenk.Name = "textRenk";
			this.textRenk.Size = new global::System.Drawing.Size(219, 22);
			this.textRenk.TabIndex = 54;
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label5.Location = new global::System.Drawing.Point(12, 247);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(48, 16);
			this.label5.TabIndex = 53;
			this.label5.Text = "Renk:";
			this.aboneSaatlik.AutoSize = true;
			this.aboneSaatlik.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.aboneSaatlik.Location = new global::System.Drawing.Point(133, 272);
			this.aboneSaatlik.Name = "aboneSaatlik";
			this.aboneSaatlik.Size = new global::System.Drawing.Size(140, 20);
			this.aboneSaatlik.TabIndex = 55;
			this.aboneSaatlik.Text = "Saatlik Abonelik";
			this.aboneSaatlik.UseVisualStyleBackColor = true;
			this.textASaat.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textASaat.Location = new global::System.Drawing.Point(133, 294);
			this.textASaat.Name = "textASaat";
			this.textASaat.Size = new global::System.Drawing.Size(219, 22);
			this.textASaat.TabIndex = 57;
			this.label6.AutoSize = true;
			this.label6.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label6.Location = new global::System.Drawing.Point(12, 297);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(109, 16);
			this.label6.TabIndex = 56;
			this.label6.Text = "Abonelik Saat:";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(377, 378);
			base.Controls.Add(this.textASaat);
			base.Controls.Add(this.label6);
			base.Controls.Add(this.aboneSaatlik);
			base.Controls.Add(this.textRenk);
			base.Controls.Add(this.label5);
			base.Controls.Add(this.textModel);
			base.Controls.Add(this.label4);
			base.Controls.Add(this.textMarka);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.login);
			base.Controls.Add(this.textSoyad);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.textAdi);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.textPlate);
			base.Controls.Add(this.pictureBox3);
			base.Controls.Add(this.shapeContainer1);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "AboneAracEkleDuzenle";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			base.Load += new global::System.EventHandler(this.AboneAracEkleDuzenle_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.TextBox textPlate;

		private global::System.Windows.Forms.PictureBox pictureBox3;

		private global::System.Windows.Forms.TextBox textSoyad;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.TextBox textAdi;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.Button login;

		private global::Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;

		private global::Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;

		private global::System.Windows.Forms.TextBox textMarka;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.TextBox textModel;

		private global::System.Windows.Forms.Label label4;

		private global::System.Windows.Forms.TextBox textRenk;

		private global::System.Windows.Forms.Label label5;

		private global::System.Windows.Forms.CheckBox aboneSaatlik;

		private global::System.Windows.Forms.TextBox textASaat;

		private global::System.Windows.Forms.Label label6;
	}
}
