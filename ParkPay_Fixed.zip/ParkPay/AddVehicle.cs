using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PdfSharp.Drawing;
using PdfSharp.Drawing.BarCodes;
using PdfSharp.Pdf;

namespace ParkPay
{
	public partial class AddVehicle : Form
	{
		public AddVehicle()
		{
			this.InitializeComponent();
		}

		private void login_Click(object sender, EventArgs e)
		{
			this.AddVehicleToDB();
			base.Close();
		}

		private void AddVehicleToDB()
		{
			if (GlobalVar.DBConnectionStatus)
			{
				this.textPlate.Text = this.textPlate.Text.ToUpper();
				string text = "SELECT * FROM db_araclar WHERE plaka = '" + this.textPlate.Text + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				bool hasRows = mySqlDataReader.HasRows;
				mySqlDataReader.Close();
				this.enterDate.CustomFormat = "yyyy-MM-dd";
				this.enterDateTime = this.enterDate.Text + " " + this.enterTime.Text;
				int num = this.camIDArray[this.camList.SelectedIndex];
				this.barkod = DateTime.Now.ToString("MMddHHmmss");
				if (hasRows)
				{
					text = string.Concat(new string[]
					{
						"UPDATE db_araclar SET aracKonum='i' , sondegisim='",
						this.enterDateTime,
						"' , barkod='",
						this.barkod,
						"' WHERE plaka='",
						this.textPlate.Text,
						"'"
					});
				}
				else
				{
					text = string.Concat(new object[]
					{
						"INSERT INTO db_araclar (`id` ,`eklenme` ,`plaka` ,`aracKonum` ,`geciciarac` ,`sondegisim`,`soncamid` , `soncamgrupid` , `barkod` , `tipID`) VALUES (NULL , '",
						this.enterDateTime,
						"','",
						this.textPlate.Text,
						"','i',1,'",
						this.enterDateTime,
						"' , ",
						num.ToString(),
						" , 1, '",
						this.barkod,
						"' , ",
						this.tipID,
						")"
					});
				}
				MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
				mySqlDataReader2.Close();
				string text2 = "Arac Tipi:" + this.aracTipleri.Text + " - ";
				text2 += this.textDetails.Text;
				text = string.Concat(new string[]
				{
					"INSERT INTO db_loglar (`id` ,`plaka` ,`kayittarihi` ,`kameraid` ,`sebep` ,`aracKonum` , `soncamgrupid` , `sistemid`) VALUES (NULL , '",
					this.textPlate.Text,
					"','",
					this.enterDateTime,
					"',",
					num.ToString(),
					",'",
					text2,
					"','i' , 1 , '",
					GlobalVar.GlobalSistemName,
					"')"
				});
				MySqlCommand mySqlCommand3 = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader3 = mySqlCommand3.ExecuteReader();
				mySqlDataReader3.Close();
				Main main = (Main)base.Owner;
				main.YoneticiLogEkle("Araclara Plaka:" + this.textPlate.Text + " Elle Eklendi!");
			}
		}

		private void AddVehicle_Load(object sender, EventArgs e)
		{
			this.textDetails.Text = "ELLE ARAC EKLEME:";
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_aractipleri c";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				int i = 0;
				while (mySqlDataReader.Read())
				{
					this.aracTipleri.Items.Add(mySqlDataReader["tipAdi"].ToString());
					this.tipIDArray[i] = int.Parse(mySqlDataReader["tipID"].ToString());
					i++;
				}
				mySqlDataReader.Close();
				this.aracTipleri.SelectedIndex = 0;
				this.tipID = this.tipIDArray[0];
				int num = 0;
				for (i = 0; i < GlobalVar.camCount; i++)
				{
					if (GlobalVar.camDirectionArray[i] == "c")
					{
						string str = "Giriş";
						string item = "Kamera:" + (i + 1).ToString() + " Yön:" + str;
						this.camList.Items.Add(item);
						this.camIDArray[num] = i + 1;
						num++;
					}
				}
				if (this.camList.Items.Count > 0)
				{
					this.camList.SelectedIndex = 0;
				}
			}
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void aracTipleri_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.tipID = this.tipIDArray[this.aracTipleri.SelectedIndex];
		}

		private void printBtn_Click(object sender, EventArgs e)
		{
			this.AddVehicleToDB();
			int num = 200;
			int num2 = 0;
			int num3 = 30;
			int num4 = 600;
			PdfDocument pdfDocument = new PdfDocument();
			XFont xfont = new XFont("Verdana", (double)GlobalVar.FontSize1);
			XFont xfont2 = new XFont("Verdana", (double)GlobalVar.FontSize2);
			PdfPage pdfPage = pdfDocument.AddPage();
			XGraphics xgraphics = XGraphics.FromPdfPage(pdfPage);
			xgraphics.DrawBarCode(new Code3of9Standard
			{
				Text = this.barkod,
				Size = new XSize(550.0, 150.0),
				TextLocation = TextLocation.Above
			}, XBrushes.Black, new XPoint(1.0, 1.0));
			xgraphics.DrawLine(XPens.Black, 0, num - num3 + 3, num4, num - num3 + 3);
			xgraphics.DrawString(GlobalVar.Label1, xfont2, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			string text = GlobalVar.Label2;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			text = GlobalVar.Label3;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "PLAKA: " + this.textPlate.Text;
			num += num3;
			xgraphics.DrawString(text, xfont2, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "ARAÇ GIRIS ZAMANI: " + this.enterDateTime;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "ARAÇ TIPI: " + this.aracTipleri.Text;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "*** GIRIS ISLEMI ***";
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			pdfDocument.Save("payment_tempfile.pdf");
			Thread.Sleep(1000);
			Process.Start(new ProcessStartInfo
			{
				UseShellExecute = true,
				Verb = "print",
				WindowStyle = ProcessWindowStyle.Hidden,
				FileName = "payment_tempfile.pdf"
			});
			base.Close();
		}

		public int tipID;

		public int[] tipIDArray = new int[50];

		public int[] camIDArray = new int[50];

		public string enterDateTime = "";

		public string barkod = "";
	}
}
