using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ParkPay
{
	public partial class OdemeEkran : Form
	{
		public OdemeEkran()
		{
			this.InitializeComponent();
		}

		private void OdemeEkran_Load(object sender, EventArgs e)
		{
			this.panel1.Left = (base.Width - this.panel1.Width - 16) / 2;
			this.panel1.Top = (base.Height - this.panel1.Height - 40) / 2;
			this.timer1.Interval = 1000;
			this.timer1.Enabled = true;
		}

		private void OdemeEkran_SizeChanged(object sender, EventArgs e)
		{
			this.panel1.Left = (base.Width - this.panel1.Width - 16) / 2;
			this.panel1.Top = (base.Height - this.panel1.Height - 40) / 2;
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			Main main = (Main)base.Owner;
			if (!(main.paymentInfo.resimyolu == ""))
			{
				if (GlobalVar.prgType == 1)
				{
					this.ShowPicLPR(main.paymentInfo.resimyolu);
					return;
				}
				int num = main.paymentInfo.resimyolu.IndexOf("_");
				if (num > 0)
				{
					string str = string.Concat(new string[]
					{
						GlobalVar.GlobalPath,
						main.paymentInfo.resimyolu.Substring(num + 1, 4),
						"\\",
						main.paymentInfo.resimyolu.Substring(num + 5, 2),
						"\\",
						main.paymentInfo.resimyolu.Substring(num + 7, 2),
						"\\"
					});
					try
					{
						Image image;
						if (main.paymentInfo.resimyolu.IndexOf(":") > 0)
						{
							image = Image.FromFile(main.paymentInfo.resimyolu);
						}
						else
						{
							image = Image.FromFile(str + main.paymentInfo.resimyolu);
						}
						this.pictureSearch.Image = image;
						this.pictureSearch.SizeMode = PictureBoxSizeMode.StretchImage;
					}
					catch (Exception)
					{
					}
				}
			}
			this.textGZaman.Text = main.paymentInfo.giriszaman;
			DateTime now = DateTime.Now;
			string format = "dd.MM.yyyy HH:mm:ss";
			this.textCZaman.Text = now.ToString(format);
			this.textPlaka.Text = main.paymentInfo.plaka;
			this.textSure.Text = main.paymentInfo.sure;
			this.textUcret.Text = main.paymentInfo.ucret;
		}

		private void ShowPicLPR(string imgpath)
		{
			if (imgpath == "")
			{
				this.pictureSearch.Image = null;
				this.pictureSearch.SizeMode = PictureBoxSizeMode.StretchImage;
			}
			else
			{
				int num = imgpath.IndexOf("_");
				string text = string.Concat(new string[]
				{
					GlobalVar.GlobalPath,
					imgpath.Substring(num + 1, 4),
					"\\",
					imgpath.Substring(num + 5, 2),
					"\\",
					imgpath.Substring(num + 7, 2),
					"\\"
				});
				try
				{
					string imageLocation = string.Concat(new string[]
					{
						"http://",
						GlobalVar.DBInfo.serverip,
						"/pts/Resim.Goster.php?w=700&img=",
						text,
						imgpath
					});
					this.pictureSearch.ImageLocation = imageLocation;
					this.pictureSearch.SizeMode = PictureBoxSizeMode.StretchImage;
				}
				catch (Exception)
				{
				}
			}
		}
	}
}
