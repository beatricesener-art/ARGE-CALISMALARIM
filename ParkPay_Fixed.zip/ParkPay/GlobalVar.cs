using System;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	internal static class GlobalVar
	{
		public static DBInfo DBInfo
		{
			get
			{
				return GlobalVar.dbInfo;
			}
		}

		public static void SetDBValues(string dbname, string username, string password, string serverip)
		{
			GlobalVar.dbInfo.dbname = dbname;
			GlobalVar.dbInfo.password = password;
			GlobalVar.dbInfo.username = username;
			GlobalVar.dbInfo.serverip = serverip;
		}

		public static MySqlConnection conn;

		public static MySqlConnection conn2;

		public static string activeUser = "";

		public static string activeName = "";

		public static int activeId = 0;

		public static int FontSize1 = 26;

		public static int FontSize2 = 28;

		public static int PageW = 600;

		public static int PageH = 450;

		public static int BarkodW = 550;

		public static int BarkodH = 150;

		public static int TopSize = 200;

		public static int LeftSize = 0;

		public static int LineFree = 30;

		public static int LeftLine = 600;

		public static int pointID = 1;

		public static int paymentCam = 0;

		public static int bariyerCam = 1;

		public static int ucretsizSure = 15;

		public static string GlobalSistemName = "";

		public static string GlobalPath = "C:\\Resimler";

		public static string WebURL = "http://127.0.0.1/pts/";

		public static string sistemadi = "sistem";

		public static bool DBConnectionStatus = false;

		public static int[] camRelaysArray = new int[10];

		public static string[] camDirectionArray = new string[10];

		public static int camCount = 0;

		public static int securityLevel = 2;

		public static string adminPassword = "123123";

		public static int showAbonelik = 1;

		public static int showAutoPay = 0;

		private static DBInfo dbInfo;

		public static string Label1 = "OTOPARK";

		public static string Label2 = "IYI YOLCULUKLAR DILERIZ!";

		public static string Label3 = "SORUMLULUK KABUL EDILMEZ!";

		public static int DayLimit = 0;

		public static int DayLimitMin = 180;

		public static int prgType = 0;

		public static int delLogsBefore = 30;

		public static int delHour = 2;

		public static int delMinute = 0;
	}
}
