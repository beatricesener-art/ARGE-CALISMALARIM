namespace ParkPay
{
	public partial class VehicleReport : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.VehicleReport));
			this.checkZaman = new global::System.Windows.Forms.CheckBox();
			this.exitTime = new global::System.Windows.Forms.DateTimePicker();
			this.exitDate = new global::System.Windows.Forms.DateTimePicker();
			this.label13 = new global::System.Windows.Forms.Label();
			this.enterTime = new global::System.Windows.Forms.DateTimePicker();
			this.enterDate = new global::System.Windows.Forms.DateTimePicker();
			this.label12 = new global::System.Windows.Forms.Label();
			this.listView1 = new global::System.Windows.Forms.ListView();
			this.columnHeader1 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader5 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader6 = new global::System.Windows.Forms.ColumnHeader();
			this.btnSearch = new global::System.Windows.Forms.Button();
			this.textPlate = new global::System.Windows.Forms.TextBox();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.checkIcerde = new global::System.Windows.Forms.CheckBox();
			this.checkDisarda = new global::System.Windows.Forms.CheckBox();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.aracSilBtn = new global::System.Windows.Forms.Button();
			this.aracCikartBtn = new global::System.Windows.Forms.Button();
			this.aracIceriBtn = new global::System.Windows.Forms.Button();
			this.aracGTDBtn = new global::System.Windows.Forms.Button();
			this.aracPlakaDuzelt = new global::System.Windows.Forms.Button();
			this.pictureSearch = new global::System.Windows.Forms.PictureBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.checkAbone = new global::System.Windows.Forms.CheckBox();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			this.groupBox1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureSearch).BeginInit();
			base.SuspendLayout();
			this.checkZaman.AutoSize = true;
			this.checkZaman.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.checkZaman.Location = new global::System.Drawing.Point(19, 24);
			this.checkZaman.Name = "checkZaman";
			this.checkZaman.Size = new global::System.Drawing.Size(121, 20);
			this.checkZaman.TabIndex = 36;
			this.checkZaman.Text = "Zamana Göre";
			this.checkZaman.UseVisualStyleBackColor = true;
			this.exitTime.Format = global::System.Windows.Forms.DateTimePickerFormat.Time;
			this.exitTime.Location = new global::System.Drawing.Point(251, 73);
			this.exitTime.Name = "exitTime";
			this.exitTime.ShowUpDown = true;
			this.exitTime.Size = new global::System.Drawing.Size(92, 20);
			this.exitTime.TabIndex = 35;
			this.exitDate.Format = global::System.Windows.Forms.DateTimePickerFormat.Custom;
			this.exitDate.Location = new global::System.Drawing.Point(153, 73);
			this.exitDate.Name = "exitDate";
			this.exitDate.Size = new global::System.Drawing.Size(92, 20);
			this.exitDate.TabIndex = 34;
			this.label13.AutoSize = true;
			this.label13.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label13.Location = new global::System.Drawing.Point(17, 77);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(89, 16);
			this.label13.TabIndex = 33;
			this.label13.Text = "Zaman Bitiş";
			this.enterTime.Format = global::System.Windows.Forms.DateTimePickerFormat.Time;
			this.enterTime.Location = new global::System.Drawing.Point(251, 46);
			this.enterTime.Name = "enterTime";
			this.enterTime.ShowUpDown = true;
			this.enterTime.Size = new global::System.Drawing.Size(92, 20);
			this.enterTime.TabIndex = 32;
			this.enterDate.Format = global::System.Windows.Forms.DateTimePickerFormat.Custom;
			this.enterDate.Location = new global::System.Drawing.Point(153, 46);
			this.enterDate.Name = "enterDate";
			this.enterDate.Size = new global::System.Drawing.Size(92, 20);
			this.enterDate.TabIndex = 31;
			this.label12.AutoSize = true;
			this.label12.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label12.Location = new global::System.Drawing.Point(17, 50);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(128, 16);
			this.label12.TabIndex = 30;
			this.label12.Text = "Zaman Başlangıç";
			this.listView1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.columnHeader1,
				this.columnHeader2,
				this.columnHeader3,
				this.columnHeader4,
				this.columnHeader5,
				this.columnHeader6
			});
			this.listView1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.listView1.FullRowSelect = true;
			this.listView1.HideSelection = false;
			this.listView1.Location = new global::System.Drawing.Point(10, 155);
			this.listView1.Name = "listView1";
			this.listView1.Size = new global::System.Drawing.Size(654, 385);
			this.listView1.TabIndex = 26;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = global::System.Windows.Forms.View.Details;
			this.listView1.ColumnClick += new global::System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
			this.listView1.Click += new global::System.EventHandler(this.listView1_Click);
			this.columnHeader1.Text = "ID";
			this.columnHeader1.Width = 50;
			this.columnHeader2.Text = "Plaka";
			this.columnHeader2.Width = 80;
			this.columnHeader3.Text = "S. Geçiş Zamanı";
			this.columnHeader3.Width = 160;
			this.columnHeader4.Text = "Abone Mi?";
			this.columnHeader4.Width = 100;
			this.columnHeader5.Text = "Abonelik B. Tarihi";
			this.columnHeader5.Width = 165;
			this.columnHeader6.Text = "Durumu";
			this.columnHeader6.Width = 80;
			this.btnSearch.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.btnSearch.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.btnSearch.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("btnSearch.Image");
			this.btnSearch.ImageAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.btnSearch.Location = new global::System.Drawing.Point(733, 20);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new global::System.Drawing.Size(83, 103);
			this.btnSearch.TabIndex = 25;
			this.btnSearch.Text = "ARA";
			this.btnSearch.TextAlign = global::System.Drawing.ContentAlignment.BottomCenter;
			this.btnSearch.UseVisualStyleBackColor = false;
			this.btnSearch.Click += new global::System.EventHandler(this.btnSearch_Click);
			this.textPlate.Font = new global::System.Drawing.Font("Arial", 36f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPlate.Location = new global::System.Drawing.Point(75, 41);
			this.textPlate.Name = "textPlate";
			this.textPlate.Size = new global::System.Drawing.Size(274, 63);
			this.textPlate.TabIndex = 24;
			this.pictureBox3.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(10, 20);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(352, 103);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 23;
			this.pictureBox3.TabStop = false;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label1.Location = new global::System.Drawing.Point(7, 136);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(117, 16);
			this.label1.TabIndex = 77;
			this.label1.Text = "Bulunan Araçlar";
			this.checkIcerde.AutoSize = true;
			this.checkIcerde.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.checkIcerde.Location = new global::System.Drawing.Point(372, 129);
			this.checkIcerde.Name = "checkIcerde";
			this.checkIcerde.Size = new global::System.Drawing.Size(141, 20);
			this.checkIcerde.TabIndex = 79;
			this.checkIcerde.Text = " İçerdeki Araçlar";
			this.checkIcerde.UseVisualStyleBackColor = true;
			this.checkDisarda.AutoSize = true;
			this.checkDisarda.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.checkDisarda.Location = new global::System.Drawing.Point(519, 129);
			this.checkDisarda.Name = "checkDisarda";
			this.checkDisarda.Size = new global::System.Drawing.Size(148, 20);
			this.checkDisarda.TabIndex = 80;
			this.checkDisarda.Text = "Dışardaki Araçlar";
			this.checkDisarda.UseVisualStyleBackColor = true;
			this.groupBox1.Controls.Add(this.checkZaman);
			this.groupBox1.Controls.Add(this.exitTime);
			this.groupBox1.Controls.Add(this.exitDate);
			this.groupBox1.Controls.Add(this.label13);
			this.groupBox1.Controls.Add(this.enterTime);
			this.groupBox1.Controls.Add(this.enterDate);
			this.groupBox1.Controls.Add(this.label12);
			this.groupBox1.Location = new global::System.Drawing.Point(368, 14);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(359, 109);
			this.groupBox1.TabIndex = 81;
			this.groupBox1.TabStop = false;
			this.aracSilBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("aracSilBtn.Image");
			this.aracSilBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.aracSilBtn.Location = new global::System.Drawing.Point(670, 432);
			this.aracSilBtn.Name = "aracSilBtn";
			this.aracSilBtn.Size = new global::System.Drawing.Size(165, 32);
			this.aracSilBtn.TabIndex = 84;
			this.aracSilBtn.Text = "Seçilen Araçları Sil";
			this.aracSilBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.aracSilBtn.UseVisualStyleBackColor = true;
			this.aracSilBtn.Click += new global::System.EventHandler(this.aracSilBtn_Click);
			this.aracCikartBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("aracCikartBtn.Image");
			this.aracCikartBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.aracCikartBtn.Location = new global::System.Drawing.Point(670, 470);
			this.aracCikartBtn.Name = "aracCikartBtn";
			this.aracCikartBtn.Size = new global::System.Drawing.Size(165, 32);
			this.aracCikartBtn.TabIndex = 83;
			this.aracCikartBtn.Text = "Seçilen Araçları Dışarı Çıkart";
			this.aracCikartBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.aracCikartBtn.UseVisualStyleBackColor = true;
			this.aracCikartBtn.Click += new global::System.EventHandler(this.aracCikartBtn_Click);
			this.aracIceriBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("aracIceriBtn.Image");
			this.aracIceriBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.aracIceriBtn.Location = new global::System.Drawing.Point(670, 508);
			this.aracIceriBtn.Name = "aracIceriBtn";
			this.aracIceriBtn.Size = new global::System.Drawing.Size(165, 32);
			this.aracIceriBtn.TabIndex = 82;
			this.aracIceriBtn.Text = "Seçilen Araçları İçeri Al";
			this.aracIceriBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.aracIceriBtn.UseVisualStyleBackColor = true;
			this.aracIceriBtn.Click += new global::System.EventHandler(this.aracIceriBtn_Click);
			this.aracGTDBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("aracGTDBtn.Image");
			this.aracGTDBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.aracGTDBtn.Location = new global::System.Drawing.Point(841, 432);
			this.aracGTDBtn.Name = "aracGTDBtn";
			this.aracGTDBtn.Size = new global::System.Drawing.Size(165, 32);
			this.aracGTDBtn.TabIndex = 87;
			this.aracGTDBtn.Text = "Aracın Geçiş Tarihini Düzelt";
			this.aracGTDBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.aracGTDBtn.UseVisualStyleBackColor = true;
			this.aracGTDBtn.Click += new global::System.EventHandler(this.aracGTDBtn_Click);
			this.aracPlakaDuzelt.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("aracPlakaDuzelt.Image");
			this.aracPlakaDuzelt.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.aracPlakaDuzelt.Location = new global::System.Drawing.Point(841, 470);
			this.aracPlakaDuzelt.Name = "aracPlakaDuzelt";
			this.aracPlakaDuzelt.Size = new global::System.Drawing.Size(165, 32);
			this.aracPlakaDuzelt.TabIndex = 86;
			this.aracPlakaDuzelt.Text = "Seç. Aracın Plakasını Düzelt";
			this.aracPlakaDuzelt.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.aracPlakaDuzelt.UseVisualStyleBackColor = true;
			this.aracPlakaDuzelt.Click += new global::System.EventHandler(this.aracPlakaDuzelt_Click);
			this.pictureSearch.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureSearch.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureSearch.Image");
			this.pictureSearch.Location = new global::System.Drawing.Point(670, 155);
			this.pictureSearch.Name = "pictureSearch";
			this.pictureSearch.Size = new global::System.Drawing.Size(336, 265);
			this.pictureSearch.TabIndex = 88;
			this.pictureSearch.TabStop = false;
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label2.Location = new global::System.Drawing.Point(862, 133);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(144, 16);
			this.label2.TabIndex = 89;
			this.label2.Text = "Seçilen Araç Resmi";
			this.checkAbone.AutoSize = true;
			this.checkAbone.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.checkAbone.Location = new global::System.Drawing.Point(668, 129);
			this.checkAbone.Name = "checkAbone";
			this.checkAbone.Size = new global::System.Drawing.Size(126, 20);
			this.checkAbone.TabIndex = 90;
			this.checkAbone.Text = "Abone Araçlar";
			this.checkAbone.UseVisualStyleBackColor = true;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(1011, 552);
			base.Controls.Add(this.checkAbone);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.pictureSearch);
			base.Controls.Add(this.aracGTDBtn);
			base.Controls.Add(this.aracPlakaDuzelt);
			base.Controls.Add(this.aracSilBtn);
			base.Controls.Add(this.aracCikartBtn);
			base.Controls.Add(this.aracIceriBtn);
			base.Controls.Add(this.groupBox1);
			base.Controls.Add(this.checkDisarda);
			base.Controls.Add(this.checkIcerde);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.listView1);
			base.Controls.Add(this.btnSearch);
			base.Controls.Add(this.textPlate);
			base.Controls.Add(this.pictureBox3);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "VehicleReport";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Araç İşlemleri";
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureSearch).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.CheckBox checkZaman;

		private global::System.Windows.Forms.DateTimePicker exitTime;

		private global::System.Windows.Forms.DateTimePicker exitDate;

		private global::System.Windows.Forms.Label label13;

		private global::System.Windows.Forms.DateTimePicker enterTime;

		private global::System.Windows.Forms.DateTimePicker enterDate;

		private global::System.Windows.Forms.Label label12;

		private global::System.Windows.Forms.ListView listView1;

		private global::System.Windows.Forms.ColumnHeader columnHeader1;

		private global::System.Windows.Forms.ColumnHeader columnHeader2;

		private global::System.Windows.Forms.ColumnHeader columnHeader3;

		private global::System.Windows.Forms.Button btnSearch;

		private global::System.Windows.Forms.TextBox textPlate;

		private global::System.Windows.Forms.PictureBox pictureBox3;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.CheckBox checkIcerde;

		private global::System.Windows.Forms.CheckBox checkDisarda;

		private global::System.Windows.Forms.GroupBox groupBox1;

		private global::System.Windows.Forms.Button aracSilBtn;

		private global::System.Windows.Forms.Button aracCikartBtn;

		private global::System.Windows.Forms.Button aracIceriBtn;

		private global::System.Windows.Forms.Button aracGTDBtn;

		private global::System.Windows.Forms.Button aracPlakaDuzelt;

		private global::System.Windows.Forms.ColumnHeader columnHeader4;

		private global::System.Windows.Forms.ColumnHeader columnHeader5;

		private global::System.Windows.Forms.ColumnHeader columnHeader6;

		private global::System.Windows.Forms.PictureBox pictureSearch;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.CheckBox checkAbone;
	}
}
