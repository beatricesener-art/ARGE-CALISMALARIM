using System;

namespace ParkPay
{
	internal struct DBInfo
	{
		public string serverip;

		public string username;

		public string password;

		public string dbname;
	}
}
