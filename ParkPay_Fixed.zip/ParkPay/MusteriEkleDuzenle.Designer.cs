namespace ParkPay
{
	public partial class MusteriEkleDuzenle : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.MusteriEkleDuzenle));
			this.textAdi = new global::System.Windows.Forms.TextBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.textSoyad = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.textSifre = new global::System.Windows.Forms.TextBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.textEmail = new global::System.Windows.Forms.TextBox();
			this.label4 = new global::System.Windows.Forms.Label();
			this.textCeptel = new global::System.Windows.Forms.TextBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.textTel = new global::System.Windows.Forms.TextBox();
			this.label6 = new global::System.Windows.Forms.Label();
			this.textArac = new global::System.Windows.Forms.TextBox();
			this.label7 = new global::System.Windows.Forms.Label();
			this.textIndirim = new global::System.Windows.Forms.TextBox();
			this.label8 = new global::System.Windows.Forms.Label();
			this.cancel = new global::System.Windows.Forms.Button();
			this.login = new global::System.Windows.Forms.Button();
			this.lineShape1 = new global::Microsoft.VisualBasic.PowerPacks.LineShape();
			this.shapeContainer1 = new global::Microsoft.VisualBasic.PowerPacks.ShapeContainer();
			base.SuspendLayout();
			this.textAdi.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textAdi.Location = new global::System.Drawing.Point(203, 23);
			this.textAdi.Name = "textAdi";
			this.textAdi.Size = new global::System.Drawing.Size(174, 22);
			this.textAdi.TabIndex = 29;
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label2.Location = new global::System.Drawing.Point(25, 26);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(35, 16);
			this.label2.TabIndex = 28;
			this.label2.Text = "Adı:";
			this.textSoyad.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textSoyad.Location = new global::System.Drawing.Point(203, 51);
			this.textSoyad.Name = "textSoyad";
			this.textSoyad.Size = new global::System.Drawing.Size(174, 22);
			this.textSoyad.TabIndex = 31;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label1.Location = new global::System.Drawing.Point(25, 54);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(61, 16);
			this.label1.TabIndex = 30;
			this.label1.Text = "Soyadı:";
			this.textSifre.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textSifre.Location = new global::System.Drawing.Point(203, 107);
			this.textSifre.Name = "textSifre";
			this.textSifre.Size = new global::System.Drawing.Size(174, 22);
			this.textSifre.TabIndex = 35;
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label3.Location = new global::System.Drawing.Point(25, 110);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(56, 16);
			this.label3.TabIndex = 34;
			this.label3.Text = "Şifresi:";
			this.textEmail.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textEmail.Location = new global::System.Drawing.Point(203, 79);
			this.textEmail.Name = "textEmail";
			this.textEmail.Size = new global::System.Drawing.Size(174, 22);
			this.textEmail.TabIndex = 33;
			this.label4.AutoSize = true;
			this.label4.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label4.Location = new global::System.Drawing.Point(25, 82);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(100, 16);
			this.label4.TabIndex = 32;
			this.label4.Text = "Email Adresi:";
			this.textCeptel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textCeptel.Location = new global::System.Drawing.Point(203, 163);
			this.textCeptel.Name = "textCeptel";
			this.textCeptel.Size = new global::System.Drawing.Size(174, 22);
			this.textCeptel.TabIndex = 39;
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label5.Location = new global::System.Drawing.Point(25, 166);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(67, 16);
			this.label5.TabIndex = 38;
			this.label5.Text = "Cep Tel:";
			this.textTel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textTel.Location = new global::System.Drawing.Point(203, 135);
			this.textTel.Name = "textTel";
			this.textTel.Size = new global::System.Drawing.Size(174, 22);
			this.textTel.TabIndex = 37;
			this.label6.AutoSize = true;
			this.label6.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label6.Location = new global::System.Drawing.Point(25, 138);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(75, 16);
			this.label6.TabIndex = 36;
			this.label6.Text = "Sabit Tel:";
			this.textArac.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textArac.Location = new global::System.Drawing.Point(203, 191);
			this.textArac.Name = "textArac";
			this.textArac.Size = new global::System.Drawing.Size(174, 22);
			this.textArac.TabIndex = 41;
			this.label7.AutoSize = true;
			this.label7.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label7.Location = new global::System.Drawing.Point(25, 194);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(169, 16);
			this.label7.TabIndex = 40;
			this.label7.Text = "İçerde Bul. Araç Sayısı:";
			this.textIndirim.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textIndirim.Location = new global::System.Drawing.Point(203, 219);
			this.textIndirim.Name = "textIndirim";
			this.textIndirim.Size = new global::System.Drawing.Size(174, 22);
			this.textIndirim.TabIndex = 43;
			this.label8.AutoSize = true;
			this.label8.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label8.Location = new global::System.Drawing.Point(25, 222);
			this.label8.Name = "label8";
			this.label8.Size = new global::System.Drawing.Size(94, 16);
			this.label8.TabIndex = 42;
			this.label8.Text = "Üye İndirimi:";
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(271, 284);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 45;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(152, 284);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 44;
			this.login.Text = "Ekle";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.lineShape1.BorderColor = global::System.Drawing.SystemColors.ControlDark;
			this.lineShape1.Name = "lineShape1";
			this.lineShape1.X1 = 30;
			this.lineShape1.X2 = 387;
			this.lineShape1.Y1 = 271;
			this.lineShape1.Y2 = 271;
			this.shapeContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.shapeContainer1.Margin = new global::System.Windows.Forms.Padding(0);
			this.shapeContainer1.Name = "shapeContainer1";
			this.shapeContainer1.Shapes.AddRange(new global::Microsoft.VisualBasic.PowerPacks.Shape[]
			{
				this.lineShape1
			});
			this.shapeContainer1.Size = new global::System.Drawing.Size(404, 324);
			this.shapeContainer1.TabIndex = 46;
			this.shapeContainer1.TabStop = false;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(404, 324);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.login);
			base.Controls.Add(this.textIndirim);
			base.Controls.Add(this.label8);
			base.Controls.Add(this.textArac);
			base.Controls.Add(this.label7);
			base.Controls.Add(this.textCeptel);
			base.Controls.Add(this.label5);
			base.Controls.Add(this.textTel);
			base.Controls.Add(this.label6);
			base.Controls.Add(this.textSifre);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.textEmail);
			base.Controls.Add(this.label4);
			base.Controls.Add(this.textSoyad);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.textAdi);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.shapeContainer1);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "MusteriEkleDuzenle";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			base.Load += new global::System.EventHandler(this.MusteriEkleDuzenle_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.TextBox textAdi;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.TextBox textSoyad;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.TextBox textSifre;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.TextBox textEmail;

		private global::System.Windows.Forms.Label label4;

		private global::System.Windows.Forms.TextBox textCeptel;

		private global::System.Windows.Forms.Label label5;

		private global::System.Windows.Forms.TextBox textTel;

		private global::System.Windows.Forms.Label label6;

		private global::System.Windows.Forms.TextBox textArac;

		private global::System.Windows.Forms.Label label7;

		private global::System.Windows.Forms.TextBox textIndirim;

		private global::System.Windows.Forms.Label label8;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.Button login;

		private global::Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;

		private global::Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
	}
}
