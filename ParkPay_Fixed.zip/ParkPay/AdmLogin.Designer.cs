namespace ParkPay
{
	public partial class AdmLogin : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.AdmLogin));
			this.textadminPass = new global::System.Windows.Forms.TextBox();
			this.label4 = new global::System.Windows.Forms.Label();
			this.lineShape1 = new global::Microsoft.VisualBasic.PowerPacks.LineShape();
			this.shapeContainer1 = new global::Microsoft.VisualBasic.PowerPacks.ShapeContainer();
			this.cancel = new global::System.Windows.Forms.Button();
			this.login = new global::System.Windows.Forms.Button();
			base.SuspendLayout();
			this.textadminPass.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textadminPass.Location = new global::System.Drawing.Point(131, 22);
			this.textadminPass.Name = "textadminPass";
			this.textadminPass.PasswordChar = '*';
			this.textadminPass.Size = new global::System.Drawing.Size(148, 22);
			this.textadminPass.TabIndex = 23;
			this.label4.AutoSize = true;
			this.label4.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label4.Location = new global::System.Drawing.Point(23, 25);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(91, 16);
			this.label4.TabIndex = 22;
			this.label4.Text = "Admin Şifre:";
			this.lineShape1.BorderColor = global::System.Drawing.SystemColors.ControlDark;
			this.lineShape1.Name = "lineShape1";
			this.lineShape1.X1 = 23;
			this.lineShape1.X2 = 290;
			this.lineShape1.Y1 = 62;
			this.lineShape1.Y2 = 62;
			this.shapeContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.shapeContainer1.Margin = new global::System.Windows.Forms.Padding(0);
			this.shapeContainer1.Name = "shapeContainer1";
			this.shapeContainer1.Shapes.AddRange(new global::Microsoft.VisualBasic.PowerPacks.Shape[]
			{
				this.lineShape1
			});
			this.shapeContainer1.Size = new global::System.Drawing.Size(307, 123);
			this.shapeContainer1.TabIndex = 24;
			this.shapeContainer1.TabStop = false;
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(166, 79);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 26;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(47, 79);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 25;
			this.login.Text = "Tamam";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(307, 123);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.login);
			base.Controls.Add(this.textadminPass);
			base.Controls.Add(this.label4);
			base.Controls.Add(this.shapeContainer1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "AdmLogin";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Admin Giriş";
			base.TopMost = true;
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.TextBox textadminPass;

		private global::System.Windows.Forms.Label label4;

		private global::Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;

		private global::Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.Button login;
	}
}
