using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;
using PdfSharp.Drawing;
using PdfSharp.Drawing.BarCodes;
using PdfSharp.Pdf;

namespace ParkPay
{
	public partial class BarkodPayment : Form
	{
		public BarkodPayment()
		{
			this.InitializeComponent();
		}

		private void BarkodPayment_Load(object sender, EventArgs e)
		{
			if (this.odemeileBariyer)
			{
				this.camList.Visible = true;
				this.label6.Visible = true;
			}
			if (this.odemeileBariyer)
			{
				this.textDetails.Text = "BARKODLU BARIYER NOKTASI:";
			}
			else
			{
				this.textDetails.Text = "BARKODLU ÖDEME NOKTASI:";
			}
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_aractipleri ORDER by tipID ASC";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				int num = 0;
				try
				{
					while (mySqlDataReader.Read())
					{
						this.aracTipleri.Items.Add(mySqlDataReader["tipAdi"].ToString());
						this.tipIDArray[num] = int.Parse(mySqlDataReader["tipID"].ToString());
						num++;
					}
				}
				catch (Exception)
				{
					MessageBox.Show("hata:100001");
				}
				mySqlDataReader.Close();
			}
		}

		private void login_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				if (this.odemeileBariyer && this.camList.SelectedIndex < 0)
				{
					MessageBox.Show("Çıkış Bariyeri Seçmelisiniz!", "Uyarı");
				}
				else
				{
					string text;
					if (this.odemeileBariyer)
					{
						text = string.Concat(new string[]
						{
							"UPDATE db_araclar SET vale_arac=0 , odeme_durum=0 , aracKonum = 'd' , sondegisim='",
							this.exitDateTime2,
							"' WHERE plaka='",
							this.textPlate.Text,
							"'"
						});
					}
					else
					{
						text = string.Concat(new string[]
						{
							"UPDATE db_araclar SET vale_arac=0 , odeme_durum=1 , sondegisim='",
							this.exitDateTime2,
							"' WHERE plaka='",
							this.textPlate.Text,
							"'"
						});
					}
					MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					mySqlDataReader.Close();
					double num = 0.0;
					if (this.paymentCheck.Checked)
					{
						num = this.t_payment;
					}
					string text2 = num.ToString();
					text2 = text2.Replace(",", ".");
					text = string.Concat(new object[]
					{
						"INSERT INTO db_odemeler (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`,`plaka` , `abonesure` , `operatorid` , `pointID` ) VALUES (NULL , '0', '",
						num,
						"','",
						num,
						"','",
						this.exitDateTime2,
						"','",
						this.tipID,
						"','",
						this.textPlate.Text,
						"' , 0 , ",
						GlobalVar.activeId,
						" , ",
						GlobalVar.pointID,
						")"
					});
					MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
					mySqlDataReader2.Close();
					string str;
					if (this.paymentCheck.Checked)
					{
						str = "ÖDEME YAPILDI:" + this.t_payment.ToString() + " TL - ";
					}
					else
					{
						str = "ÖDEME YAPILMADI!:" + this.t_payment.ToString() + " TL - ";
					}
					str = str + "Arac Tipi:" + this.aracTipleri.Text + " - ";
					string text3 = str + this.textDetails.Text;
					int num2 = GlobalVar.paymentCam;
					if (this.odemeileBariyer)
					{
						num2 = this.camIDArray[this.camList.SelectedIndex];
					}
					text = string.Concat(new object[]
					{
						"INSERT INTO db_loglar (`id` ,`plaka` ,`kayittarihi` ,`kameraid` ,`sebep` ,`aracKonum` , `soncamgrupid` , `sistemid`) VALUES (NULL , '",
						this.textPlate.Text,
						"','",
						this.exitDateTime2,
						"',",
						num2,
						",'",
						text3,
						"','d' , 1 , '",
						GlobalVar.GlobalSistemName,
						"')"
					});
					MySqlCommand mySqlCommand3 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader3 = mySqlCommand3.ExecuteReader();
					mySqlDataReader3.Close();
					if (this.odemeileBariyer)
					{
						Main main = (Main)base.Owner;
						if (this.camList.SelectedIndex > -1)
						{
							main.OpenBariyer(this.camList.SelectedIndex);
						}
						GlobalVar.bariyerCam = this.camList.SelectedIndex + 1;
					}
					base.Close();
				}
			}
		}

		private void SendToScreen()
		{
			Main main = (Main)base.Owner;
			main.paymentInfo.giriszaman = this.enterDateTimeText.Text;
			main.paymentInfo.sure = this.textMinutes.Text;
			main.paymentInfo.ucret = this.textPayment.Text;
			main.paymentInfo.plaka = this.textPlate.Text;
			string text = this.enterDateTimeText.Text;
			if (text.Length > 8)
			{
				text = text.Substring(text.Length - 8, 8);
			}
			main.SentToLedScreen(this.textPayment.Text, text, this.textPlate.Text);
		}

		private void plakaAraBtn_Click(object sender, EventArgs e)
		{
			this.UcretGoster();
		}

		private void UcretGoster()
		{
			if (this.textBarkod.Text.Length < 1)
			{
				MessageBox.Show("Barkod Giriniz...");
			}
			else
			{
				string text = this.textBarkod.Text;
				int num = 0;
				string text2 = "SELECT * FROM db_araclar WHERE barkod = '" + text + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				string a = "";
				bool flag = false;
				if (mySqlDataReader.Read())
				{
					flag = true;
					a = mySqlDataReader["odeme_durum"].ToString();
					this.textPlate.Text = mySqlDataReader["plaka"].ToString();
					num = int.Parse(mySqlDataReader["tipID"].ToString());
					this.enterDateTime = mySqlDataReader["sondegisim"].ToString();
					if (num < 1)
					{
						num = 1;
						this.ucretliAbone = 1;
					}
				}
				mySqlDataReader.Close();
				this.enterDateTimeText.Text = this.enterDateTime;
				if (flag)
				{
					for (int i = 0; i < 50; i++)
					{
						if (this.tipIDArray[i] == num)
						{
							this.aracTipleri.SelectedIndex = i;
							break;
						}
					}
					if (a == "1")
					{
						this.payStatusText.Text = "Ödemesi Yapılmış!";
						this.odemeStatus = true;
					}
					int num2 = 0;
					for (int i = 0; i < GlobalVar.camCount; i++)
					{
						if (!(GlobalVar.camDirectionArray[i] == "c"))
						{
							string str = "Çıkış";
							string item = "Kamera:" + (i + 1).ToString() + " Yön:" + str;
							this.camIDArray[num2] = i + 1;
							num2++;
							this.camList.Items.Add(item);
						}
					}
					this.SendToScreen();
					if (this.odemeileBariyer && this.camList.Items.Count >= GlobalVar.bariyerCam)
					{
						this.camList.SelectedIndex = GlobalVar.bariyerCam - 1;
					}
				}
			}
		}

		private void aracTipleri_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.tipID = this.tipIDArray[this.aracTipleri.SelectedIndex];
			this.CalculatePayment();
		}

		private void CalculatePayment()
		{
			if (GlobalVar.DBConnectionStatus)
			{
				DateTime now = DateTime.Now;
				string format = "dd.MM.yyyy HH:mm:ss";
				string format2 = "yyyy-MM-dd HH:mm:ss";
				this.exitDateTime = now.ToString(format);
				this.exitDateTime2 = now.ToString(format2);
				DateTime value = DateTime.Parse(this.enterDateTime);
				int num = (int)now.Subtract(value).TotalMinutes;
				this.textMinutes.Text = num.ToString();
				this.t_minues = num;
				if (GlobalVar.ucretsizSure - num >= 0 && this.odemeStatus)
				{
					double num2 = 0.0;
					this.textPayment.Text = num2.ToString();
					this.t_payment = num2;
				}
				else
				{
					string text = "SELECT * FROM db_araclar WHERE plaka = '" + this.textPlate.Text + "'";
					MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					int num3 = 0;
					string s = "";
					string s2 = "";
					int num4 = 0;
					string s3 = "";
					bool flag = false;
					if (mySqlDataReader.Read())
					{
						s = mySqlDataReader["abonelikTipi"].ToString();
						s2 = mySqlDataReader["AbonelikSaat"].ToString();
						try
						{
							s3 = mySqlDataReader["abonelikbitis"].ToString();
							flag = true;
						}
						catch (Exception)
						{
							s3 = this.exitDateTime;
						}
					}
					mySqlDataReader.Close();
					try
					{
						num3 = int.Parse(s);
						num4 = int.Parse(s2);
					}
					catch (Exception)
					{
						num3 = 0;
						num4 = 0;
					}
					DateTime value2 = DateTime.ParseExact(s3, "dd.MM.yyyy HH:mm:ss", null);
					int num5 = (int)now.Subtract(value2).TotalMinutes;
					if (num3 > 0 && num5 < 0)
					{
						this.t_minues -= num4 * 60;
						if (this.t_minues < 0)
						{
							this.t_minues = 0;
							this.textPayment.Text = "0";
							this.t_payment = 0.0;
							this.InfoText.Text = "Saatlik Abone Araç. Süresi Var! Ücretsiz!";
							return;
						}
						num = this.t_minues;
						this.textMinutes.Text = num.ToString();
						this.InfoText.Text = "Saatlik Abone Araç. Saati Dolmuş, Ücret Ödeyecek!";
					}
					int num6 = 0;
					bool flag2 = false;
					int chargeMinutes = ParkingDurationRule.GetChargeMinutes(this.textPlate.Text, num, out num6, out flag2);
					this.textMinEk.Text = num6.ToString();
					if (flag2)
					{
						this.textDetails.Text = this.textDetails.Text + "-TICARI TAKSI: 24DK UCRETSIZ / GUNLUK TOPLAM YOK-";
					}
					else if (num6 > 0)
					{
						this.textDetails.Text = this.textDetails.Text + "-GUNLUK ONCEKI:" + num6.ToString() + "DK-";
					}
					num = chargeMinutes;
					if (ParkingDurationRule.IsFree(num))
					{
						this.textPayment.Text = "0";
						this.t_payment = 0.0;
						this.SendToScreen();
					}
					else
					{
						if (this.ucretliAbone == 1)
						{
							this.textDetails.Text = this.textDetails.Text + "-UCRETLI ABONE-";
						}
						if (flag && this.ucretliAbone == 0)
						{
							int num7 = (int)value2.Subtract(value).TotalMinutes;
							if (num7 > 0)
							{
								num -= num7;
								this.textMinutes.Text = num.ToString();
							}
						}
						text = string.Concat(new string[]
						{
							"SELECT * FROM db_fiyatlar WHERE tipID=",
							this.tipID.ToString(),
							" AND baslangic <= ",
							num.ToString(),
							" AND bitis > ",
							num.ToString(),
							" "
						});
						MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
						MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
						int num8 = 0;
						double num9 = 0.0;
						int num10 = 0;
						if (mySqlDataReader2.Read())
						{
							try
							{
								int.Parse(mySqlDataReader2["id"].ToString());
								if (mySqlDataReader2["sistemli"].ToString() == "e")
								{
									num8 = 1;
								}
								else
								{
									num8 = 0;
								}
								num9 = double.Parse(mySqlDataReader2["ucret"].ToString());
								num10 = int.Parse(mySqlDataReader2["carpan"].ToString());
							}
							catch (Exception)
							{
								MessageBox.Show("Hata:12001");
							}
						}
						mySqlDataReader2.Close();
						double num2;
						if (num8 == 0)
						{
							num2 = num9;
						}
						else
						{
							num2 = Math.Ceiling((double)num / (double)num10);
							num2 *= num9;
						}
						this.textPayment.Text = num2.ToString();
						this.t_payment = num2;
						if (this.t_payment > 0.0 && !this.feeAlertPlayed)
						{
							this.feeAlertPlayed = true;
							FeeAlertSound.PlayTwoSeconds();
						}
						this.SendToScreen();
					}
				}
			}
		}

		private int GunlukHareketVarMi()
		{
			DateTime now = DateTime.Now;
			string format = "yyyy-MM-dd";
			string text = now.ToString(format);
			string text2 = string.Concat(new string[]
			{
				"SELECT * FROM db_loglar WHERE plaka = '",
				this.textPlate.Text,
				"' AND kayittarihi>'",
				text,
				" 00:00:00' AND kayittarihi<'",
				text,
				" 23:59:59' order by `kayittarihi` ASC "
			});
			MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
			MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
			int num = 0;
			string[] array = new string[50];
			string[] array2 = new string[50];
			while (mySqlDataReader.Read())
			{
				array[num] = mySqlDataReader["kayittarihi"].ToString();
				array2[num] = mySqlDataReader["aracKonum"].ToString();
				num++;
			}
			mySqlDataReader.Close();
			int num2 = 0;
			if (num > 1)
			{
				for (int i = 0; i < num - 1; i++)
				{
					if (array2[i] == "i" && array2[i + 1] == "d")
					{
						DateTime value = DateTime.Parse(array[i]);
						int num3 = (int)DateTime.Parse(array[i + 1]).Subtract(value).TotalMinutes;
						num2 += num3;
					}
				}
			}
			if (num2 > GlobalVar.DayLimitMin)
			{
				num2 = GlobalVar.DayLimitMin;
			}
			return num2;
		}

		private void textBarkod_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return)
			{
				this.UcretGoster();
			}
		}

		private void printBtn_Click(object sender, EventArgs e)
		{
			int num = GlobalVar.TopSize;
			int leftSize = GlobalVar.LeftSize;
			int lineFree = GlobalVar.LineFree;
			int leftLine = GlobalVar.LeftLine;
			PdfDocument pdfDocument = new PdfDocument();
			XFont xfont = new XFont("Verdana", (double)GlobalVar.FontSize1);
			XFont xfont2 = new XFont("Verdana", (double)GlobalVar.FontSize2);
			PdfPage pdfPage = pdfDocument.AddPage();
			pdfPage.Width = GlobalVar.PageW;
			pdfPage.Height = GlobalVar.PageH;
			XGraphics xgraphics = XGraphics.FromPdfPage(pdfPage);
			xgraphics.DrawBarCode(new Code3of9Standard
			{
				Text = this.textBarkod.Text,
				Size = new XSize((double)GlobalVar.BarkodW, (double)GlobalVar.BarkodH),
				TextLocation = TextLocation.Above
			}, XBrushes.Black, new XPoint(1.0, 1.0));
			xgraphics.DrawLine(XPens.Black, 0, num - lineFree + 3, leftLine, num - lineFree + 3);
			xgraphics.DrawString(GlobalVar.Label1, xfont2, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			string text = GlobalVar.Label2;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = GlobalVar.Label3;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "PLAKA/KART: " + this.textPlate.Text;
			num += lineFree;
			xgraphics.DrawString(text, xfont2, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "ARAÇ GIRIS ZAMANI: " + this.enterDateTime;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = "ARAÇ CIKIS ZAMANI: " + this.exitDateTime;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = string.Concat(new string[]
			{
				"SÜRE: ",
				this.t_minues.ToString(),
				" dk - EK SÜRE: ",
				this.textMinEk.Text,
				" dk"
			});
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "ÜCRET: " + this.t_payment.ToString() + " TL";
			num += lineFree;
			xgraphics.DrawString(text, xfont2, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			pdfDocument.Save("payment_tempfile.pdf");
			Thread.Sleep(1000);
			Process.Start(new ProcessStartInfo
			{
				UseShellExecute = true,
				Verb = "print",
				WindowStyle = ProcessWindowStyle.Hidden,
				FileName = "payment_tempfile.pdf"
			});
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		public bool odemeileBariyer = true;

		public int[] tipIDArray = new int[50];

		public int[] camIDArray = new int[50];

		public int tipID;

		public int ucretliAbone;

		public bool odemeStatus;

		public string exitDateTime;

		public string exitDateTime2;

		public string enterDateTime;

		public int t_minues;

		public double t_payment;

		private bool feeAlertPlayed;
	}
}
