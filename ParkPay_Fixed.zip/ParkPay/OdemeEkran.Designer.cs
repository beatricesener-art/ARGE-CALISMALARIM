namespace ParkPay
{
	public partial class OdemeEkran : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.OdemeEkran));
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.label7 = new global::System.Windows.Forms.Label();
			this.textUcret = new global::System.Windows.Forms.TextBox();
			this.label6 = new global::System.Windows.Forms.Label();
			this.textSure = new global::System.Windows.Forms.TextBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.textCZaman = new global::System.Windows.Forms.TextBox();
			this.label4 = new global::System.Windows.Forms.Label();
			this.textGZaman = new global::System.Windows.Forms.TextBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.textPlaka = new global::System.Windows.Forms.TextBox();
			this.pictureSearch = new global::System.Windows.Forms.PictureBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureSearch).BeginInit();
			base.SuspendLayout();
			this.panel1.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.panel1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.label7);
			this.panel1.Controls.Add(this.textUcret);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.textSure);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.textCZaman);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.textGZaman);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.textPlaka);
			this.panel1.Controls.Add(this.pictureSearch);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new global::System.Drawing.Point(3, 5);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(1014, 636);
			this.panel1.TabIndex = 0;
			this.label7.AutoSize = true;
			this.label7.Font = new global::System.Drawing.Font("Calibri", 24f, global::System.Drawing.FontStyle.Bold);
			this.label7.Location = new global::System.Drawing.Point(458, 15);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(163, 39);
			this.label7.TabIndex = 25;
			this.label7.Text = "Araç Resmi";
			this.textUcret.Enabled = false;
			this.textUcret.Font = new global::System.Drawing.Font("Calibri", 72f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textUcret.Location = new global::System.Drawing.Point(465, 490);
			this.textUcret.Name = "textUcret";
			this.textUcret.Size = new global::System.Drawing.Size(303, 125);
			this.textUcret.TabIndex = 24;
			this.label6.AutoSize = true;
			this.label6.Font = new global::System.Drawing.Font("Calibri", 48f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label6.Location = new global::System.Drawing.Point(147, 523);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(291, 78);
			this.label6.TabIndex = 23;
			this.label6.Text = "Ücret (TL)";
			this.textSure.Enabled = false;
			this.textSure.Font = new global::System.Drawing.Font("Calibri", 24f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textSure.Location = new global::System.Drawing.Point(184, 284);
			this.textSure.Name = "textSure";
			this.textSure.Size = new global::System.Drawing.Size(275, 47);
			this.textSure.TabIndex = 22;
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Calibri", 24f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label5.Location = new global::System.Drawing.Point(6, 292);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(135, 39);
			this.label5.TabIndex = 21;
			this.label5.Text = "Süre (dk)";
			this.textCZaman.Enabled = false;
			this.textCZaman.Font = new global::System.Drawing.Font("Calibri", 24f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textCZaman.Location = new global::System.Drawing.Point(184, 231);
			this.textCZaman.Name = "textCZaman";
			this.textCZaman.Size = new global::System.Drawing.Size(275, 47);
			this.textCZaman.TabIndex = 20;
			this.label4.AutoSize = true;
			this.label4.Font = new global::System.Drawing.Font("Calibri", 24f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label4.Location = new global::System.Drawing.Point(6, 234);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(175, 39);
			this.label4.TabIndex = 19;
			this.label4.Text = "Çıkış Zaman";
			this.textGZaman.Enabled = false;
			this.textGZaman.Font = new global::System.Drawing.Font("Calibri", 24f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textGZaman.Location = new global::System.Drawing.Point(184, 179);
			this.textGZaman.Name = "textGZaman";
			this.textGZaman.Size = new global::System.Drawing.Size(275, 47);
			this.textGZaman.TabIndex = 18;
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Calibri", 24f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label3.Location = new global::System.Drawing.Point(6, 182);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(174, 39);
			this.label3.TabIndex = 17;
			this.label3.Text = "Giriş Zaman";
			this.textPlaka.Enabled = false;
			this.textPlaka.Font = new global::System.Drawing.Font("Calibri", 24f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPlaka.Location = new global::System.Drawing.Point(184, 128);
			this.textPlaka.Name = "textPlaka";
			this.textPlaka.Size = new global::System.Drawing.Size(275, 47);
			this.textPlaka.TabIndex = 16;
			this.pictureSearch.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureSearch.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureSearch.Image");
			this.pictureSearch.Location = new global::System.Drawing.Point(465, 57);
			this.pictureSearch.Name = "pictureSearch";
			this.pictureSearch.Size = new global::System.Drawing.Size(543, 408);
			this.pictureSearch.TabIndex = 15;
			this.pictureSearch.TabStop = false;
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Calibri", 24f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label2.Location = new global::System.Drawing.Point(6, 131);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(154, 39);
			this.label2.TabIndex = 1;
			this.label2.Text = "Araç Plaka";
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Calibri", 48f, global::System.Drawing.FontStyle.Bold | global::System.Drawing.FontStyle.Underline, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label1.Location = new global::System.Drawing.Point(10, 34);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(368, 78);
			this.label1.TabIndex = 0;
			this.label1.Text = "Araç Bilgileri";
			this.timer1.Interval = 1000;
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(1021, 646);
			base.Controls.Add(this.panel1);
			base.MinimizeBox = false;
			base.Name = "OdemeEkran";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
			base.Load += new global::System.EventHandler(this.OdemeEkran_Load);
			base.SizeChanged += new global::System.EventHandler(this.OdemeEkran_SizeChanged);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureSearch).EndInit();
			base.ResumeLayout(false);
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.Panel panel1;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.Label label7;

		private global::System.Windows.Forms.TextBox textUcret;

		private global::System.Windows.Forms.Label label6;

		private global::System.Windows.Forms.TextBox textSure;

		private global::System.Windows.Forms.Label label5;

		private global::System.Windows.Forms.TextBox textCZaman;

		private global::System.Windows.Forms.Label label4;

		private global::System.Windows.Forms.TextBox textGZaman;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.TextBox textPlaka;

		private global::System.Windows.Forms.PictureBox pictureSearch;

		private global::System.Windows.Forms.Timer timer1;
	}
}
