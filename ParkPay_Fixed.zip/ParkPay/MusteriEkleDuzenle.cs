using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class MusteriEkleDuzenle : Form
	{
		public MusteriEkleDuzenle()
		{
			this.InitializeComponent();
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void login_Click(object sender, EventArgs e)
		{
			DateTime now = DateTime.Now;
			string format = "yyyy-MM-dd HH:mm:ss";
			string text = now.ToString(format);
			if (GlobalVar.DBConnectionStatus)
			{
				this.textIndirim.Text = this.textIndirim.Text.Replace(",", ".");
				string text2;
				if (this.Duzenle)
				{
					text2 = string.Concat(new string[]
					{
						"UPDATE db_musteriler SET kAdi='",
						this.textAdi.Text,
						"' , kSoyadi='",
						this.textSoyad.Text,
						"' , kEvTel='",
						this.textTel.Text,
						"' , kCepTel='",
						this.textCeptel.Text,
						"' ,kMail='",
						this.textEmail.Text,
						"' , kSifre='",
						this.textSifre.Text,
						"' , maxarac='",
						this.textArac.Text,
						"', uyeindirim='",
						this.textIndirim.Text,
						"' WHERE id=",
						this.MusteriID.ToString()
					});
				}
				else
				{
					text2 = string.Concat(new string[]
					{
						"INSERT INTO db_musteriler (`id` ,`kAdi` ,`kSoyadi` ,`kEvTel` ,`kCepTel` ,`kMail` , `kSifre` , `keklenmetarihi` , `maxarac`, `uyeindirim`) VALUES (NULL , '",
						this.textAdi.Text,
						"','",
						this.textSoyad.Text,
						"','",
						this.textTel.Text,
						"','",
						this.textCeptel.Text,
						"','",
						this.textEmail.Text,
						"' , '",
						this.textSifre.Text,
						"' , '",
						text,
						"' , '",
						this.textArac.Text,
						"' , '",
						this.textIndirim.Text,
						"')"
					});
				}
				MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				base.Close();
			}
		}

		private void MusteriEkleDuzenle_Load(object sender, EventArgs e)
		{
			if (this.Duzenle)
			{
				this.login.Text = "Düzenle";
				string text = "SELECT * FROM db_musteriler WHERE id = " + this.MusteriID.ToString();
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				if (mySqlDataReader.Read())
				{
					this.textAdi.Text = mySqlDataReader["kAdi"].ToString();
					this.textSoyad.Text = mySqlDataReader["kSoyadi"].ToString();
					this.textTel.Text = mySqlDataReader["kEvTel"].ToString();
					this.textCeptel.Text = mySqlDataReader["kCepTel"].ToString();
					this.textEmail.Text = mySqlDataReader["kMail"].ToString();
					this.textSifre.Text = mySqlDataReader["kSifre"].ToString();
					this.textArac.Text = mySqlDataReader["maxarac"].ToString();
					this.textIndirim.Text = mySqlDataReader["uyeindirim"].ToString();
				}
				mySqlDataReader.Close();
			}
			else
			{
				this.login.Text = "Ekle";
				this.textIndirim.Text = "0";
				this.textEmail.Text = "a@a.com";
				this.textArac.Text = "5";
				this.textSifre.Text = "1";
			}
		}

		public int MusteriID;

		public bool Duzenle;
	}
}
