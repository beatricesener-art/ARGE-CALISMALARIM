using System;

namespace ParkPay
{
	public class PaymentInfo
	{
		public string giriszaman;

		public string cikiszaman;

		public string plaka;

		public string resimyolu;

		public string ucret;

		public string sure;
	}
}
