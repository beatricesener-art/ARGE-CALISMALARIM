namespace ParkPay
{
	public partial class TarihSaatDuzelt : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.TarihSaatDuzelt));
			this.label3 = new global::System.Windows.Forms.Label();
			this.cancel = new global::System.Windows.Forms.Button();
			this.login = new global::System.Windows.Forms.Button();
			this.lineShape1 = new global::Microsoft.VisualBasic.PowerPacks.LineShape();
			this.shapeContainer1 = new global::Microsoft.VisualBasic.PowerPacks.ShapeContainer();
			this.label1 = new global::System.Windows.Forms.Label();
			this.enterTime = new global::System.Windows.Forms.DateTimePicker();
			this.enterDate = new global::System.Windows.Forms.DateTimePicker();
			base.SuspendLayout();
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label3.Location = new global::System.Drawing.Point(50, 38);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(64, 24);
			this.label3.TabIndex = 67;
			this.label3.Text = "Tarih:";
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(214, 127);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 66;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(95, 127);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 65;
			this.login.Text = "Düzelt";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.lineShape1.BorderColor = global::System.Drawing.SystemColors.ControlDark;
			this.lineShape1.Name = "lineShape1";
			this.lineShape1.X1 = 12;
			this.lineShape1.X2 = 325;
			this.lineShape1.Y1 = 120;
			this.lineShape1.Y2 = 120;
			this.shapeContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.shapeContainer1.Margin = new global::System.Windows.Forms.Padding(0);
			this.shapeContainer1.Name = "shapeContainer1";
			this.shapeContainer1.Shapes.AddRange(new global::Microsoft.VisualBasic.PowerPacks.Shape[]
			{
				this.lineShape1
			});
			this.shapeContainer1.Size = new global::System.Drawing.Size(339, 171);
			this.shapeContainer1.TabIndex = 68;
			this.shapeContainer1.TabStop = false;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label1.Location = new global::System.Drawing.Point(50, 74);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(56, 24);
			this.label1.TabIndex = 69;
			this.label1.Text = "Saat:";
			this.enterTime.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Bold);
			this.enterTime.Format = global::System.Windows.Forms.DateTimePickerFormat.Time;
			this.enterTime.Location = new global::System.Drawing.Point(120, 71);
			this.enterTime.Name = "enterTime";
			this.enterTime.ShowUpDown = true;
			this.enterTime.Size = new global::System.Drawing.Size(157, 29);
			this.enterTime.TabIndex = 71;
			this.enterDate.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Bold);
			this.enterDate.Format = global::System.Windows.Forms.DateTimePickerFormat.Custom;
			this.enterDate.Location = new global::System.Drawing.Point(120, 36);
			this.enterDate.Name = "enterDate";
			this.enterDate.Size = new global::System.Drawing.Size(157, 29);
			this.enterDate.TabIndex = 70;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(339, 171);
			base.Controls.Add(this.enterTime);
			base.Controls.Add(this.enterDate);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.login);
			base.Controls.Add(this.shapeContainer1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "TarihSaatDuzelt";
			base.ShowIcon = false;
			base.SizeGripStyle = global::System.Windows.Forms.SizeGripStyle.Hide;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Plaka Giriş Tarih Düzelt";
			base.TopMost = true;
			base.Load += new global::System.EventHandler(this.TarihSaatDuzelt_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.Button login;

		private global::Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;

		private global::Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.DateTimePicker enterTime;

		private global::System.Windows.Forms.DateTimePicker enterDate;
	}
}
