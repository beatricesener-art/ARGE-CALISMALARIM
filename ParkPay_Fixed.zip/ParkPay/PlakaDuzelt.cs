using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class PlakaDuzelt : Form
	{
		public PlakaDuzelt()
		{
			this.InitializeComponent();
		}

		private void login_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				if (this.textPlate2.Text.Length < 1)
				{
					MessageBox.Show("Plaka Giriniz...");
				}
				else
				{
					this.textPlate2.Text = this.textPlate2.Text.ToUpper();
					string text = "SELECT * FROM db_araclar WHERE plaka = '" + this.textPlate2.Text + "' LIMIT 1";
					MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					bool flag = mySqlDataReader.Read();
					mySqlDataReader.Close();
					if (flag)
					{
						this.PlakayiCikart(this.textPlate.Text);
						string format = "yyyy-MM-dd HH:mm:ss";
						this.enterDateTime = DateTime.Parse(this.enterDateTime).ToString(format);
						text = string.Concat(new string[]
						{
							"UPDATE db_araclar SET sondegisim='",
							this.enterDateTime,
							"' , aracKonum='i' WHERE plaka='",
							this.textPlate2.Text,
							"'"
						});
						MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
						MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
						mySqlDataReader2.Close();
					}
					else
					{
						text = string.Concat(new string[]
						{
							"UPDATE db_araclar SET plaka='",
							this.textPlate2.Text,
							"' WHERE plaka='",
							this.textPlate.Text,
							"'"
						});
						MySqlCommand mySqlCommand3 = new MySqlCommand(text, GlobalVar.conn);
						MySqlDataReader mySqlDataReader3 = mySqlCommand3.ExecuteReader();
						mySqlDataReader3.Close();
					}
					this.plate = this.textPlate2.Text;
					text = string.Concat(new string[]
					{
						"UPDATE db_loglar SET plaka='",
						this.textPlate2.Text,
						"' WHERE plaka='",
						this.textPlate.Text,
						"' order by `kayittarihi` DESC LIMIT 1"
					});
					MySqlCommand mySqlCommand4 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader4 = mySqlCommand4.ExecuteReader();
					mySqlDataReader4.Close();
					base.Close();
				}
			}
		}

		private void PlakayiCikart(string duzPlaka)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "UPDATE db_araclar SET aracKonum='d'  WHERE plaka='" + duzPlaka + "' ";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				Main main = (Main)base.Owner;
				main.YoneticiLogEkle("Araclardan Plaka: " + duzPlaka + " Disari Cikti! ");
			}
		}

		private void PlakayiSil(string silPlaka)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "DELETE FROM db_araclar WHERE plaka = '" + silPlaka + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				Main main = (Main)base.Owner;
				main.YoneticiLogEkle("Araclardan 2 Plaka: " + silPlaka + " Silindi! ");
			}
		}

		private void PlakaDuzelt_Load(object sender, EventArgs e)
		{
			this.textPlate.Text = this.plate;
			this.textPlate2.Text = this.plate;
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		public string plate;

		public int plateID;

		public string enterDateTime = "";
	}
}
