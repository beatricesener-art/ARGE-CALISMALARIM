using System;
using System.Diagnostics;
using System.Threading;
using MySql.Data.MySqlClient;
using PdfSharp.Drawing;
using PdfSharp.Drawing.BarCodes;
using PdfSharp.Pdf;

namespace ParkPay
{
	internal class AutoPrint
	{
		public void LoadPlateDetails(string _plate)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				this.plate = _plate;
				this.barkod = "";
				this.enterDateTime = "";
				this.tipID = 0;
				int num = 0;
				string s = "";
				string text = "SELECT * FROM db_araclar WHERE plaka = '" + _plate + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				if (mySqlDataReader.Read())
				{
					try
					{
						this.barkod = mySqlDataReader["barkod"].ToString();
						this.enterDateTime = mySqlDataReader["sondegisim"].ToString();
						this.tipID = int.Parse(mySqlDataReader["tipID"].ToString());
						num = int.Parse(mySqlDataReader["geciciarac"].ToString());
						if (mySqlDataReader.GetMySqlDateTime("abonelikbitis").IsValidDateTime)
						{
							s = mySqlDataReader["abonelikbitis"].ToString();
						}
						else
						{
							s = "2016-01-01 00:00:00";
						}
					}
					catch (Exception)
					{
						if (this.barkod.Length < 1)
						{
							this.barkod = "1000000";
						}
						if (this.enterDateTime.Length < 1)
						{
							this.enterDateTime = "2016-01-01 00:00:00";
						}
						num = 1;
					}
				}
				mySqlDataReader.Close();
				if (num > 1)
				{
					DateTime now = DateTime.Now;
					int num2 = (int)DateTime.Parse(s).Subtract(now).TotalMinutes;
					if (num2 > 0)
					{
						return;
					}
				}
				if (this.barkod.Length < 1)
				{
					string text2 = DateTime.Now.ToString("MMddHHmmss");
					text = string.Concat(new string[]
					{
						"UPDATE db_araclar SET  barkod='",
						text2,
						"'  WHERE plaka = '",
						_plate,
						"'"
					});
					MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
					mySqlDataReader2.Close();
					this.barkod = text2;
				}
				this.AracYazdir();
			}
		}

		public void AracYazdir()
		{
			int num = GlobalVar.TopSize;
			int leftSize = GlobalVar.LeftSize;
			int lineFree = GlobalVar.LineFree;
			int leftLine = GlobalVar.LeftLine;
			PdfDocument pdfDocument = new PdfDocument();
			XFont xfont = new XFont("Verdana", (double)GlobalVar.FontSize1);
			XFont xfont2 = new XFont("Verdana", (double)GlobalVar.FontSize2);
			PdfPage pdfPage = pdfDocument.AddPage();
			pdfPage.Width = GlobalVar.PageW;
			pdfPage.Height = GlobalVar.PageH;
			XGraphics xgraphics = XGraphics.FromPdfPage(pdfPage);
			xgraphics.DrawBarCode(new Code3of9Standard
			{
				Text = this.barkod,
				Size = new XSize((double)GlobalVar.BarkodW, (double)GlobalVar.BarkodH),
				TextLocation = TextLocation.Above
			}, XBrushes.Black, new XPoint(1.0, 1.0));
			xgraphics.DrawLine(XPens.Black, 0, num - lineFree + 3, leftLine, num - lineFree + 3);
			xgraphics.DrawString(GlobalVar.Label1, xfont2, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			string text = GlobalVar.Label2;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = GlobalVar.Label3;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "PLAKA: " + this.plate;
			num += lineFree;
			xgraphics.DrawString(text, xfont2, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "ARAÇ GIRIS ZAMANI: " + this.enterDateTime;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "*** ARAÇ GIRIS BILGI ***";
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			pdfDocument.Save("payment_tempfile.pdf");
			Thread.Sleep(1000);
			Process.Start(new ProcessStartInfo
			{
				UseShellExecute = true,
				Verb = "print",
				WindowStyle = ProcessWindowStyle.Hidden,
				FileName = "payment_tempfile.pdf"
			});
		}

		public string plate;

		public string barkod;

		public string enterDateTime;

		public int tipID;
	}
}
