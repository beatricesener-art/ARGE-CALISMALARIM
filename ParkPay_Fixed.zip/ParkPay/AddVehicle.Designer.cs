namespace ParkPay
{
	public partial class AddVehicle : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.AddVehicle));
			this.textDetails = new global::System.Windows.Forms.TextBox();
			this.cancel = new global::System.Windows.Forms.Button();
			this.login = new global::System.Windows.Forms.Button();
			this.aracTipleri = new global::System.Windows.Forms.ComboBox();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.label5 = new global::System.Windows.Forms.Label();
			this.label2 = new global::System.Windows.Forms.Label();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.camList = new global::System.Windows.Forms.ComboBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.enterTime = new global::System.Windows.Forms.DateTimePicker();
			this.enterDate = new global::System.Windows.Forms.DateTimePicker();
			this.textPlate = new global::System.Windows.Forms.TextBox();
			this.printBtn = new global::System.Windows.Forms.Button();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			this.groupBox1.SuspendLayout();
			base.SuspendLayout();
			this.textDetails.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textDetails.Location = new global::System.Drawing.Point(17, 127);
			this.textDetails.Multiline = true;
			this.textDetails.Name = "textDetails";
			this.textDetails.Size = new global::System.Drawing.Size(316, 47);
			this.textDetails.TabIndex = 12;
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(251, 389);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 20;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(132, 389);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 19;
			this.login.Text = "Ekle Kapat";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.aracTipleri.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.aracTipleri.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.aracTipleri.FormattingEnabled = true;
			this.aracTipleri.Location = new global::System.Drawing.Point(149, 28);
			this.aracTipleri.Name = "aracTipleri";
			this.aracTipleri.Size = new global::System.Drawing.Size(184, 26);
			this.aracTipleri.TabIndex = 2;
			this.aracTipleri.SelectedIndexChanged += new global::System.EventHandler(this.aracTipleri_SelectedIndexChanged);
			this.pictureBox3.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(12, 12);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(352, 103);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 17;
			this.pictureBox3.TabStop = false;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label1.Location = new global::System.Drawing.Point(15, 31);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(74, 18);
			this.label1.TabIndex = 0;
			this.label1.Text = "Araç Tipi";
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label5.Location = new global::System.Drawing.Point(15, 100);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(76, 18);
			this.label5.TabIndex = 8;
			this.label5.Text = "Açıklama";
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label2.Location = new global::System.Drawing.Point(14, 65);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(103, 18);
			this.label2.TabIndex = 5;
			this.label2.Text = "Araç Giriş Z.";
			this.groupBox1.Controls.Add(this.printBtn);
			this.groupBox1.Controls.Add(this.camList);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.enterTime);
			this.groupBox1.Controls.Add(this.enterDate);
			this.groupBox1.Controls.Add(this.textDetails);
			this.groupBox1.Controls.Add(this.aracTipleri);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.groupBox1.Location = new global::System.Drawing.Point(12, 121);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(352, 262);
			this.groupBox1.TabIndex = 18;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Araç Detaylar";
			this.camList.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.camList.FormattingEnabled = true;
			this.camList.Location = new global::System.Drawing.Point(149, 180);
			this.camList.Name = "camList";
			this.camList.Size = new global::System.Drawing.Size(184, 26);
			this.camList.TabIndex = 21;
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label3.Location = new global::System.Drawing.Point(15, 184);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(105, 18);
			this.label3.TabIndex = 20;
			this.label3.Text = "Giriş KamNo";
			this.enterTime.Format = global::System.Windows.Forms.DateTimePickerFormat.Time;
			this.enterTime.Location = new global::System.Drawing.Point(149, 95);
			this.enterTime.Name = "enterTime";
			this.enterTime.ShowUpDown = true;
			this.enterTime.Size = new global::System.Drawing.Size(132, 24);
			this.enterTime.TabIndex = 19;
			this.enterDate.Format = global::System.Windows.Forms.DateTimePickerFormat.Custom;
			this.enterDate.Location = new global::System.Drawing.Point(149, 62);
			this.enterDate.Name = "enterDate";
			this.enterDate.Size = new global::System.Drawing.Size(132, 24);
			this.enterDate.TabIndex = 13;
			this.textPlate.Font = new global::System.Drawing.Font("Arial", 36f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPlate.Location = new global::System.Drawing.Point(78, 34);
			this.textPlate.Name = "textPlate";
			this.textPlate.Size = new global::System.Drawing.Size(274, 63);
			this.textPlate.TabIndex = 21;
			this.printBtn.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.printBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("printBtn.Image");
			this.printBtn.Location = new global::System.Drawing.Point(176, 224);
			this.printBtn.Name = "printBtn";
			this.printBtn.Size = new global::System.Drawing.Size(157, 32);
			this.printBtn.TabIndex = 22;
			this.printBtn.Text = "Ekle  - Yazdır";
			this.printBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.printBtn.UseVisualStyleBackColor = true;
			this.printBtn.Click += new global::System.EventHandler(this.printBtn_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(377, 427);
			base.Controls.Add(this.textPlate);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.login);
			base.Controls.Add(this.pictureBox3);
			base.Controls.Add(this.groupBox1);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "AddVehicle";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Araç Ekle";
			base.Load += new global::System.EventHandler(this.AddVehicle_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.TextBox textDetails;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.Button login;

		private global::System.Windows.Forms.ComboBox aracTipleri;

		private global::System.Windows.Forms.PictureBox pictureBox3;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.Label label5;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.GroupBox groupBox1;

		private global::System.Windows.Forms.DateTimePicker enterDate;

		private global::System.Windows.Forms.TextBox textPlate;

		private global::System.Windows.Forms.DateTimePicker enterTime;

		private global::System.Windows.Forms.ComboBox camList;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.Button printBtn;
	}
}
