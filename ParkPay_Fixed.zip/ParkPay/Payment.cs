using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;
using PdfSharp.Drawing;
using PdfSharp.Drawing.BarCodes;
using PdfSharp.Pdf;

namespace ParkPay
{
	public partial class Payment : Form
	{
		public Payment()
		{
			this.InitializeComponent();
			this.InitializeDuplicateDailyPanel();
		}

		private void Payment_Load(object sender, EventArgs e)
		{
			if (this.odemeileBariyer)
			{
				this.camList.Visible = true;
				this.label6.Visible = true;
			}
			if (this.odemeileBariyer)
			{
				this.textDetails.Text = "BARIYER NOKTASI:";
			}
			else
			{
				this.textDetails.Text = "ÖDEME NOKTASI:";
			}
			this.textPlate.Text = this.plate;
			this.enterDateTimeText.Text = this.enterDateTime;
			int num = 0;
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_aractipleri ORDER by tipID ASC";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				int i = 0;
				try
				{
					while (mySqlDataReader.Read())
					{
						this.aracTipleri.Items.Add(mySqlDataReader["tipAdi"].ToString());
						this.tipIDArray[i] = int.Parse(mySqlDataReader["tipID"].ToString());
						i++;
					}
				}
				catch (Exception)
				{
					MessageBox.Show("hata:100001");
				}
				mySqlDataReader.Close();
				this.tipID = this.tipIDArray[0];
				text = "SELECT * FROM db_araclar WHERE plaka = '" + this.textPlate.Text + "'";
				MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
				string a = "";
				if (mySqlDataReader2.Read())
				{
					a = mySqlDataReader2["odeme_durum"].ToString();
					this.barkod = mySqlDataReader2["barkod"].ToString();
					num = int.Parse(mySqlDataReader2["tipID"].ToString());
					if (num < 1)
					{
						num = 1;
						this.ucretliAbone = 1;
					}
				}
				mySqlDataReader2.Close();
				for (i = 0; i < 50; i++)
				{
					if (this.tipIDArray[i] == num)
					{
						this.aracTipleri.SelectedIndex = i;
						break;
					}
				}
				if (this.barkod.Length < 1)
				{
					string text2 = DateTime.Now.ToString("MMddHHmmss");
					text = string.Concat(new string[]
					{
						"UPDATE db_araclar SET  barkod='",
						text2,
						"'  WHERE plaka = '",
						this.textPlate.Text,
						"'"
					});
					MySqlCommand mySqlCommand3 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader3 = mySqlCommand3.ExecuteReader();
					mySqlDataReader3.Close();
					this.barkod = text2;
				}
				if (a == "1")
				{
					this.payStatusText.Text = "Ödemesi Yapılmış!";
					this.odemeStatus = true;
				}
				int num2 = 0;
				for (i = 0; i < GlobalVar.camCount; i++)
				{
					if (!(GlobalVar.camDirectionArray[i] == "c"))
					{
						string str = "Çıkış";
						string item = "Kamera:" + (i + 1).ToString() + " Yön:" + str;
						this.camIDArray[num2] = i;
						num2++;
						this.camList.Items.Add(item);
					}
				}
				this.SendToScreen();
				this.UpdateDuplicateDailyPanel();
				if (this.odemeileBariyer && this.camList.Items.Count >= GlobalVar.bariyerCam)
				{
					this.camList.SelectedIndex = GlobalVar.bariyerCam - 1;
				}
			}
		}

		private void SendToScreen()
		{
			Main main = (Main)base.Owner;
			main.paymentInfo.giriszaman = this.enterDateTimeText.Text;
			main.paymentInfo.sure = this.textMinutes.Text;
			main.paymentInfo.ucret = this.textPayment.Text;
			main.paymentInfo.plaka = this.textPlate.Text;
			string text = this.enterDateTimeText.Text;
			if (text.Length > 8)
			{
				text = text.Substring(text.Length - 8, 8);
			}
			main.SentToLedScreen(this.textPayment.Text, text, this.textPlate.Text);
		}

		private void login_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				if (this.odemeileBariyer && this.camList.SelectedIndex < 0)
				{
					MessageBox.Show("Çıkış Bariyeri Seçmelisiniz!", "Uyarı");
				}
				else
				{
					string text;
					if (this.odemeileBariyer)
					{
						text = string.Concat(new string[]
						{
							"UPDATE db_araclar SET vale_arac=0 , odeme_durum=0 , aracKonum = 'd' , sondegisim='",
							this.exitDateTime2,
							"' WHERE plaka='",
							this.textPlate.Text,
							"'"
						});
					}
					else
					{
						text = string.Concat(new string[]
						{
							"UPDATE db_araclar SET vale_arac=0 , odeme_durum=1 , sondegisim='",
							this.exitDateTime2,
							"' WHERE plaka='",
							this.textPlate.Text,
							"'"
						});
					}
					MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					mySqlDataReader.Close();
					double num = 0.0;
					if (this.paymentCheck.Checked)
					{
						num = this.t_payment;
					}
					string text2 = num.ToString();
					text2 = text2.Replace(",", ".");
					text = string.Concat(new object[]
					{
						"INSERT INTO db_odemeler (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`,`plaka` , `abonesure` , `operatorid` , `pointID` ) VALUES (NULL , '0', '",
						text2,
						"','",
						text2,
						"','",
						this.exitDateTime2,
						"','",
						this.tipID,
						"','",
						this.textPlate.Text,
						"' , 0 , ",
						GlobalVar.activeId,
						" , ",
						GlobalVar.pointID,
						")"
					});
					MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
					mySqlDataReader2.Close();
					string str;
					if (this.paymentCheck.Checked)
					{
						str = "ÖDEME YAPILDI:" + this.t_payment.ToString() + " TL - ";
					}
					else
					{
						str = "ÖDEME YAPILMADI!:" + this.t_payment.ToString() + " TL - ";
					}
					str = str + "Arac Tipi:" + this.aracTipleri.Text + " - ";
					string text3 = str + this.textDetails.Text;
					int num2 = GlobalVar.paymentCam;
					if (this.odemeileBariyer)
					{
						num2 = this.camIDArray[this.camList.SelectedIndex];
					}
					text = string.Concat(new object[]
					{
						"INSERT INTO db_loglar (`id` ,`plaka` ,`kayittarihi` ,`kameraid` ,`sebep` ,`aracKonum` , `soncamgrupid` , `sistemid`) VALUES (NULL , '",
						this.textPlate.Text,
						"','",
						this.exitDateTime2,
						"',",
						num2,
						",'",
						text3,
						"','d' , 1 , '",
						GlobalVar.GlobalSistemName,
						"')"
					});
					MySqlCommand mySqlCommand3 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader3 = mySqlCommand3.ExecuteReader();
					mySqlDataReader3.Close();
					if (this.odemeileBariyer)
					{
						Main main = (Main)base.Owner;
						if (this.camList.SelectedIndex > -1)
						{
							main.OpenBariyer(this.camIDArray[this.camList.SelectedIndex]);
						}
						GlobalVar.bariyerCam = this.camList.SelectedIndex + 1;
					}
					base.Close();
				}
			}
		}

		private void printBtn_Click(object sender, EventArgs e)
		{
			int num = GlobalVar.TopSize;
			int leftSize = GlobalVar.LeftSize;
			int lineFree = GlobalVar.LineFree;
			int leftLine = GlobalVar.LeftLine;
			PdfDocument pdfDocument = new PdfDocument();
			XFont xfont = new XFont("Verdana", (double)GlobalVar.FontSize1);
			XFont xfont2 = new XFont("Verdana", (double)GlobalVar.FontSize2);
			PdfPage pdfPage = pdfDocument.AddPage();
			pdfPage.Width = GlobalVar.PageW;
			pdfPage.Height = GlobalVar.PageH;
			XGraphics xgraphics = XGraphics.FromPdfPage(pdfPage);
			xgraphics.DrawBarCode(new Code3of9Standard
			{
				Text = this.barkod,
				Size = new XSize((double)GlobalVar.BarkodW, (double)GlobalVar.BarkodH),
				TextLocation = TextLocation.Above
			}, XBrushes.Black, new XPoint(1.0, 1.0));
			xgraphics.DrawLine(XPens.Black, 0, num - lineFree + 3, leftLine, num - lineFree + 3);
			xgraphics.DrawString(GlobalVar.Label1, xfont2, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			string text = GlobalVar.Label2;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = GlobalVar.Label3;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "PLAKA/KART: " + this.textPlate.Text;
			num += lineFree;
			xgraphics.DrawString(text, xfont2, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "ARAÇ GIRIS ZAMANI: " + this.enterDateTime;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = "ARAÇ CIKIS ZAMANI: " + this.exitDateTime;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = string.Concat(new string[]
			{
				"SÜRE: ",
				this.t_minues.ToString(),
				" dk - EK SÜRE: ",
				this.textMinEk.Text,
				" dk"
			});
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "ÜCRET: " + this.t_payment.ToString() + " TL";
			num += lineFree;
			xgraphics.DrawString(text, xfont2, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			pdfDocument.Save("payment_tempfile.pdf");
			Thread.Sleep(1000);
			Process.Start(new ProcessStartInfo
			{
				UseShellExecute = true,
				Verb = "print",
				WindowStyle = ProcessWindowStyle.Hidden,
				FileName = "payment_tempfile.pdf"
			});
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private int GunlukHareketVarMi()
		{
			DateTime now = DateTime.Now;
			string format = "yyyy-MM-dd";
			string text = now.ToString(format);
			string text2 = string.Concat(new string[]
			{
				"SELECT * FROM db_loglar WHERE plaka = '",
				this.textPlate.Text,
				"' AND kayittarihi>'",
				text,
				" 00:00:00' AND kayittarihi<'",
				text,
				" 23:59:59' order by `kayittarihi` ASC "
			});
			MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
			MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
			int num = 0;
			string[] array = new string[50];
			string[] array2 = new string[50];
			while (mySqlDataReader.Read())
			{
				array[num] = mySqlDataReader["kayittarihi"].ToString();
				array2[num] = mySqlDataReader["aracKonum"].ToString();
				num++;
			}
			mySqlDataReader.Close();
			int num2 = 0;
			if (num > 1)
			{
				for (int i = 0; i < num - 1; i++)
				{
					if (array2[i] == "i" && array2[i + 1] == "d")
					{
						DateTime value = DateTime.Parse(array[i]);
						int num3 = (int)DateTime.Parse(array[i + 1]).Subtract(value).TotalMinutes;
						num2 += num3;
					}
				}
			}
			if (num2 > GlobalVar.DayLimitMin)
			{
				num2 = GlobalVar.DayLimitMin;
			}
			return num2;
		}

		private void CalculatePayment()
		{
			if (GlobalVar.DBConnectionStatus)
			{
				DateTime now = DateTime.Now;
				string format = "dd.MM.yyyy HH:mm:ss";
				string format2 = "yyyy-MM-dd HH:mm:ss";
				this.exitDateTime = now.ToString(format);
				this.exitDateTime2 = now.ToString(format2);
				DateTime value = DateTime.Parse(this.enterDateTime);
				int num = (int)now.Subtract(value).TotalMinutes;
				this.textMinutes.Text = num.ToString();
				this.t_minues = num;
				if (GlobalVar.ucretsizSure - num >= 0 && this.odemeStatus)
				{
					double num2 = 0.0;
					this.textPayment.Text = num2.ToString();
					this.t_payment = num2;
				}
				else
				{
					string text = "SELECT * FROM db_araclar WHERE plaka = '" + this.plate + "'";
					MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					int num3 = 0;
					string s = "";
					string s2 = "";
					int num4 = 0;
					string s3 = "";
					bool flag = false;
					if (mySqlDataReader.Read())
					{
						s = mySqlDataReader["abonelikTipi"].ToString();
						s2 = mySqlDataReader["AbonelikSaat"].ToString();
						try
						{
							s3 = mySqlDataReader["abonelikbitis"].ToString();
							flag = true;
						}
						catch (Exception)
						{
							s3 = this.exitDateTime;
						}
					}
					mySqlDataReader.Close();
					try
					{
						num3 = int.Parse(s);
						num4 = int.Parse(s2);
					}
					catch (Exception)
					{
						num3 = 0;
						num4 = 0;
					}
					DateTime value2 = DateTime.ParseExact(s3, "dd.MM.yyyy HH:mm:ss", null);
					int num5 = (int)now.Subtract(value2).TotalMinutes;
					if (num3 > 0 && num5 < 0)
					{
						this.t_minues -= num4 * 60;
						if (this.t_minues < 0)
						{
							this.t_minues = 0;
							this.textPayment.Text = "0";
							this.t_payment = 0.0;
							this.InfoText.Text = "Saatlik Abone Araç. Süresi Var! Ücretsiz!";
							return;
						}
						num = this.t_minues;
						this.textMinutes.Text = num.ToString();
						this.InfoText.Text = "Saatlik Abone Araç. Saati Dolmuş, Ücret Ödeyecek!";
					}
					int num6 = 0;
					bool flag2 = false;
					int chargeMinutes = ParkingDurationRule.GetChargeMinutes(this.plate, num, out num6, out flag2);
					this.textMinEk.Text = num6.ToString();
					if (flag2)
					{
						this.textDetails.Text = this.textDetails.Text + "-TICARI TAKSI: 24DK UCRETSIZ / GUNLUK TOPLAM YOK-";
					}
					else if (num6 > 0)
					{
						this.textDetails.Text = this.textDetails.Text + "-GUNLUK ONCEKI:" + num6.ToString() + "DK-";
					}
					num = chargeMinutes;
					if (ParkingDurationRule.IsFree(num))
					{
						this.textPayment.Text = "0";
						this.t_payment = 0.0;
						this.SendToScreen();
						this.UpdateDuplicateDailyPanel();
					}
					else
					{
						if (this.ucretliAbone == 1)
						{
							this.textDetails.Text = this.textDetails.Text + "-UCRETLI ABONE-";
						}
						if (flag && this.ucretliAbone == 0)
						{
							int num7 = (int)value2.Subtract(value).TotalMinutes;
							if (num7 > 0)
							{
								num -= num7;
								this.textMinutes.Text = num.ToString();
							}
						}
						text = string.Concat(new string[]
						{
							"SELECT * FROM db_fiyatlar WHERE tipID=",
							this.tipID.ToString(),
							" AND baslangic <= ",
							num.ToString(),
							" AND bitis > ",
							num.ToString(),
							" "
						});
						MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
						MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
						int num8 = 0;
						double num9 = 0.0;
						int num10 = 0;
						if (mySqlDataReader2.Read())
						{
							try
							{
								int.Parse(mySqlDataReader2["id"].ToString());
								if (mySqlDataReader2["sistemli"].ToString() == "e")
								{
									num8 = 1;
								}
								else
								{
									num8 = 0;
								}
								num9 = double.Parse(mySqlDataReader2["ucret"].ToString());
								num10 = int.Parse(mySqlDataReader2["carpan"].ToString());
							}
							catch (Exception)
							{
								MessageBox.Show("Hata:12001");
							}
						}
						mySqlDataReader2.Close();
						double num2;
						if (num8 == 0)
						{
							num2 = num9;
						}
						else
						{
							num2 = Math.Ceiling((double)num / (double)num10);
							num2 *= num9;
						}
						this.textPayment.Text = num2.ToString();
						this.t_payment = num2;
						if (this.t_payment > 0.0 && !this.feeAlertPlayed)
						{
							this.feeAlertPlayed = true;
							FeeAlertSound.PlayTwoSeconds();
						}
						this.SendToScreen();
						this.UpdateDuplicateDailyPanel();
					}
				}
			}
		}

		private Payment.DuplicateDailySummary GetDuplicateDailySummary()
		{
			Payment.DuplicateDailySummary duplicateDailySummary = new Payment.DuplicateDailySummary();
			Payment.DuplicateDailySummary result;
			if (!GlobalVar.DBConnectionStatus || GlobalVar.conn == null)
			{
				result = duplicateDailySummary;
			}
			else
			{
				DateTime now = DateTime.Now;
				DateTime cycleStartToday = ParkingDurationRule.GetCycleStartToday(this.textPlate.Text);
				duplicateDailySummary.CycleStart = cycleStartToday;
				duplicateDailySummary.ResetByPayment = (cycleStartToday > now.Date);
				string text = "SELECT kayittarihi, aracKonum FROM db_loglar WHERE plaka=@plaka AND kayittarihi>@baslangic AND kayittarihi<=@bitis ORDER BY kayittarihi ASC";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				mySqlCommand.Parameters.AddWithValue("@plaka", this.textPlate.Text);
				mySqlCommand.Parameters.AddWithValue("@baslangic", cycleStartToday.ToString("yyyy-MM-dd HH:mm:ss"));
				mySqlCommand.Parameters.AddWithValue("@bitis", now.ToString("yyyy-MM-dd HH:mm:ss"));
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				DateTime? dateTime = null;
				try
				{
					while (mySqlDataReader.Read())
					{
						DateTime dateTime2;
						if (DateTime.TryParse(mySqlDataReader["kayittarihi"].ToString(), out dateTime2))
						{
							string a = mySqlDataReader["aracKonum"].ToString();
							if (a == "i")
							{
								dateTime = new DateTime?(dateTime2);
							}
							else if (a == "d" && dateTime != null && dateTime2 >= dateTime.Value)
							{
								duplicateDailySummary.PreviousSeconds += Math.Max(0, (int)Math.Floor(dateTime2.Subtract(dateTime.Value).TotalSeconds));
								duplicateDailySummary.CompletedVisitCount++;
								dateTime = null;
							}
						}
					}
				}
				finally
				{
					mySqlDataReader.Close();
				}
				DateTime value;
				if (DateTime.TryParse(this.enterDateTime, out value))
				{
					duplicateDailySummary.CurrentSeconds = Math.Max(0, (int)Math.Floor(now.Subtract(value).TotalSeconds));
				}
				duplicateDailySummary.IsCommercialTaxi = ParkingDurationRule.IsCommercialTaxi(this.textPlate.Text);
				if (duplicateDailySummary.IsCommercialTaxi)
				{
					duplicateDailySummary.PreviousSeconds = 0;
					duplicateDailySummary.CompletedVisitCount = 0;
				}
				duplicateDailySummary.VisitCount = duplicateDailySummary.CompletedVisitCount + 1;
				duplicateDailySummary.TotalSeconds = duplicateDailySummary.PreviousSeconds + duplicateDailySummary.CurrentSeconds;
				result = duplicateDailySummary;
			}
			return result;
		}

		private string FormatDuplicateDuration(int totalSeconds)
		{
			if (totalSeconds < 0)
			{
				totalSeconds = 0;
			}
			int num = totalSeconds / 60;
			int num2 = totalSeconds % 60;
			return num.ToString() + " dk " + num2.ToString("00") + " sn";
		}

		private bool ShouldShowDuplicateDailyPanel(Payment.DuplicateDailySummary summary)
		{
			return !summary.IsCommercialTaxi && summary.CompletedVisitCount > 0 && summary.TotalSeconds >= 1500;
		}

		private void InitializeDuplicateDailyPanel()
		{
			this.dailyPanel = new Panel();
			this.dailyPanel.Location = new Point(400, 12);
			this.dailyPanel.Size = new Size(438, 570);
			this.dailyPanel.BackColor = Color.FromArgb(28, 35, 43);
			this.dailyPanel.BorderStyle = BorderStyle.FixedSingle;
			this.dailyPanel.Visible = false;
			Label value = this.MakeDuplicatePanelLabel("GÜNLÜK BİRİKİMLİ ÜCRET", 18, 14, 400, 25, 12.5f, true, Color.FromArgb(255, 183, 28));
			this.dailyPanel.Controls.Add(value);
			Label value2 = this.MakeDuplicatePanelLabel("Mükerrer giriş toplamı 24 dakikayı geçtiğinde ayrıntılı günlük hesap", 18, 43, 400, 34, 8.5f, false, Color.LightSteelBlue);
			this.dailyPanel.Controls.Add(value2);
			this.lblVisitCount = this.AddDuplicateValueRow("Ziyaret sayısı", 84);
			this.lblCurrentVisit = this.AddDuplicateValueRow("Bu ziyaret", 116);
			this.lblPreviousTotal = this.AddDuplicateValueRow("Önceki toplam", 148);
			this.lblDailyTotal = this.AddDuplicateValueRow("Günlük toplam", 180);
			this.lblDailyTotal.ForeColor = Color.FromArgb(255, 183, 28);
			this.lblDailyTotal.Font = new Font("Microsoft Sans Serif", 10.5f, FontStyle.Bold);
			this.lblFreeLimit = this.AddDuplicateValueRow("Ücretsiz sınır", 218);
			this.lblCycle = this.AddDuplicateValueRow("Kural", 250);
			Label value3 = this.MakeDuplicatePanelLabel("Şimdi alınacak", 18, 292, 150, 22, 9.5f, false, Color.LightSteelBlue);
			this.dailyPanel.Controls.Add(value3);
			this.lblAmount = this.MakeDuplicatePanelLabel("0 TL", 282, 288, 132, 31, 14f, true, Color.FromArgb(255, 183, 28));
			this.lblAmount.TextAlign = ContentAlignment.MiddleRight;
			this.dailyPanel.Controls.Add(this.lblAmount);
			this.statusPanel = new Panel();
			this.statusPanel.Location = new Point(18, 326);
			this.statusPanel.Size = new Size(396, 54);
			this.statusPanel.BackColor = Color.FromArgb(145, 64, 12);
			this.lblStatus = this.MakeDuplicatePanelLabel("", 6, 4, 384, 46, 9.5f, true, Color.White);
			this.lblStatus.TextAlign = ContentAlignment.MiddleCenter;
			this.statusPanel.Controls.Add(this.lblStatus);
			this.dailyPanel.Controls.Add(this.statusPanel);
			this.lblPanelNote = this.MakeDuplicatePanelLabel("Aşağıdaki hareketler ücretin hangi giriş/çıkışlardan oluştuğunu gösterir.", 18, 389, 396, 32, 8.25f, false, Color.LightSteelBlue);
			this.dailyPanel.Controls.Add(this.lblPanelNote);
			Label value4 = this.MakeDuplicatePanelLabel("BUGÜNKÜ HAREKETLER", 18, 420, 396, 22, 9.5f, true, Color.WhiteSmoke);
			this.dailyPanel.Controls.Add(value4);
			this.dailyMovementList = new ListView();
			this.dailyMovementList.Location = new Point(18, 444);
			this.dailyMovementList.Size = new Size(396, 108);
			this.dailyMovementList.View = View.Details;
			this.dailyMovementList.FullRowSelect = true;
			this.dailyMovementList.GridLines = true;
			this.dailyMovementList.HeaderStyle = ColumnHeaderStyle.Nonclickable;
			this.dailyMovementList.MultiSelect = false;
			this.dailyMovementList.HideSelection = false;
			this.dailyMovementList.BackColor = Color.FromArgb(244, 247, 249);
			this.dailyMovementList.ForeColor = Color.FromArgb(28, 35, 43);
			this.dailyMovementList.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular);
			this.dailyMovementList.Columns.Add("#", 30, HorizontalAlignment.Center);
			this.dailyMovementList.Columns.Add("Saat", 66, HorizontalAlignment.Center);
			this.dailyMovementList.Columns.Add("Yön", 54, HorizontalAlignment.Center);
			this.dailyMovementList.Columns.Add("Kam", 38, HorizontalAlignment.Center);
			this.dailyMovementList.Columns.Add("Açıklama", 188, HorizontalAlignment.Left);
			this.dailyPanel.Controls.Add(this.dailyMovementList);
			base.Controls.Add(this.dailyPanel);
			this.dailyPanel.BringToFront();
		}

		private Label MakeDuplicatePanelLabel(string labelText, int x, int y, int width, int height, float size, bool bold, Color color)
		{
			return new Label
			{
				Text = labelText,
				Location = new Point(x, y),
				Size = new Size(width, height),
				Font = new Font("Microsoft Sans Serif", size, bold ? FontStyle.Bold : FontStyle.Regular),
				ForeColor = color,
				BackColor = Color.Transparent
			};
		}

		private Label AddDuplicateValueRow(string caption, int y)
		{
			Label value = this.MakeDuplicatePanelLabel(caption, 18, y, 178, 24, 9f, false, Color.LightSteelBlue);
			Label label = this.MakeDuplicatePanelLabel("-", 218, y, 196, 24, 9.5f, true, Color.WhiteSmoke);
			label.TextAlign = ContentAlignment.MiddleRight;
			this.dailyPanel.Controls.Add(value);
			this.dailyPanel.Controls.Add(label);
			return label;
		}

		private void LoadDuplicateDailyMovements()
		{
			if (this.dailyMovementList != null)
			{
				this.dailyMovementList.Items.Clear();
				if (GlobalVar.DBConnectionStatus && GlobalVar.conn != null)
				{
					DateTime now = DateTime.Now;
					DateTime cycleStartToday = ParkingDurationRule.GetCycleStartToday(this.textPlate.Text);
					string text = "SELECT id, kayittarihi, kameraid, sebep, aracKonum FROM db_loglar WHERE plaka=@plaka AND kayittarihi>@baslangic AND kayittarihi<=@bitis ORDER BY kayittarihi DESC";
					MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
					mySqlCommand.Parameters.AddWithValue("@plaka", this.textPlate.Text);
					mySqlCommand.Parameters.AddWithValue("@baslangic", cycleStartToday.ToString("yyyy-MM-dd HH:mm:ss"));
					mySqlCommand.Parameters.AddWithValue("@bitis", now.ToString("yyyy-MM-dd HH:mm:ss"));
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					try
					{
						int num = 1;
						while (mySqlDataReader.Read())
						{
							string text2 = mySqlDataReader["kayittarihi"].ToString();
							DateTime dateTime;
							if (DateTime.TryParse(text2, out dateTime))
							{
								text2 = dateTime.ToString("HH:mm:ss");
							}
							string text3 = (mySqlDataReader["aracKonum"].ToString() == "i") ? "Giriş" : "Çıkış";
							string text4 = mySqlDataReader["kameraid"].ToString();
							string text5 = mySqlDataReader["sebep"].ToString();
							if (text5 == null)
							{
								text5 = "";
							}
							text5 = text5.Replace("\r", " ").Replace("\n", " ").Trim();
							if (text5.Length > 42)
							{
								text5 = text5.Substring(0, 39) + "...";
							}
							ListViewItem listViewItem = new ListViewItem(num.ToString());
							listViewItem.SubItems.Add(text2);
							listViewItem.SubItems.Add(text3);
							listViewItem.SubItems.Add(text4);
							listViewItem.SubItems.Add(text5);
							if (text3 == "Çıkış")
							{
								listViewItem.BackColor = Color.FromArgb(255, 247, 236);
							}
							else
							{
								listViewItem.BackColor = Color.FromArgb(239, 248, 255);
							}
							this.dailyMovementList.Items.Add(listViewItem);
							num++;
							if (num > 8)
							{
								break;
							}
						}
					}
					finally
					{
						mySqlDataReader.Close();
					}
				}
			}
		}

		private void SetDuplicateDailyPanelVisible(bool visible)
		{
			if (this.dailyPanel != null)
			{
				if (visible)
				{
					if (!this.dailyPanel.Visible)
					{
						base.SuspendLayout();
						base.ClientSize = new Size(852, 594);
						this.dailyPanel.Visible = true;
						this.dailyPanel.BringToFront();
						base.ResumeLayout(false);
						this.EnsurePaymentWindowOnScreen();
					}
				}
				else if (this.dailyPanel.Visible)
				{
					base.SuspendLayout();
					this.dailyPanel.Visible = false;
					base.ClientSize = new Size(386, 533);
					base.ResumeLayout(false);
				}
			}
		}

		private void EnsurePaymentWindowOnScreen()
		{
			Rectangle workingArea = Screen.FromControl(this).WorkingArea;
			int num = base.Left;
			int num2 = base.Top;
			if (num + base.Width > workingArea.Right)
			{
				num = workingArea.Right - base.Width;
			}
			if (num < workingArea.Left)
			{
				num = workingArea.Left;
			}
			if (num2 + base.Height > workingArea.Bottom)
			{
				num2 = workingArea.Bottom - base.Height;
			}
			if (num2 < workingArea.Top)
			{
				num2 = workingArea.Top;
			}
			base.Location = new Point(num, num2);
		}

		private void UpdateDuplicateDailyPanel()
		{
			if (!GlobalVar.DBConnectionStatus || this.dailyPanel == null)
			{
				this.SetDuplicateDailyPanelVisible(false);
			}
			else
			{
				try
				{
					Payment.DuplicateDailySummary duplicateDailySummary = this.GetDuplicateDailySummary();
					bool flag = this.ShouldShowDuplicateDailyPanel(duplicateDailySummary);
					this.SetDuplicateDailyPanelVisible(flag);
					if (flag)
					{
						this.lblVisitCount.Text = duplicateDailySummary.VisitCount.ToString();
						this.lblCurrentVisit.Text = this.FormatDuplicateDuration(duplicateDailySummary.CurrentSeconds);
						this.lblPreviousTotal.Text = this.FormatDuplicateDuration(duplicateDailySummary.PreviousSeconds);
						this.lblDailyTotal.Text = this.FormatDuplicateDuration(duplicateDailySummary.TotalSeconds);
						this.lblFreeLimit.Text = "25 dk 00 sn";
						this.lblCycle.Text = (duplicateDailySummary.ResetByPayment ? "Son ödeme sonrası V2" : "Gün başlangıcından");
						this.lblAmount.Text = this.t_payment.ToString("0.##") + " TL";
						int num = Math.Max(0, duplicateDailySummary.TotalSeconds - 1500);
						this.statusPanel.BackColor = Color.FromArgb(145, 64, 12);
						if (num == 0)
						{
							this.lblStatus.Text = "MÜKERRER ÜCRETLİ\r\n25 dakika sınırına ulaşıldı";
						}
						else
						{
							this.lblStatus.Text = "MÜKERRER ÜCRETLİ\r\n25 dakika sınırı " + this.FormatDuplicateDuration(num) + " aşıldı";
						}
						if (duplicateDailySummary.ResetByPayment)
						{
							this.lblPanelNote.Text = "YENİ DÖNGÜ V2: " + duplicateDailySummary.CycleStart.ToString("HH:mm:ss") + " saatindeki ücretli ödeme öncesi süreler tamamen kapatıldı.";
						}
						else
						{
							this.lblPanelNote.Text = "Bugün henüz ücretli ödeme yok. Mükerrer süreler gün başlangıcından beri toplanır.";
						}
						this.LoadDuplicateDailyMovements();
					}
				}
				catch (Exception)
				{
					this.SetDuplicateDailyPanelVisible(false);
				}
			}
		}

		private void aracTipleri_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.tipID = this.tipIDArray[this.aracTipleri.SelectedIndex];
			this.CalculatePayment();
		}

		private Panel dailyPanel;

		private Panel statusPanel;

		private Label lblVisitCount;

		private Label lblCurrentVisit;

		private Label lblPreviousTotal;

		private Label lblDailyTotal;

		private Label lblFreeLimit;

		private Label lblCycle;

		private Label lblAmount;

		private Label lblStatus;

		private Label lblPanelNote;

		private ListView dailyMovementList;

		public bool odemeileBariyer;

		public string plate;

		public string enterDateTime;

		public string exitDateTime;

		public string exitDateTime2;

		public int tipID;

		public int[] tipIDArray = new int[50];

		public int[] camIDArray = new int[50];

		public int t_minues;

		public double t_payment;

		private bool feeAlertPlayed;

		public bool odemeStatus;

		public string barkod = "";

		public int ucretliAbone;

		private class DuplicateDailySummary
		{
			public int PreviousSeconds;

			public int CurrentSeconds;

			public int TotalSeconds;

			public int CompletedVisitCount;

			public int VisitCount;

			public bool IsCommercialTaxi;

			public DateTime CycleStart;

			public bool ResetByPayment;
		}
	}
}
