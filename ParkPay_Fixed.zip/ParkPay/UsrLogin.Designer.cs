namespace ParkPay
{
	public partial class UsrLogin : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.UsrLogin));
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.cancel = new global::System.Windows.Forms.Button();
			this.login = new global::System.Windows.Forms.Button();
			this.password = new global::System.Windows.Forms.TextBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.userList = new global::System.Windows.Forms.ComboBox();
			this.shapeContainer1 = new global::Microsoft.VisualBasic.PowerPacks.ShapeContainer();
			this.lineShape2 = new global::Microsoft.VisualBasic.PowerPacks.LineShape();
			this.lineShape1 = new global::Microsoft.VisualBasic.PowerPacks.LineShape();
			this.label3 = new global::System.Windows.Forms.Label();
			this.serverSettings = new global::System.Windows.Forms.Button();
			this.checkAdmin = new global::System.Windows.Forms.CheckBox();
			this.textadminPass = new global::System.Windows.Forms.TextBox();
			this.label4 = new global::System.Windows.Forms.Label();
			this.label5 = new global::System.Windows.Forms.Label();
			this.pointid = new global::System.Windows.Forms.TextBox();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			this.groupBox1.SuspendLayout();
			base.SuspendLayout();
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(58, 101);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(135, 150);
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(372, 282);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 14;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(253, 282);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 13;
			this.login.Text = "Tamam";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.password.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.password.Location = new global::System.Drawing.Point(115, 54);
			this.password.Name = "password";
			this.password.PasswordChar = '*';
			this.password.Size = new global::System.Drawing.Size(148, 22);
			this.password.TabIndex = 12;
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label2.Location = new global::System.Drawing.Point(7, 57);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(44, 16);
			this.label2.TabIndex = 11;
			this.label2.Text = "Şifre:";
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label1.Location = new global::System.Drawing.Point(7, 26);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(97, 16);
			this.label1.TabIndex = 9;
			this.label1.Text = "Kullanıcı Adı:";
			this.groupBox1.Controls.Add(this.userList);
			this.groupBox1.Controls.Add(this.password);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.groupBox1.Location = new global::System.Drawing.Point(199, 101);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(283, 89);
			this.groupBox1.TabIndex = 15;
			this.groupBox1.TabStop = false;
			this.userList.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.userList.Enabled = false;
			this.userList.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.userList.FormattingEnabled = true;
			this.userList.Location = new global::System.Drawing.Point(115, 23);
			this.userList.Name = "userList";
			this.userList.Size = new global::System.Drawing.Size(148, 24);
			this.userList.TabIndex = 13;
			this.shapeContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.shapeContainer1.Margin = new global::System.Windows.Forms.Padding(0);
			this.shapeContainer1.Name = "shapeContainer1";
			this.shapeContainer1.Shapes.AddRange(new global::Microsoft.VisualBasic.PowerPacks.Shape[]
			{
				this.lineShape2,
				this.lineShape1
			});
			this.shapeContainer1.Size = new global::System.Drawing.Size(496, 326);
			this.shapeContainer1.TabIndex = 16;
			this.shapeContainer1.TabStop = false;
			this.lineShape2.BorderColor = global::System.Drawing.SystemColors.ControlDark;
			this.lineShape2.Name = "lineShape2";
			this.lineShape2.X1 = 16;
			this.lineShape2.X2 = 481;
			this.lineShape2.Y1 = 64;
			this.lineShape2.Y2 = 64;
			this.lineShape1.BorderColor = global::System.Drawing.SystemColors.ControlDark;
			this.lineShape1.Name = "lineShape1";
			this.lineShape1.X1 = 19;
			this.lineShape1.X2 = 484;
			this.lineShape1.Y1 = 266;
			this.lineShape1.Y2 = 266;
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Arial", 21.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label3.Location = new global::System.Drawing.Point(97, 26);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(337, 34);
			this.label3.TabIndex = 17;
			this.label3.Text = "Otopark Kullanıcı Girişi";
			this.serverSettings.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.serverSettings.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("serverSettings.Image");
			this.serverSettings.Location = new global::System.Drawing.Point(19, 282);
			this.serverSettings.Name = "serverSettings";
			this.serverSettings.Size = new global::System.Drawing.Size(160, 32);
			this.serverSettings.TabIndex = 18;
			this.serverSettings.Text = "Sunucu Ayarları";
			this.serverSettings.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.serverSettings.UseVisualStyleBackColor = true;
			this.serverSettings.Click += new global::System.EventHandler(this.serverSettings_Click);
			this.checkAdmin.AutoSize = true;
			this.checkAdmin.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.checkAdmin.Location = new global::System.Drawing.Point(209, 200);
			this.checkAdmin.Name = "checkAdmin";
			this.checkAdmin.Size = new global::System.Drawing.Size(106, 20);
			this.checkAdmin.TabIndex = 19;
			this.checkAdmin.Text = "Admin Giriş";
			this.checkAdmin.UseVisualStyleBackColor = true;
			this.checkAdmin.CheckedChanged += new global::System.EventHandler(this.checkAdmin_CheckedChanged);
			this.textadminPass.Enabled = false;
			this.textadminPass.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textadminPass.Location = new global::System.Drawing.Point(314, 226);
			this.textadminPass.Name = "textadminPass";
			this.textadminPass.PasswordChar = '*';
			this.textadminPass.Size = new global::System.Drawing.Size(148, 22);
			this.textadminPass.TabIndex = 21;
			this.label4.AutoSize = true;
			this.label4.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label4.Location = new global::System.Drawing.Point(206, 229);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(91, 16);
			this.label4.TabIndex = 20;
			this.label4.Text = "Admin Şifre:";
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label5.Location = new global::System.Drawing.Point(206, 82);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(72, 16);
			this.label5.TabIndex = 22;
			this.label5.Text = "Nokta ID:";
			this.pointid.Enabled = false;
			this.pointid.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.pointid.Location = new global::System.Drawing.Point(314, 79);
			this.pointid.Name = "pointid";
			this.pointid.ReadOnly = true;
			this.pointid.Size = new global::System.Drawing.Size(148, 22);
			this.pointid.TabIndex = 23;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(496, 326);
			base.Controls.Add(this.pointid);
			base.Controls.Add(this.label5);
			base.Controls.Add(this.textadminPass);
			base.Controls.Add(this.label4);
			base.Controls.Add(this.checkAdmin);
			base.Controls.Add(this.serverSettings);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.groupBox1);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.login);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.shapeContainer1);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "UsrLogin";
			base.ShowInTaskbar = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Kullanıcı Giriş";
			base.TopMost = true;
			base.Load += new global::System.EventHandler(this.UsrLogin_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.PictureBox pictureBox1;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.Button login;

		private global::System.Windows.Forms.TextBox password;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.GroupBox groupBox1;

		private global::Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;

		private global::Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;

		private global::Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.ComboBox userList;

		private global::System.Windows.Forms.Button serverSettings;

		private global::System.Windows.Forms.CheckBox checkAdmin;

		private global::System.Windows.Forms.TextBox textadminPass;

		private global::System.Windows.Forms.Label label4;

		private global::System.Windows.Forms.Label label5;

		private global::System.Windows.Forms.TextBox pointid;
	}
}
