using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;
using PdfSharp.Drawing;
using PdfSharp.Pdf;

namespace ParkPay
{
	public partial class AbonelikUzat : Form
	{
		public AbonelikUzat()
		{
			this.InitializeComponent();
		}

		private void login_Click(object sender, EventArgs e)
		{
			if (this.musteriID < 1)
			{
				MessageBox.Show("Müşteri Seçilmedi...");
			}
			else
			{
				DateTime now = DateTime.Now;
				string format = "yyyy-MM-dd HH:mm:ss";
				string text = now.ToString(format);
				this.endDateTime = this.endDateTime.AddDays((double)this.abonelikSure);
				string text2 = this.endDateTime.ToString(format);
				string text3 = string.Concat(new string[]
				{
					"UPDATE db_araclar SET UID=1 , abonelikbaslangic='",
					text,
					"' , abonelikbitis='",
					text2,
					"' WHERE plaka='",
					this.plate,
					"'"
				});
				MySqlCommand mySqlCommand = new MySqlCommand(text3, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				string text4 = this.textFiyat.Text;
				text4 = text4.Replace(",", ".");
				text3 = string.Concat(new object[]
				{
					"INSERT INTO db_odemeler (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`,`plaka` , `abonesure` , `operatorid` , `pointID`) VALUES (NULL , '",
					this.musteriID.ToString(),
					"', '",
					text4,
					"','",
					text4,
					"','",
					text,
					"','0','",
					this.plate,
					"' , ",
					this.abonelikSure.ToString(),
					" , ",
					GlobalVar.activeId,
					" , ",
					GlobalVar.pointID,
					")"
				});
				MySqlCommand mySqlCommand2 = new MySqlCommand(text3, GlobalVar.conn);
				MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
				mySqlDataReader2.Close();
				this.abone_bas_tar = text;
				this.abone_bit_tar = text2;
				this.abone_ucret = this.textFiyat.Text;
				this.uzatma_ok = true;
				this.login.Enabled = false;
				this.bituzatBtn.Enabled = false;
				this.printBtn.Enabled = true;
			}
		}

		private void AbonelikUzat_Load(object sender, EventArgs e)
		{
			this.textPlate.Text = this.plate;
			this.textIndirim.Text = "0";
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_abonelikturleri ORDER by id ASC";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				int num = 0;
				while (mySqlDataReader.Read())
				{
					string item = string.Concat(new string[]
					{
						mySqlDataReader["abonelik_adi"].ToString(),
						" ",
						mySqlDataReader["abonelik_suresi"].ToString(),
						"gun ",
						mySqlDataReader["ucret"].ToString(),
						"TL"
					});
					this.abonelikTipleri.Items.Add(item);
					this.abonelikSureArray[num] = int.Parse(mySqlDataReader["abonelik_suresi"].ToString());
					this.abonelikUcretArray[num] = int.Parse(mySqlDataReader["ucret"].ToString());
					num++;
				}
				mySqlDataReader.Close();
				this.abonelikTipleri.SelectedIndex = 0;
				this.abonelikSure = this.abonelikSureArray[0];
				this.abonelikUcret = this.abonelikUcretArray[0];
				text = "SELECT * FROM db_musteriler WHERE id=" + this.musteriID.ToString() + " ";
				MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
				if (mySqlDataReader2.Read())
				{
					this.textIndirim.Text = mySqlDataReader2["uyeindirim"].ToString();
				}
				mySqlDataReader2.Close();
				this.FiyatHesapla();
			}
		}

		private void FiyatHesapla()
		{
			int num = Convert.ToInt32(Convert.ToDouble(this.abonelikUcret) * Convert.ToDouble(this.textIndirim.Text));
			int num2 = this.abonelikUcret - num;
			this.textFiyat.Text = num2.ToString();
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void abonelikTipleri_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.abonelikSure = this.abonelikSureArray[this.abonelikTipleri.SelectedIndex];
			this.abonelikUcret = this.abonelikUcretArray[this.abonelikTipleri.SelectedIndex];
			this.textFiyat.Text = this.abonelikUcret.ToString();
			this.FiyatHesapla();
		}

		private void close_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void printBtn_Click(object sender, EventArgs e)
		{
			int num = 200;
			int num2 = 0;
			int num3 = 30;
			int num4 = 600;
			PdfDocument pdfDocument = new PdfDocument();
			XFont xfont = new XFont("Verdana", (double)GlobalVar.FontSize1);
			XFont xfont2 = new XFont("Verdana", (double)GlobalVar.FontSize2);
			PdfPage pdfPage = pdfDocument.AddPage();
			XGraphics xgraphics = XGraphics.FromPdfPage(pdfPage);
			xgraphics.DrawLine(XPens.Black, 0, num - num3 + 3, num4, num - num3 + 3);
			xgraphics.DrawString(GlobalVar.Label1, xfont2, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			string text = GlobalVar.Label2;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			text = GlobalVar.Label3;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "Plaka: " + this.plate;
			num += num3;
			xgraphics.DrawString(text, xfont2, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "Abonelik Bas. Zamanı: " + this.abone_bas_tar;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			text = "Abonelik Bit. Zamanı: " + this.abone_bit_tar;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "Ücret: " + this.abone_ucret + " TL";
			num += num3;
			xgraphics.DrawString(text, xfont2, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			pdfDocument.Save("abone_tempfile.pdf");
			Thread.Sleep(1000);
			Process.Start(new ProcessStartInfo
			{
				UseShellExecute = true,
				Verb = "print",
				WindowStyle = ProcessWindowStyle.Hidden,
				FileName = "abone_tempfile.pdf"
			});
		}

		private void bituzatBtn_Click(object sender, EventArgs e)
		{
			if (this.musteriID < 1)
			{
				MessageBox.Show("Müşteri Seçilmedi...");
			}
			else
			{
				DateTime now = DateTime.Now;
				string format = "yyyy-MM-dd HH:mm:ss";
				string text = now.ToString(format);
				this.endDateTimeReal = this.endDateTimeReal.AddDays((double)this.abonelikSure);
				string text2 = this.endDateTimeReal.ToString(format);
				string text3 = string.Concat(new string[]
				{
					"UPDATE db_araclar SET UID=1 , abonelikbaslangic='",
					text,
					"' , abonelikbitis='",
					text2,
					"' WHERE plaka='",
					this.plate,
					"'"
				});
				MySqlCommand mySqlCommand = new MySqlCommand(text3, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				string text4 = this.textFiyat.Text;
				text4 = text4.Replace(",", ".");
				text3 = string.Concat(new object[]
				{
					"INSERT INTO db_odemeler (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`,`plaka` , `abonesure` , `operatorid` , `pointID`) VALUES (NULL , '",
					this.musteriID.ToString(),
					"', '",
					text4,
					"','",
					text4,
					"','",
					text,
					"','0','",
					this.plate,
					"' , ",
					this.abonelikSure.ToString(),
					" , ",
					GlobalVar.activeId,
					" , ",
					GlobalVar.pointID,
					")"
				});
				MySqlCommand mySqlCommand2 = new MySqlCommand(text3, GlobalVar.conn);
				MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
				mySqlDataReader2.Close();
				this.abone_bas_tar = text;
				this.abone_bit_tar = text2;
				this.abone_ucret = this.textFiyat.Text;
				this.uzatma_ok = true;
				this.login.Enabled = false;
				this.bituzatBtn.Enabled = false;
				this.printBtn.Enabled = true;
			}
		}

		public string plate;

		public int plateId;

		public DateTime endDateTime;

		public DateTime endDateTimeReal;

		public int musteriID;

		public double musteriIndirim;

		public int abonelikSure;

		public int[] abonelikSureArray = new int[50];

		public int abonelikUcret;

		public int[] abonelikUcretArray = new int[50];

		public bool uzatma_ok;

		public string abone_bas_tar = "";

		public string abone_bit_tar = "";

		public string abone_ucret = "";
	}
}
