namespace ParkPay
{
	public partial class AboneOdemeler : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.AboneOdemeler));
			this.listView1 = new global::System.Windows.Forms.ListView();
			this.columnHeader1 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new global::System.Windows.Forms.ColumnHeader();
			this.label1 = new global::System.Windows.Forms.Label();
			this.login = new global::System.Windows.Forms.Button();
			this.cancel = new global::System.Windows.Forms.Button();
			base.SuspendLayout();
			this.listView1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.columnHeader1,
				this.columnHeader2,
				this.columnHeader3,
				this.columnHeader4
			});
			this.listView1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.listView1.FullRowSelect = true;
			this.listView1.HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.listView1.HideSelection = false;
			this.listView1.Location = new global::System.Drawing.Point(12, 30);
			this.listView1.Name = "listView1";
			this.listView1.Size = new global::System.Drawing.Size(405, 264);
			this.listView1.TabIndex = 25;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = global::System.Windows.Forms.View.Details;
			this.columnHeader1.Text = "Plaka";
			this.columnHeader1.Width = 95;
			this.columnHeader2.Text = "Zaman";
			this.columnHeader2.Width = 160;
			this.columnHeader3.Text = "Ücret";
			this.columnHeader3.Width = 80;
			this.columnHeader4.Text = "Süre";
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label1.Location = new global::System.Drawing.Point(9, 9);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(213, 18);
			this.label1.TabIndex = 76;
			this.label1.Text = "Yapılan Abonelik Ödemeleri";
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
			this.login.Location = new global::System.Drawing.Point(185, 300);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 77;
			this.login.Text = "Tamam";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
			this.cancel.Location = new global::System.Drawing.Point(304, 300);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 78;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(428, 342);
			base.Controls.Add(this.login);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.listView1);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "AboneOdemeler";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Abonelik Ödemeler";
			base.Load += new global::System.EventHandler(this.AboneOdemeler_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.ListView listView1;

		private global::System.Windows.Forms.ColumnHeader columnHeader1;

		private global::System.Windows.Forms.ColumnHeader columnHeader2;

		private global::System.Windows.Forms.ColumnHeader columnHeader3;

		private global::System.Windows.Forms.ColumnHeader columnHeader4;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.Button login;

		private global::System.Windows.Forms.Button cancel;
	}
}
