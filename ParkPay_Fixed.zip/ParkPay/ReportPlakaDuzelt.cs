using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class ReportPlakaDuzelt : Form
	{
		public ReportPlakaDuzelt()
		{
			this.InitializeComponent();
		}

		private void login_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				if (this.textPlate2.Text.Length < 1)
				{
					MessageBox.Show("Plaka Giriniz...");
				}
				else
				{
					this.textPlate2.Text = this.textPlate2.Text.ToUpper();
					string text = string.Concat(new string[]
					{
						"UPDATE db_araclar SET plaka='",
						this.textPlate2.Text,
						"' WHERE id='",
						this.id,
						"'"
					});
					MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					mySqlDataReader.Close();
					this.plate = this.textPlate2.Text;
					base.Close();
				}
			}
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void ReportPlakaDuzelt_Load(object sender, EventArgs e)
		{
			this.textPlate.Text = this.plate;
			this.textPlate2.Text = this.plate;
		}

		public string plate = "";

		public string id = "";
	}
}
