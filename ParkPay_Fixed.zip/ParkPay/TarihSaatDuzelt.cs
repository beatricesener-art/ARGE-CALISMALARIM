using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class TarihSaatDuzelt : Form
	{
		public TarihSaatDuzelt()
		{
			this.InitializeComponent();
		}

		private void login_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = string.Concat(new string[]
				{
					"UPDATE db_araclar SET sondegisim='",
					this.enterDate.Text,
					" ",
					this.enterTime.Text,
					"'  WHERE id='",
					this.id,
					"'"
				});
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				base.Close();
			}
		}

		private void TarihSaatDuzelt_Load(object sender, EventArgs e)
		{
			this.enterDate.CustomFormat = "yyyy-MM-dd";
			this.enterDate.Text = this.tarihsaat;
			this.enterTime.CustomFormat = "HH:mm:ss";
			this.enterTime.Text = this.tarihsaat;
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		public string tarihsaat = "";

		public string id = "";
	}
}
