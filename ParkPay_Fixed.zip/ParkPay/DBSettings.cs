using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class DBSettings : Form
	{
		public DBSettings()
		{
			this.InitializeComponent();
		}

		private void DBSettings_Load(object sender, EventArgs e)
		{
			this.dbname.Text = GlobalVar.DBInfo.dbname;
			this.password.Text = GlobalVar.DBInfo.password;
			this.username.Text = GlobalVar.DBInfo.username;
			this.ipaddress.Text = GlobalVar.DBInfo.serverip;
			this.camList.Text = GlobalVar.paymentCam.ToString();
			this.textWebUrl.Text = GlobalVar.WebURL;
		}

		private void BtnTest_Click(object sender, EventArgs e)
		{
			string connectionString = string.Concat(new string[]
			{
				"server=",
				GlobalVar.DBInfo.serverip,
				";uid=",
				GlobalVar.DBInfo.username,
				";pwd=",
				GlobalVar.DBInfo.password,
				";database=",
				GlobalVar.DBInfo.dbname,
				";"
			});
			MySqlConnection mySqlConnection = new MySqlConnection();
			try
			{
				mySqlConnection.ConnectionString = connectionString;
				mySqlConnection.Open();
				MessageBox.Show("Sorunsuz Bağlandı!", "Bilgi");
			}
			catch (MySqlException ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void BtnSave_Click(object sender, EventArgs e)
		{
			GlobalVar.SetDBValues(this.dbname.Text, this.username.Text, this.password.Text, this.ipaddress.Text);
			GlobalVar.paymentCam = int.Parse(this.camList.Text);
			GlobalVar.WebURL = this.textWebUrl.Text;
			base.Close();
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void BtnDBDuzenle_Click(object sender, EventArgs e)
		{
			Main main = (Main)base.Owner;
			main.DelLogs();
			MessageBox.Show("Veritabani Düzenlendi!");
		}
	}
}
