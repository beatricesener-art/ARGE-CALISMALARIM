using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class VehicleReport : Form
	{
		public VehicleReport()
		{
			this.InitializeComponent();
		}

		private void ListePlates(int type)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				DateTime now = DateTime.Now;
				string format = "yyyy-MM-dd HH:mm:ss";
				string text = now.ToString(format);
				string text2 = "";
				if (this.checkAbone.Checked)
				{
					text2 = "geciciarac=2 AND ";
				}
				if (this.checkIcerde.Checked && this.checkDisarda.Checked)
				{
					text2 = (text2 ?? "");
				}
				else if (this.checkIcerde.Checked)
				{
					text2 += "aracKonum = 'i' AND ";
				}
				else if (this.checkDisarda.Checked)
				{
					text2 += "aracKonum = 'd' AND ";
				}
				string text3 = "";
				if (type == 0)
				{
					text3 = " ORDER by id ASC";
				}
				else if (type == 1)
				{
					text3 = " ORDER by plaka ASC";
				}
				else if (type == 2)
				{
					text3 = " ORDER by sondegisim ASC";
				}
				string text6;
				if (this.checkZaman.Checked)
				{
					this.enterDate.CustomFormat = "yyyy-MM-dd";
					this.exitDate.CustomFormat = "yyyy-MM-dd";
					string text4 = this.enterDate.Text + " " + this.enterTime.Text;
					string text5 = this.exitDate.Text + " " + this.exitTime.Text;
					text6 = string.Concat(new string[]
					{
						"SELECT * FROM db_araclar WHERE ",
						text2,
						"sondegisim BETWEEN '",
						text4,
						"' AND '",
						text5,
						"' AND plaka LIKE '%",
						this.textPlate.Text,
						"%'",
						text3
					});
				}
				else
				{
					text6 = string.Concat(new string[]
					{
						"SELECT * FROM db_araclar WHERE ",
						text2,
						"( abonelikbitis < '",
						text,
						"' OR abonelikTipi=1 ) AND plaka LIKE '%",
						this.textPlate.Text,
						"%'",
						text3
					});
				}
				MySqlCommand mySqlCommand = new MySqlCommand(text6, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				this.listView1.Items.Clear();
				while (mySqlDataReader.Read())
				{
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = mySqlDataReader["id"].ToString();
					try
					{
						listViewItem.SubItems.Add(mySqlDataReader["plaka"].ToString());
						listViewItem.SubItems.Add(mySqlDataReader["sondegisim"].ToString());
						if (int.Parse(mySqlDataReader["geciciarac"].ToString()) > 1)
						{
							listViewItem.SubItems.Add("Evet");
							try
							{
								listViewItem.SubItems.Add(mySqlDataReader["abonelikbitis"].ToString());
								goto IL_367;
							}
							catch (Exception)
							{
								listViewItem.SubItems.Add("0000-00-00 00:00:00");
								goto IL_367;
							}
						}
						listViewItem.SubItems.Add("Hayır");
						listViewItem.SubItems.Add("0000-00-00 00:00:00");
						IL_367:
						if (mySqlDataReader["aracKonum"].ToString() == "i")
						{
							listViewItem.SubItems.Add("Icerde");
						}
						else
						{
							listViewItem.SubItems.Add("Disarda");
						}
					}
					catch (Exception)
					{
						listViewItem.SubItems.Add("0000-00-00 00:00:00");
						if (int.Parse(mySqlDataReader["geciciarac"].ToString()) > 1)
						{
							listViewItem.SubItems.Add("Evet");
							try
							{
								listViewItem.SubItems.Add(mySqlDataReader["abonelikbitis"].ToString());
								goto IL_460;
							}
							catch (Exception)
							{
								listViewItem.SubItems.Add("0000-00-00 00:00:00");
								goto IL_460;
							}
						}
						listViewItem.SubItems.Add("Hayır");
						listViewItem.SubItems.Add("0000-00-00 00:00:00");
						IL_460:
						if (mySqlDataReader["aracKonum"].ToString() == "i")
						{
							listViewItem.SubItems.Add("Icerde");
						}
						else
						{
							listViewItem.SubItems.Add("Disarda");
						}
					}
					this.listView1.Items.Add(listViewItem);
				}
				mySqlDataReader.Close();
			}
		}

		private void btnSearch_Click(object sender, EventArgs e)
		{
			this.ListePlates(0);
		}

		private void PlakayiSil(string silPlaka)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "DELETE FROM db_araclar WHERE id = '" + silPlaka + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				Main main = (Main)base.Owner;
				main.YoneticiLogEkle("Araclardan: " + silPlaka + " Silindi! ");
			}
		}

		private void PlakayYonDegistir(string silPlaka, string yon)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = string.Concat(new string[]
				{
					"UPDATE db_araclar SET aracKonum='",
					yon,
					"'  WHERE id='",
					silPlaka,
					"'"
				});
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				Main main = (Main)base.Owner;
				main.YoneticiLogEkle(string.Concat(new string[]
				{
					"Araclardan Plaka:",
					silPlaka,
					" Yon:",
					yon,
					" Oldu! "
				}));
			}
		}

		private void aracSilBtn_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count <= 0)
			{
				MessageBox.Show("Seçili Plaka Yok!");
			}
			else if (MessageBox.Show("Seçilen Plaka Silmek İstiyor musunuz?", "Seçilen Plaka Sil", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				for (int i = 0; i < this.listView1.SelectedIndices.Count; i++)
				{
					int index = this.listView1.SelectedIndices[i];
					string text = this.listView1.Items[index].Text;
					this.PlakayiSil(text);
				}
				this.ListePlates(0);
			}
		}

		private void aracCikartBtn_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count <= 0)
			{
				MessageBox.Show("Seçili Plaka Yok!");
			}
			else
			{
				for (int i = 0; i < this.listView1.SelectedIndices.Count; i++)
				{
					int index = this.listView1.SelectedIndices[i];
					string text = this.listView1.Items[index].Text;
					this.PlakayYonDegistir(text, "d");
				}
				this.ListePlates(0);
			}
		}

		private void aracIceriBtn_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count <= 0)
			{
				MessageBox.Show("Seçili Plaka Yok!");
			}
			else
			{
				for (int i = 0; i < this.listView1.SelectedIndices.Count; i++)
				{
					int index = this.listView1.SelectedIndices[i];
					string text = this.listView1.Items[index].Text;
					this.PlakayYonDegistir(text, "i");
				}
				this.ListePlates(0);
			}
		}

		private void aracGTDBtn_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count <= 0)
			{
				MessageBox.Show("Seçili Plaka Yok!");
			}
			else if (this.listView1.SelectedIndices.Count > 1)
			{
				MessageBox.Show("Seçili Plaka Birden Fazla!");
			}
			else
			{
				int index = this.listView1.SelectedIndices[0];
				string text = this.listView1.Items[index].Text;
				string text2 = this.listView1.Items[index].SubItems[2].Text;
				new TarihSaatDuzelt
				{
					tarihsaat = text2,
					id = text
				}.ShowDialog(this);
				Main main = (Main)base.Owner;
				main.YoneticiLogEkle("Araclardan Plaka:" + this.listView1.Items[index].SubItems[1].Text + " Tarih-Saat Degistirildi! ");
				this.ListePlates(0);
			}
		}

		private void aracPlakaDuzelt_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count <= 0)
			{
				MessageBox.Show("Seçili Plaka Yok!");
			}
			else if (this.listView1.SelectedIndices.Count > 1)
			{
				MessageBox.Show("Seçili Plaka Birden Fazla!");
			}
			else
			{
				int index = this.listView1.SelectedIndices[0];
				string text = this.listView1.Items[index].Text;
				string text2 = this.listView1.Items[index].SubItems[1].Text;
				new ReportPlakaDuzelt
				{
					plate = text2,
					id = text
				}.ShowDialog(this);
				Main main = (Main)base.Owner;
				main.YoneticiLogEkle("Araclardan Plaka:" + text2 + " Plaka Degistirildi! ");
				this.ListePlates(0);
			}
		}

		private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
		{
			this.ListePlates(e.Column);
		}

		private void ShowPicSearch(string plate)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_loglar WHERE plaka = '" + plate + "' order by `kayittarihi` DESC LIMIT 0,1";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				string text2 = "";
				bool flag = false;
				if (mySqlDataReader.Read())
				{
					text2 = mySqlDataReader["resimyolu"].ToString();
					flag = true;
				}
				mySqlDataReader.Close();
				if (flag && text2.Length > 0)
				{
					int num = text2.IndexOf("_");
					string str = string.Concat(new string[]
					{
						GlobalVar.GlobalPath,
						text2.Substring(num + 1, 4),
						"\\",
						text2.Substring(num + 5, 2),
						"\\",
						text2.Substring(num + 7, 2),
						"\\"
					});
					try
					{
						Image image = Image.FromFile(str + text2);
						this.pictureSearch.Image = image;
						this.pictureSearch.SizeMode = PictureBoxSizeMode.StretchImage;
					}
					catch (Exception)
					{
					}
				}
			}
		}

		private void listView1_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count > 0)
			{
				int num = this.listView1.SelectedIndices[0];
				if (num >= 0)
				{
					string text = this.listView1.Items[num].SubItems[1].Text;
					this.ShowPicSearch(text);
				}
			}
		}
	}
}
