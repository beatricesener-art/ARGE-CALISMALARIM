using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class AboneAracEkleDuzenle : Form
	{
		public AboneAracEkleDuzenle()
		{
			this.InitializeComponent();
		}

		private void AboneAracEkleDuzenle_Load(object sender, EventArgs e)
		{
			this.textAdi.Text = this.MusteriAd;
			this.textSoyad.Text = this.MusteriSoyad;
			if (this.Duzenle)
			{
				this.login.Text = "Düzenle";
				string text = "SELECT * FROM db_araclar WHERE id = " + this.plateID.ToString();
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				if (mySqlDataReader.Read())
				{
					this.textMarka.Text = mySqlDataReader["marka"].ToString();
					this.textModel.Text = mySqlDataReader["model"].ToString();
					this.textRenk.Text = mySqlDataReader["renk"].ToString();
					this.textASaat.Text = mySqlDataReader["AbonelikSaat"].ToString();
					if (mySqlDataReader["abonelikTipi"].ToString() == "1")
					{
						this.aboneSaatlik.Checked = true;
					}
					else
					{
						this.aboneSaatlik.Checked = false;
					}
				}
				mySqlDataReader.Close();
				this.textPlate.Text = this.plate;
			}
			else
			{
				this.login.Text = "Ekle";
				this.textMarka.Text = "M";
				this.textModel.Text = "M";
				this.textRenk.Text = "R";
			}
		}

		private void login_Click(object sender, EventArgs e)
		{
			DateTime now = DateTime.Now;
			string format = "yyyy-MM-dd HH:mm:ss";
			string text = now.ToString(format);
			if (GlobalVar.DBConnectionStatus)
			{
				this.textPlate.Text = this.textPlate.Text.ToUpper();
				int num;
				if (this.aboneSaatlik.Checked)
				{
					num = 1;
				}
				else
				{
					num = 0;
				}
				string text2;
				if (this.Duzenle)
				{
					text2 = string.Concat(new object[]
					{
						"UPDATE db_araclar SET marka='",
						this.textMarka.Text,
						"' , model='",
						this.textModel.Text,
						"' , renk='",
						this.textRenk.Text,
						"' , plaka='",
						this.textPlate.Text,
						"' , abonelikTipi=",
						num,
						" , AbonelikSaat = '",
						this.textASaat.Text,
						"' WHERE id=",
						this.plateID.ToString()
					});
				}
				else
				{
					text2 = string.Concat(new object[]
					{
						"INSERT INTO db_araclar (`id` ,`kullaniciid` ,`marka` ,`model` ,`renk` ,`eklenme`,`plaka` , `geciciarac` , `abonelikbaslangic` , `abonelikTipi` , `AbonelikSaat` ) VALUES (NULL , '",
						this.MusteriID.ToString(),
						"','",
						this.textMarka.Text,
						"','",
						this.textModel.Text,
						"','",
						this.textRenk.Text,
						"' , '",
						text,
						"' , '",
						this.textPlate.Text,
						"', 2,  '",
						text,
						"' , ",
						num,
						" , '",
						this.textASaat.Text,
						"')"
					});
				}
				MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				base.Close();
			}
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		public int MusteriID;

		public string MusteriAd = "";

		public string MusteriSoyad = "";

		public string plate = "";

		public int plateID;

		public bool Duzenle;
	}
}
