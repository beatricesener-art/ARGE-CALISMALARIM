namespace ParkPay
{
	public partial class AbonelikUzat : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.AbonelikUzat));
			this.textPlate = new global::System.Windows.Forms.TextBox();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.abonelikTipleri = new global::System.Windows.Forms.ComboBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.cancel = new global::System.Windows.Forms.Button();
			this.login = new global::System.Windows.Forms.Button();
			this.lineShape1 = new global::Microsoft.VisualBasic.PowerPacks.LineShape();
			this.shapeContainer1 = new global::Microsoft.VisualBasic.PowerPacks.ShapeContainer();
			this.label2 = new global::System.Windows.Forms.Label();
			this.textFiyat = new global::System.Windows.Forms.TextBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.textIndirim = new global::System.Windows.Forms.TextBox();
			this.printBtn = new global::System.Windows.Forms.Button();
			this.close = new global::System.Windows.Forms.Button();
			this.bituzatBtn = new global::System.Windows.Forms.Button();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			base.SuspendLayout();
			this.textPlate.Enabled = false;
			this.textPlate.Font = new global::System.Drawing.Font("Arial", 36f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPlate.Location = new global::System.Drawing.Point(84, 44);
			this.textPlate.Name = "textPlate";
			this.textPlate.ReadOnly = true;
			this.textPlate.Size = new global::System.Drawing.Size(274, 63);
			this.textPlate.TabIndex = 5;
			this.pictureBox3.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(19, 23);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(352, 103);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 4;
			this.pictureBox3.TabStop = false;
			this.abonelikTipleri.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.abonelikTipleri.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.abonelikTipleri.FormattingEnabled = true;
			this.abonelikTipleri.Location = new global::System.Drawing.Point(131, 148);
			this.abonelikTipleri.Name = "abonelikTipleri";
			this.abonelikTipleri.Size = new global::System.Drawing.Size(240, 26);
			this.abonelikTipleri.TabIndex = 7;
			this.abonelikTipleri.SelectedIndexChanged += new global::System.EventHandler(this.abonelikTipleri_SelectedIndexChanged);
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label1.Location = new global::System.Drawing.Point(21, 151);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(104, 18);
			this.label1.TabIndex = 6;
			this.label1.Text = "Abonelik Tipi";
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(263, 316);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 18;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(229, 181);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(147, 32);
			this.login.TabIndex = 17;
			this.login.Text = "Bugünden Uzat";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.lineShape1.BorderColor = global::System.Drawing.SystemColors.ControlDark;
			this.lineShape1.Name = "lineShape1";
			this.lineShape1.X1 = 17;
			this.lineShape1.X2 = 374;
			this.lineShape1.Y1 = 309;
			this.lineShape1.Y2 = 309;
			this.shapeContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.shapeContainer1.Margin = new global::System.Windows.Forms.Padding(0);
			this.shapeContainer1.Name = "shapeContainer1";
			this.shapeContainer1.Shapes.AddRange(new global::Microsoft.VisualBasic.PowerPacks.Shape[]
			{
				this.lineShape1
			});
			this.shapeContainer1.Size = new global::System.Drawing.Size(400, 355);
			this.shapeContainer1.TabIndex = 19;
			this.shapeContainer1.TabStop = false;
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label2.Location = new global::System.Drawing.Point(21, 211);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(49, 18);
			this.label2.TabIndex = 20;
			this.label2.Text = "Ücret";
			this.textFiyat.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.textFiyat.Location = new global::System.Drawing.Point(131, 210);
			this.textFiyat.Name = "textFiyat";
			this.textFiyat.Size = new global::System.Drawing.Size(87, 24);
			this.textFiyat.TabIndex = 30;
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label3.Location = new global::System.Drawing.Point(21, 180);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(104, 18);
			this.label3.TabIndex = 31;
			this.label3.Text = "İndirim Oranı";
			this.textIndirim.Enabled = false;
			this.textIndirim.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.textIndirim.Location = new global::System.Drawing.Point(131, 180);
			this.textIndirim.Name = "textIndirim";
			this.textIndirim.ReadOnly = true;
			this.textIndirim.Size = new global::System.Drawing.Size(58, 24);
			this.textIndirim.TabIndex = 32;
			this.printBtn.Enabled = false;
			this.printBtn.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.printBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("printBtn.Image");
			this.printBtn.Location = new global::System.Drawing.Point(278, 257);
			this.printBtn.Name = "printBtn";
			this.printBtn.Size = new global::System.Drawing.Size(98, 32);
			this.printBtn.TabIndex = 33;
			this.printBtn.Text = "Yazdır";
			this.printBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.printBtn.UseVisualStyleBackColor = true;
			this.printBtn.Click += new global::System.EventHandler(this.printBtn_Click);
			this.close.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.close.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("close.Image");
			this.close.Location = new global::System.Drawing.Point(144, 316);
			this.close.Name = "close";
			this.close.Size = new global::System.Drawing.Size(113, 32);
			this.close.TabIndex = 34;
			this.close.Text = "Tamam";
			this.close.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.close.UseVisualStyleBackColor = true;
			this.close.Click += new global::System.EventHandler(this.close_Click);
			this.bituzatBtn.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.bituzatBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("bituzatBtn.Image");
			this.bituzatBtn.Location = new global::System.Drawing.Point(228, 219);
			this.bituzatBtn.Name = "bituzatBtn";
			this.bituzatBtn.Size = new global::System.Drawing.Size(147, 32);
			this.bituzatBtn.TabIndex = 35;
			this.bituzatBtn.Text = "Bitişten Uzat";
			this.bituzatBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.bituzatBtn.UseVisualStyleBackColor = true;
			this.bituzatBtn.Click += new global::System.EventHandler(this.bituzatBtn_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(400, 355);
			base.Controls.Add(this.bituzatBtn);
			base.Controls.Add(this.close);
			base.Controls.Add(this.printBtn);
			base.Controls.Add(this.textIndirim);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.textFiyat);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.login);
			base.Controls.Add(this.abonelikTipleri);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.textPlate);
			base.Controls.Add(this.pictureBox3);
			base.Controls.Add(this.shapeContainer1);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "AbonelikUzat";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "AbonelikUzat";
			base.TopMost = true;
			base.Load += new global::System.EventHandler(this.AbonelikUzat_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.TextBox textPlate;

		private global::System.Windows.Forms.PictureBox pictureBox3;

		private global::System.Windows.Forms.ComboBox abonelikTipleri;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.Button login;

		private global::Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;

		private global::Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.TextBox textFiyat;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.TextBox textIndirim;

		private global::System.Windows.Forms.Button printBtn;

		private global::System.Windows.Forms.Button close;

		private global::System.Windows.Forms.Button bituzatBtn;
	}
}
