using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class AracLogListesi : Form
	{
		public AracLogListesi()
		{
			this.InitializeComponent();
		}

		private void ListeLog()
		{
			if (GlobalVar.DBConnectionStatus)
			{
				DateTime now = DateTime.Now;
				string format = "yyyy-MM-dd HH:mm:ss";
				now.ToString(format);
				this.enterDate.CustomFormat = "yyyy-MM-dd";
				this.exitDate.CustomFormat = "yyyy-MM-dd";
				string text = this.enterDate.Text + " " + this.enterTime.Text;
				string text2 = this.exitDate.Text + " " + this.exitTime.Text;
				string text3 = string.Concat(new string[]
				{
					"SELECT * FROM db_loglar WHERE kayittarihi BETWEEN '",
					text,
					"' AND '",
					text2,
					"' AND plaka LIKE '%",
					this.textPlate.Text,
					"%'"
				});
				MySqlCommand mySqlCommand = new MySqlCommand(text3, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				this.listView1.Items.Clear();
				while (mySqlDataReader.Read())
				{
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = mySqlDataReader["id"].ToString();
					listViewItem.SubItems.Add(mySqlDataReader["plaka"].ToString());
					listViewItem.SubItems.Add(mySqlDataReader["kayittarihi"].ToString());
					listViewItem.SubItems.Add(mySqlDataReader["kameraid"].ToString());
					listViewItem.SubItems.Add(mySqlDataReader["sebep"].ToString());
					if (mySqlDataReader["aracKonum"].ToString() == "i")
					{
						listViewItem.SubItems.Add("Icerde");
					}
					else
					{
						listViewItem.SubItems.Add("Disarda");
					}
					this.listView1.Items.Add(listViewItem);
				}
				mySqlDataReader.Close();
			}
		}

		private void btnSearch_Click(object sender, EventArgs e)
		{
			this.ListeLog();
		}

		private void AracLogListesi_Load(object sender, EventArgs e)
		{
			DateTime now = DateTime.Now;
			string format = "yyyy-MM-dd HH:mm:ss";
			string text = now.ToString(format);
			this.enterDate.CustomFormat = "yyyy-MM-dd";
			this.exitDate.CustomFormat = "yyyy-MM-dd";
			this.enterDate.Text = text;
			this.enterTime.Text = text;
			this.exitDate.Text = text;
			this.exitTime.Text = text;
		}

		private void ShowPicSearch(string logid)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = "SELECT * FROM db_loglar WHERE id = '" + logid + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				string text2 = "";
				bool flag = false;
				if (mySqlDataReader.Read())
				{
					text2 = mySqlDataReader["resimyolu"].ToString();
					flag = true;
				}
				mySqlDataReader.Close();
				if (flag && text2.Length > 0)
				{
					int num = text2.IndexOf("_");
					string str = string.Concat(new string[]
					{
						GlobalVar.GlobalPath,
						text2.Substring(num + 1, 4),
						"\\",
						text2.Substring(num + 5, 2),
						"\\",
						text2.Substring(num + 7, 2),
						"\\"
					});
					try
					{
						Image image = Image.FromFile(str + text2);
						this.pictureSearch.Image = image;
						this.pictureSearch.SizeMode = PictureBoxSizeMode.StretchImage;
					}
					catch (Exception)
					{
					}
				}
			}
		}

		private void listView1_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count > 0)
			{
				int num = this.listView1.SelectedIndices[0];
				if (num >= 0)
				{
					string text = this.listView1.Items[num].Text;
					this.ShowPicSearch(text);
				}
			}
		}
	}
}
