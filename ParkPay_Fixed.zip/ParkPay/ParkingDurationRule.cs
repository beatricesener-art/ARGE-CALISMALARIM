using System;
using System.Globalization;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	internal static class ParkingDurationRule
	{
		public static bool IsCommercialTaxi(string plate)
		{
			bool result;
			if (plate == null)
			{
				result = false;
			}
			else
			{
				string text = plate.Trim().ToUpperInvariant();
				text = text.Replace(" ", "");
				text = text.Replace("-", "");
				if (text.Length < 4)
				{
					result = false;
				}
				else if (!char.IsDigit(text[0]) || !char.IsDigit(text[1]) || text[2] != 'T')
				{
					result = false;
				}
				else
				{
					for (int i = 3; i < text.Length; i++)
					{
						if (!char.IsDigit(text[i]))
						{
							return false;
						}
					}
					result = true;
				}
			}
			return result;
		}

		public static DateTime GetCycleStartToday(string plate)
		{
			DateTime today = DateTime.Today;
			DateTime result;
			if (!GlobalVar.DBConnectionStatus || GlobalVar.conn == null)
			{
				result = today;
			}
			else
			{
				string text = "SELECT kayittarihi, sebep FROM db_loglar WHERE plaka=@plaka AND aracKonum='d' AND kayittarihi>=@baslangic AND kayittarihi<@bitis AND sebep LIKE 'ÖDEME YAPILDI:%' ORDER BY kayittarihi DESC, id DESC";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				mySqlCommand.Parameters.AddWithValue("@plaka", plate);
				mySqlCommand.Parameters.AddWithValue("@baslangic", today.ToString("yyyy-MM-dd 00:00:00"));
				mySqlCommand.Parameters.AddWithValue("@bitis", today.AddDays(1.0).ToString("yyyy-MM-dd 00:00:00"));
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				try
				{
					while (mySqlDataReader.Read())
					{
						DateTime result2;
						if (DateTime.TryParse(mySqlDataReader["kayittarihi"].ToString(), out result2))
						{
							string reason = mySqlDataReader["sebep"].ToString();
							double num = ParkingDurationRule.ParsePaidAmount(reason);
							if (num > 0.0)
							{
								return result2;
							}
						}
					}
				}
				finally
				{
					mySqlDataReader.Close();
				}
				result = today;
			}
			return result;
		}

		private static double ParsePaidAmount(string reason)
		{
			double result;
			if (reason == null)
			{
				result = 0.0;
			}
			else
			{
				int num = reason.IndexOf("ÖDEME YAPILDI:");
				if (num < 0)
				{
					result = 0.0;
				}
				else
				{
					num += "ÖDEME YAPILDI:".Length;
					int num2 = reason.IndexOf("TL", num);
					if (num2 < 0)
					{
						num2 = reason.Length;
					}
					string text = reason.Substring(num, num2 - num).Trim();
					text = text.Replace(",", ".");
					double num3;
					if (double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out num3))
					{
						result = num3;
					}
					else
					{
						result = 0.0;
					}
				}
			}
			return result;
		}

		public static int GetPreviousCompletedMinutesToday(string plate)
		{
			int result;
			if (!GlobalVar.DBConnectionStatus || GlobalVar.conn == null)
			{
				result = 0;
			}
			else
			{
				DateTime cycleStartToday = ParkingDurationRule.GetCycleStartToday(plate);
				DateTime now = DateTime.Now;
				string text = "SELECT kayittarihi, aracKonum FROM db_loglar WHERE plaka=@plaka AND kayittarihi>@baslangic AND kayittarihi<=@bitis ORDER BY kayittarihi ASC";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				mySqlCommand.Parameters.AddWithValue("@plaka", plate);
				mySqlCommand.Parameters.AddWithValue("@baslangic", cycleStartToday.ToString("yyyy-MM-dd HH:mm:ss"));
				mySqlCommand.Parameters.AddWithValue("@bitis", now.ToString("yyyy-MM-dd HH:mm:ss"));
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				int num = 0;
				bool flag = false;
				DateTime dateTime = DateTime.MinValue;
				try
				{
					while (mySqlDataReader.Read())
					{
						string a = mySqlDataReader["aracKonum"].ToString();
						DateTime dateTime2;
						if (DateTime.TryParse(mySqlDataReader["kayittarihi"].ToString(), out dateTime2))
						{
							if (a == "i")
							{
								dateTime = dateTime2;
								flag = true;
							}
							else if (a == "d" && flag)
							{
								if (dateTime2 >= dateTime)
								{
									int num2 = (int)Math.Floor(dateTime2.Subtract(dateTime).TotalMinutes);
									if (num2 > 0)
									{
										num += num2;
									}
								}
								flag = false;
							}
						}
					}
				}
				finally
				{
					mySqlDataReader.Close();
				}
				result = num;
			}
			return result;
		}

		public static int GetChargeMinutes(string plate, int currentMinutes, out int previousMinutes, out bool commercialTaxi)
		{
			if (currentMinutes < 0)
			{
				currentMinutes = 0;
			}
			commercialTaxi = ParkingDurationRule.IsCommercialTaxi(plate);
			int result;
			if (commercialTaxi)
			{
				previousMinutes = 0;
				result = currentMinutes;
			}
			else
			{
				previousMinutes = ParkingDurationRule.GetPreviousCompletedMinutesToday(plate);
				result = currentMinutes + previousMinutes;
			}
			return result;
		}

		public static bool IsFree(int chargeMinutes)
		{
			return chargeMinutes <= 24;
		}

		public const int FreeMinutes = 24;
	}
}
