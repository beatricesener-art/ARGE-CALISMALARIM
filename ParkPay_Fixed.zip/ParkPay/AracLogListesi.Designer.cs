namespace ParkPay
{
	public partial class AracLogListesi : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.AracLogListesi));
			this.label7 = new global::System.Windows.Forms.Label();
			this.pictureSearch = new global::System.Windows.Forms.PictureBox();
			this.textPlate = new global::System.Windows.Forms.TextBox();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.exitTime = new global::System.Windows.Forms.DateTimePicker();
			this.exitDate = new global::System.Windows.Forms.DateTimePicker();
			this.label13 = new global::System.Windows.Forms.Label();
			this.enterTime = new global::System.Windows.Forms.DateTimePicker();
			this.btnSearch = new global::System.Windows.Forms.Button();
			this.enterDate = new global::System.Windows.Forms.DateTimePicker();
			this.label12 = new global::System.Windows.Forms.Label();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.listView1 = new global::System.Windows.Forms.ListView();
			this.columnHeader1 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader5 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader6 = new global::System.Windows.Forms.ColumnHeader();
			((global::System.ComponentModel.ISupportInitialize)this.pictureSearch).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			this.groupBox1.SuspendLayout();
			base.SuspendLayout();
			this.label7.AutoSize = true;
			this.label7.Font = new global::System.Drawing.Font("Calibri", 14.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label7.Location = new global::System.Drawing.Point(5, 4);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(99, 23);
			this.label7.TabIndex = 27;
			this.label7.Text = "Araç Resmi";
			this.pictureSearch.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureSearch.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureSearch.Image");
			this.pictureSearch.Location = new global::System.Drawing.Point(9, 32);
			this.pictureSearch.Name = "pictureSearch";
			this.pictureSearch.Size = new global::System.Drawing.Size(439, 264);
			this.pictureSearch.TabIndex = 26;
			this.pictureSearch.TabStop = false;
			this.textPlate.Font = new global::System.Drawing.Font("Arial", 36f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPlate.Location = new global::System.Drawing.Point(522, 53);
			this.textPlate.Name = "textPlate";
			this.textPlate.Size = new global::System.Drawing.Size(274, 63);
			this.textPlate.TabIndex = 29;
			this.pictureBox3.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(455, 32);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(352, 103);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 28;
			this.pictureBox3.TabStop = false;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Calibri", 14.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label1.Location = new global::System.Drawing.Point(457, 6);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(105, 23);
			this.label1.TabIndex = 30;
			this.label1.Text = "Araç Plakası";
			this.exitTime.Font = new global::System.Drawing.Font("Calibri", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.exitTime.Format = global::System.Windows.Forms.DateTimePickerFormat.Time;
			this.exitTime.Location = new global::System.Drawing.Point(116, 115);
			this.exitTime.Name = "exitTime";
			this.exitTime.ShowUpDown = true;
			this.exitTime.Size = new global::System.Drawing.Size(139, 27);
			this.exitTime.TabIndex = 42;
			this.exitDate.Font = new global::System.Drawing.Font("Calibri", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.exitDate.Format = global::System.Windows.Forms.DateTimePickerFormat.Custom;
			this.exitDate.Location = new global::System.Drawing.Point(116, 82);
			this.exitDate.Name = "exitDate";
			this.exitDate.Size = new global::System.Drawing.Size(139, 27);
			this.exitDate.TabIndex = 41;
			this.label13.AutoSize = true;
			this.label13.Font = new global::System.Drawing.Font("Calibri", 14.25f, global::System.Drawing.FontStyle.Bold);
			this.label13.Location = new global::System.Drawing.Point(6, 86);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(45, 23);
			this.label13.TabIndex = 40;
			this.label13.Text = "Bitiş";
			this.enterTime.Font = new global::System.Drawing.Font("Calibri", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.enterTime.Format = global::System.Windows.Forms.DateTimePickerFormat.Time;
			this.enterTime.Location = new global::System.Drawing.Point(116, 49);
			this.enterTime.Name = "enterTime";
			this.enterTime.ShowUpDown = true;
			this.enterTime.Size = new global::System.Drawing.Size(139, 27);
			this.enterTime.TabIndex = 39;
			this.btnSearch.BackColor = global::System.Drawing.SystemColors.ControlLightLight;
			this.btnSearch.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.btnSearch.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("btnSearch.Image");
			this.btnSearch.ImageAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.btnSearch.Location = new global::System.Drawing.Point(261, 16);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new global::System.Drawing.Size(83, 103);
			this.btnSearch.TabIndex = 36;
			this.btnSearch.Text = "ARA";
			this.btnSearch.TextAlign = global::System.Drawing.ContentAlignment.BottomCenter;
			this.btnSearch.UseVisualStyleBackColor = false;
			this.btnSearch.Click += new global::System.EventHandler(this.btnSearch_Click);
			this.enterDate.Font = new global::System.Drawing.Font("Calibri", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.enterDate.Format = global::System.Windows.Forms.DateTimePickerFormat.Custom;
			this.enterDate.Location = new global::System.Drawing.Point(116, 16);
			this.enterDate.Name = "enterDate";
			this.enterDate.Size = new global::System.Drawing.Size(139, 27);
			this.enterDate.TabIndex = 38;
			this.label12.AutoSize = true;
			this.label12.Font = new global::System.Drawing.Font("Calibri", 14.25f, global::System.Drawing.FontStyle.Bold);
			this.label12.Location = new global::System.Drawing.Point(6, 20);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(84, 23);
			this.label12.TabIndex = 37;
			this.label12.Text = "Başlangıç";
			this.groupBox1.Controls.Add(this.exitTime);
			this.groupBox1.Controls.Add(this.btnSearch);
			this.groupBox1.Controls.Add(this.exitDate);
			this.groupBox1.Controls.Add(this.label12);
			this.groupBox1.Controls.Add(this.label13);
			this.groupBox1.Controls.Add(this.enterTime);
			this.groupBox1.Controls.Add(this.enterDate);
			this.groupBox1.Location = new global::System.Drawing.Point(455, 141);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(352, 155);
			this.groupBox1.TabIndex = 43;
			this.groupBox1.TabStop = false;
			this.listView1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.columnHeader1,
				this.columnHeader2,
				this.columnHeader3,
				this.columnHeader4,
				this.columnHeader5,
				this.columnHeader6
			});
			this.listView1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.listView1.FullRowSelect = true;
			this.listView1.HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.listView1.HideSelection = false;
			this.listView1.Location = new global::System.Drawing.Point(9, 303);
			this.listView1.Name = "listView1";
			this.listView1.Size = new global::System.Drawing.Size(797, 259);
			this.listView1.TabIndex = 44;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = global::System.Windows.Forms.View.Details;
			this.listView1.Click += new global::System.EventHandler(this.listView1_Click);
			this.columnHeader1.Text = "ID";
			this.columnHeader1.Width = 80;
			this.columnHeader2.Text = "Plaka";
			this.columnHeader2.Width = 80;
			this.columnHeader3.Text = "Tarih - Zaman";
			this.columnHeader3.Width = 160;
			this.columnHeader4.Text = "KamNo";
			this.columnHeader4.Width = 80;
			this.columnHeader5.Text = "Sebep";
			this.columnHeader5.Width = 300;
			this.columnHeader6.Text = "Yön";
			this.columnHeader6.Width = 80;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(814, 568);
			base.Controls.Add(this.listView1);
			base.Controls.Add(this.groupBox1);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.textPlate);
			base.Controls.Add(this.pictureBox3);
			base.Controls.Add(this.label7);
			base.Controls.Add(this.pictureSearch);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "AracLogListesi";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Araç Geçiş Listesi";
			base.Load += new global::System.EventHandler(this.AracLogListesi_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureSearch).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.Label label7;

		private global::System.Windows.Forms.PictureBox pictureSearch;

		private global::System.Windows.Forms.TextBox textPlate;

		private global::System.Windows.Forms.PictureBox pictureBox3;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.DateTimePicker exitTime;

		private global::System.Windows.Forms.DateTimePicker exitDate;

		private global::System.Windows.Forms.Label label13;

		private global::System.Windows.Forms.DateTimePicker enterTime;

		private global::System.Windows.Forms.Button btnSearch;

		private global::System.Windows.Forms.DateTimePicker enterDate;

		private global::System.Windows.Forms.Label label12;

		private global::System.Windows.Forms.GroupBox groupBox1;

		private global::System.Windows.Forms.ListView listView1;

		private global::System.Windows.Forms.ColumnHeader columnHeader1;

		private global::System.Windows.Forms.ColumnHeader columnHeader2;

		private global::System.Windows.Forms.ColumnHeader columnHeader3;

		private global::System.Windows.Forms.ColumnHeader columnHeader4;

		private global::System.Windows.Forms.ColumnHeader columnHeader5;

		private global::System.Windows.Forms.ColumnHeader columnHeader6;
	}
}
