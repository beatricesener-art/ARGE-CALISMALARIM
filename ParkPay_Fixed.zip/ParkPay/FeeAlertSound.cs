using System;
using System.IO;
using System.Media;
using System.Threading;

namespace ParkPay
{
	internal static class FeeAlertSound
	{
		public static string SoundFileName
		{
			get
			{
				return "itfaiye.wav";
			}
		}

		public static string SoundFilePath
		{
			get
			{
				return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, FeeAlertSound.SoundFileName);
			}
		}

		public static void PlayTwoSeconds()
		{
			try
			{
				string soundFilePath = FeeAlertSound.SoundFilePath;
				if (File.Exists(soundFilePath))
				{
					lock (FeeAlertSound.SyncRoot)
					{
						FeeAlertSound.StopInternal();
						FeeAlertSound.currentPlayer = new SoundPlayer(soundFilePath);
						FeeAlertSound.currentPlayer.Load();
						FeeAlertSound.currentPlayer.Play();
						FeeAlertSound.stopTimer = new Timer(new TimerCallback(FeeAlertSound.StopTimerCallback), null, 2000, -1);
					}
				}
			}
			catch
			{
			}
		}

		private static void StopTimerCallback(object state)
		{
			lock (FeeAlertSound.SyncRoot)
			{
				FeeAlertSound.StopInternal();
			}
		}

		private static void StopInternal()
		{
			try
			{
				if (FeeAlertSound.stopTimer != null)
				{
					FeeAlertSound.stopTimer.Dispose();
					FeeAlertSound.stopTimer = null;
				}
				if (FeeAlertSound.currentPlayer != null)
				{
					FeeAlertSound.currentPlayer.Stop();
					FeeAlertSound.currentPlayer.Dispose();
					FeeAlertSound.currentPlayer = null;
				}
			}
			catch
			{
			}
		}

		private static readonly object SyncRoot = new object();

		private static SoundPlayer currentPlayer;

		private static Timer stopTimer;
	}
}
