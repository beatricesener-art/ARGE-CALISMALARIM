using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;
using PdfSharp.Drawing;
using PdfSharp.Drawing.BarCodes;
using PdfSharp.Pdf;

namespace ParkPay
{
	public partial class PaymentAuto : Form
	{
		public PaymentAuto()
		{
			this.InitializeComponent();
		}

		private void SendToScreen()
		{
			Main main = (Main)base.Owner;
			main.paymentInfo.giriszaman = this.enterDateTimeText.Text;
			main.paymentInfo.sure = this.textMinutes.Text;
			main.paymentInfo.ucret = this.textPayment.Text;
			main.paymentInfo.plaka = this.textPlate.Text;
			main.paymentInfo.resimyolu = this.resimyolu;
			string text = this.enterDateTimeText.Text;
			if (text.Length > 8)
			{
				text = text.Substring(text.Length - 8, 8);
			}
			main.SentToLedScreen(this.textPayment.Text, text, this.textPlate.Text);
		}

		private void login_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				string text = string.Concat(new string[]
				{
					"UPDATE db_araclar SET vale_arac=0 , odeme_durum=0 , aracKonum = 'd' , sondegisim='",
					this.exitDateTime2,
					"' WHERE plaka='",
					this.plate,
					"'"
				});
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				double num = 0.0;
				if (this.paymentCheck.Checked)
				{
					num = this.t_payment;
				}
				string text2 = num.ToString();
				text2 = text2.Replace(",", ".");
				text = string.Concat(new object[]
				{
					"INSERT INTO db_odemeler (`id` ,`kullaniciid` ,`borc` ,`odenen` ,`tarihzaman` ,`status`,`plaka` , `abonesure` , `operatorid`, `pointID`) VALUES (NULL , '0', '",
					text2,
					"','",
					text2,
					"','",
					this.exitDateTime2,
					"','",
					this.tipID,
					"','",
					this.plate,
					"' , 0 , ",
					GlobalVar.activeId,
					" , ",
					GlobalVar.pointID,
					")"
				});
				MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
				mySqlDataReader2.Close();
				string str;
				if (this.paymentCheck.Checked)
				{
					str = "ÖDEME YAPILDI:" + this.t_payment.ToString() + " TL - ";
				}
				else
				{
					str = "ÖDEME YAPILMADI!:" + this.t_payment.ToString() + " TL - ";
				}
				str = str + "Arac Tipi:" + this.aracTipleri.Text + " - ";
				string text3 = str + this.textDetails.Text;
				int num2 = 0;
				for (;;)
				{
					int num3 = this.resimyolu.IndexOf("\\", num2);
					if (num3 < 0)
					{
						break;
					}
					num2 = num3 + 1;
				}
				string text4 = this.resimyolu.Substring(num2, this.resimyolu.Length - num2);
				text = string.Concat(new object[]
				{
					"INSERT INTO db_loglar (`id` ,`plaka` ,`kayittarihi` ,`kameraid` ,`sebep` , `resimyolu` ,`aracKonum` , `soncamgrupid` , `sistemid`) VALUES (NULL , '",
					this.textPlate.Text,
					"','",
					this.exitDateTime2,
					"',",
					this.camno,
					",'",
					text3,
					"', '",
					text4,
					"', 'd' , 1 , '",
					GlobalVar.GlobalSistemName,
					"')"
				});
				MySqlCommand mySqlCommand3 = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader3 = mySqlCommand3.ExecuteReader();
				mySqlDataReader3.Close();
				Main main = (Main)base.Owner;
				main.OpenBariyer(this.camno - 1);
				base.Close();
			}
		}

		private void PaymentAuto_Load(object sender, EventArgs e)
		{
			this.textPlate.Text = this.plate;
			this.camnoText.Text = this.camno.ToString();
			if (GlobalVar.DBConnectionStatus)
			{
				Image image = Image.FromFile(this.resimyolu);
				this.pictureEnter.Image = image;
				this.pictureEnter.SizeMode = PictureBoxSizeMode.StretchImage;
				string text = "SELECT * FROM db_aractipleri ORDER by tipID ASC";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				int num = 0;
				while (mySqlDataReader.Read())
				{
					this.aracTipleri.Items.Add(mySqlDataReader["tipAdi"].ToString());
					this.tipIDArray[num] = int.Parse(mySqlDataReader["tipID"].ToString());
					num++;
				}
				mySqlDataReader.Close();
				this.aracTipleri.SelectedIndex = 0;
				this.tipID = this.tipIDArray[0];
				text = "SELECT * FROM db_araclar WHERE plaka = '" + this.textPlate.Text + "'";
				MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
				string a = "";
				if (mySqlDataReader2.Read())
				{
					this.barkod = mySqlDataReader2["barkod"].ToString();
					a = mySqlDataReader2["odeme_durum"].ToString();
				}
				mySqlDataReader2.Close();
				if (this.barkod.Length < 1)
				{
					string text2 = DateTime.Now.ToString("MMddHHmmss");
					text = string.Concat(new string[]
					{
						"UPDATE db_araclar SET  barkod='",
						text2,
						"'  WHERE plaka = '",
						this.textPlate.Text,
						"'"
					});
					MySqlCommand mySqlCommand3 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader3 = mySqlCommand3.ExecuteReader();
					mySqlDataReader3.Close();
					this.barkod = text2;
				}
				if (a == "1")
				{
					this.payStatusText.Text = "Ödemesi Yapılmış!";
				}
				this.SendToScreen();
			}
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void CalculatePayment()
		{
			if (GlobalVar.DBConnectionStatus)
			{
				DateTime now = DateTime.Now;
				string format = "dd.MM.yyyy HH:mm:ss";
				string format2 = "yyyy-MM-dd HH:mm:ss";
				this.exitDateTime = now.ToString(format);
				this.exitDateTime2 = now.ToString(format2);
				string text = "SELECT * FROM db_araclar WHERE plaka = '" + this.plate + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				int num = 0;
				int num2 = 0;
				string s = "";
				if (mySqlDataReader.Read())
				{
					num = int.Parse(mySqlDataReader["abonelikTipi"].ToString());
					num2 = int.Parse(mySqlDataReader["AbonelikSaat"].ToString());
					this.enterDateTime = mySqlDataReader["sondegisim"].ToString();
					try
					{
						s = mySqlDataReader["abonelikbitis"].ToString();
					}
					catch (Exception)
					{
						s = this.exitDateTime;
					}
				}
				this.enterDateTimeText.Text = this.enterDateTime;
				DateTime value = DateTime.Parse(this.enterDateTime);
				DateTime value2 = DateTime.Parse(s);
				int num3 = (int)now.Subtract(value2).TotalMinutes;
				mySqlDataReader.Close();
				int num4 = (int)now.Subtract(value).TotalMinutes;
				this.textMinutes.Text = num4.ToString();
				this.t_minues = num4;
				if (num > 0 && num3 < 0)
				{
					this.t_minues -= num2 * 60;
					if (this.t_minues < 0)
					{
						this.t_minues = 0;
						this.textPayment.Text = "0";
						this.t_payment = 0.0;
						this.InfoText.Text = "Saatlik Abone Araç. Süresi Var! Ücretsiz!";
						return;
					}
					num4 = this.t_minues;
					this.textMinutes.Text = num4.ToString();
					this.InfoText.Text = "Saatlik Abone Araç. Saati Dolmuş, Ücret Ödeyecek!";
				}
				int num5 = 0;
				bool flag = false;
				int chargeMinutes = ParkingDurationRule.GetChargeMinutes(this.plate, num4, out num5, out flag);
				if (flag)
				{
					this.textDetails.Text = this.textDetails.Text + "-TICARI TAKSI: 24DK UCRETSIZ / GUNLUK TOPLAM YOK-";
				}
				else if (num5 > 0)
				{
					this.textDetails.Text = this.textDetails.Text + "-GUNLUK ONCEKI:" + num5.ToString() + "DK-";
				}
				num4 = chargeMinutes;
				if (ParkingDurationRule.IsFree(num4))
				{
					this.textPayment.Text = "0";
					this.t_payment = 0.0;
					Main main = (Main)base.Owner;
					main.paymentInfo.ucret = this.textPayment.Text;
					this.SendToScreen();
				}
				else
				{
					text = string.Concat(new string[]
					{
						"SELECT * FROM db_fiyatlar WHERE tipID=",
						this.tipID.ToString(),
						" AND baslangic <= ",
						num4.ToString(),
						" AND bitis > ",
						num4.ToString(),
						" "
					});
					MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
					int num6 = 0;
					double num7 = 0.0;
					int num8 = 0;
					if (mySqlDataReader2.Read())
					{
						int.Parse(mySqlDataReader2["id"].ToString());
						if (mySqlDataReader2["sistemli"].ToString() == "e")
						{
							num6 = 1;
						}
						else
						{
							num6 = 0;
						}
						num7 = double.Parse(mySqlDataReader2["ucret"].ToString());
						num8 = int.Parse(mySqlDataReader2["carpan"].ToString());
					}
					mySqlDataReader2.Close();
					double num9;
					if (num6 == 0)
					{
						num9 = num7;
					}
					else
					{
						num9 = Math.Ceiling((double)num4 / (double)num8);
						num9 *= num7;
					}
					this.textPayment.Text = num9.ToString();
					this.t_payment = num9;
					if (this.t_payment > 0.0 && !this.feeAlertPlayed)
					{
						this.feeAlertPlayed = true;
						FeeAlertSound.PlayTwoSeconds();
					}
					Main main2 = (Main)base.Owner;
					main2.paymentInfo.ucret = this.textPayment.Text;
					this.SendToScreen();
				}
			}
		}

		private void aracTipleri_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.tipID = this.tipIDArray[this.aracTipleri.SelectedIndex];
			this.CalculatePayment();
		}

		private void printBtn_Click(object sender, EventArgs e)
		{
			int num = GlobalVar.TopSize;
			int leftSize = GlobalVar.LeftSize;
			int lineFree = GlobalVar.LineFree;
			int leftLine = GlobalVar.LeftLine;
			PdfDocument pdfDocument = new PdfDocument();
			XFont xfont = new XFont("Verdana", (double)GlobalVar.FontSize1);
			XFont xfont2 = new XFont("Verdana", (double)GlobalVar.FontSize2);
			PdfPage pdfPage = pdfDocument.AddPage();
			pdfPage.Width = GlobalVar.PageW;
			pdfPage.Height = GlobalVar.PageH;
			XGraphics xgraphics = XGraphics.FromPdfPage(pdfPage);
			xgraphics.DrawBarCode(new Code3of9Standard
			{
				Text = this.barkod,
				Size = new XSize((double)GlobalVar.BarkodW, (double)GlobalVar.BarkodH),
				TextLocation = TextLocation.Above
			}, XBrushes.Black, new XPoint(1.0, 1.0));
			xgraphics.DrawLine(XPens.Black, 0, num - lineFree + 3, leftLine, num - lineFree + 3);
			xgraphics.DrawString(GlobalVar.Label1, xfont2, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			string text = GlobalVar.Label2;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = GlobalVar.Label3;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, leftLine, num + 3);
			text = "Plaka/Kart: " + this.plate;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = "Araç Giriş Zamanı: " + this.enterDateTime;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = "Araç Çıkış Zamanı: " + this.exitDateTime;
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = "Süre: " + this.t_minues.ToString() + " dk";
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			text = "Ücret: " + this.t_payment.ToString() + " TL";
			num += lineFree;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)leftSize, (double)num, XStringFormats.Default);
			pdfDocument.Save("payment_tempfile.pdf");
			Thread.Sleep(1000);
			Process.Start(new ProcessStartInfo
			{
				UseShellExecute = true,
				Verb = "print",
				WindowStyle = ProcessWindowStyle.Hidden,
				FileName = "payment_tempfile.pdf"
			});
		}

		public string resimyolu;

		public int camno;

		public string plate;

		public string enterDateTime;

		public string exitDateTime;

		public string exitDateTime2;

		public int tipID;

		public int[] tipIDArray = new int[50];

		public int t_minues;

		public double t_payment;

		private bool feeAlertPlayed;

		public string barkod = "";
	}
}
