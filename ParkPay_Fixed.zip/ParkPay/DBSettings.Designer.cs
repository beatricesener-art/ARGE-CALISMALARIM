namespace ParkPay
{
	public partial class DBSettings : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.DBSettings));
			this.label1 = new global::System.Windows.Forms.Label();
			this.ipaddress = new global::System.Windows.Forms.TextBox();
			this.dbname = new global::System.Windows.Forms.TextBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.username = new global::System.Windows.Forms.TextBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.password = new global::System.Windows.Forms.TextBox();
			this.label4 = new global::System.Windows.Forms.Label();
			this.BtnSave = new global::System.Windows.Forms.Button();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.BtnTest = new global::System.Windows.Forms.Button();
			this.label5 = new global::System.Windows.Forms.Label();
			this.camList = new global::System.Windows.Forms.ComboBox();
			this.cancel = new global::System.Windows.Forms.Button();
			this.lineShape1 = new global::Microsoft.VisualBasic.PowerPacks.LineShape();
			this.shapeContainer1 = new global::Microsoft.VisualBasic.PowerPacks.ShapeContainer();
			this.textWebUrl = new global::System.Windows.Forms.TextBox();
			this.label6 = new global::System.Windows.Forms.Label();
			this.BtnDBDuzenle = new global::System.Windows.Forms.Button();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			this.groupBox1.SuspendLayout();
			base.SuspendLayout();
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(7, 31);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(71, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "IP Adres:";
			this.ipaddress.Location = new global::System.Drawing.Point(145, 28);
			this.ipaddress.Name = "ipaddress";
			this.ipaddress.Size = new global::System.Drawing.Size(139, 22);
			this.ipaddress.TabIndex = 1;
			this.dbname.Location = new global::System.Drawing.Point(145, 54);
			this.dbname.Name = "dbname";
			this.dbname.Size = new global::System.Drawing.Size(139, 22);
			this.dbname.TabIndex = 3;
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(7, 57);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(60, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "DB Adı:";
			this.username.Location = new global::System.Drawing.Point(145, 80);
			this.username.Name = "username";
			this.username.Size = new global::System.Drawing.Size(139, 22);
			this.username.TabIndex = 5;
			this.label3.AutoSize = true;
			this.label3.Location = new global::System.Drawing.Point(7, 83);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(97, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Kullanıcı Adı:";
			this.password.Location = new global::System.Drawing.Point(145, 106);
			this.password.Name = "password";
			this.password.PasswordChar = '*';
			this.password.Size = new global::System.Drawing.Size(139, 22);
			this.password.TabIndex = 7;
			this.label4.AutoSize = true;
			this.label4.Location = new global::System.Drawing.Point(9, 109);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(44, 16);
			this.label4.TabIndex = 6;
			this.label4.Text = "Şifre:";
			this.BtnSave.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("BtnSave.Image");
			this.BtnSave.Location = new global::System.Drawing.Point(260, 305);
			this.BtnSave.Name = "BtnSave";
			this.BtnSave.Size = new global::System.Drawing.Size(100, 28);
			this.BtnSave.TabIndex = 9;
			this.BtnSave.Text = "Kaydet";
			this.BtnSave.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.BtnSave.UseVisualStyleBackColor = true;
			this.BtnSave.Click += new global::System.EventHandler(this.BtnSave_Click);
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(13, 19);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(152, 140);
			this.pictureBox1.TabIndex = 10;
			this.pictureBox1.TabStop = false;
			this.groupBox1.Controls.Add(this.password);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.username);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.dbname);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.ipaddress);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.groupBox1.Location = new global::System.Drawing.Point(171, 19);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(295, 140);
			this.groupBox1.TabIndex = 11;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "DB Ayarları";
			this.BtnTest.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("BtnTest.Image");
			this.BtnTest.Location = new global::System.Drawing.Point(366, 165);
			this.BtnTest.Name = "BtnTest";
			this.BtnTest.Size = new global::System.Drawing.Size(100, 28);
			this.BtnTest.TabIndex = 12;
			this.BtnTest.Text = "Test Et";
			this.BtnTest.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.BtnTest.UseVisualStyleBackColor = true;
			this.BtnTest.Click += new global::System.EventHandler(this.BtnTest_Click);
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label5.Location = new global::System.Drawing.Point(20, 206);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(131, 16);
			this.label5.TabIndex = 13;
			this.label5.Text = "Ödeme Kamerası:";
			this.camList.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.camList.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.camList.FormattingEnabled = true;
			this.camList.Items.AddRange(new object[]
			{
				"1",
				"2",
				"3",
				"4",
				"5",
				"6",
				"7",
				"8"
			});
			this.camList.Location = new global::System.Drawing.Point(157, 203);
			this.camList.Name = "camList";
			this.camList.Size = new global::System.Drawing.Size(139, 24);
			this.camList.TabIndex = 14;
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(366, 305);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(100, 28);
			this.cancel.TabIndex = 15;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.lineShape1.BorderColor = global::System.Drawing.SystemColors.ControlDark;
			this.lineShape1.Name = "lineShape1";
			this.lineShape1.X1 = 12;
			this.lineShape1.X2 = 463;
			this.lineShape1.Y1 = 296;
			this.lineShape1.Y2 = 296;
			this.shapeContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.shapeContainer1.Margin = new global::System.Windows.Forms.Padding(0);
			this.shapeContainer1.Name = "shapeContainer1";
			this.shapeContainer1.Shapes.AddRange(new global::Microsoft.VisualBasic.PowerPacks.Shape[]
			{
				this.lineShape1
			});
			this.shapeContainer1.Size = new global::System.Drawing.Size(485, 345);
			this.shapeContainer1.TabIndex = 16;
			this.shapeContainer1.TabStop = false;
			this.textWebUrl.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textWebUrl.Location = new global::System.Drawing.Point(157, 236);
			this.textWebUrl.Name = "textWebUrl";
			this.textWebUrl.Size = new global::System.Drawing.Size(298, 22);
			this.textWebUrl.TabIndex = 18;
			this.label6.AutoSize = true;
			this.label6.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label6.Location = new global::System.Drawing.Point(20, 239);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(78, 16);
			this.label6.TabIndex = 19;
			this.label6.Text = "Web URL:";
			this.BtnDBDuzenle.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("BtnDBDuzenle.Image");
			this.BtnDBDuzenle.Location = new global::System.Drawing.Point(36, 165);
			this.BtnDBDuzenle.Name = "BtnDBDuzenle";
			this.BtnDBDuzenle.Size = new global::System.Drawing.Size(100, 28);
			this.BtnDBDuzenle.TabIndex = 20;
			this.BtnDBDuzenle.Text = "DB Düzenle";
			this.BtnDBDuzenle.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.BtnDBDuzenle.UseVisualStyleBackColor = true;
			this.BtnDBDuzenle.Click += new global::System.EventHandler(this.BtnDBDuzenle_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(485, 345);
			base.Controls.Add(this.BtnDBDuzenle);
			base.Controls.Add(this.label6);
			base.Controls.Add(this.textWebUrl);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.camList);
			base.Controls.Add(this.label5);
			base.Controls.Add(this.BtnTest);
			base.Controls.Add(this.groupBox1);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.BtnSave);
			base.Controls.Add(this.shapeContainer1);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "DBSettings";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Ayarlar";
			base.TopMost = true;
			base.Load += new global::System.EventHandler(this.DBSettings_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.TextBox ipaddress;

		private global::System.Windows.Forms.TextBox dbname;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.TextBox username;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.TextBox password;

		private global::System.Windows.Forms.Label label4;

		private global::System.Windows.Forms.Button BtnSave;

		private global::System.Windows.Forms.PictureBox pictureBox1;

		private global::System.Windows.Forms.GroupBox groupBox1;

		private global::System.Windows.Forms.Button BtnTest;

		private global::System.Windows.Forms.Label label5;

		private global::System.Windows.Forms.ComboBox camList;

		private global::System.Windows.Forms.Button cancel;

		private global::Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;

		private global::Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;

		private global::System.Windows.Forms.TextBox textWebUrl;

		private global::System.Windows.Forms.Label label6;

		private global::System.Windows.Forms.Button BtnDBDuzenle;
	}
}
