namespace ParkPay
{
	public partial class AracTipi : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.AracTipi));
			this.textPlate = new global::System.Windows.Forms.TextBox();
			this.cancel = new global::System.Windows.Forms.Button();
			this.login = new global::System.Windows.Forms.Button();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.aracTipleri = new global::System.Windows.Forms.ComboBox();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.printBtn = new global::System.Windows.Forms.Button();
			this.label2 = new global::System.Windows.Forms.Label();
			this.enterDateTimeText = new global::System.Windows.Forms.TextBox();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			this.groupBox1.SuspendLayout();
			base.SuspendLayout();
			this.textPlate.Font = new global::System.Drawing.Font("Arial", 36f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPlate.Location = new global::System.Drawing.Point(78, 34);
			this.textPlate.Name = "textPlate";
			this.textPlate.ReadOnly = true;
			this.textPlate.Size = new global::System.Drawing.Size(274, 63);
			this.textPlate.TabIndex = 26;
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(251, 276);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 25;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(132, 276);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 24;
			this.login.Text = "Tamam";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.pictureBox3.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(12, 12);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(352, 103);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 22;
			this.pictureBox3.TabStop = false;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label1.Location = new global::System.Drawing.Point(22, 69);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(74, 18);
			this.label1.TabIndex = 0;
			this.label1.Text = "Araç Tipi";
			this.aracTipleri.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.aracTipleri.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.aracTipleri.FormattingEnabled = true;
			this.aracTipleri.Location = new global::System.Drawing.Point(156, 66);
			this.aracTipleri.Name = "aracTipleri";
			this.aracTipleri.Size = new global::System.Drawing.Size(184, 26);
			this.aracTipleri.TabIndex = 2;
			this.aracTipleri.SelectedIndexChanged += new global::System.EventHandler(this.aracTipleri_SelectedIndexChanged);
			this.groupBox1.Controls.Add(this.enterDateTimeText);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.printBtn);
			this.groupBox1.Controls.Add(this.aracTipleri);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.groupBox1.Location = new global::System.Drawing.Point(12, 121);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(352, 149);
			this.groupBox1.TabIndex = 23;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Araç Detaylar";
			this.printBtn.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.printBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("printBtn.Image");
			this.printBtn.Location = new global::System.Drawing.Point(242, 107);
			this.printBtn.Name = "printBtn";
			this.printBtn.Size = new global::System.Drawing.Size(98, 32);
			this.printBtn.TabIndex = 27;
			this.printBtn.Text = "Yazdır";
			this.printBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.printBtn.UseVisualStyleBackColor = true;
			this.printBtn.Click += new global::System.EventHandler(this.printBtn_Click);
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label2.Location = new global::System.Drawing.Point(22, 32);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(100, 18);
			this.label2.TabIndex = 28;
			this.label2.Text = "Giriş Zaman";
			this.enterDateTimeText.Enabled = false;
			this.enterDateTimeText.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.enterDateTimeText.Location = new global::System.Drawing.Point(156, 29);
			this.enterDateTimeText.Name = "enterDateTimeText";
			this.enterDateTimeText.ReadOnly = true;
			this.enterDateTimeText.Size = new global::System.Drawing.Size(184, 24);
			this.enterDateTimeText.TabIndex = 29;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(376, 320);
			base.Controls.Add(this.groupBox1);
			base.Controls.Add(this.textPlate);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.login);
			base.Controls.Add(this.pictureBox3);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "AracTipi";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Araç Tipi Düzenle";
			base.Load += new global::System.EventHandler(this.AracTipi_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.TextBox textPlate;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.Button login;

		private global::System.Windows.Forms.PictureBox pictureBox3;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.ComboBox aracTipleri;

		private global::System.Windows.Forms.GroupBox groupBox1;

		private global::System.Windows.Forms.Button printBtn;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.TextBox enterDateTimeText;
	}
}
