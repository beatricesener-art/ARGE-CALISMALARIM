namespace ParkPay
{
	public partial class Abonelik : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.Abonelik));
			this.login = new global::System.Windows.Forms.Button();
			this.cancel = new global::System.Windows.Forms.Button();
			this.label2 = new global::System.Windows.Forms.Label();
			this.textAdi = new global::System.Windows.Forms.TextBox();
			this.musteriAraBtn = new global::System.Windows.Forms.Button();
			this.listMusteriler = new global::System.Windows.Forms.ListView();
			this.columnHeader1 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new global::System.Windows.Forms.ColumnHeader();
			this.label3 = new global::System.Windows.Forms.Label();
			this.label4 = new global::System.Windows.Forms.Label();
			this.listPlakalar = new global::System.Windows.Forms.ListView();
			this.columnHeader4 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader5 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader6 = new global::System.Windows.Forms.ColumnHeader();
			this.musteriEkleBtn = new global::System.Windows.Forms.Button();
			this.musteriDuzenleBtn = new global::System.Windows.Forms.Button();
			this.musteriSilBtn = new global::System.Windows.Forms.Button();
			this.groupBox2 = new global::System.Windows.Forms.GroupBox();
			this.groupBox3 = new global::System.Windows.Forms.GroupBox();
			this.abonelikEkleBtn = new global::System.Windows.Forms.Button();
			this.plakaSilBtn = new global::System.Windows.Forms.Button();
			this.plakaDuzenleBtn = new global::System.Windows.Forms.Button();
			this.plakaEkleBtn = new global::System.Windows.Forms.Button();
			this.plakaAraBtn = new global::System.Windows.Forms.Button();
			this.textPlaka = new global::System.Windows.Forms.TextBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.odemelerBtn = new global::System.Windows.Forms.Button();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			base.SuspendLayout();
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(262, 473);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 24;
			this.login.Text = "Tamam";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(381, 473);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 25;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label2.Location = new global::System.Drawing.Point(7, 19);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(89, 16);
			this.label2.TabIndex = 26;
			this.label2.Text = "Müşteri Adı:";
			this.textAdi.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textAdi.Location = new global::System.Drawing.Point(111, 16);
			this.textAdi.Name = "textAdi";
			this.textAdi.Size = new global::System.Drawing.Size(174, 22);
			this.textAdi.TabIndex = 27;
			this.musteriAraBtn.AutoSize = true;
			this.musteriAraBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("musteriAraBtn.Image");
			this.musteriAraBtn.Location = new global::System.Drawing.Point(291, 15);
			this.musteriAraBtn.Name = "musteriAraBtn";
			this.musteriAraBtn.Size = new global::System.Drawing.Size(113, 54);
			this.musteriAraBtn.TabIndex = 28;
			this.musteriAraBtn.Text = "Ara";
			this.musteriAraBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.musteriAraBtn.UseVisualStyleBackColor = true;
			this.musteriAraBtn.Click += new global::System.EventHandler(this.musteriAraBtn_Click);
			this.listMusteriler.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.columnHeader1,
				this.columnHeader2,
				this.columnHeader3
			});
			this.listMusteriler.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.listMusteriler.FullRowSelect = true;
			this.listMusteriler.HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.listMusteriler.HideSelection = false;
			this.listMusteriler.Location = new global::System.Drawing.Point(10, 75);
			this.listMusteriler.Name = "listMusteriler";
			this.listMusteriler.Size = new global::System.Drawing.Size(314, 139);
			this.listMusteriler.TabIndex = 29;
			this.listMusteriler.UseCompatibleStateImageBehavior = false;
			this.listMusteriler.View = global::System.Windows.Forms.View.Details;
			this.listMusteriler.SelectedIndexChanged += new global::System.EventHandler(this.listMusteriler_SelectedIndexChanged);
			this.columnHeader1.Text = "ID";
			this.columnHeader1.Width = 46;
			this.columnHeader2.Text = "Ad";
			this.columnHeader2.Width = 99;
			this.columnHeader3.Text = "Soyad";
			this.columnHeader3.Width = 159;
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label3.Location = new global::System.Drawing.Point(7, 54);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(135, 16);
			this.label3.TabIndex = 30;
			this.label3.Text = "Bulunan Müşteriler";
			this.label4.AutoSize = true;
			this.label4.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label4.Location = new global::System.Drawing.Point(7, 56);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(192, 16);
			this.label4.TabIndex = 32;
			this.label4.Text = "Seçilen Müşterinin Araçları";
			this.listPlakalar.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.columnHeader4,
				this.columnHeader5,
				this.columnHeader6
			});
			this.listPlakalar.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.listPlakalar.FullRowSelect = true;
			this.listPlakalar.HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.listPlakalar.HideSelection = false;
			this.listPlakalar.Location = new global::System.Drawing.Point(11, 77);
			this.listPlakalar.Name = "listPlakalar";
			this.listPlakalar.Size = new global::System.Drawing.Size(313, 139);
			this.listPlakalar.TabIndex = 31;
			this.listPlakalar.UseCompatibleStateImageBehavior = false;
			this.listPlakalar.View = global::System.Windows.Forms.View.Details;
			this.listPlakalar.SelectedIndexChanged += new global::System.EventHandler(this.listPlakalar_SelectedIndexChanged);
			this.columnHeader4.Text = "ID";
			this.columnHeader4.Width = 42;
			this.columnHeader5.Text = "Plaka";
			this.columnHeader5.Width = 82;
			this.columnHeader6.Text = "Abonelik Bit. T.";
			this.columnHeader6.Width = 176;
			this.musteriEkleBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("musteriEkleBtn.Image");
			this.musteriEkleBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.musteriEkleBtn.Location = new global::System.Drawing.Point(330, 75);
			this.musteriEkleBtn.Name = "musteriEkleBtn";
			this.musteriEkleBtn.Size = new global::System.Drawing.Size(142, 32);
			this.musteriEkleBtn.TabIndex = 33;
			this.musteriEkleBtn.Text = "Müşteri Ekle";
			this.musteriEkleBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.musteriEkleBtn.UseVisualStyleBackColor = true;
			this.musteriEkleBtn.Click += new global::System.EventHandler(this.musteriEkleBtn_Click);
			this.musteriDuzenleBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("musteriDuzenleBtn.Image");
			this.musteriDuzenleBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.musteriDuzenleBtn.Location = new global::System.Drawing.Point(330, 110);
			this.musteriDuzenleBtn.Name = "musteriDuzenleBtn";
			this.musteriDuzenleBtn.Size = new global::System.Drawing.Size(142, 32);
			this.musteriDuzenleBtn.TabIndex = 34;
			this.musteriDuzenleBtn.Text = "Müşteri Düzenle";
			this.musteriDuzenleBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.musteriDuzenleBtn.UseVisualStyleBackColor = true;
			this.musteriDuzenleBtn.Click += new global::System.EventHandler(this.musteriDuzenleBtn_Click);
			this.musteriSilBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("musteriSilBtn.Image");
			this.musteriSilBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.musteriSilBtn.Location = new global::System.Drawing.Point(330, 145);
			this.musteriSilBtn.Name = "musteriSilBtn";
			this.musteriSilBtn.Size = new global::System.Drawing.Size(142, 32);
			this.musteriSilBtn.TabIndex = 35;
			this.musteriSilBtn.Text = "Müşteri Sil";
			this.musteriSilBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.musteriSilBtn.UseVisualStyleBackColor = true;
			this.musteriSilBtn.Click += new global::System.EventHandler(this.musteriSilBtn_Click);
			this.groupBox2.Controls.Add(this.odemelerBtn);
			this.groupBox2.Controls.Add(this.musteriSilBtn);
			this.groupBox2.Controls.Add(this.musteriDuzenleBtn);
			this.groupBox2.Controls.Add(this.musteriEkleBtn);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Controls.Add(this.listMusteriler);
			this.groupBox2.Controls.Add(this.musteriAraBtn);
			this.groupBox2.Controls.Add(this.textAdi);
			this.groupBox2.Controls.Add(this.label2);
			this.groupBox2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.groupBox2.Location = new global::System.Drawing.Point(11, 6);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new global::System.Drawing.Size(483, 223);
			this.groupBox2.TabIndex = 36;
			this.groupBox2.TabStop = false;
			this.groupBox3.Controls.Add(this.abonelikEkleBtn);
			this.groupBox3.Controls.Add(this.plakaSilBtn);
			this.groupBox3.Controls.Add(this.plakaDuzenleBtn);
			this.groupBox3.Controls.Add(this.plakaEkleBtn);
			this.groupBox3.Controls.Add(this.plakaAraBtn);
			this.groupBox3.Controls.Add(this.textPlaka);
			this.groupBox3.Controls.Add(this.label4);
			this.groupBox3.Controls.Add(this.label5);
			this.groupBox3.Controls.Add(this.listPlakalar);
			this.groupBox3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.groupBox3.Location = new global::System.Drawing.Point(11, 228);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new global::System.Drawing.Size(483, 228);
			this.groupBox3.TabIndex = 37;
			this.groupBox3.TabStop = false;
			this.abonelikEkleBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("abonelikEkleBtn.Image");
			this.abonelikEkleBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.abonelikEkleBtn.Location = new global::System.Drawing.Point(330, 182);
			this.abonelikEkleBtn.Name = "abonelikEkleBtn";
			this.abonelikEkleBtn.Size = new global::System.Drawing.Size(142, 32);
			this.abonelikEkleBtn.TabIndex = 44;
			this.abonelikEkleBtn.Text = "Abonelik Uzat";
			this.abonelikEkleBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.abonelikEkleBtn.UseVisualStyleBackColor = true;
			this.abonelikEkleBtn.Click += new global::System.EventHandler(this.abonelikEkleBtn_Click);
			this.plakaSilBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("plakaSilBtn.Image");
			this.plakaSilBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.plakaSilBtn.Location = new global::System.Drawing.Point(330, 147);
			this.plakaSilBtn.Name = "plakaSilBtn";
			this.plakaSilBtn.Size = new global::System.Drawing.Size(142, 32);
			this.plakaSilBtn.TabIndex = 43;
			this.plakaSilBtn.Text = "Plaka Sil";
			this.plakaSilBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.plakaSilBtn.UseVisualStyleBackColor = true;
			this.plakaSilBtn.Click += new global::System.EventHandler(this.plakaSilBtn_Click);
			this.plakaDuzenleBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("plakaDuzenleBtn.Image");
			this.plakaDuzenleBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.plakaDuzenleBtn.Location = new global::System.Drawing.Point(330, 112);
			this.plakaDuzenleBtn.Name = "plakaDuzenleBtn";
			this.plakaDuzenleBtn.Size = new global::System.Drawing.Size(142, 32);
			this.plakaDuzenleBtn.TabIndex = 42;
			this.plakaDuzenleBtn.Text = "Plaka Düzenle";
			this.plakaDuzenleBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.plakaDuzenleBtn.UseVisualStyleBackColor = true;
			this.plakaDuzenleBtn.Click += new global::System.EventHandler(this.plakaDuzenleBtn_Click);
			this.plakaEkleBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("plakaEkleBtn.Image");
			this.plakaEkleBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.plakaEkleBtn.Location = new global::System.Drawing.Point(330, 77);
			this.plakaEkleBtn.Name = "plakaEkleBtn";
			this.plakaEkleBtn.Size = new global::System.Drawing.Size(142, 32);
			this.plakaEkleBtn.TabIndex = 41;
			this.plakaEkleBtn.Text = "Plaka Ekle";
			this.plakaEkleBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.plakaEkleBtn.UseVisualStyleBackColor = true;
			this.plakaEkleBtn.Click += new global::System.EventHandler(this.plakaEkleBtn_Click);
			this.plakaAraBtn.AutoSize = true;
			this.plakaAraBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("plakaAraBtn.Image");
			this.plakaAraBtn.Location = new global::System.Drawing.Point(291, 19);
			this.plakaAraBtn.Name = "plakaAraBtn";
			this.plakaAraBtn.Size = new global::System.Drawing.Size(113, 54);
			this.plakaAraBtn.TabIndex = 40;
			this.plakaAraBtn.Text = "Ara";
			this.plakaAraBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.plakaAraBtn.UseVisualStyleBackColor = true;
			this.plakaAraBtn.Click += new global::System.EventHandler(this.plakaAraBtn_Click);
			this.textPlaka.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.textPlaka.Location = new global::System.Drawing.Point(111, 20);
			this.textPlaka.Name = "textPlaka";
			this.textPlaka.Size = new global::System.Drawing.Size(174, 22);
			this.textPlaka.TabIndex = 39;
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label5.Location = new global::System.Drawing.Point(7, 23);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(52, 16);
			this.label5.TabIndex = 38;
			this.label5.Text = "Plaka:";
			this.odemelerBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("odemelerBtn.Image");
			this.odemelerBtn.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.odemelerBtn.Location = new global::System.Drawing.Point(330, 182);
			this.odemelerBtn.Name = "odemelerBtn";
			this.odemelerBtn.Size = new global::System.Drawing.Size(142, 32);
			this.odemelerBtn.TabIndex = 45;
			this.odemelerBtn.Text = "Ödemeler";
			this.odemelerBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.odemelerBtn.UseVisualStyleBackColor = true;
			this.odemelerBtn.Click += new global::System.EventHandler(this.odemelerBtn_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(502, 518);
			base.Controls.Add(this.groupBox3);
			base.Controls.Add(this.groupBox2);
			base.Controls.Add(this.login);
			base.Controls.Add(this.cancel);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Abonelik";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Abonelik";
			base.Load += new global::System.EventHandler(this.Abonelik_Load);
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			base.ResumeLayout(false);
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.Button login;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.TextBox textAdi;

		private global::System.Windows.Forms.Button musteriAraBtn;

		private global::System.Windows.Forms.ListView listMusteriler;

		private global::System.Windows.Forms.ColumnHeader columnHeader1;

		private global::System.Windows.Forms.ColumnHeader columnHeader2;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.Label label4;

		private global::System.Windows.Forms.ListView listPlakalar;

		private global::System.Windows.Forms.ColumnHeader columnHeader4;

		private global::System.Windows.Forms.ColumnHeader columnHeader5;

		private global::System.Windows.Forms.Button musteriEkleBtn;

		private global::System.Windows.Forms.Button musteriDuzenleBtn;

		private global::System.Windows.Forms.Button musteriSilBtn;

		private global::System.Windows.Forms.GroupBox groupBox2;

		private global::System.Windows.Forms.GroupBox groupBox3;

		private global::System.Windows.Forms.Button plakaAraBtn;

		private global::System.Windows.Forms.TextBox textPlaka;

		private global::System.Windows.Forms.Label label5;

		private global::System.Windows.Forms.ColumnHeader columnHeader3;

		private global::System.Windows.Forms.ColumnHeader columnHeader6;

		private global::System.Windows.Forms.Button plakaSilBtn;

		private global::System.Windows.Forms.Button plakaDuzenleBtn;

		private global::System.Windows.Forms.Button plakaEkleBtn;

		private global::System.Windows.Forms.Button abonelikEkleBtn;

		private global::System.Windows.Forms.Button odemelerBtn;
	}
}
