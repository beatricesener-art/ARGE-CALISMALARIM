using System;
using System.Runtime.InteropServices;

namespace ParkPay
{
	public class Protect
	{
		[DllImport("lc1.dll")]
		private static extern int LC_open(int vendor, int index, ref int handle);

		[DllImport("lc1.dll")]
		private static extern int LC_close(int handle);

		[DllImport("lc1.dll")]
		private static extern int LC_passwd(int handle, int type, byte[] passwd);

		[DllImport("lc1.dll")]
		private static extern int LC_read(int handle, int block, byte[] buffer);

		[DllImport("lc1.dll")]
		private static extern int LC_write(int handle, int block, byte[] buffer);

		[DllImport("lc1.dll")]
		private static extern int LC_encrypt(int handle, byte[] plaintext, byte[] ciphertext);

		[DllImport("lc1.dll")]
		private static extern int LC_decrypt(int handle, byte[] ciphertext, byte[] plaintext);

		[DllImport("lc1.dll")]
		private static extern int LC_set_passwd(int handle, int type, byte[] newpasswd, int retries);

		[DllImport("lc1.dll")]
		private static extern int LC_change_passwd(int handle, int type, byte[] oldpasswd, byte[] newpasswd);

		[DllImport("lc1.dll")]
		private static extern int LC_get_hardware_info(int handle, ref Protect.LC_hardware_info info);

		[DllImport("lc1.dll")]
		private static extern int LC_get_software_info(ref Protect.LC_software_info info);

		[DllImport("lc1.dll")]
		private static extern int LC_update(int handle, byte[] buffer);

		public int GetProtect()
		{
			int handle = 0;
			int num = Protect.LC_open(927352119, 0, ref handle);
			if ((long)num != (long)((ulong)Protect.LC_SUCCESS))
			{
				num = Protect.LC_open(1127433268, 0, ref handle);
				if ((long)num != (long)((ulong)Protect.LC_SUCCESS))
				{
					num = Protect.LC_open(1127433286, 0, ref handle);
					if ((long)num != (long)((ulong)Protect.LC_SUCCESS))
					{
						num = Protect.LC_open(1127433017, 0, ref handle);
						if ((long)num != (long)((ulong)Protect.LC_SUCCESS))
						{
							return 0;
						}
					}
				}
			}
			Protect.LC_close(handle);
			return 1;
		}

		public static uint LC_SUCCESS = 0U;

		public static uint LC_OPEN_DEVICE_FAILED = 1U;

		public static uint LC_FIND_DEVICE_FAILED = 2U;

		public static uint LC_INVALID_PARAMETER = 3U;

		public static uint LC_INVALID_BLOCK_NUMBER = 4U;

		public static uint LC_HARDWARE_COMMUNICATE_ERROR = 5U;

		public static uint LC_INVALID_PASSWORD = 6U;

		public static uint LC_ACCESS_DENIED = 7U;

		public static uint LC_ALREADY_OPENED = 8U;

		public static uint LC_ALLOCATE_MEMORY_FAILED = 9U;

		public static uint LC_INVALID_UPDATE_PACKAGE = 10U;

		public static uint LC_SYN_ERROR = 11U;

		public static uint LC_OTHER_ERROR = 12U;

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
		public struct LC_hardware_info
		{
			public int developerNumber;

			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
			public byte[] serialNumber;

			public int setDate;

			public int reservation;
		}

		public struct LC_software_info
		{
			public int version;

			public int reservation;
		}
	}
}
