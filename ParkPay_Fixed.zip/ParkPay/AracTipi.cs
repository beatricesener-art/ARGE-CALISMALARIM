using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PdfSharp.Drawing;
using PdfSharp.Drawing.BarCodes;
using PdfSharp.Pdf;

namespace ParkPay
{
	public partial class AracTipi : Form
	{
		public AracTipi()
		{
			this.InitializeComponent();
		}

		private void login_Click(object sender, EventArgs e)
		{
			string text = string.Concat(new string[]
			{
				"UPDATE db_araclar SET tipID=",
				this.tipID.ToString(),
				", vale_arac=1 WHERE plaka='",
				this.plate,
				"'"
			});
			MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
			MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
			mySqlDataReader.Close();
			base.Close();
		}

		private void AracTipi_Load(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				this.textPlate.Text = this.plate;
				this.enterDateTimeText.Text = this.enterDateTime;
				string text = "SELECT * FROM db_araclar WHERE plaka = '" + this.plate + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				int num = 0;
				int num2 = 0;
				if (mySqlDataReader.Read())
				{
					this.barkod = mySqlDataReader["barkod"].ToString();
					num = int.Parse(mySqlDataReader["tipID"].ToString());
				}
				mySqlDataReader.Close();
				text = "SELECT * FROM db_aractipleri ORDER by tipID ASC";
				MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
				int num3 = 0;
				try
				{
					while (mySqlDataReader2.Read())
					{
						this.aracTipleri.Items.Add(mySqlDataReader2["tipAdi"].ToString());
						this.tipIDArray[num3] = int.Parse(mySqlDataReader2["tipID"].ToString());
						if (this.tipIDArray[num3] == num)
						{
							num2 = num3;
						}
						num3++;
					}
				}
				catch (Exception)
				{
					MessageBox.Show("hata:100007");
				}
				mySqlDataReader2.Close();
				if (this.barkod.Length < 1)
				{
					string text2 = DateTime.Now.ToString("MMddHHmmss");
					text = string.Concat(new string[]
					{
						"UPDATE db_araclar SET  barkod='",
						text2,
						"'  WHERE plaka = '",
						this.textPlate.Text,
						"'"
					});
					MySqlCommand mySqlCommand3 = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader3 = mySqlCommand3.ExecuteReader();
					mySqlDataReader3.Close();
					this.barkod = text2;
				}
				this.tipID = this.tipIDArray[num2];
				this.aracTipleri.SelectedIndex = num2;
			}
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void aracTipleri_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.tipID = this.tipIDArray[this.aracTipleri.SelectedIndex];
		}

		private void printBtn_Click(object sender, EventArgs e)
		{
			int num = 200;
			int num2 = 0;
			int num3 = 30;
			int num4 = 600;
			PdfDocument pdfDocument = new PdfDocument();
			XFont xfont = new XFont("Verdana", (double)GlobalVar.FontSize1);
			XFont xfont2 = new XFont("Verdana", (double)GlobalVar.FontSize2);
			PdfPage pdfPage = pdfDocument.AddPage();
			XGraphics xgraphics = XGraphics.FromPdfPage(pdfPage);
			xgraphics.DrawBarCode(new Code3of9Standard
			{
				Text = this.barkod,
				Size = new XSize(550.0, 150.0),
				TextLocation = TextLocation.Above
			}, XBrushes.Black, new XPoint(1.0, 1.0));
			xgraphics.DrawLine(XPens.Black, 0, num - num3 + 3, num4, num - num3 + 3);
			xgraphics.DrawString(GlobalVar.Label1, xfont2, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			string text = GlobalVar.Label2;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			text = GlobalVar.Label3;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "PLAKA: " + this.plate;
			num += num3;
			xgraphics.DrawString(text, xfont2, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "ARAÇ GIRIS ZAMANI: " + this.enterDateTime;
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			xgraphics.DrawLine(XPens.Black, 0, num + 3, num4, num + 3);
			text = "*** VIP ARAÇ ***";
			num += num3;
			xgraphics.DrawString(text, xfont, XBrushes.Black, (double)num2, (double)num, XStringFormats.Default);
			pdfDocument.Save("payment_tempfile.pdf");
			Thread.Sleep(1000);
			Process.Start(new ProcessStartInfo
			{
				UseShellExecute = true,
				Verb = "print",
				WindowStyle = ProcessWindowStyle.Hidden,
				FileName = "payment_tempfile.pdf"
			});
		}

		public string plate;

		public string barkod;

		public string enterDateTime;

		public int tipID;

		public int[] tipIDArray = new int[50];
	}
}
