using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class UsrLogin : Form
	{
		public UsrLogin()
		{
			this.InitializeComponent();
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void UsrLogin_Load(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				this.pointid.Text = GlobalVar.pointID.ToString();
				string text = "SELECT * FROM db_super_users WHERE yetki = 4";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				while (mySqlDataReader.Read())
				{
					this.userList.Items.Add(mySqlDataReader["username"].ToString());
				}
				mySqlDataReader.Close();
				text = "SELECT * FROM db_calisma_saatlari WHERE end_time IS NULL AND pointID=" + GlobalVar.pointID.ToString();
				MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
				string text2 = "";
				if (mySqlDataReader2.Read())
				{
					text2 = mySqlDataReader2["user_name"].ToString();
				}
				mySqlDataReader2.Close();
				if (text2.Length > 0)
				{
					this.userList.Text = text2;
					this.isExistUser = true;
				}
				else
				{
					this.userList.Enabled = true;
					this.newLogin = true;
					this.isExistUser = false;
				}
			}
		}

		private void login_Click(object sender, EventArgs e)
		{
			if (GlobalVar.DBConnectionStatus)
			{
				if (this.checkAdmin.Checked)
				{
					if (this.textadminPass.Text == GlobalVar.adminPassword)
					{
						GlobalVar.securityLevel = 1;
						GlobalVar.activeUser = "admin";
						GlobalVar.activeName = "Sistem Admin";
						GlobalVar.activeId = 1;
						this.loginOK = true;
						base.Close();
					}
					else
					{
						MessageBox.Show("Şifre Hatalı!", "Bilgi");
					}
				}
				else
				{
					string text = string.Concat(new string[]
					{
						"SELECT * FROM db_super_users WHERE username ='",
						this.userList.Text,
						"' AND password='",
						this.password.Text,
						"'"
					});
					MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
					MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
					if (mySqlDataReader.Read())
					{
						GlobalVar.activeUser = mySqlDataReader["username"].ToString();
						GlobalVar.activeName = mySqlDataReader["ad"].ToString() + " " + mySqlDataReader["soyad"].ToString();
						GlobalVar.activeId = int.Parse(mySqlDataReader["id"].ToString());
						GlobalVar.securityLevel = 2;
						this.loginOK = true;
					}
					else if (!this.isExistUser)
					{
						GlobalVar.activeId = 0;
						this.loginOK = false;
					}
					mySqlDataReader.Close();
					DateTime now = DateTime.Now;
					string format = "yyyy-MM-dd HH:mm:ss";
					string text2 = now.ToString(format);
					if (GlobalVar.activeId > 0)
					{
						if (this.newLogin)
						{
							text = string.Concat(new object[]
							{
								"INSERT INTO db_calisma_saatlari (`id` ,`user_id` ,`user_name` ,`start_time` ,`end_time`, `pointID` ) VALUES (NULL , ",
								GlobalVar.activeId,
								",'",
								GlobalVar.activeUser,
								"','",
								text2,
								"', NULL , ",
								GlobalVar.pointID,
								")"
							});
							MySqlCommand mySqlCommand2 = new MySqlCommand(text, GlobalVar.conn);
							MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
							mySqlDataReader2.Close();
						}
						base.Close();
					}
					else
					{
						MessageBox.Show("Şifre Hatalı!", "Bilgi");
					}
				}
			}
		}

		private void serverSettings_Click(object sender, EventArgs e)
		{
			DBSettings dbsettings = new DBSettings();
			dbsettings.ShowDialog();
			Main main = (Main)base.Owner;
			main.WriteDbSettings();
		}

		private void checkAdmin_CheckedChanged(object sender, EventArgs e)
		{
			if (this.checkAdmin.Checked)
			{
				this.textadminPass.Enabled = true;
			}
			else
			{
				this.textadminPass.Enabled = false;
			}
		}

		public bool loginOK;

		public bool newLogin;

		public bool isExistUser;
	}
}
