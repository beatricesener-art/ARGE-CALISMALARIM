namespace ParkPay
{
	public partial class Plakasizlar : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.Plakasizlar));
			this.picturePlakasiz = new global::System.Windows.Forms.PictureBox();
			this.listView1 = new global::System.Windows.Forms.ListView();
			this.columnHeader1 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new global::System.Windows.Forms.ColumnHeader();
			this.textPlate2 = new global::System.Windows.Forms.TextBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.plakaSilBtn = new global::System.Windows.Forms.Button();
			this.plakaDuzenleBtn = new global::System.Windows.Forms.Button();
			this.login = new global::System.Windows.Forms.Button();
			this.cancel = new global::System.Windows.Forms.Button();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			((global::System.ComponentModel.ISupportInitialize)this.picturePlakasiz).BeginInit();
			this.groupBox1.SuspendLayout();
			base.SuspendLayout();
			this.picturePlakasiz.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			componentResourceManager.ApplyResources(this.picturePlakasiz, "picturePlakasiz");
			this.picturePlakasiz.Name = "picturePlakasiz";
			this.picturePlakasiz.TabStop = false;
			this.listView1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.columnHeader1,
				this.columnHeader2,
				this.columnHeader3
			});
			componentResourceManager.ApplyResources(this.listView1, "listView1");
			this.listView1.FullRowSelect = true;
			this.listView1.HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.listView1.HideSelection = false;
			this.listView1.Name = "listView1";
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = global::System.Windows.Forms.View.Details;
			this.listView1.Click += new global::System.EventHandler(this.listView1_Click);
			componentResourceManager.ApplyResources(this.columnHeader1, "columnHeader1");
			componentResourceManager.ApplyResources(this.columnHeader2, "columnHeader2");
			componentResourceManager.ApplyResources(this.columnHeader3, "columnHeader3");
			componentResourceManager.ApplyResources(this.textPlate2, "textPlate2");
			this.textPlate2.Name = "textPlate2";
			componentResourceManager.ApplyResources(this.label3, "label3");
			this.label3.Name = "label3";
			componentResourceManager.ApplyResources(this.plakaSilBtn, "plakaSilBtn");
			this.plakaSilBtn.Name = "plakaSilBtn";
			this.plakaSilBtn.UseVisualStyleBackColor = true;
			this.plakaSilBtn.Click += new global::System.EventHandler(this.plakaSilBtn_Click);
			componentResourceManager.ApplyResources(this.plakaDuzenleBtn, "plakaDuzenleBtn");
			this.plakaDuzenleBtn.Name = "plakaDuzenleBtn";
			this.plakaDuzenleBtn.UseVisualStyleBackColor = true;
			this.plakaDuzenleBtn.Click += new global::System.EventHandler(this.plakaDuzenleBtn_Click);
			componentResourceManager.ApplyResources(this.login, "login");
			this.login.Name = "login";
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			componentResourceManager.ApplyResources(this.cancel, "cancel");
			this.cancel.Name = "cancel";
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.groupBox1.Controls.Add(this.picturePlakasiz);
			this.groupBox1.Controls.Add(this.listView1);
			this.groupBox1.Controls.Add(this.textPlate2);
			this.groupBox1.Controls.Add(this.plakaSilBtn);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.plakaDuzenleBtn);
			componentResourceManager.ApplyResources(this.groupBox1, "groupBox1");
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.TabStop = false;
			componentResourceManager.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.groupBox1);
			base.Controls.Add(this.login);
			base.Controls.Add(this.cancel);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Plakasizlar";
			base.ShowIcon = false;
			base.TopMost = true;
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.Plakasizlar_FormClosing);
			base.Load += new global::System.EventHandler(this.Plakasizlar_Load);
			((global::System.ComponentModel.ISupportInitialize)this.picturePlakasiz).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			base.ResumeLayout(false);
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.PictureBox picturePlakasiz;

		private global::System.Windows.Forms.ListView listView1;

		private global::System.Windows.Forms.ColumnHeader columnHeader1;

		private global::System.Windows.Forms.ColumnHeader columnHeader2;

		private global::System.Windows.Forms.ColumnHeader columnHeader3;

		private global::System.Windows.Forms.TextBox textPlate2;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.Button plakaSilBtn;

		private global::System.Windows.Forms.Button plakaDuzenleBtn;

		private global::System.Windows.Forms.Button login;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.GroupBox groupBox1;
	}
}
