using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ParkPay
{
	public partial class Plakasizlar : Form
	{
		public Plakasizlar()
		{
			this.InitializeComponent();
		}

		private void Plakasizlar_Load(object sender, EventArgs e)
		{
			this.ShowPlakasizList();
		}

		private void ShowEnterExitPic(string imgpath)
		{
			if (!(imgpath == ""))
			{
				int num = imgpath.IndexOf("_");
				string str = string.Concat(new string[]
				{
					GlobalVar.GlobalPath,
					imgpath.Substring(num + 1, 4),
					"\\",
					imgpath.Substring(num + 5, 2),
					"\\",
					imgpath.Substring(num + 7, 2),
					"\\"
				});
				Image image = Image.FromFile(str + imgpath);
				this.picturePlakasiz.Image = image;
				this.picturePlakasiz.SizeMode = PictureBoxSizeMode.StretchImage;
			}
		}

		private void ShowPlakasizList()
		{
			if (GlobalVar.DBConnectionStatus)
			{
				DateTime now = DateTime.Now;
				DateTime dateTime = now.AddDays(-1.0);
				string format = "yyyy-MM-dd HH:mm:ss";
				string text = dateTime.ToString(format);
				string text2 = now.ToString(format);
				string text3 = string.Concat(new string[]
				{
					"SELECT * FROM db_loglar WHERE aracKonum = 'i' AND kayittarihi BETWEEN '",
					text,
					"' AND '",
					text2,
					"' AND plaka LIKE '%PLAKA%' ORDER by id DESC LIMIT 10"
				});
				MySqlCommand mySqlCommand = new MySqlCommand(text3, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				int num = 0;
				while (mySqlDataReader.Read())
				{
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = mySqlDataReader["plaka"].ToString();
					this.enterDateTimeList[num] = mySqlDataReader["kayittarihi"].ToString();
					listViewItem.SubItems.Add(this.enterDateTimeList[num]);
					listViewItem.SubItems.Add(mySqlDataReader["kameraid"].ToString());
					this.listView1.Items.Add(listViewItem);
					this.resimyoluArray[num] = mySqlDataReader["resimyolu"].ToString();
					num++;
				}
				mySqlDataReader.Close();
				if (num > 0)
				{
					this.listView1.Items[0].Selected = true;
					this.ShowEnterExitPic(this.resimyoluArray[0]);
				}
			}
		}

		private void login_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void cancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void Plakasizlar_FormClosing(object sender, FormClosingEventArgs e)
		{
			Main main = (Main)base.Owner;
			main.PlakasizActive = false;
		}

		private void listView1_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count > 0)
			{
				int num = this.listView1.SelectedIndices[0];
				if (num >= 0)
				{
					this.plate = this.listView1.Items[num].Text;
					this.ShowEnterExitPic(this.resimyoluArray[num]);
					this.degisimData = this.listView1.Items[num].SubItems[1].Text;
				}
			}
		}

		private void PlakayiSil(string silPlaka)
		{
			if (this.listView1.SelectedIndices.Count <= 0)
			{
				MessageBox.Show("Seçili Plaka Yok!");
			}
			else if (GlobalVar.DBConnectionStatus)
			{
				string text = "DELETE FROM db_araclar WHERE plaka = '" + silPlaka + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				Main main = (Main)base.Owner;
				main.YoneticiLogEkle("Araclardan 3 Plaka: " + silPlaka + " Silindi! ");
			}
		}

		private void plakaDuzenleBtn_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count <= 0 || this.plate == "")
			{
				MessageBox.Show("Seçili Plaka Yok!");
			}
			else if (this.textPlate2.Text.Length < 1)
			{
				MessageBox.Show("Plaka Giriniz...");
			}
			else if (GlobalVar.DBConnectionStatus)
			{
				DateTime now = DateTime.Now;
				string format = "yyyy-MM-dd HH:mm:ss";
				int num = this.listView1.SelectedIndices[0];
				string text = this.enterDateTimeList[num];
				text = DateTime.Parse(text).ToString(format);
				this.textPlate2.Text = this.textPlate2.Text.ToUpper();
				string text2 = "SELECT * FROM db_araclar WHERE plaka = '" + this.textPlate2.Text + "' LIMIT 1";
				MySqlCommand mySqlCommand = new MySqlCommand(text2, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				bool flag = false;
				if (mySqlDataReader.Read())
				{
					flag = true;
				}
				mySqlDataReader.Close();
				if (flag)
				{
					this.PlakayiSil(this.plate);
					text2 = string.Concat(new string[]
					{
						"UPDATE db_araclar SET aracKonum='i'  , sondegisim='",
						text,
						"' , tipID=1 WHERE plaka='",
						this.textPlate2.Text,
						"'"
					});
					MySqlCommand mySqlCommand2 = new MySqlCommand(text2, GlobalVar.conn);
					MySqlDataReader mySqlDataReader2 = mySqlCommand2.ExecuteReader();
					mySqlDataReader2.Close();
				}
				else
				{
					text2 = string.Concat(new string[]
					{
						"UPDATE db_araclar SET plaka='",
						this.textPlate2.Text,
						"' , aracKonum='i' WHERE plaka='",
						this.plate,
						"'"
					});
					MySqlCommand mySqlCommand3 = new MySqlCommand(text2, GlobalVar.conn);
					MySqlDataReader mySqlDataReader3 = mySqlCommand3.ExecuteReader();
					mySqlDataReader3.Close();
				}
				text2 = string.Concat(new string[]
				{
					"UPDATE db_loglar SET plaka='",
					this.textPlate2.Text,
					"' WHERE plaka='",
					this.plate,
					"'"
				});
				MySqlCommand mySqlCommand4 = new MySqlCommand(text2, GlobalVar.conn);
				MySqlDataReader mySqlDataReader4 = mySqlCommand4.ExecuteReader();
				mySqlDataReader4.Close();
				this.plate = "";
				this.listView1.Items.Clear();
				this.ShowPlakasizList();
			}
		}

		private void plakaSilBtn_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedIndices.Count <= 0 || this.plate == "")
			{
				MessageBox.Show("Seçili Plaka Yok!");
			}
			else if (GlobalVar.DBConnectionStatus)
			{
				this.PlakayiSil(this.plate);
				string text = "DELETE FROM db_loglar WHERE plaka = '" + this.plate + "'";
				MySqlCommand mySqlCommand = new MySqlCommand(text, GlobalVar.conn);
				MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
				mySqlDataReader.Close();
				Main main = (Main)base.Owner;
				main.YoneticiLogEkle("Loglardan Plaka: " + this.plate + " Silindi! ");
				int num = this.listView1.SelectedIndices[0];
				this.listView1.Items.Clear();
				this.ShowPlakasizList();
				this.plate = "";
			}
		}

		public string[] resimyoluArray = new string[12];

		public string[] enterDateTimeList = new string[12];

		public string plate = "";

		public string degisimData = "";
	}
}
