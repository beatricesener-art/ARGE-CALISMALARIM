namespace ParkPay
{
	public partial class BarkodPayment : global::System.Windows.Forms.Form
	{
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ParkPay.BarkodPayment));
			this.camList = new global::System.Windows.Forms.ComboBox();
			this.label6 = new global::System.Windows.Forms.Label();
			this.login = new global::System.Windows.Forms.Button();
			this.payStatusText = new global::System.Windows.Forms.Label();
			this.printBtn = new global::System.Windows.Forms.Button();
			this.cancel = new global::System.Windows.Forms.Button();
			this.textDetails = new global::System.Windows.Forms.TextBox();
			this.InfoText = new global::System.Windows.Forms.Label();
			this.textPayment = new global::System.Windows.Forms.TextBox();
			this.textMinutes = new global::System.Windows.Forms.TextBox();
			this.aracTipleri = new global::System.Windows.Forms.ComboBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.textMinEk = new global::System.Windows.Forms.TextBox();
			this.label7 = new global::System.Windows.Forms.Label();
			this.paymentCheck = new global::System.Windows.Forms.CheckBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.label4 = new global::System.Windows.Forms.Label();
			this.label3 = new global::System.Windows.Forms.Label();
			this.enterDateTimeText = new global::System.Windows.Forms.TextBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.textBarkod = new global::System.Windows.Forms.TextBox();
			this.label8 = new global::System.Windows.Forms.Label();
			this.plakaAraBtn = new global::System.Windows.Forms.Button();
			this.lineShape1 = new global::Microsoft.VisualBasic.PowerPacks.LineShape();
			this.shapeContainer1 = new global::Microsoft.VisualBasic.PowerPacks.ShapeContainer();
			this.textPlate = new global::System.Windows.Forms.TextBox();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.groupBox1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			base.SuspendLayout();
			this.camList.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.camList.Font = new global::System.Drawing.Font("Arial", 14.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.camList.FormattingEnabled = true;
			this.camList.Location = new global::System.Drawing.Point(18, 307);
			this.camList.Name = "camList";
			this.camList.Size = new global::System.Drawing.Size(211, 30);
			this.camList.TabIndex = 21;
			this.camList.Visible = false;
			this.label6.AutoSize = true;
			this.label6.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label6.Location = new global::System.Drawing.Point(16, 286);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(117, 18);
			this.label6.TabIndex = 20;
			this.label6.Text = "Çıkış Kam No:";
			this.label6.Visible = false;
			this.login.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.login.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("login.Image");
			this.login.Location = new global::System.Drawing.Point(131, 548);
			this.login.Name = "login";
			this.login.Size = new global::System.Drawing.Size(113, 32);
			this.login.TabIndex = 22;
			this.login.Text = "Tamam";
			this.login.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.login.UseVisualStyleBackColor = true;
			this.login.Click += new global::System.EventHandler(this.login_Click);
			this.payStatusText.AutoSize = true;
			this.payStatusText.ForeColor = global::System.Drawing.Color.Red;
			this.payStatusText.Location = new global::System.Drawing.Point(149, 25);
			this.payStatusText.Name = "payStatusText";
			this.payStatusText.Size = new global::System.Drawing.Size(0, 18);
			this.payStatusText.TabIndex = 19;
			this.printBtn.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.printBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("printBtn.Image");
			this.printBtn.Location = new global::System.Drawing.Point(235, 289);
			this.printBtn.Name = "printBtn";
			this.printBtn.Size = new global::System.Drawing.Size(98, 32);
			this.printBtn.TabIndex = 18;
			this.printBtn.Text = "Yazdır";
			this.printBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.printBtn.UseVisualStyleBackColor = true;
			this.printBtn.Click += new global::System.EventHandler(this.printBtn_Click);
			this.cancel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.cancel.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cancel.Image");
			this.cancel.Location = new global::System.Drawing.Point(250, 548);
			this.cancel.Name = "cancel";
			this.cancel.Size = new global::System.Drawing.Size(113, 32);
			this.cancel.TabIndex = 23;
			this.cancel.Text = "İptal";
			this.cancel.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cancel.UseVisualStyleBackColor = true;
			this.cancel.Click += new global::System.EventHandler(this.cancel_Click);
			this.textDetails.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textDetails.Location = new global::System.Drawing.Point(18, 192);
			this.textDetails.Multiline = true;
			this.textDetails.Name = "textDetails";
			this.textDetails.Size = new global::System.Drawing.Size(316, 91);
			this.textDetails.TabIndex = 12;
			this.InfoText.AutoSize = true;
			this.InfoText.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.InfoText.ForeColor = global::System.Drawing.Color.Red;
			this.InfoText.Location = new global::System.Drawing.Point(27, 492);
			this.InfoText.Name = "InfoText";
			this.InfoText.Size = new global::System.Drawing.Size(0, 13);
			this.InfoText.TabIndex = 24;
			this.textPayment.Enabled = false;
			this.textPayment.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPayment.Location = new global::System.Drawing.Point(149, 143);
			this.textPayment.Name = "textPayment";
			this.textPayment.ReadOnly = true;
			this.textPayment.Size = new global::System.Drawing.Size(184, 24);
			this.textPayment.TabIndex = 11;
			this.textMinutes.Enabled = false;
			this.textMinutes.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textMinutes.Location = new global::System.Drawing.Point(149, 114);
			this.textMinutes.Name = "textMinutes";
			this.textMinutes.ReadOnly = true;
			this.textMinutes.Size = new global::System.Drawing.Size(80, 24);
			this.textMinutes.TabIndex = 10;
			this.aracTipleri.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.aracTipleri.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.aracTipleri.FormattingEnabled = true;
			this.aracTipleri.Location = new global::System.Drawing.Point(149, 53);
			this.aracTipleri.Name = "aracTipleri";
			this.aracTipleri.Size = new global::System.Drawing.Size(184, 26);
			this.aracTipleri.TabIndex = 2;
			this.aracTipleri.SelectedIndexChanged += new global::System.EventHandler(this.aracTipleri_SelectedIndexChanged);
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label1.Location = new global::System.Drawing.Point(15, 56);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(74, 18);
			this.label1.TabIndex = 0;
			this.label1.Text = "Araç Tipi";
			this.groupBox1.Controls.Add(this.textMinEk);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.camList);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.payStatusText);
			this.groupBox1.Controls.Add(this.printBtn);
			this.groupBox1.Controls.Add(this.textDetails);
			this.groupBox1.Controls.Add(this.textPayment);
			this.groupBox1.Controls.Add(this.textMinutes);
			this.groupBox1.Controls.Add(this.aracTipleri);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.paymentCheck);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.enterDateTimeText);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.groupBox1.Location = new global::System.Drawing.Point(13, 186);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(350, 344);
			this.groupBox1.TabIndex = 21;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Araç Detaylar";
			this.textMinEk.Enabled = false;
			this.textMinEk.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textMinEk.Location = new global::System.Drawing.Point(274, 114);
			this.textMinEk.Name = "textMinEk";
			this.textMinEk.ReadOnly = true;
			this.textMinEk.Size = new global::System.Drawing.Size(59, 24);
			this.textMinEk.TabIndex = 25;
			this.label7.AutoSize = true;
			this.label7.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label7.Location = new global::System.Drawing.Point(240, 117);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(28, 18);
			this.label7.TabIndex = 24;
			this.label7.Text = "Ek";
			this.paymentCheck.AutoSize = true;
			this.paymentCheck.Checked = true;
			this.paymentCheck.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.paymentCheck.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.paymentCheck.Location = new global::System.Drawing.Point(19, 25);
			this.paymentCheck.Name = "paymentCheck";
			this.paymentCheck.Size = new global::System.Drawing.Size(123, 22);
			this.paymentCheck.TabIndex = 9;
			this.paymentCheck.Text = "Ödeme Yaptı";
			this.paymentCheck.UseVisualStyleBackColor = true;
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label5.Location = new global::System.Drawing.Point(16, 169);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(76, 18);
			this.label5.TabIndex = 8;
			this.label5.Text = "Açıklama";
			this.label4.AutoSize = true;
			this.label4.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label4.Location = new global::System.Drawing.Point(16, 146);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(85, 18);
			this.label4.TabIndex = 7;
			this.label4.Text = "Ücret (TL)";
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label3.Location = new global::System.Drawing.Point(16, 117);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(78, 18);
			this.label3.TabIndex = 6;
			this.label3.Text = "Süre (dk)";
			this.enterDateTimeText.Enabled = false;
			this.enterDateTimeText.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.enterDateTimeText.Location = new global::System.Drawing.Point(149, 84);
			this.enterDateTimeText.Name = "enterDateTimeText";
			this.enterDateTimeText.ReadOnly = true;
			this.enterDateTimeText.Size = new global::System.Drawing.Size(184, 24);
			this.enterDateTimeText.TabIndex = 1;
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label2.Location = new global::System.Drawing.Point(14, 86);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(103, 18);
			this.label2.TabIndex = 5;
			this.label2.Text = "Araç Giriş Z.";
			this.textBarkod.Font = new global::System.Drawing.Font("Arial", 21.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textBarkod.Location = new global::System.Drawing.Point(12, 28);
			this.textBarkod.Name = "textBarkod";
			this.textBarkod.Size = new global::System.Drawing.Size(286, 41);
			this.textBarkod.TabIndex = 20;
			this.textBarkod.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.textBarkod_KeyDown);
			this.label8.AutoSize = true;
			this.label8.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.label8.Location = new global::System.Drawing.Point(12, 6);
			this.label8.Name = "label8";
			this.label8.Size = new global::System.Drawing.Size(62, 18);
			this.label8.TabIndex = 25;
			this.label8.Text = "Barkod";
			this.plakaAraBtn.AutoSize = true;
			this.plakaAraBtn.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.plakaAraBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("plakaAraBtn.Image");
			this.plakaAraBtn.Location = new global::System.Drawing.Point(300, 6);
			this.plakaAraBtn.Name = "plakaAraBtn";
			this.plakaAraBtn.Size = new global::System.Drawing.Size(63, 63);
			this.plakaAraBtn.TabIndex = 29;
			this.plakaAraBtn.TextImageRelation = global::System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.plakaAraBtn.UseVisualStyleBackColor = true;
			this.plakaAraBtn.Click += new global::System.EventHandler(this.plakaAraBtn_Click);
			this.lineShape1.BorderColor = global::System.Drawing.SystemColors.ControlDark;
			this.lineShape1.Name = "lineShape1";
			this.lineShape1.X1 = 13;
			this.lineShape1.X2 = 363;
			this.lineShape1.Y1 = 538;
			this.lineShape1.Y2 = 538;
			this.shapeContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.shapeContainer1.Margin = new global::System.Windows.Forms.Padding(0);
			this.shapeContainer1.Name = "shapeContainer1";
			this.shapeContainer1.Shapes.AddRange(new global::Microsoft.VisualBasic.PowerPacks.Shape[]
			{
				this.lineShape1
			});
			this.shapeContainer1.Size = new global::System.Drawing.Size(373, 589);
			this.shapeContainer1.TabIndex = 30;
			this.shapeContainer1.TabStop = false;
			this.textPlate.Enabled = false;
			this.textPlate.Font = new global::System.Drawing.Font("Arial", 36f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 162);
			this.textPlate.Location = new global::System.Drawing.Point(76, 96);
			this.textPlate.Name = "textPlate";
			this.textPlate.ReadOnly = true;
			this.textPlate.Size = new global::System.Drawing.Size(274, 63);
			this.textPlate.TabIndex = 32;
			this.pictureBox3.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(11, 75);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(352, 103);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 31;
			this.pictureBox3.TabStop = false;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(373, 589);
			base.Controls.Add(this.textPlate);
			base.Controls.Add(this.pictureBox3);
			base.Controls.Add(this.plakaAraBtn);
			base.Controls.Add(this.label8);
			base.Controls.Add(this.login);
			base.Controls.Add(this.cancel);
			base.Controls.Add(this.InfoText);
			base.Controls.Add(this.groupBox1);
			base.Controls.Add(this.textBarkod);
			base.Controls.Add(this.shapeContainer1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "BarkodPayment";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Barkod İle Ödeme";
			base.TopMost = true;
			base.Load += new global::System.EventHandler(this.BarkodPayment_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private global::System.ComponentModel.IContainer components;

		private global::System.Windows.Forms.ComboBox camList;

		private global::System.Windows.Forms.Label label6;

		private global::System.Windows.Forms.Button login;

		private global::System.Windows.Forms.Label payStatusText;

		private global::System.Windows.Forms.Button printBtn;

		private global::System.Windows.Forms.Button cancel;

		private global::System.Windows.Forms.TextBox textDetails;

		private global::System.Windows.Forms.Label InfoText;

		private global::System.Windows.Forms.TextBox textPayment;

		private global::System.Windows.Forms.TextBox textMinutes;

		private global::System.Windows.Forms.ComboBox aracTipleri;

		private global::System.Windows.Forms.Label label1;

		private global::System.Windows.Forms.GroupBox groupBox1;

		private global::System.Windows.Forms.CheckBox paymentCheck;

		private global::System.Windows.Forms.Label label5;

		private global::System.Windows.Forms.Label label4;

		private global::System.Windows.Forms.Label label3;

		private global::System.Windows.Forms.TextBox enterDateTimeText;

		private global::System.Windows.Forms.Label label2;

		private global::System.Windows.Forms.TextBox textBarkod;

		private global::System.Windows.Forms.Label label8;

		private global::System.Windows.Forms.Button plakaAraBtn;

		private global::Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;

		private global::Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;

		private global::System.Windows.Forms.TextBox textPlate;

		private global::System.Windows.Forms.PictureBox pictureBox3;

		private global::System.Windows.Forms.TextBox textMinEk;

		private global::System.Windows.Forms.Label label7;
	}
}
