using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ParkPay
{
	public partial class WebTarayici : Form
	{
		public WebTarayici()
		{
			this.InitializeComponent();
		}

		private void WebTarayici_Load(object sender, EventArgs e)
		{
			this.webBrowser1.Navigate(GlobalVar.WebURL);
		}
	}
}
